
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 90 10 00       	mov    $0x109000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc d0 b5 10 80       	mov    $0x8010b5d0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 8b 2a 10 80       	mov    $0x80102a8b,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax

80100034 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100034:	55                   	push   %ebp
80100035:	89 e5                	mov    %esp,%ebp
80100037:	53                   	push   %ebx
80100038:	83 ec 0c             	sub    $0xc,%esp
  struct buf *b;

  initlock(&bcache.lock, "bcache");
8010003b:	68 00 68 10 80       	push   $0x80106800
80100040:	68 e0 b5 10 80       	push   $0x8010b5e0
80100045:	e8 c0 3d 00 00       	call   80103e0a <initlock>

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
8010004a:	c7 05 2c fd 10 80 dc 	movl   $0x8010fcdc,0x8010fd2c
80100051:	fc 10 80 
  bcache.head.next = &bcache.head;
80100054:	c7 05 30 fd 10 80 dc 	movl   $0x8010fcdc,0x8010fd30
8010005b:	fc 10 80 
8010005e:	83 c4 10             	add    $0x10,%esp
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100061:	bb 14 b6 10 80       	mov    $0x8010b614,%ebx
    b->next = bcache.head.next;
80100066:	a1 30 fd 10 80       	mov    0x8010fd30,%eax
8010006b:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
8010006e:	c7 43 50 dc fc 10 80 	movl   $0x8010fcdc,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100075:	83 ec 08             	sub    $0x8,%esp
80100078:	68 07 68 10 80       	push   $0x80106807
8010007d:	8d 43 0c             	lea    0xc(%ebx),%eax
80100080:	50                   	push   %eax
80100081:	e8 7a 3c 00 00       	call   80103d00 <initsleeplock>
    bcache.head.next->prev = b;
80100086:	a1 30 fd 10 80       	mov    0x8010fd30,%eax
8010008b:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
8010008e:	89 1d 30 fd 10 80    	mov    %ebx,0x8010fd30
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100094:	81 c3 5c 02 00 00    	add    $0x25c,%ebx
8010009a:	83 c4 10             	add    $0x10,%esp
8010009d:	81 fb dc fc 10 80    	cmp    $0x8010fcdc,%ebx
801000a3:	72 c1                	jb     80100066 <binit+0x32>
  }
}
801000a5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000a8:	c9                   	leave  
801000a9:	c3                   	ret    

801000aa <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000aa:	55                   	push   %ebp
801000ab:	89 e5                	mov    %esp,%ebp
801000ad:	57                   	push   %edi
801000ae:	56                   	push   %esi
801000af:	53                   	push   %ebx
801000b0:	83 ec 18             	sub    $0x18,%esp
801000b3:	8b 75 08             	mov    0x8(%ebp),%esi
801000b6:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000b9:	68 e0 b5 10 80       	push   $0x8010b5e0
801000be:	e8 8f 3e 00 00       	call   80103f52 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000c3:	8b 1d 30 fd 10 80    	mov    0x8010fd30,%ebx
801000c9:	83 c4 10             	add    $0x10,%esp
801000cc:	81 fb dc fc 10 80    	cmp    $0x8010fcdc,%ebx
801000d2:	75 26                	jne    801000fa <bread+0x50>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
801000d4:	8b 1d 2c fd 10 80    	mov    0x8010fd2c,%ebx
801000da:	81 fb dc fc 10 80    	cmp    $0x8010fcdc,%ebx
801000e0:	75 4e                	jne    80100130 <bread+0x86>
  panic("bget: no buffers");
801000e2:	83 ec 0c             	sub    $0xc,%esp
801000e5:	68 0e 68 10 80       	push   $0x8010680e
801000ea:	e8 55 02 00 00       	call   80100344 <panic>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000ef:	8b 5b 54             	mov    0x54(%ebx),%ebx
801000f2:	81 fb dc fc 10 80    	cmp    $0x8010fcdc,%ebx
801000f8:	74 da                	je     801000d4 <bread+0x2a>
    if(b->dev == dev && b->blockno == blockno){
801000fa:	3b 73 04             	cmp    0x4(%ebx),%esi
801000fd:	75 f0                	jne    801000ef <bread+0x45>
801000ff:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100102:	75 eb                	jne    801000ef <bread+0x45>
      b->refcnt++;
80100104:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100108:	83 ec 0c             	sub    $0xc,%esp
8010010b:	68 e0 b5 10 80       	push   $0x8010b5e0
80100110:	e8 a4 3e 00 00       	call   80103fb9 <release>
      acquiresleep(&b->lock);
80100115:	8d 43 0c             	lea    0xc(%ebx),%eax
80100118:	89 04 24             	mov    %eax,(%esp)
8010011b:	e8 13 3c 00 00       	call   80103d33 <acquiresleep>
80100120:	83 c4 10             	add    $0x10,%esp
80100123:	eb 44                	jmp    80100169 <bread+0xbf>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100125:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100128:	81 fb dc fc 10 80    	cmp    $0x8010fcdc,%ebx
8010012e:	74 b2                	je     801000e2 <bread+0x38>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
80100130:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
80100134:	75 ef                	jne    80100125 <bread+0x7b>
80100136:	f6 03 04             	testb  $0x4,(%ebx)
80100139:	75 ea                	jne    80100125 <bread+0x7b>
      b->dev = dev;
8010013b:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010013e:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
80100141:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100147:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010014e:	83 ec 0c             	sub    $0xc,%esp
80100151:	68 e0 b5 10 80       	push   $0x8010b5e0
80100156:	e8 5e 3e 00 00       	call   80103fb9 <release>
      acquiresleep(&b->lock);
8010015b:	8d 43 0c             	lea    0xc(%ebx),%eax
8010015e:	89 04 24             	mov    %eax,(%esp)
80100161:	e8 cd 3b 00 00       	call   80103d33 <acquiresleep>
80100166:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100169:	f6 03 02             	testb  $0x2,(%ebx)
8010016c:	74 0a                	je     80100178 <bread+0xce>
    iderw(b);
  }
  return b;
}
8010016e:	89 d8                	mov    %ebx,%eax
80100170:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100173:	5b                   	pop    %ebx
80100174:	5e                   	pop    %esi
80100175:	5f                   	pop    %edi
80100176:	5d                   	pop    %ebp
80100177:	c3                   	ret    
    iderw(b);
80100178:	83 ec 0c             	sub    $0xc,%esp
8010017b:	53                   	push   %ebx
8010017c:	e8 0e 1d 00 00       	call   80101e8f <iderw>
80100181:	83 c4 10             	add    $0x10,%esp
  return b;
80100184:	eb e8                	jmp    8010016e <bread+0xc4>

80100186 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
80100186:	55                   	push   %ebp
80100187:	89 e5                	mov    %esp,%ebp
80100189:	53                   	push   %ebx
8010018a:	83 ec 10             	sub    $0x10,%esp
8010018d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
80100190:	8d 43 0c             	lea    0xc(%ebx),%eax
80100193:	50                   	push   %eax
80100194:	e8 27 3c 00 00       	call   80103dc0 <holdingsleep>
80100199:	83 c4 10             	add    $0x10,%esp
8010019c:	85 c0                	test   %eax,%eax
8010019e:	74 14                	je     801001b4 <bwrite+0x2e>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001a0:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001a3:	83 ec 0c             	sub    $0xc,%esp
801001a6:	53                   	push   %ebx
801001a7:	e8 e3 1c 00 00       	call   80101e8f <iderw>
}
801001ac:	83 c4 10             	add    $0x10,%esp
801001af:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001b2:	c9                   	leave  
801001b3:	c3                   	ret    
    panic("bwrite");
801001b4:	83 ec 0c             	sub    $0xc,%esp
801001b7:	68 1f 68 10 80       	push   $0x8010681f
801001bc:	e8 83 01 00 00       	call   80100344 <panic>

801001c1 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
801001c1:	55                   	push   %ebp
801001c2:	89 e5                	mov    %esp,%ebp
801001c4:	56                   	push   %esi
801001c5:	53                   	push   %ebx
801001c6:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001c9:	8d 73 0c             	lea    0xc(%ebx),%esi
801001cc:	83 ec 0c             	sub    $0xc,%esp
801001cf:	56                   	push   %esi
801001d0:	e8 eb 3b 00 00       	call   80103dc0 <holdingsleep>
801001d5:	83 c4 10             	add    $0x10,%esp
801001d8:	85 c0                	test   %eax,%eax
801001da:	74 6b                	je     80100247 <brelse+0x86>
    panic("brelse");

  releasesleep(&b->lock);
801001dc:	83 ec 0c             	sub    $0xc,%esp
801001df:	56                   	push   %esi
801001e0:	e8 a0 3b 00 00       	call   80103d85 <releasesleep>

  acquire(&bcache.lock);
801001e5:	c7 04 24 e0 b5 10 80 	movl   $0x8010b5e0,(%esp)
801001ec:	e8 61 3d 00 00       	call   80103f52 <acquire>
  b->refcnt--;
801001f1:	8b 43 4c             	mov    0x4c(%ebx),%eax
801001f4:	83 e8 01             	sub    $0x1,%eax
801001f7:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
801001fa:	83 c4 10             	add    $0x10,%esp
801001fd:	85 c0                	test   %eax,%eax
801001ff:	75 2f                	jne    80100230 <brelse+0x6f>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100201:	8b 43 54             	mov    0x54(%ebx),%eax
80100204:	8b 53 50             	mov    0x50(%ebx),%edx
80100207:	89 50 50             	mov    %edx,0x50(%eax)
    b->prev->next = b->next;
8010020a:	8b 43 50             	mov    0x50(%ebx),%eax
8010020d:	8b 53 54             	mov    0x54(%ebx),%edx
80100210:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
80100213:	a1 30 fd 10 80       	mov    0x8010fd30,%eax
80100218:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
8010021b:	c7 43 50 dc fc 10 80 	movl   $0x8010fcdc,0x50(%ebx)
    bcache.head.next->prev = b;
80100222:	a1 30 fd 10 80       	mov    0x8010fd30,%eax
80100227:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
8010022a:	89 1d 30 fd 10 80    	mov    %ebx,0x8010fd30
  }
  
  release(&bcache.lock);
80100230:	83 ec 0c             	sub    $0xc,%esp
80100233:	68 e0 b5 10 80       	push   $0x8010b5e0
80100238:	e8 7c 3d 00 00       	call   80103fb9 <release>
}
8010023d:	83 c4 10             	add    $0x10,%esp
80100240:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100243:	5b                   	pop    %ebx
80100244:	5e                   	pop    %esi
80100245:	5d                   	pop    %ebp
80100246:	c3                   	ret    
    panic("brelse");
80100247:	83 ec 0c             	sub    $0xc,%esp
8010024a:	68 26 68 10 80       	push   $0x80106826
8010024f:	e8 f0 00 00 00       	call   80100344 <panic>

80100254 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
80100254:	55                   	push   %ebp
80100255:	89 e5                	mov    %esp,%ebp
80100257:	57                   	push   %edi
80100258:	56                   	push   %esi
80100259:	53                   	push   %ebx
8010025a:	83 ec 28             	sub    $0x28,%esp
8010025d:	8b 7d 0c             	mov    0xc(%ebp),%edi
80100260:	8b 75 10             	mov    0x10(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
80100263:	ff 75 08             	pushl  0x8(%ebp)
80100266:	e8 3d 13 00 00       	call   801015a8 <iunlock>
  target = n;
8010026b:	89 75 e4             	mov    %esi,-0x1c(%ebp)
  acquire(&cons.lock);
8010026e:	c7 04 24 20 a5 10 80 	movl   $0x8010a520,(%esp)
80100275:	e8 d8 3c 00 00       	call   80103f52 <acquire>
  while(n > 0){
8010027a:	83 c4 10             	add    $0x10,%esp
    while(input.r == input.w){
8010027d:	bb 40 ff 10 80       	mov    $0x8010ff40,%ebx
  while(n > 0){
80100282:	85 f6                	test   %esi,%esi
80100284:	7e 68                	jle    801002ee <consoleread+0x9a>
    while(input.r == input.w){
80100286:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
8010028c:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
80100292:	75 2e                	jne    801002c2 <consoleread+0x6e>
      if(myproc()->killed){
80100294:	e8 ac 30 00 00       	call   80103345 <myproc>
80100299:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010029d:	75 71                	jne    80100310 <consoleread+0xbc>
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
8010029f:	83 ec 08             	sub    $0x8,%esp
801002a2:	68 20 a5 10 80       	push   $0x8010a520
801002a7:	68 c0 ff 10 80       	push   $0x8010ffc0
801002ac:	e8 56 37 00 00       	call   80103a07 <sleep>
    while(input.r == input.w){
801002b1:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
801002b7:	83 c4 10             	add    $0x10,%esp
801002ba:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
801002c0:	74 d2                	je     80100294 <consoleread+0x40>
    }
    c = input.buf[input.r++ % INPUT_BUF];
801002c2:	8d 50 01             	lea    0x1(%eax),%edx
801002c5:	89 93 80 00 00 00    	mov    %edx,0x80(%ebx)
801002cb:	89 c2                	mov    %eax,%edx
801002cd:	83 e2 7f             	and    $0x7f,%edx
801002d0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
801002d4:	0f be d1             	movsbl %cl,%edx
    if(c == C('D')){  // EOF
801002d7:	83 fa 04             	cmp    $0x4,%edx
801002da:	74 5c                	je     80100338 <consoleread+0xe4>
        // caller gets a 0-byte result.
        input.r--;
      }
      break;
    }
    *dst++ = c;
801002dc:	83 c7 01             	add    $0x1,%edi
801002df:	88 4f ff             	mov    %cl,-0x1(%edi)
    --n;
801002e2:	83 ee 01             	sub    $0x1,%esi
    if(c == '\n')
801002e5:	83 fa 0a             	cmp    $0xa,%edx
801002e8:	74 04                	je     801002ee <consoleread+0x9a>
  while(n > 0){
801002ea:	85 f6                	test   %esi,%esi
801002ec:	75 98                	jne    80100286 <consoleread+0x32>
      break;
  }
  release(&cons.lock);
801002ee:	83 ec 0c             	sub    $0xc,%esp
801002f1:	68 20 a5 10 80       	push   $0x8010a520
801002f6:	e8 be 3c 00 00       	call   80103fb9 <release>
  ilock(ip);
801002fb:	83 c4 04             	add    $0x4,%esp
801002fe:	ff 75 08             	pushl  0x8(%ebp)
80100301:	e8 e0 11 00 00       	call   801014e6 <ilock>

  return target - n;
80100306:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100309:	29 f0                	sub    %esi,%eax
8010030b:	83 c4 10             	add    $0x10,%esp
8010030e:	eb 20                	jmp    80100330 <consoleread+0xdc>
        release(&cons.lock);
80100310:	83 ec 0c             	sub    $0xc,%esp
80100313:	68 20 a5 10 80       	push   $0x8010a520
80100318:	e8 9c 3c 00 00       	call   80103fb9 <release>
        ilock(ip);
8010031d:	83 c4 04             	add    $0x4,%esp
80100320:	ff 75 08             	pushl  0x8(%ebp)
80100323:	e8 be 11 00 00       	call   801014e6 <ilock>
        return -1;
80100328:	83 c4 10             	add    $0x10,%esp
8010032b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100330:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100333:	5b                   	pop    %ebx
80100334:	5e                   	pop    %esi
80100335:	5f                   	pop    %edi
80100336:	5d                   	pop    %ebp
80100337:	c3                   	ret    
      if(n < target){
80100338:	3b 75 e4             	cmp    -0x1c(%ebp),%esi
8010033b:	73 b1                	jae    801002ee <consoleread+0x9a>
        input.r--;
8010033d:	a3 c0 ff 10 80       	mov    %eax,0x8010ffc0
80100342:	eb aa                	jmp    801002ee <consoleread+0x9a>

80100344 <panic>:
{
80100344:	55                   	push   %ebp
80100345:	89 e5                	mov    %esp,%ebp
80100347:	56                   	push   %esi
80100348:	53                   	push   %ebx
80100349:	83 ec 30             	sub    $0x30,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
8010034c:	fa                   	cli    
  cons.locking = 0;
8010034d:	c7 05 54 a5 10 80 00 	movl   $0x0,0x8010a554
80100354:	00 00 00 
  cprintf("lapicid %d: panic: ", lapicid());
80100357:	e8 e4 20 00 00       	call   80102440 <lapicid>
8010035c:	83 ec 08             	sub    $0x8,%esp
8010035f:	50                   	push   %eax
80100360:	68 2d 68 10 80       	push   $0x8010682d
80100365:	e8 77 02 00 00       	call   801005e1 <cprintf>
  cprintf(s);
8010036a:	83 c4 04             	add    $0x4,%esp
8010036d:	ff 75 08             	pushl  0x8(%ebp)
80100370:	e8 6c 02 00 00       	call   801005e1 <cprintf>
  cprintf("\n");
80100375:	c7 04 24 7b 71 10 80 	movl   $0x8010717b,(%esp)
8010037c:	e8 60 02 00 00       	call   801005e1 <cprintf>
  getcallerpcs(&s, pcs);
80100381:	83 c4 08             	add    $0x8,%esp
80100384:	8d 5d d0             	lea    -0x30(%ebp),%ebx
80100387:	53                   	push   %ebx
80100388:	8d 45 08             	lea    0x8(%ebp),%eax
8010038b:	50                   	push   %eax
8010038c:	e8 94 3a 00 00       	call   80103e25 <getcallerpcs>
80100391:	8d 75 f8             	lea    -0x8(%ebp),%esi
80100394:	83 c4 10             	add    $0x10,%esp
    cprintf(" %p", pcs[i]);
80100397:	83 ec 08             	sub    $0x8,%esp
8010039a:	ff 33                	pushl  (%ebx)
8010039c:	68 41 68 10 80       	push   $0x80106841
801003a1:	e8 3b 02 00 00       	call   801005e1 <cprintf>
801003a6:	83 c3 04             	add    $0x4,%ebx
  for(i=0; i<10; i++)
801003a9:	83 c4 10             	add    $0x10,%esp
801003ac:	39 f3                	cmp    %esi,%ebx
801003ae:	75 e7                	jne    80100397 <panic+0x53>
  panicked = 1; // freeze other CPU
801003b0:	c7 05 58 a5 10 80 01 	movl   $0x1,0x8010a558
801003b7:	00 00 00 
801003ba:	eb fe                	jmp    801003ba <panic+0x76>

801003bc <consputc>:
  if(panicked){
801003bc:	83 3d 58 a5 10 80 00 	cmpl   $0x0,0x8010a558
801003c3:	74 03                	je     801003c8 <consputc+0xc>
801003c5:	fa                   	cli    
801003c6:	eb fe                	jmp    801003c6 <consputc+0xa>
{
801003c8:	55                   	push   %ebp
801003c9:	89 e5                	mov    %esp,%ebp
801003cb:	57                   	push   %edi
801003cc:	56                   	push   %esi
801003cd:	53                   	push   %ebx
801003ce:	83 ec 0c             	sub    $0xc,%esp
801003d1:	89 c6                	mov    %eax,%esi
  if(c == BACKSPACE){
801003d3:	3d 00 01 00 00       	cmp    $0x100,%eax
801003d8:	74 5f                	je     80100439 <consputc+0x7d>
    uartputc(c);
801003da:	83 ec 0c             	sub    $0xc,%esp
801003dd:	50                   	push   %eax
801003de:	e8 56 50 00 00       	call   80105439 <uartputc>
801003e3:	83 c4 10             	add    $0x10,%esp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801003e6:	bb d4 03 00 00       	mov    $0x3d4,%ebx
801003eb:	b8 0e 00 00 00       	mov    $0xe,%eax
801003f0:	89 da                	mov    %ebx,%edx
801003f2:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801003f3:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
801003f8:	89 ca                	mov    %ecx,%edx
801003fa:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
801003fb:	0f b6 c0             	movzbl %al,%eax
801003fe:	c1 e0 08             	shl    $0x8,%eax
80100401:	89 c7                	mov    %eax,%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100403:	b8 0f 00 00 00       	mov    $0xf,%eax
80100408:	89 da                	mov    %ebx,%edx
8010040a:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010040b:	89 ca                	mov    %ecx,%edx
8010040d:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
8010040e:	0f b6 d8             	movzbl %al,%ebx
80100411:	09 fb                	or     %edi,%ebx
  if(c == '\n')
80100413:	83 fe 0a             	cmp    $0xa,%esi
80100416:	74 48                	je     80100460 <consputc+0xa4>
  else if(c == BACKSPACE){
80100418:	81 fe 00 01 00 00    	cmp    $0x100,%esi
8010041e:	0f 84 93 00 00 00    	je     801004b7 <consputc+0xfb>
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
80100424:	89 f0                	mov    %esi,%eax
80100426:	0f b6 c0             	movzbl %al,%eax
80100429:	80 cc 07             	or     $0x7,%ah
8010042c:	66 89 84 1b 00 80 0b 	mov    %ax,-0x7ff48000(%ebx,%ebx,1)
80100433:	80 
80100434:	8d 5b 01             	lea    0x1(%ebx),%ebx
80100437:	eb 35                	jmp    8010046e <consputc+0xb2>
    uartputc('\b'); uartputc(' '); uartputc('\b');
80100439:	83 ec 0c             	sub    $0xc,%esp
8010043c:	6a 08                	push   $0x8
8010043e:	e8 f6 4f 00 00       	call   80105439 <uartputc>
80100443:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
8010044a:	e8 ea 4f 00 00       	call   80105439 <uartputc>
8010044f:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
80100456:	e8 de 4f 00 00       	call   80105439 <uartputc>
8010045b:	83 c4 10             	add    $0x10,%esp
8010045e:	eb 86                	jmp    801003e6 <consputc+0x2a>
    pos += 80 - pos%80;
80100460:	b9 50 00 00 00       	mov    $0x50,%ecx
80100465:	89 d8                	mov    %ebx,%eax
80100467:	99                   	cltd   
80100468:	f7 f9                	idiv   %ecx
8010046a:	29 d1                	sub    %edx,%ecx
8010046c:	01 cb                	add    %ecx,%ebx
  if(pos < 0 || pos > 25*80)
8010046e:	81 fb d0 07 00 00    	cmp    $0x7d0,%ebx
80100474:	77 4a                	ja     801004c0 <consputc+0x104>
  if((pos/80) >= 24){  // Scroll up.
80100476:	81 fb 7f 07 00 00    	cmp    $0x77f,%ebx
8010047c:	7f 4f                	jg     801004cd <consputc+0x111>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010047e:	be d4 03 00 00       	mov    $0x3d4,%esi
80100483:	b8 0e 00 00 00       	mov    $0xe,%eax
80100488:	89 f2                	mov    %esi,%edx
8010048a:	ee                   	out    %al,(%dx)
  outb(CRTPORT+1, pos>>8);
8010048b:	89 d8                	mov    %ebx,%eax
8010048d:	c1 f8 08             	sar    $0x8,%eax
80100490:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
80100495:	89 ca                	mov    %ecx,%edx
80100497:	ee                   	out    %al,(%dx)
80100498:	b8 0f 00 00 00       	mov    $0xf,%eax
8010049d:	89 f2                	mov    %esi,%edx
8010049f:	ee                   	out    %al,(%dx)
801004a0:	89 d8                	mov    %ebx,%eax
801004a2:	89 ca                	mov    %ecx,%edx
801004a4:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004a5:	66 c7 84 1b 00 80 0b 	movw   $0x720,-0x7ff48000(%ebx,%ebx,1)
801004ac:	80 20 07 
}
801004af:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004b2:	5b                   	pop    %ebx
801004b3:	5e                   	pop    %esi
801004b4:	5f                   	pop    %edi
801004b5:	5d                   	pop    %ebp
801004b6:	c3                   	ret    
    if(pos > 0) --pos;
801004b7:	85 db                	test   %ebx,%ebx
801004b9:	7e b3                	jle    8010046e <consputc+0xb2>
801004bb:	83 eb 01             	sub    $0x1,%ebx
801004be:	eb ae                	jmp    8010046e <consputc+0xb2>
    panic("pos under/overflow");
801004c0:	83 ec 0c             	sub    $0xc,%esp
801004c3:	68 45 68 10 80       	push   $0x80106845
801004c8:	e8 77 fe ff ff       	call   80100344 <panic>
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
801004cd:	83 ec 04             	sub    $0x4,%esp
801004d0:	68 60 0e 00 00       	push   $0xe60
801004d5:	68 a0 80 0b 80       	push   $0x800b80a0
801004da:	68 00 80 0b 80       	push   $0x800b8000
801004df:	e8 b1 3b 00 00       	call   80104095 <memmove>
    pos -= 80;
801004e4:	83 eb 50             	sub    $0x50,%ebx
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
801004e7:	83 c4 0c             	add    $0xc,%esp
801004ea:	b8 80 07 00 00       	mov    $0x780,%eax
801004ef:	29 d8                	sub    %ebx,%eax
801004f1:	01 c0                	add    %eax,%eax
801004f3:	50                   	push   %eax
801004f4:	6a 00                	push   $0x0
801004f6:	8d 04 1b             	lea    (%ebx,%ebx,1),%eax
801004f9:	2d 00 80 f4 7f       	sub    $0x7ff48000,%eax
801004fe:	50                   	push   %eax
801004ff:	e8 fc 3a 00 00       	call   80104000 <memset>
80100504:	83 c4 10             	add    $0x10,%esp
80100507:	e9 72 ff ff ff       	jmp    8010047e <consputc+0xc2>

8010050c <printint>:
{
8010050c:	55                   	push   %ebp
8010050d:	89 e5                	mov    %esp,%ebp
8010050f:	57                   	push   %edi
80100510:	56                   	push   %esi
80100511:	53                   	push   %ebx
80100512:	83 ec 1c             	sub    $0x1c,%esp
80100515:	89 d6                	mov    %edx,%esi
  if(sign && (sign = xx < 0))
80100517:	85 c9                	test   %ecx,%ecx
80100519:	74 04                	je     8010051f <printint+0x13>
8010051b:	85 c0                	test   %eax,%eax
8010051d:	78 0e                	js     8010052d <printint+0x21>
    x = xx;
8010051f:	89 c2                	mov    %eax,%edx
80100521:	bf 00 00 00 00       	mov    $0x0,%edi
  i = 0;
80100526:	b9 00 00 00 00       	mov    $0x0,%ecx
8010052b:	eb 0d                	jmp    8010053a <printint+0x2e>
    x = -xx;
8010052d:	f7 d8                	neg    %eax
8010052f:	89 c2                	mov    %eax,%edx
  if(sign && (sign = xx < 0))
80100531:	bf 01 00 00 00       	mov    $0x1,%edi
    x = -xx;
80100536:	eb ee                	jmp    80100526 <printint+0x1a>
    buf[i++] = digits[x % base];
80100538:	89 d9                	mov    %ebx,%ecx
8010053a:	8d 59 01             	lea    0x1(%ecx),%ebx
8010053d:	89 d0                	mov    %edx,%eax
8010053f:	ba 00 00 00 00       	mov    $0x0,%edx
80100544:	f7 f6                	div    %esi
80100546:	0f b6 92 70 68 10 80 	movzbl -0x7fef9790(%edx),%edx
8010054d:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
80100551:	89 c2                	mov    %eax,%edx
80100553:	85 c0                	test   %eax,%eax
80100555:	75 e1                	jne    80100538 <printint+0x2c>
  if(sign)
80100557:	85 ff                	test   %edi,%edi
80100559:	74 08                	je     80100563 <printint+0x57>
    buf[i++] = '-';
8010055b:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
80100560:	8d 59 02             	lea    0x2(%ecx),%ebx
  while(--i >= 0)
80100563:	83 eb 01             	sub    $0x1,%ebx
80100566:	78 12                	js     8010057a <printint+0x6e>
    consputc(buf[i]);
80100568:	0f be 44 2b d8       	movsbl -0x28(%ebx,%ebp,1),%eax
8010056d:	e8 4a fe ff ff       	call   801003bc <consputc>
  while(--i >= 0)
80100572:	83 eb 01             	sub    $0x1,%ebx
80100575:	83 fb ff             	cmp    $0xffffffff,%ebx
80100578:	75 ee                	jne    80100568 <printint+0x5c>
}
8010057a:	83 c4 1c             	add    $0x1c,%esp
8010057d:	5b                   	pop    %ebx
8010057e:	5e                   	pop    %esi
8010057f:	5f                   	pop    %edi
80100580:	5d                   	pop    %ebp
80100581:	c3                   	ret    

80100582 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
80100582:	55                   	push   %ebp
80100583:	89 e5                	mov    %esp,%ebp
80100585:	57                   	push   %edi
80100586:	56                   	push   %esi
80100587:	53                   	push   %ebx
80100588:	83 ec 18             	sub    $0x18,%esp
8010058b:	8b 75 0c             	mov    0xc(%ebp),%esi
8010058e:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  iunlock(ip);
80100591:	ff 75 08             	pushl  0x8(%ebp)
80100594:	e8 0f 10 00 00       	call   801015a8 <iunlock>
  acquire(&cons.lock);
80100599:	c7 04 24 20 a5 10 80 	movl   $0x8010a520,(%esp)
801005a0:	e8 ad 39 00 00       	call   80103f52 <acquire>
  for(i = 0; i < n; i++)
801005a5:	83 c4 10             	add    $0x10,%esp
801005a8:	85 ff                	test   %edi,%edi
801005aa:	7e 13                	jle    801005bf <consolewrite+0x3d>
801005ac:	89 f3                	mov    %esi,%ebx
801005ae:	01 fe                	add    %edi,%esi
    consputc(buf[i] & 0xff);
801005b0:	0f b6 03             	movzbl (%ebx),%eax
801005b3:	e8 04 fe ff ff       	call   801003bc <consputc>
801005b8:	83 c3 01             	add    $0x1,%ebx
  for(i = 0; i < n; i++)
801005bb:	39 f3                	cmp    %esi,%ebx
801005bd:	75 f1                	jne    801005b0 <consolewrite+0x2e>
  release(&cons.lock);
801005bf:	83 ec 0c             	sub    $0xc,%esp
801005c2:	68 20 a5 10 80       	push   $0x8010a520
801005c7:	e8 ed 39 00 00       	call   80103fb9 <release>
  ilock(ip);
801005cc:	83 c4 04             	add    $0x4,%esp
801005cf:	ff 75 08             	pushl  0x8(%ebp)
801005d2:	e8 0f 0f 00 00       	call   801014e6 <ilock>

  return n;
}
801005d7:	89 f8                	mov    %edi,%eax
801005d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801005dc:	5b                   	pop    %ebx
801005dd:	5e                   	pop    %esi
801005de:	5f                   	pop    %edi
801005df:	5d                   	pop    %ebp
801005e0:	c3                   	ret    

801005e1 <cprintf>:
{
801005e1:	55                   	push   %ebp
801005e2:	89 e5                	mov    %esp,%ebp
801005e4:	57                   	push   %edi
801005e5:	56                   	push   %esi
801005e6:	53                   	push   %ebx
801005e7:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking;
801005ea:	a1 54 a5 10 80       	mov    0x8010a554,%eax
801005ef:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if(locking)
801005f2:	85 c0                	test   %eax,%eax
801005f4:	75 2b                	jne    80100621 <cprintf+0x40>
  if (fmt == 0)
801005f6:	8b 7d 08             	mov    0x8(%ebp),%edi
801005f9:	85 ff                	test   %edi,%edi
801005fb:	74 36                	je     80100633 <cprintf+0x52>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801005fd:	0f b6 07             	movzbl (%edi),%eax
  argp = (uint*)(void*)(&fmt + 1);
80100600:	8d 4d 0c             	lea    0xc(%ebp),%ecx
80100603:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100606:	bb 00 00 00 00       	mov    $0x0,%ebx
8010060b:	85 c0                	test   %eax,%eax
8010060d:	75 41                	jne    80100650 <cprintf+0x6f>
  if(locking)
8010060f:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80100613:	0f 85 0d 01 00 00    	jne    80100726 <cprintf+0x145>
}
80100619:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010061c:	5b                   	pop    %ebx
8010061d:	5e                   	pop    %esi
8010061e:	5f                   	pop    %edi
8010061f:	5d                   	pop    %ebp
80100620:	c3                   	ret    
    acquire(&cons.lock);
80100621:	83 ec 0c             	sub    $0xc,%esp
80100624:	68 20 a5 10 80       	push   $0x8010a520
80100629:	e8 24 39 00 00       	call   80103f52 <acquire>
8010062e:	83 c4 10             	add    $0x10,%esp
80100631:	eb c3                	jmp    801005f6 <cprintf+0x15>
    panic("null fmt");
80100633:	83 ec 0c             	sub    $0xc,%esp
80100636:	68 5f 68 10 80       	push   $0x8010685f
8010063b:	e8 04 fd ff ff       	call   80100344 <panic>
      consputc(c);
80100640:	e8 77 fd ff ff       	call   801003bc <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100645:	83 c3 01             	add    $0x1,%ebx
80100648:	0f b6 04 1f          	movzbl (%edi,%ebx,1),%eax
8010064c:	85 c0                	test   %eax,%eax
8010064e:	74 bf                	je     8010060f <cprintf+0x2e>
    if(c != '%'){
80100650:	83 f8 25             	cmp    $0x25,%eax
80100653:	75 eb                	jne    80100640 <cprintf+0x5f>
    c = fmt[++i] & 0xff;
80100655:	83 c3 01             	add    $0x1,%ebx
80100658:	0f b6 34 1f          	movzbl (%edi,%ebx,1),%esi
    if(c == 0)
8010065c:	85 f6                	test   %esi,%esi
8010065e:	74 af                	je     8010060f <cprintf+0x2e>
    switch(c){
80100660:	83 fe 70             	cmp    $0x70,%esi
80100663:	74 4c                	je     801006b1 <cprintf+0xd0>
80100665:	83 fe 70             	cmp    $0x70,%esi
80100668:	7f 2a                	jg     80100694 <cprintf+0xb3>
8010066a:	83 fe 25             	cmp    $0x25,%esi
8010066d:	0f 84 a4 00 00 00    	je     80100717 <cprintf+0x136>
80100673:	83 fe 64             	cmp    $0x64,%esi
80100676:	75 26                	jne    8010069e <cprintf+0xbd>
      printint(*argp++, 10, 1);
80100678:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010067b:	8d 70 04             	lea    0x4(%eax),%esi
8010067e:	b9 01 00 00 00       	mov    $0x1,%ecx
80100683:	ba 0a 00 00 00       	mov    $0xa,%edx
80100688:	8b 00                	mov    (%eax),%eax
8010068a:	e8 7d fe ff ff       	call   8010050c <printint>
8010068f:	89 75 e4             	mov    %esi,-0x1c(%ebp)
      break;
80100692:	eb b1                	jmp    80100645 <cprintf+0x64>
    switch(c){
80100694:	83 fe 73             	cmp    $0x73,%esi
80100697:	74 37                	je     801006d0 <cprintf+0xef>
80100699:	83 fe 78             	cmp    $0x78,%esi
8010069c:	74 13                	je     801006b1 <cprintf+0xd0>
      consputc('%');
8010069e:	b8 25 00 00 00       	mov    $0x25,%eax
801006a3:	e8 14 fd ff ff       	call   801003bc <consputc>
      consputc(c);
801006a8:	89 f0                	mov    %esi,%eax
801006aa:	e8 0d fd ff ff       	call   801003bc <consputc>
      break;
801006af:	eb 94                	jmp    80100645 <cprintf+0x64>
      printint(*argp++, 16, 0);
801006b1:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801006b4:	8d 70 04             	lea    0x4(%eax),%esi
801006b7:	b9 00 00 00 00       	mov    $0x0,%ecx
801006bc:	ba 10 00 00 00       	mov    $0x10,%edx
801006c1:	8b 00                	mov    (%eax),%eax
801006c3:	e8 44 fe ff ff       	call   8010050c <printint>
801006c8:	89 75 e4             	mov    %esi,-0x1c(%ebp)
      break;
801006cb:	e9 75 ff ff ff       	jmp    80100645 <cprintf+0x64>
      if((s = (char*)*argp++) == 0)
801006d0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801006d3:	8d 50 04             	lea    0x4(%eax),%edx
801006d6:	89 55 dc             	mov    %edx,-0x24(%ebp)
801006d9:	8b 00                	mov    (%eax),%eax
801006db:	85 c0                	test   %eax,%eax
801006dd:	74 11                	je     801006f0 <cprintf+0x10f>
801006df:	89 c6                	mov    %eax,%esi
      for(; *s; s++)
801006e1:	0f b6 00             	movzbl (%eax),%eax
      if((s = (char*)*argp++) == 0)
801006e4:	89 55 e4             	mov    %edx,-0x1c(%ebp)
      for(; *s; s++)
801006e7:	84 c0                	test   %al,%al
801006e9:	75 0f                	jne    801006fa <cprintf+0x119>
801006eb:	e9 55 ff ff ff       	jmp    80100645 <cprintf+0x64>
        s = "(null)";
801006f0:	be 58 68 10 80       	mov    $0x80106858,%esi
      for(; *s; s++)
801006f5:	b8 28 00 00 00       	mov    $0x28,%eax
        consputc(*s);
801006fa:	0f be c0             	movsbl %al,%eax
801006fd:	e8 ba fc ff ff       	call   801003bc <consputc>
      for(; *s; s++)
80100702:	83 c6 01             	add    $0x1,%esi
80100705:	0f b6 06             	movzbl (%esi),%eax
80100708:	84 c0                	test   %al,%al
8010070a:	75 ee                	jne    801006fa <cprintf+0x119>
      if((s = (char*)*argp++) == 0)
8010070c:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010070f:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100712:	e9 2e ff ff ff       	jmp    80100645 <cprintf+0x64>
      consputc('%');
80100717:	b8 25 00 00 00       	mov    $0x25,%eax
8010071c:	e8 9b fc ff ff       	call   801003bc <consputc>
      break;
80100721:	e9 1f ff ff ff       	jmp    80100645 <cprintf+0x64>
    release(&cons.lock);
80100726:	83 ec 0c             	sub    $0xc,%esp
80100729:	68 20 a5 10 80       	push   $0x8010a520
8010072e:	e8 86 38 00 00       	call   80103fb9 <release>
80100733:	83 c4 10             	add    $0x10,%esp
}
80100736:	e9 de fe ff ff       	jmp    80100619 <cprintf+0x38>

8010073b <consoleintr>:
{
8010073b:	55                   	push   %ebp
8010073c:	89 e5                	mov    %esp,%ebp
8010073e:	57                   	push   %edi
8010073f:	56                   	push   %esi
80100740:	53                   	push   %ebx
80100741:	83 ec 28             	sub    $0x28,%esp
80100744:	8b 7d 08             	mov    0x8(%ebp),%edi
  acquire(&cons.lock);
80100747:	68 20 a5 10 80       	push   $0x8010a520
8010074c:	e8 01 38 00 00       	call   80103f52 <acquire>
  while((c = getc()) >= 0){
80100751:	83 c4 10             	add    $0x10,%esp
  int c, doprocdump = 0;
80100754:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
      if(c != 0 && input.e-input.r < INPUT_BUF){
8010075b:	bb 40 ff 10 80       	mov    $0x8010ff40,%ebx
  while((c = getc()) >= 0){
80100760:	e9 c2 00 00 00       	jmp    80100827 <consoleintr+0xec>
    switch(c){
80100765:	83 fe 08             	cmp    $0x8,%esi
80100768:	0f 84 dd 00 00 00    	je     8010084b <consoleintr+0x110>
      if(c != 0 && input.e-input.r < INPUT_BUF){
8010076e:	85 f6                	test   %esi,%esi
80100770:	0f 84 b1 00 00 00    	je     80100827 <consoleintr+0xec>
80100776:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
8010077c:	89 c2                	mov    %eax,%edx
8010077e:	2b 93 80 00 00 00    	sub    0x80(%ebx),%edx
80100784:	83 fa 7f             	cmp    $0x7f,%edx
80100787:	0f 87 9a 00 00 00    	ja     80100827 <consoleintr+0xec>
        c = (c == '\r') ? '\n' : c;
8010078d:	83 fe 0d             	cmp    $0xd,%esi
80100790:	0f 84 fd 00 00 00    	je     80100893 <consoleintr+0x158>
        input.buf[input.e++ % INPUT_BUF] = c;
80100796:	8d 50 01             	lea    0x1(%eax),%edx
80100799:	89 93 88 00 00 00    	mov    %edx,0x88(%ebx)
8010079f:	83 e0 7f             	and    $0x7f,%eax
801007a2:	89 f1                	mov    %esi,%ecx
801007a4:	88 0c 03             	mov    %cl,(%ebx,%eax,1)
        consputc(c);
801007a7:	89 f0                	mov    %esi,%eax
801007a9:	e8 0e fc ff ff       	call   801003bc <consputc>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
801007ae:	83 fe 0a             	cmp    $0xa,%esi
801007b1:	0f 84 f6 00 00 00    	je     801008ad <consoleintr+0x172>
801007b7:	83 fe 04             	cmp    $0x4,%esi
801007ba:	0f 84 ed 00 00 00    	je     801008ad <consoleintr+0x172>
801007c0:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
801007c6:	83 e8 80             	sub    $0xffffff80,%eax
801007c9:	39 83 88 00 00 00    	cmp    %eax,0x88(%ebx)
801007cf:	75 56                	jne    80100827 <consoleintr+0xec>
801007d1:	e9 d7 00 00 00       	jmp    801008ad <consoleintr+0x172>
      while(input.e != input.w &&
801007d6:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
801007dc:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
801007e2:	74 43                	je     80100827 <consoleintr+0xec>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
801007e4:	83 e8 01             	sub    $0x1,%eax
801007e7:	89 c2                	mov    %eax,%edx
801007e9:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
801007ec:	80 3c 13 0a          	cmpb   $0xa,(%ebx,%edx,1)
801007f0:	74 35                	je     80100827 <consoleintr+0xec>
        input.e--;
801007f2:	89 83 88 00 00 00    	mov    %eax,0x88(%ebx)
        consputc(BACKSPACE);
801007f8:	b8 00 01 00 00       	mov    $0x100,%eax
801007fd:	e8 ba fb ff ff       	call   801003bc <consputc>
      while(input.e != input.w &&
80100802:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
80100808:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
8010080e:	74 17                	je     80100827 <consoleintr+0xec>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
80100810:	83 e8 01             	sub    $0x1,%eax
80100813:	89 c2                	mov    %eax,%edx
80100815:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
80100818:	80 3c 13 0a          	cmpb   $0xa,(%ebx,%edx,1)
8010081c:	75 d4                	jne    801007f2 <consoleintr+0xb7>
8010081e:	eb 07                	jmp    80100827 <consoleintr+0xec>
      doprocdump = 1;
80100820:	c7 45 e4 01 00 00 00 	movl   $0x1,-0x1c(%ebp)
  while((c = getc()) >= 0){
80100827:	ff d7                	call   *%edi
80100829:	89 c6                	mov    %eax,%esi
8010082b:	85 c0                	test   %eax,%eax
8010082d:	78 3f                	js     8010086e <consoleintr+0x133>
    switch(c){
8010082f:	83 fe 10             	cmp    $0x10,%esi
80100832:	74 ec                	je     80100820 <consoleintr+0xe5>
80100834:	83 fe 10             	cmp    $0x10,%esi
80100837:	0f 8e 28 ff ff ff    	jle    80100765 <consoleintr+0x2a>
8010083d:	83 fe 15             	cmp    $0x15,%esi
80100840:	74 94                	je     801007d6 <consoleintr+0x9b>
80100842:	83 fe 7f             	cmp    $0x7f,%esi
80100845:	0f 85 23 ff ff ff    	jne    8010076e <consoleintr+0x33>
      if(input.e != input.w){
8010084b:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
80100851:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
80100857:	74 ce                	je     80100827 <consoleintr+0xec>
        input.e--;
80100859:	83 e8 01             	sub    $0x1,%eax
8010085c:	89 83 88 00 00 00    	mov    %eax,0x88(%ebx)
        consputc(BACKSPACE);
80100862:	b8 00 01 00 00       	mov    $0x100,%eax
80100867:	e8 50 fb ff ff       	call   801003bc <consputc>
8010086c:	eb b9                	jmp    80100827 <consoleintr+0xec>
  release(&cons.lock);
8010086e:	83 ec 0c             	sub    $0xc,%esp
80100871:	68 20 a5 10 80       	push   $0x8010a520
80100876:	e8 3e 37 00 00       	call   80103fb9 <release>
  if(doprocdump) {
8010087b:	83 c4 10             	add    $0x10,%esp
8010087e:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
80100882:	75 08                	jne    8010088c <consoleintr+0x151>
}
80100884:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100887:	5b                   	pop    %ebx
80100888:	5e                   	pop    %esi
80100889:	5f                   	pop    %edi
8010088a:	5d                   	pop    %ebp
8010088b:	c3                   	ret    
    procdump();  // now call procdump() wo. cons.lock held
8010088c:	e8 a0 33 00 00       	call   80103c31 <procdump>
}
80100891:	eb f1                	jmp    80100884 <consoleintr+0x149>
        input.buf[input.e++ % INPUT_BUF] = c;
80100893:	8d 50 01             	lea    0x1(%eax),%edx
80100896:	89 93 88 00 00 00    	mov    %edx,0x88(%ebx)
8010089c:	83 e0 7f             	and    $0x7f,%eax
8010089f:	c6 04 03 0a          	movb   $0xa,(%ebx,%eax,1)
        consputc(c);
801008a3:	b8 0a 00 00 00       	mov    $0xa,%eax
801008a8:	e8 0f fb ff ff       	call   801003bc <consputc>
          input.w = input.e;
801008ad:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
801008b3:	89 83 84 00 00 00    	mov    %eax,0x84(%ebx)
          wakeup(&input.r);
801008b9:	83 ec 0c             	sub    $0xc,%esp
801008bc:	68 c0 ff 10 80       	push   $0x8010ffc0
801008c1:	e8 c1 32 00 00       	call   80103b87 <wakeup>
801008c6:	83 c4 10             	add    $0x10,%esp
801008c9:	e9 59 ff ff ff       	jmp    80100827 <consoleintr+0xec>

801008ce <consoleinit>:

void
consoleinit(void)
{
801008ce:	55                   	push   %ebp
801008cf:	89 e5                	mov    %esp,%ebp
801008d1:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
801008d4:	68 68 68 10 80       	push   $0x80106868
801008d9:	68 20 a5 10 80       	push   $0x8010a520
801008de:	e8 27 35 00 00       	call   80103e0a <initlock>

  devsw[CONSOLE].write = consolewrite;
801008e3:	c7 05 8c 09 11 80 82 	movl   $0x80100582,0x8011098c
801008ea:	05 10 80 
  devsw[CONSOLE].read = consoleread;
801008ed:	c7 05 88 09 11 80 54 	movl   $0x80100254,0x80110988
801008f4:	02 10 80 
  cons.locking = 1;
801008f7:	c7 05 54 a5 10 80 01 	movl   $0x1,0x8010a554
801008fe:	00 00 00 

  ioapicenable(IRQ_KBD, 0);
80100901:	83 c4 08             	add    $0x8,%esp
80100904:	6a 00                	push   $0x0
80100906:	6a 01                	push   $0x1
80100908:	e8 f9 16 00 00       	call   80102006 <ioapicenable>
}
8010090d:	83 c4 10             	add    $0x10,%esp
80100910:	c9                   	leave  
80100911:	c3                   	ret    

80100912 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100912:	55                   	push   %ebp
80100913:	89 e5                	mov    %esp,%ebp
80100915:	57                   	push   %edi
80100916:	56                   	push   %esi
80100917:	53                   	push   %ebx
80100918:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
8010091e:	e8 22 2a 00 00       	call   80103345 <myproc>
80100923:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)

  begin_op();
80100929:	e8 7f 1e 00 00       	call   801027ad <begin_op>

  if((ip = namei(path)) == 0){
8010092e:	83 ec 0c             	sub    $0xc,%esp
80100931:	ff 75 08             	pushl  0x8(%ebp)
80100934:	e8 4a 13 00 00       	call   80101c83 <namei>
80100939:	83 c4 10             	add    $0x10,%esp
8010093c:	85 c0                	test   %eax,%eax
8010093e:	74 42                	je     80100982 <exec+0x70>
80100940:	89 c3                	mov    %eax,%ebx
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100942:	83 ec 0c             	sub    $0xc,%esp
80100945:	50                   	push   %eax
80100946:	e8 9b 0b 00 00       	call   801014e6 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
8010094b:	6a 34                	push   $0x34
8010094d:	6a 00                	push   $0x0
8010094f:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100955:	50                   	push   %eax
80100956:	53                   	push   %ebx
80100957:	e8 1e 0e 00 00       	call   8010177a <readi>
8010095c:	83 c4 20             	add    $0x20,%esp
8010095f:	83 f8 34             	cmp    $0x34,%eax
80100962:	74 3a                	je     8010099e <exec+0x8c>

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
80100964:	83 ec 0c             	sub    $0xc,%esp
80100967:	53                   	push   %ebx
80100968:	e8 c2 0d 00 00       	call   8010172f <iunlockput>
    end_op();
8010096d:	e8 b6 1e 00 00       	call   80102828 <end_op>
80100972:	83 c4 10             	add    $0x10,%esp
  }
  return -1;
80100975:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010097a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010097d:	5b                   	pop    %ebx
8010097e:	5e                   	pop    %esi
8010097f:	5f                   	pop    %edi
80100980:	5d                   	pop    %ebp
80100981:	c3                   	ret    
    end_op();
80100982:	e8 a1 1e 00 00       	call   80102828 <end_op>
    cprintf("exec: fail\n");
80100987:	83 ec 0c             	sub    $0xc,%esp
8010098a:	68 81 68 10 80       	push   $0x80106881
8010098f:	e8 4d fc ff ff       	call   801005e1 <cprintf>
    return -1;
80100994:	83 c4 10             	add    $0x10,%esp
80100997:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010099c:	eb dc                	jmp    8010097a <exec+0x68>
  if(elf.magic != ELF_MAGIC)
8010099e:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
801009a5:	45 4c 46 
801009a8:	75 ba                	jne    80100964 <exec+0x52>
  if((pgdir = setupkvm()) == 0)
801009aa:	e8 fb 5b 00 00       	call   801065aa <setupkvm>
801009af:	89 c7                	mov    %eax,%edi
801009b1:	85 c0                	test   %eax,%eax
801009b3:	74 af                	je     80100964 <exec+0x52>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801009b5:	8b 85 40 ff ff ff    	mov    -0xc0(%ebp),%eax
801009bb:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
801009c1:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
801009c8:	00 
801009c9:	0f 84 bf 00 00 00    	je     80100a8e <exec+0x17c>
  sz = 0;
801009cf:	c7 85 ec fe ff ff 00 	movl   $0x0,-0x114(%ebp)
801009d6:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801009d9:	be 00 00 00 00       	mov    $0x0,%esi
801009de:	eb 12                	jmp    801009f2 <exec+0xe0>
801009e0:	83 c6 01             	add    $0x1,%esi
801009e3:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
801009ea:	39 f0                	cmp    %esi,%eax
801009ec:	0f 8e a6 00 00 00    	jle    80100a98 <exec+0x186>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
801009f2:	6a 20                	push   $0x20
801009f4:	89 f0                	mov    %esi,%eax
801009f6:	c1 e0 05             	shl    $0x5,%eax
801009f9:	03 85 f0 fe ff ff    	add    -0x110(%ebp),%eax
801009ff:	50                   	push   %eax
80100a00:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100a06:	50                   	push   %eax
80100a07:	53                   	push   %ebx
80100a08:	e8 6d 0d 00 00       	call   8010177a <readi>
80100a0d:	83 c4 10             	add    $0x10,%esp
80100a10:	83 f8 20             	cmp    $0x20,%eax
80100a13:	0f 85 c2 00 00 00    	jne    80100adb <exec+0x1c9>
    if(ph.type != ELF_PROG_LOAD)
80100a19:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100a20:	75 be                	jne    801009e0 <exec+0xce>
    if(ph.memsz < ph.filesz)
80100a22:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100a28:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100a2e:	0f 82 a7 00 00 00    	jb     80100adb <exec+0x1c9>
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100a34:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100a3a:	0f 82 9b 00 00 00    	jb     80100adb <exec+0x1c9>
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100a40:	83 ec 04             	sub    $0x4,%esp
80100a43:	50                   	push   %eax
80100a44:	ff b5 ec fe ff ff    	pushl  -0x114(%ebp)
80100a4a:	57                   	push   %edi
80100a4b:	e8 f9 59 00 00       	call   80106449 <allocuvm>
80100a50:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)
80100a56:	83 c4 10             	add    $0x10,%esp
80100a59:	85 c0                	test   %eax,%eax
80100a5b:	74 7e                	je     80100adb <exec+0x1c9>
    if(ph.vaddr % PGSIZE != 0)
80100a5d:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100a63:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100a68:	75 71                	jne    80100adb <exec+0x1c9>
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100a6a:	83 ec 0c             	sub    $0xc,%esp
80100a6d:	ff b5 14 ff ff ff    	pushl  -0xec(%ebp)
80100a73:	ff b5 08 ff ff ff    	pushl  -0xf8(%ebp)
80100a79:	53                   	push   %ebx
80100a7a:	50                   	push   %eax
80100a7b:	57                   	push   %edi
80100a7c:	e8 8b 58 00 00       	call   8010630c <loaduvm>
80100a81:	83 c4 20             	add    $0x20,%esp
80100a84:	85 c0                	test   %eax,%eax
80100a86:	0f 89 54 ff ff ff    	jns    801009e0 <exec+0xce>
 bad:
80100a8c:	eb 4d                	jmp    80100adb <exec+0x1c9>
  sz = 0;
80100a8e:	c7 85 ec fe ff ff 00 	movl   $0x0,-0x114(%ebp)
80100a95:	00 00 00 
  iunlockput(ip);
80100a98:	83 ec 0c             	sub    $0xc,%esp
80100a9b:	53                   	push   %ebx
80100a9c:	e8 8e 0c 00 00       	call   8010172f <iunlockput>
  end_op();
80100aa1:	e8 82 1d 00 00       	call   80102828 <end_op>
  sz = PGROUNDUP(sz);
80100aa6:	8b 85 ec fe ff ff    	mov    -0x114(%ebp),%eax
80100aac:	05 ff 0f 00 00       	add    $0xfff,%eax
80100ab1:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80100ab6:	89 c2                	mov    %eax,%edx
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ab8:	83 c4 0c             	add    $0xc,%esp
80100abb:	8d 80 00 20 00 00    	lea    0x2000(%eax),%eax
80100ac1:	50                   	push   %eax
80100ac2:	52                   	push   %edx
80100ac3:	57                   	push   %edi
80100ac4:	e8 80 59 00 00       	call   80106449 <allocuvm>
80100ac9:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100acf:	83 c4 10             	add    $0x10,%esp
  ip = 0;
80100ad2:	bb 00 00 00 00       	mov    $0x0,%ebx
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ad7:	85 c0                	test   %eax,%eax
80100ad9:	75 1e                	jne    80100af9 <exec+0x1e7>
    freevm(pgdir);
80100adb:	83 ec 0c             	sub    $0xc,%esp
80100ade:	57                   	push   %edi
80100adf:	e8 53 5a 00 00       	call   80106537 <freevm>
  if(ip){
80100ae4:	83 c4 10             	add    $0x10,%esp
80100ae7:	85 db                	test   %ebx,%ebx
80100ae9:	0f 85 75 fe ff ff    	jne    80100964 <exec+0x52>
  return -1;
80100aef:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100af4:	e9 81 fe ff ff       	jmp    8010097a <exec+0x68>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100af9:	83 ec 08             	sub    $0x8,%esp
80100afc:	89 c3                	mov    %eax,%ebx
80100afe:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
80100b04:	50                   	push   %eax
80100b05:	57                   	push   %edi
80100b06:	e8 24 5b 00 00       	call   8010662f <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100b0b:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b0e:	8b 00                	mov    (%eax),%eax
80100b10:	83 c4 10             	add    $0x10,%esp
80100b13:	be 00 00 00 00       	mov    $0x0,%esi
80100b18:	85 c0                	test   %eax,%eax
80100b1a:	74 5f                	je     80100b7b <exec+0x269>
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100b1c:	83 ec 0c             	sub    $0xc,%esp
80100b1f:	50                   	push   %eax
80100b20:	e8 9e 36 00 00       	call   801041c3 <strlen>
80100b25:	f7 d0                	not    %eax
80100b27:	01 d8                	add    %ebx,%eax
80100b29:	83 e0 fc             	and    $0xfffffffc,%eax
80100b2c:	89 c3                	mov    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100b2e:	83 c4 04             	add    $0x4,%esp
80100b31:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b34:	ff 34 b0             	pushl  (%eax,%esi,4)
80100b37:	e8 87 36 00 00       	call   801041c3 <strlen>
80100b3c:	83 c0 01             	add    $0x1,%eax
80100b3f:	50                   	push   %eax
80100b40:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b43:	ff 34 b0             	pushl  (%eax,%esi,4)
80100b46:	53                   	push   %ebx
80100b47:	57                   	push   %edi
80100b48:	e8 2d 5c 00 00       	call   8010677a <copyout>
80100b4d:	83 c4 20             	add    $0x20,%esp
80100b50:	85 c0                	test   %eax,%eax
80100b52:	0f 88 f4 00 00 00    	js     80100c4c <exec+0x33a>
    ustack[3+argc] = sp;
80100b58:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
  for(argc = 0; argv[argc]; argc++) {
80100b5f:	83 c6 01             	add    $0x1,%esi
80100b62:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b65:	8b 04 b0             	mov    (%eax,%esi,4),%eax
80100b68:	85 c0                	test   %eax,%eax
80100b6a:	74 15                	je     80100b81 <exec+0x26f>
    if(argc >= MAXARG)
80100b6c:	83 fe 20             	cmp    $0x20,%esi
80100b6f:	75 ab                	jne    80100b1c <exec+0x20a>
  ip = 0;
80100b71:	bb 00 00 00 00       	mov    $0x0,%ebx
80100b76:	e9 60 ff ff ff       	jmp    80100adb <exec+0x1c9>
  sp = sz;
80100b7b:	8b 9d f0 fe ff ff    	mov    -0x110(%ebp),%ebx
  ustack[3+argc] = 0;
80100b81:	c7 84 b5 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%esi,4)
80100b88:	00 00 00 00 
  ustack[0] = 0xffffffff;  // fake return PC
80100b8c:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100b93:	ff ff ff 
  ustack[1] = argc;
80100b96:	89 b5 5c ff ff ff    	mov    %esi,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100b9c:	8d 04 b5 04 00 00 00 	lea    0x4(,%esi,4),%eax
80100ba3:	89 da                	mov    %ebx,%edx
80100ba5:	29 c2                	sub    %eax,%edx
80100ba7:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%ebp)
  sp -= (3+argc+1) * 4;
80100bad:	83 c0 0c             	add    $0xc,%eax
80100bb0:	89 de                	mov    %ebx,%esi
80100bb2:	29 c6                	sub    %eax,%esi
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100bb4:	50                   	push   %eax
80100bb5:	8d 85 58 ff ff ff    	lea    -0xa8(%ebp),%eax
80100bbb:	50                   	push   %eax
80100bbc:	56                   	push   %esi
80100bbd:	57                   	push   %edi
80100bbe:	e8 b7 5b 00 00       	call   8010677a <copyout>
80100bc3:	83 c4 10             	add    $0x10,%esp
80100bc6:	85 c0                	test   %eax,%eax
80100bc8:	0f 88 88 00 00 00    	js     80100c56 <exec+0x344>
  for(last=s=path; *s; s++)
80100bce:	8b 45 08             	mov    0x8(%ebp),%eax
80100bd1:	0f b6 10             	movzbl (%eax),%edx
80100bd4:	84 d2                	test   %dl,%dl
80100bd6:	74 1a                	je     80100bf2 <exec+0x2e0>
80100bd8:	83 c0 01             	add    $0x1,%eax
80100bdb:	8b 4d 08             	mov    0x8(%ebp),%ecx
      last = s+1;
80100bde:	80 fa 2f             	cmp    $0x2f,%dl
80100be1:	0f 44 c8             	cmove  %eax,%ecx
80100be4:	83 c0 01             	add    $0x1,%eax
  for(last=s=path; *s; s++)
80100be7:	0f b6 50 ff          	movzbl -0x1(%eax),%edx
80100beb:	84 d2                	test   %dl,%dl
80100bed:	75 ef                	jne    80100bde <exec+0x2cc>
80100bef:	89 4d 08             	mov    %ecx,0x8(%ebp)
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100bf2:	83 ec 04             	sub    $0x4,%esp
80100bf5:	6a 10                	push   $0x10
80100bf7:	ff 75 08             	pushl  0x8(%ebp)
80100bfa:	8b 9d f4 fe ff ff    	mov    -0x10c(%ebp),%ebx
80100c00:	89 d8                	mov    %ebx,%eax
80100c02:	83 c0 6c             	add    $0x6c,%eax
80100c05:	50                   	push   %eax
80100c06:	e8 84 35 00 00       	call   8010418f <safestrcpy>
  oldpgdir = curproc->pgdir;
80100c0b:	89 d8                	mov    %ebx,%eax
80100c0d:	8b 5b 04             	mov    0x4(%ebx),%ebx
  curproc->pgdir = pgdir;
80100c10:	89 78 04             	mov    %edi,0x4(%eax)
  curproc->sz = sz;
80100c13:	8b 95 f0 fe ff ff    	mov    -0x110(%ebp),%edx
80100c19:	89 10                	mov    %edx,(%eax)
  curproc->tf->eip = elf.entry;  // main
80100c1b:	89 c7                	mov    %eax,%edi
80100c1d:	8b 40 18             	mov    0x18(%eax),%eax
80100c20:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100c26:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100c29:	8b 47 18             	mov    0x18(%edi),%eax
80100c2c:	89 70 44             	mov    %esi,0x44(%eax)
  switchuvm(curproc);
80100c2f:	89 3c 24             	mov    %edi,(%esp)
80100c32:	e8 6e 55 00 00       	call   801061a5 <switchuvm>
  freevm(oldpgdir);
80100c37:	89 1c 24             	mov    %ebx,(%esp)
80100c3a:	e8 f8 58 00 00       	call   80106537 <freevm>
  return 0;
80100c3f:	83 c4 10             	add    $0x10,%esp
80100c42:	b8 00 00 00 00       	mov    $0x0,%eax
80100c47:	e9 2e fd ff ff       	jmp    8010097a <exec+0x68>
  ip = 0;
80100c4c:	bb 00 00 00 00       	mov    $0x0,%ebx
80100c51:	e9 85 fe ff ff       	jmp    80100adb <exec+0x1c9>
80100c56:	bb 00 00 00 00       	mov    $0x0,%ebx
80100c5b:	e9 7b fe ff ff       	jmp    80100adb <exec+0x1c9>

80100c60 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100c60:	55                   	push   %ebp
80100c61:	89 e5                	mov    %esp,%ebp
80100c63:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100c66:	68 8d 68 10 80       	push   $0x8010688d
80100c6b:	68 e0 ff 10 80       	push   $0x8010ffe0
80100c70:	e8 95 31 00 00       	call   80103e0a <initlock>
}
80100c75:	83 c4 10             	add    $0x10,%esp
80100c78:	c9                   	leave  
80100c79:	c3                   	ret    

80100c7a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100c7a:	55                   	push   %ebp
80100c7b:	89 e5                	mov    %esp,%ebp
80100c7d:	53                   	push   %ebx
80100c7e:	83 ec 10             	sub    $0x10,%esp
  struct file *f;

  acquire(&ftable.lock);
80100c81:	68 e0 ff 10 80       	push   $0x8010ffe0
80100c86:	e8 c7 32 00 00       	call   80103f52 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    if(f->ref == 0){
80100c8b:	83 c4 10             	add    $0x10,%esp
80100c8e:	83 3d 18 00 11 80 00 	cmpl   $0x0,0x80110018
80100c95:	74 2d                	je     80100cc4 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100c97:	bb 2c 00 11 80       	mov    $0x8011002c,%ebx
    if(f->ref == 0){
80100c9c:	83 7b 04 00          	cmpl   $0x0,0x4(%ebx)
80100ca0:	74 27                	je     80100cc9 <filealloc+0x4f>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100ca2:	83 c3 18             	add    $0x18,%ebx
80100ca5:	81 fb 74 09 11 80    	cmp    $0x80110974,%ebx
80100cab:	72 ef                	jb     80100c9c <filealloc+0x22>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
80100cad:	83 ec 0c             	sub    $0xc,%esp
80100cb0:	68 e0 ff 10 80       	push   $0x8010ffe0
80100cb5:	e8 ff 32 00 00       	call   80103fb9 <release>
  return 0;
80100cba:	83 c4 10             	add    $0x10,%esp
80100cbd:	bb 00 00 00 00       	mov    $0x0,%ebx
80100cc2:	eb 1c                	jmp    80100ce0 <filealloc+0x66>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100cc4:	bb 14 00 11 80       	mov    $0x80110014,%ebx
      f->ref = 1;
80100cc9:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100cd0:	83 ec 0c             	sub    $0xc,%esp
80100cd3:	68 e0 ff 10 80       	push   $0x8010ffe0
80100cd8:	e8 dc 32 00 00       	call   80103fb9 <release>
      return f;
80100cdd:	83 c4 10             	add    $0x10,%esp
}
80100ce0:	89 d8                	mov    %ebx,%eax
80100ce2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100ce5:	c9                   	leave  
80100ce6:	c3                   	ret    

80100ce7 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100ce7:	55                   	push   %ebp
80100ce8:	89 e5                	mov    %esp,%ebp
80100cea:	53                   	push   %ebx
80100ceb:	83 ec 10             	sub    $0x10,%esp
80100cee:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100cf1:	68 e0 ff 10 80       	push   $0x8010ffe0
80100cf6:	e8 57 32 00 00       	call   80103f52 <acquire>
  if(f->ref < 1)
80100cfb:	8b 43 04             	mov    0x4(%ebx),%eax
80100cfe:	83 c4 10             	add    $0x10,%esp
80100d01:	85 c0                	test   %eax,%eax
80100d03:	7e 1a                	jle    80100d1f <filedup+0x38>
    panic("filedup");
  f->ref++;
80100d05:	83 c0 01             	add    $0x1,%eax
80100d08:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100d0b:	83 ec 0c             	sub    $0xc,%esp
80100d0e:	68 e0 ff 10 80       	push   $0x8010ffe0
80100d13:	e8 a1 32 00 00       	call   80103fb9 <release>
  return f;
}
80100d18:	89 d8                	mov    %ebx,%eax
80100d1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100d1d:	c9                   	leave  
80100d1e:	c3                   	ret    
    panic("filedup");
80100d1f:	83 ec 0c             	sub    $0xc,%esp
80100d22:	68 94 68 10 80       	push   $0x80106894
80100d27:	e8 18 f6 ff ff       	call   80100344 <panic>

80100d2c <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100d2c:	55                   	push   %ebp
80100d2d:	89 e5                	mov    %esp,%ebp
80100d2f:	57                   	push   %edi
80100d30:	56                   	push   %esi
80100d31:	53                   	push   %ebx
80100d32:	83 ec 28             	sub    $0x28,%esp
80100d35:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80100d38:	68 e0 ff 10 80       	push   $0x8010ffe0
80100d3d:	e8 10 32 00 00       	call   80103f52 <acquire>
  if(f->ref < 1)
80100d42:	8b 43 04             	mov    0x4(%ebx),%eax
80100d45:	83 c4 10             	add    $0x10,%esp
80100d48:	85 c0                	test   %eax,%eax
80100d4a:	7e 22                	jle    80100d6e <fileclose+0x42>
    panic("fileclose");
  if(--f->ref > 0){
80100d4c:	83 e8 01             	sub    $0x1,%eax
80100d4f:	89 43 04             	mov    %eax,0x4(%ebx)
80100d52:	85 c0                	test   %eax,%eax
80100d54:	7e 25                	jle    80100d7b <fileclose+0x4f>
    release(&ftable.lock);
80100d56:	83 ec 0c             	sub    $0xc,%esp
80100d59:	68 e0 ff 10 80       	push   $0x8010ffe0
80100d5e:	e8 56 32 00 00       	call   80103fb9 <release>
80100d63:	83 c4 10             	add    $0x10,%esp
  else if(ff.type == FD_INODE){
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100d66:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100d69:	5b                   	pop    %ebx
80100d6a:	5e                   	pop    %esi
80100d6b:	5f                   	pop    %edi
80100d6c:	5d                   	pop    %ebp
80100d6d:	c3                   	ret    
    panic("fileclose");
80100d6e:	83 ec 0c             	sub    $0xc,%esp
80100d71:	68 9c 68 10 80       	push   $0x8010689c
80100d76:	e8 c9 f5 ff ff       	call   80100344 <panic>
  ff = *f;
80100d7b:	8b 33                	mov    (%ebx),%esi
80100d7d:	0f b6 43 09          	movzbl 0x9(%ebx),%eax
80100d81:	88 45 e7             	mov    %al,-0x19(%ebp)
80100d84:	8b 7b 0c             	mov    0xc(%ebx),%edi
80100d87:	8b 43 10             	mov    0x10(%ebx),%eax
80100d8a:	89 45 e0             	mov    %eax,-0x20(%ebp)
  f->ref = 0;
80100d8d:	c7 43 04 00 00 00 00 	movl   $0x0,0x4(%ebx)
  f->type = FD_NONE;
80100d94:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  release(&ftable.lock);
80100d9a:	83 ec 0c             	sub    $0xc,%esp
80100d9d:	68 e0 ff 10 80       	push   $0x8010ffe0
80100da2:	e8 12 32 00 00       	call   80103fb9 <release>
  if(ff.type == FD_PIPE)
80100da7:	83 c4 10             	add    $0x10,%esp
80100daa:	83 fe 01             	cmp    $0x1,%esi
80100dad:	74 1f                	je     80100dce <fileclose+0xa2>
  else if(ff.type == FD_INODE){
80100daf:	83 fe 02             	cmp    $0x2,%esi
80100db2:	75 b2                	jne    80100d66 <fileclose+0x3a>
    begin_op();
80100db4:	e8 f4 19 00 00       	call   801027ad <begin_op>
    iput(ff.ip);
80100db9:	83 ec 0c             	sub    $0xc,%esp
80100dbc:	ff 75 e0             	pushl  -0x20(%ebp)
80100dbf:	e8 29 08 00 00       	call   801015ed <iput>
    end_op();
80100dc4:	e8 5f 1a 00 00       	call   80102828 <end_op>
80100dc9:	83 c4 10             	add    $0x10,%esp
80100dcc:	eb 98                	jmp    80100d66 <fileclose+0x3a>
    pipeclose(ff.pipe, ff.writable);
80100dce:	83 ec 08             	sub    $0x8,%esp
80100dd1:	0f be 45 e7          	movsbl -0x19(%ebp),%eax
80100dd5:	50                   	push   %eax
80100dd6:	57                   	push   %edi
80100dd7:	e8 fe 20 00 00       	call   80102eda <pipeclose>
80100ddc:	83 c4 10             	add    $0x10,%esp
80100ddf:	eb 85                	jmp    80100d66 <fileclose+0x3a>

80100de1 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80100de1:	55                   	push   %ebp
80100de2:	89 e5                	mov    %esp,%ebp
80100de4:	53                   	push   %ebx
80100de5:	83 ec 04             	sub    $0x4,%esp
80100de8:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80100deb:	83 3b 02             	cmpl   $0x2,(%ebx)
80100dee:	75 31                	jne    80100e21 <filestat+0x40>
    ilock(f->ip);
80100df0:	83 ec 0c             	sub    $0xc,%esp
80100df3:	ff 73 10             	pushl  0x10(%ebx)
80100df6:	e8 eb 06 00 00       	call   801014e6 <ilock>
    stati(f->ip, st);
80100dfb:	83 c4 08             	add    $0x8,%esp
80100dfe:	ff 75 0c             	pushl  0xc(%ebp)
80100e01:	ff 73 10             	pushl  0x10(%ebx)
80100e04:	e8 46 09 00 00       	call   8010174f <stati>
    iunlock(f->ip);
80100e09:	83 c4 04             	add    $0x4,%esp
80100e0c:	ff 73 10             	pushl  0x10(%ebx)
80100e0f:	e8 94 07 00 00       	call   801015a8 <iunlock>
    return 0;
80100e14:	83 c4 10             	add    $0x10,%esp
80100e17:	b8 00 00 00 00       	mov    $0x0,%eax
  }
  return -1;
}
80100e1c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100e1f:	c9                   	leave  
80100e20:	c3                   	ret    
  return -1;
80100e21:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100e26:	eb f4                	jmp    80100e1c <filestat+0x3b>

80100e28 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80100e28:	55                   	push   %ebp
80100e29:	89 e5                	mov    %esp,%ebp
80100e2b:	56                   	push   %esi
80100e2c:	53                   	push   %ebx
80100e2d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;

  if(f->readable == 0)
80100e30:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80100e34:	74 70                	je     80100ea6 <fileread+0x7e>
    return -1;
  if(f->type == FD_PIPE)
80100e36:	8b 03                	mov    (%ebx),%eax
80100e38:	83 f8 01             	cmp    $0x1,%eax
80100e3b:	74 44                	je     80100e81 <fileread+0x59>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100e3d:	83 f8 02             	cmp    $0x2,%eax
80100e40:	75 57                	jne    80100e99 <fileread+0x71>
    ilock(f->ip);
80100e42:	83 ec 0c             	sub    $0xc,%esp
80100e45:	ff 73 10             	pushl  0x10(%ebx)
80100e48:	e8 99 06 00 00       	call   801014e6 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80100e4d:	ff 75 10             	pushl  0x10(%ebp)
80100e50:	ff 73 14             	pushl  0x14(%ebx)
80100e53:	ff 75 0c             	pushl  0xc(%ebp)
80100e56:	ff 73 10             	pushl  0x10(%ebx)
80100e59:	e8 1c 09 00 00       	call   8010177a <readi>
80100e5e:	89 c6                	mov    %eax,%esi
80100e60:	83 c4 20             	add    $0x20,%esp
80100e63:	85 c0                	test   %eax,%eax
80100e65:	7e 03                	jle    80100e6a <fileread+0x42>
      f->off += r;
80100e67:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80100e6a:	83 ec 0c             	sub    $0xc,%esp
80100e6d:	ff 73 10             	pushl  0x10(%ebx)
80100e70:	e8 33 07 00 00       	call   801015a8 <iunlock>
    return r;
80100e75:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80100e78:	89 f0                	mov    %esi,%eax
80100e7a:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100e7d:	5b                   	pop    %ebx
80100e7e:	5e                   	pop    %esi
80100e7f:	5d                   	pop    %ebp
80100e80:	c3                   	ret    
    return piperead(f->pipe, addr, n);
80100e81:	83 ec 04             	sub    $0x4,%esp
80100e84:	ff 75 10             	pushl  0x10(%ebp)
80100e87:	ff 75 0c             	pushl  0xc(%ebp)
80100e8a:	ff 73 0c             	pushl  0xc(%ebx)
80100e8d:	e8 cd 21 00 00       	call   8010305f <piperead>
80100e92:	89 c6                	mov    %eax,%esi
80100e94:	83 c4 10             	add    $0x10,%esp
80100e97:	eb df                	jmp    80100e78 <fileread+0x50>
  panic("fileread");
80100e99:	83 ec 0c             	sub    $0xc,%esp
80100e9c:	68 a6 68 10 80       	push   $0x801068a6
80100ea1:	e8 9e f4 ff ff       	call   80100344 <panic>
    return -1;
80100ea6:	be ff ff ff ff       	mov    $0xffffffff,%esi
80100eab:	eb cb                	jmp    80100e78 <fileread+0x50>

80100ead <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80100ead:	55                   	push   %ebp
80100eae:	89 e5                	mov    %esp,%ebp
80100eb0:	57                   	push   %edi
80100eb1:	56                   	push   %esi
80100eb2:	53                   	push   %ebx
80100eb3:	83 ec 1c             	sub    $0x1c,%esp
80100eb6:	8b 75 08             	mov    0x8(%ebp),%esi
  int r;

  if(f->writable == 0)
80100eb9:	80 7e 09 00          	cmpb   $0x0,0x9(%esi)
80100ebd:	0f 84 e8 00 00 00    	je     80100fab <filewrite+0xfe>
    return -1;
  if(f->type == FD_PIPE)
80100ec3:	8b 06                	mov    (%esi),%eax
80100ec5:	83 f8 01             	cmp    $0x1,%eax
80100ec8:	74 1a                	je     80100ee4 <filewrite+0x37>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100eca:	83 f8 02             	cmp    $0x2,%eax
80100ecd:	0f 85 cb 00 00 00    	jne    80100f9e <filewrite+0xf1>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80100ed3:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80100ed7:	0f 8e 9e 00 00 00    	jle    80100f7b <filewrite+0xce>
    int i = 0;
80100edd:	bf 00 00 00 00       	mov    $0x0,%edi
80100ee2:	eb 3f                	jmp    80100f23 <filewrite+0x76>
    return pipewrite(f->pipe, addr, n);
80100ee4:	83 ec 04             	sub    $0x4,%esp
80100ee7:	ff 75 10             	pushl  0x10(%ebp)
80100eea:	ff 75 0c             	pushl  0xc(%ebp)
80100eed:	ff 76 0c             	pushl  0xc(%esi)
80100ef0:	e8 71 20 00 00       	call   80102f66 <pipewrite>
80100ef5:	89 45 10             	mov    %eax,0x10(%ebp)
80100ef8:	83 c4 10             	add    $0x10,%esp
80100efb:	e9 93 00 00 00       	jmp    80100f93 <filewrite+0xe6>

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
      iunlock(f->ip);
80100f00:	83 ec 0c             	sub    $0xc,%esp
80100f03:	ff 76 10             	pushl  0x10(%esi)
80100f06:	e8 9d 06 00 00       	call   801015a8 <iunlock>
      end_op();
80100f0b:	e8 18 19 00 00       	call   80102828 <end_op>

      if(r < 0)
80100f10:	83 c4 10             	add    $0x10,%esp
80100f13:	85 db                	test   %ebx,%ebx
80100f15:	78 6b                	js     80100f82 <filewrite+0xd5>
        break;
      if(r != n1)
80100f17:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
80100f1a:	75 4e                	jne    80100f6a <filewrite+0xbd>
        panic("short filewrite");
      i += r;
80100f1c:	01 df                	add    %ebx,%edi
    while(i < n){
80100f1e:	39 7d 10             	cmp    %edi,0x10(%ebp)
80100f21:	7e 54                	jle    80100f77 <filewrite+0xca>
      int n1 = n - i;
80100f23:	8b 45 10             	mov    0x10(%ebp),%eax
80100f26:	29 f8                	sub    %edi,%eax
80100f28:	3d 00 06 00 00       	cmp    $0x600,%eax
80100f2d:	ba 00 06 00 00       	mov    $0x600,%edx
80100f32:	0f 4f c2             	cmovg  %edx,%eax
80100f35:	89 c3                	mov    %eax,%ebx
80100f37:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      begin_op();
80100f3a:	e8 6e 18 00 00       	call   801027ad <begin_op>
      ilock(f->ip);
80100f3f:	83 ec 0c             	sub    $0xc,%esp
80100f42:	ff 76 10             	pushl  0x10(%esi)
80100f45:	e8 9c 05 00 00       	call   801014e6 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80100f4a:	53                   	push   %ebx
80100f4b:	ff 76 14             	pushl  0x14(%esi)
80100f4e:	89 f8                	mov    %edi,%eax
80100f50:	03 45 0c             	add    0xc(%ebp),%eax
80100f53:	50                   	push   %eax
80100f54:	ff 76 10             	pushl  0x10(%esi)
80100f57:	e8 1a 09 00 00       	call   80101876 <writei>
80100f5c:	89 c3                	mov    %eax,%ebx
80100f5e:	83 c4 20             	add    $0x20,%esp
80100f61:	85 c0                	test   %eax,%eax
80100f63:	7e 9b                	jle    80100f00 <filewrite+0x53>
        f->off += r;
80100f65:	01 46 14             	add    %eax,0x14(%esi)
80100f68:	eb 96                	jmp    80100f00 <filewrite+0x53>
        panic("short filewrite");
80100f6a:	83 ec 0c             	sub    $0xc,%esp
80100f6d:	68 af 68 10 80       	push   $0x801068af
80100f72:	e8 cd f3 ff ff       	call   80100344 <panic>
80100f77:	89 f8                	mov    %edi,%eax
80100f79:	eb 09                	jmp    80100f84 <filewrite+0xd7>
    int i = 0;
80100f7b:	b8 00 00 00 00       	mov    $0x0,%eax
80100f80:	eb 02                	jmp    80100f84 <filewrite+0xd7>
80100f82:	89 f8                	mov    %edi,%eax
    }
    return i == n ? n : -1;
80100f84:	39 45 10             	cmp    %eax,0x10(%ebp)
80100f87:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100f8c:	0f 44 45 10          	cmove  0x10(%ebp),%eax
80100f90:	89 45 10             	mov    %eax,0x10(%ebp)
  }
  panic("filewrite");
}
80100f93:	8b 45 10             	mov    0x10(%ebp),%eax
80100f96:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100f99:	5b                   	pop    %ebx
80100f9a:	5e                   	pop    %esi
80100f9b:	5f                   	pop    %edi
80100f9c:	5d                   	pop    %ebp
80100f9d:	c3                   	ret    
  panic("filewrite");
80100f9e:	83 ec 0c             	sub    $0xc,%esp
80100fa1:	68 b5 68 10 80       	push   $0x801068b5
80100fa6:	e8 99 f3 ff ff       	call   80100344 <panic>
    return -1;
80100fab:	c7 45 10 ff ff ff ff 	movl   $0xffffffff,0x10(%ebp)
80100fb2:	eb df                	jmp    80100f93 <filewrite+0xe6>

80100fb4 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
80100fb4:	55                   	push   %ebp
80100fb5:	89 e5                	mov    %esp,%ebp
80100fb7:	56                   	push   %esi
80100fb8:	53                   	push   %ebx
80100fb9:	89 d3                	mov    %edx,%ebx
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
80100fbb:	83 ec 08             	sub    $0x8,%esp
80100fbe:	c1 ea 0c             	shr    $0xc,%edx
80100fc1:	03 15 f8 09 11 80    	add    0x801109f8,%edx
80100fc7:	52                   	push   %edx
80100fc8:	50                   	push   %eax
80100fc9:	e8 dc f0 ff ff       	call   801000aa <bread>
80100fce:	89 c6                	mov    %eax,%esi
  bi = b % BPB;
  m = 1 << (bi % 8);
80100fd0:	89 d9                	mov    %ebx,%ecx
80100fd2:	83 e1 07             	and    $0x7,%ecx
80100fd5:	b8 01 00 00 00       	mov    $0x1,%eax
80100fda:	d3 e0                	shl    %cl,%eax
  bi = b % BPB;
80100fdc:	81 e3 ff 0f 00 00    	and    $0xfff,%ebx
  if((bp->data[bi/8] & m) == 0)
80100fe2:	83 c4 10             	add    $0x10,%esp
80100fe5:	c1 fb 03             	sar    $0x3,%ebx
80100fe8:	0f b6 54 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%edx
80100fed:	0f b6 ca             	movzbl %dl,%ecx
80100ff0:	85 c1                	test   %eax,%ecx
80100ff2:	74 23                	je     80101017 <bfree+0x63>
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
80100ff4:	f7 d0                	not    %eax
80100ff6:	21 d0                	and    %edx,%eax
80100ff8:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
80100ffc:	83 ec 0c             	sub    $0xc,%esp
80100fff:	56                   	push   %esi
80101000:	e8 68 19 00 00       	call   8010296d <log_write>
  brelse(bp);
80101005:	89 34 24             	mov    %esi,(%esp)
80101008:	e8 b4 f1 ff ff       	call   801001c1 <brelse>
}
8010100d:	83 c4 10             	add    $0x10,%esp
80101010:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101013:	5b                   	pop    %ebx
80101014:	5e                   	pop    %esi
80101015:	5d                   	pop    %ebp
80101016:	c3                   	ret    
    panic("freeing free block");
80101017:	83 ec 0c             	sub    $0xc,%esp
8010101a:	68 bf 68 10 80       	push   $0x801068bf
8010101f:	e8 20 f3 ff ff       	call   80100344 <panic>

80101024 <balloc>:
{
80101024:	55                   	push   %ebp
80101025:	89 e5                	mov    %esp,%ebp
80101027:	57                   	push   %edi
80101028:	56                   	push   %esi
80101029:	53                   	push   %ebx
8010102a:	83 ec 2c             	sub    $0x2c,%esp
8010102d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101030:	83 3d e0 09 11 80 00 	cmpl   $0x0,0x801109e0
80101037:	0f 84 32 01 00 00    	je     8010116f <balloc+0x14b>
8010103d:	c7 45 d8 00 00 00 00 	movl   $0x0,-0x28(%ebp)
80101044:	e9 8f 00 00 00       	jmp    801010d8 <balloc+0xb4>
80101049:	89 c3                	mov    %eax,%ebx
        bp->data[bi/8] |= m;  // Mark block in use.
8010104b:	09 ca                	or     %ecx,%edx
8010104d:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101050:	88 54 03 5c          	mov    %dl,0x5c(%ebx,%eax,1)
        log_write(bp);
80101054:	83 ec 0c             	sub    $0xc,%esp
80101057:	53                   	push   %ebx
80101058:	e8 10 19 00 00       	call   8010296d <log_write>
        brelse(bp);
8010105d:	89 1c 24             	mov    %ebx,(%esp)
80101060:	e8 5c f1 ff ff       	call   801001c1 <brelse>
  bp = bread(dev, bno);
80101065:	83 c4 08             	add    $0x8,%esp
80101068:	ff 75 e4             	pushl  -0x1c(%ebp)
8010106b:	ff 75 d4             	pushl  -0x2c(%ebp)
8010106e:	e8 37 f0 ff ff       	call   801000aa <bread>
80101073:	89 c6                	mov    %eax,%esi
  memset(bp->data, 0, BSIZE);
80101075:	83 c4 0c             	add    $0xc,%esp
80101078:	68 00 02 00 00       	push   $0x200
8010107d:	6a 00                	push   $0x0
8010107f:	8d 40 5c             	lea    0x5c(%eax),%eax
80101082:	50                   	push   %eax
80101083:	e8 78 2f 00 00       	call   80104000 <memset>
  log_write(bp);
80101088:	89 34 24             	mov    %esi,(%esp)
8010108b:	e8 dd 18 00 00       	call   8010296d <log_write>
  brelse(bp);
80101090:	89 34 24             	mov    %esi,(%esp)
80101093:	e8 29 f1 ff ff       	call   801001c1 <brelse>
}
80101098:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010109b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010109e:	5b                   	pop    %ebx
8010109f:	5e                   	pop    %esi
801010a0:	5f                   	pop    %edi
801010a1:	5d                   	pop    %ebp
801010a2:	c3                   	ret    
801010a3:	89 c3                	mov    %eax,%ebx
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801010a5:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      m = 1 << (bi % 8);
801010a8:	b9 01 00 00 00       	mov    $0x1,%ecx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801010ad:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
801010b4:	eb 95                	jmp    8010104b <balloc+0x27>
    brelse(bp);
801010b6:	83 ec 0c             	sub    $0xc,%esp
801010b9:	50                   	push   %eax
801010ba:	e8 02 f1 ff ff       	call   801001c1 <brelse>
  for(b = 0; b < sb.size; b += BPB){
801010bf:	81 45 d8 00 10 00 00 	addl   $0x1000,-0x28(%ebp)
801010c6:	8b 45 d8             	mov    -0x28(%ebp),%eax
801010c9:	83 c4 10             	add    $0x10,%esp
801010cc:	39 05 e0 09 11 80    	cmp    %eax,0x801109e0
801010d2:	0f 86 97 00 00 00    	jbe    8010116f <balloc+0x14b>
    bp = bread(dev, BBLOCK(b, sb));
801010d8:	83 ec 08             	sub    $0x8,%esp
801010db:	8b 7d d8             	mov    -0x28(%ebp),%edi
801010de:	89 fb                	mov    %edi,%ebx
801010e0:	8d 87 ff 0f 00 00    	lea    0xfff(%edi),%eax
801010e6:	85 ff                	test   %edi,%edi
801010e8:	0f 49 c7             	cmovns %edi,%eax
801010eb:	c1 f8 0c             	sar    $0xc,%eax
801010ee:	03 05 f8 09 11 80    	add    0x801109f8,%eax
801010f4:	50                   	push   %eax
801010f5:	ff 75 d4             	pushl  -0x2c(%ebp)
801010f8:	e8 ad ef ff ff       	call   801000aa <bread>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801010fd:	8b 0d e0 09 11 80    	mov    0x801109e0,%ecx
80101103:	83 c4 10             	add    $0x10,%esp
80101106:	39 cf                	cmp    %ecx,%edi
80101108:	73 ac                	jae    801010b6 <balloc+0x92>
      if((bp->data[bi/8] & m) == 0){  // Is block free?
8010110a:	0f b6 50 5c          	movzbl 0x5c(%eax),%edx
8010110e:	f6 c2 01             	test   $0x1,%dl
80101111:	74 90                	je     801010a3 <balloc+0x7f>
80101113:	29 f9                	sub    %edi,%ecx
80101115:	89 4d e0             	mov    %ecx,-0x20(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
80101118:	be 01 00 00 00       	mov    $0x1,%esi
8010111d:	8d 3c 1e             	lea    (%esi,%ebx,1),%edi
80101120:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80101123:	3b 75 e0             	cmp    -0x20(%ebp),%esi
80101126:	74 8e                	je     801010b6 <balloc+0x92>
      m = 1 << (bi % 8);
80101128:	89 f2                	mov    %esi,%edx
8010112a:	c1 fa 1f             	sar    $0x1f,%edx
8010112d:	c1 ea 1d             	shr    $0x1d,%edx
80101130:	8d 0c 16             	lea    (%esi,%edx,1),%ecx
80101133:	83 e1 07             	and    $0x7,%ecx
80101136:	29 d1                	sub    %edx,%ecx
80101138:	bf 01 00 00 00       	mov    $0x1,%edi
8010113d:	d3 e7                	shl    %cl,%edi
8010113f:	89 f9                	mov    %edi,%ecx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101141:	8d 56 07             	lea    0x7(%esi),%edx
80101144:	85 f6                	test   %esi,%esi
80101146:	0f 49 d6             	cmovns %esi,%edx
80101149:	c1 fa 03             	sar    $0x3,%edx
8010114c:	89 55 dc             	mov    %edx,-0x24(%ebp)
8010114f:	0f b6 54 10 5c       	movzbl 0x5c(%eax,%edx,1),%edx
80101154:	0f b6 fa             	movzbl %dl,%edi
80101157:	85 cf                	test   %ecx,%edi
80101159:	0f 84 ea fe ff ff    	je     80101049 <balloc+0x25>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010115f:	83 c6 01             	add    $0x1,%esi
80101162:	81 fe 00 10 00 00    	cmp    $0x1000,%esi
80101168:	75 b3                	jne    8010111d <balloc+0xf9>
8010116a:	e9 47 ff ff ff       	jmp    801010b6 <balloc+0x92>
  panic("balloc: out of blocks");
8010116f:	83 ec 0c             	sub    $0xc,%esp
80101172:	68 d2 68 10 80       	push   $0x801068d2
80101177:	e8 c8 f1 ff ff       	call   80100344 <panic>

8010117c <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
8010117c:	55                   	push   %ebp
8010117d:	89 e5                	mov    %esp,%ebp
8010117f:	57                   	push   %edi
80101180:	56                   	push   %esi
80101181:	53                   	push   %ebx
80101182:	83 ec 1c             	sub    $0x1c,%esp
80101185:	89 c6                	mov    %eax,%esi
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
80101187:	83 fa 0b             	cmp    $0xb,%edx
8010118a:	77 18                	ja     801011a4 <bmap+0x28>
8010118c:	8d 3c 90             	lea    (%eax,%edx,4),%edi
    if((addr = ip->addrs[bn]) == 0)
8010118f:	8b 5f 5c             	mov    0x5c(%edi),%ebx
80101192:	85 db                	test   %ebx,%ebx
80101194:	75 49                	jne    801011df <bmap+0x63>
      ip->addrs[bn] = addr = balloc(ip->dev);
80101196:	8b 00                	mov    (%eax),%eax
80101198:	e8 87 fe ff ff       	call   80101024 <balloc>
8010119d:	89 c3                	mov    %eax,%ebx
8010119f:	89 47 5c             	mov    %eax,0x5c(%edi)
801011a2:	eb 3b                	jmp    801011df <bmap+0x63>
    return addr;
  }
  bn -= NDIRECT;
801011a4:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
801011a7:	83 fb 7f             	cmp    $0x7f,%ebx
801011aa:	77 68                	ja     80101214 <bmap+0x98>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
801011ac:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
801011b2:	85 c0                	test   %eax,%eax
801011b4:	74 33                	je     801011e9 <bmap+0x6d>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
801011b6:	83 ec 08             	sub    $0x8,%esp
801011b9:	50                   	push   %eax
801011ba:	ff 36                	pushl  (%esi)
801011bc:	e8 e9 ee ff ff       	call   801000aa <bread>
801011c1:	89 c7                	mov    %eax,%edi
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
801011c3:	8d 44 98 5c          	lea    0x5c(%eax,%ebx,4),%eax
801011c7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801011ca:	8b 18                	mov    (%eax),%ebx
801011cc:	83 c4 10             	add    $0x10,%esp
801011cf:	85 db                	test   %ebx,%ebx
801011d1:	74 25                	je     801011f8 <bmap+0x7c>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
801011d3:	83 ec 0c             	sub    $0xc,%esp
801011d6:	57                   	push   %edi
801011d7:	e8 e5 ef ff ff       	call   801001c1 <brelse>
    return addr;
801011dc:	83 c4 10             	add    $0x10,%esp
  }

  panic("bmap: out of range");
}
801011df:	89 d8                	mov    %ebx,%eax
801011e1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801011e4:	5b                   	pop    %ebx
801011e5:	5e                   	pop    %esi
801011e6:	5f                   	pop    %edi
801011e7:	5d                   	pop    %ebp
801011e8:	c3                   	ret    
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801011e9:	8b 06                	mov    (%esi),%eax
801011eb:	e8 34 fe ff ff       	call   80101024 <balloc>
801011f0:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
801011f6:	eb be                	jmp    801011b6 <bmap+0x3a>
      a[bn] = addr = balloc(ip->dev);
801011f8:	8b 06                	mov    (%esi),%eax
801011fa:	e8 25 fe ff ff       	call   80101024 <balloc>
801011ff:	89 c3                	mov    %eax,%ebx
80101201:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101204:	89 18                	mov    %ebx,(%eax)
      log_write(bp);
80101206:	83 ec 0c             	sub    $0xc,%esp
80101209:	57                   	push   %edi
8010120a:	e8 5e 17 00 00       	call   8010296d <log_write>
8010120f:	83 c4 10             	add    $0x10,%esp
80101212:	eb bf                	jmp    801011d3 <bmap+0x57>
  panic("bmap: out of range");
80101214:	83 ec 0c             	sub    $0xc,%esp
80101217:	68 e8 68 10 80       	push   $0x801068e8
8010121c:	e8 23 f1 ff ff       	call   80100344 <panic>

80101221 <iget>:
{
80101221:	55                   	push   %ebp
80101222:	89 e5                	mov    %esp,%ebp
80101224:	57                   	push   %edi
80101225:	56                   	push   %esi
80101226:	53                   	push   %ebx
80101227:	83 ec 28             	sub    $0x28,%esp
8010122a:	89 c7                	mov    %eax,%edi
8010122c:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  acquire(&icache.lock);
8010122f:	68 00 0a 11 80       	push   $0x80110a00
80101234:	e8 19 2d 00 00       	call   80103f52 <acquire>
80101239:	83 c4 10             	add    $0x10,%esp
  empty = 0;
8010123c:	be 00 00 00 00       	mov    $0x0,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101241:	bb 34 0a 11 80       	mov    $0x80110a34,%ebx
80101246:	eb 1c                	jmp    80101264 <iget+0x43>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101248:	85 c0                	test   %eax,%eax
8010124a:	75 0a                	jne    80101256 <iget+0x35>
8010124c:	85 f6                	test   %esi,%esi
8010124e:	0f 94 c0             	sete   %al
80101251:	84 c0                	test   %al,%al
80101253:	0f 45 f3             	cmovne %ebx,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101256:	81 c3 90 00 00 00    	add    $0x90,%ebx
8010125c:	81 fb 54 26 11 80    	cmp    $0x80112654,%ebx
80101262:	73 2d                	jae    80101291 <iget+0x70>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101264:	8b 43 08             	mov    0x8(%ebx),%eax
80101267:	85 c0                	test   %eax,%eax
80101269:	7e dd                	jle    80101248 <iget+0x27>
8010126b:	39 3b                	cmp    %edi,(%ebx)
8010126d:	75 e7                	jne    80101256 <iget+0x35>
8010126f:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101272:	39 4b 04             	cmp    %ecx,0x4(%ebx)
80101275:	75 df                	jne    80101256 <iget+0x35>
      ip->ref++;
80101277:	83 c0 01             	add    $0x1,%eax
8010127a:	89 43 08             	mov    %eax,0x8(%ebx)
      release(&icache.lock);
8010127d:	83 ec 0c             	sub    $0xc,%esp
80101280:	68 00 0a 11 80       	push   $0x80110a00
80101285:	e8 2f 2d 00 00       	call   80103fb9 <release>
      return ip;
8010128a:	83 c4 10             	add    $0x10,%esp
8010128d:	89 de                	mov    %ebx,%esi
8010128f:	eb 2a                	jmp    801012bb <iget+0x9a>
  if(empty == 0)
80101291:	85 f6                	test   %esi,%esi
80101293:	74 30                	je     801012c5 <iget+0xa4>
  ip->dev = dev;
80101295:	89 3e                	mov    %edi,(%esi)
  ip->inum = inum;
80101297:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010129a:	89 46 04             	mov    %eax,0x4(%esi)
  ip->ref = 1;
8010129d:	c7 46 08 01 00 00 00 	movl   $0x1,0x8(%esi)
  ip->valid = 0;
801012a4:	c7 46 4c 00 00 00 00 	movl   $0x0,0x4c(%esi)
  release(&icache.lock);
801012ab:	83 ec 0c             	sub    $0xc,%esp
801012ae:	68 00 0a 11 80       	push   $0x80110a00
801012b3:	e8 01 2d 00 00       	call   80103fb9 <release>
  return ip;
801012b8:	83 c4 10             	add    $0x10,%esp
}
801012bb:	89 f0                	mov    %esi,%eax
801012bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801012c0:	5b                   	pop    %ebx
801012c1:	5e                   	pop    %esi
801012c2:	5f                   	pop    %edi
801012c3:	5d                   	pop    %ebp
801012c4:	c3                   	ret    
    panic("iget: no inodes");
801012c5:	83 ec 0c             	sub    $0xc,%esp
801012c8:	68 fb 68 10 80       	push   $0x801068fb
801012cd:	e8 72 f0 ff ff       	call   80100344 <panic>

801012d2 <readsb>:
{
801012d2:	55                   	push   %ebp
801012d3:	89 e5                	mov    %esp,%ebp
801012d5:	53                   	push   %ebx
801012d6:	83 ec 0c             	sub    $0xc,%esp
  bp = bread(dev, 1);
801012d9:	6a 01                	push   $0x1
801012db:	ff 75 08             	pushl  0x8(%ebp)
801012de:	e8 c7 ed ff ff       	call   801000aa <bread>
801012e3:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
801012e5:	83 c4 0c             	add    $0xc,%esp
801012e8:	6a 1c                	push   $0x1c
801012ea:	8d 40 5c             	lea    0x5c(%eax),%eax
801012ed:	50                   	push   %eax
801012ee:	ff 75 0c             	pushl  0xc(%ebp)
801012f1:	e8 9f 2d 00 00       	call   80104095 <memmove>
  brelse(bp);
801012f6:	89 1c 24             	mov    %ebx,(%esp)
801012f9:	e8 c3 ee ff ff       	call   801001c1 <brelse>
}
801012fe:	83 c4 10             	add    $0x10,%esp
80101301:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101304:	c9                   	leave  
80101305:	c3                   	ret    

80101306 <iinit>:
{
80101306:	55                   	push   %ebp
80101307:	89 e5                	mov    %esp,%ebp
80101309:	56                   	push   %esi
8010130a:	53                   	push   %ebx
  initlock(&icache.lock, "icache");
8010130b:	83 ec 08             	sub    $0x8,%esp
8010130e:	68 0b 69 10 80       	push   $0x8010690b
80101313:	68 00 0a 11 80       	push   $0x80110a00
80101318:	e8 ed 2a 00 00       	call   80103e0a <initlock>
8010131d:	bb 40 0a 11 80       	mov    $0x80110a40,%ebx
80101322:	be 60 26 11 80       	mov    $0x80112660,%esi
80101327:	83 c4 10             	add    $0x10,%esp
    initsleeplock(&icache.inode[i].lock, "inode");
8010132a:	83 ec 08             	sub    $0x8,%esp
8010132d:	68 12 69 10 80       	push   $0x80106912
80101332:	53                   	push   %ebx
80101333:	e8 c8 29 00 00       	call   80103d00 <initsleeplock>
80101338:	81 c3 90 00 00 00    	add    $0x90,%ebx
  for(i = 0; i < NINODE; i++) {
8010133e:	83 c4 10             	add    $0x10,%esp
80101341:	39 f3                	cmp    %esi,%ebx
80101343:	75 e5                	jne    8010132a <iinit+0x24>
  readsb(dev, &sb);
80101345:	83 ec 08             	sub    $0x8,%esp
80101348:	68 e0 09 11 80       	push   $0x801109e0
8010134d:	ff 75 08             	pushl  0x8(%ebp)
80101350:	e8 7d ff ff ff       	call   801012d2 <readsb>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
80101355:	ff 35 f8 09 11 80    	pushl  0x801109f8
8010135b:	ff 35 f4 09 11 80    	pushl  0x801109f4
80101361:	ff 35 f0 09 11 80    	pushl  0x801109f0
80101367:	ff 35 ec 09 11 80    	pushl  0x801109ec
8010136d:	ff 35 e8 09 11 80    	pushl  0x801109e8
80101373:	ff 35 e4 09 11 80    	pushl  0x801109e4
80101379:	ff 35 e0 09 11 80    	pushl  0x801109e0
8010137f:	68 78 69 10 80       	push   $0x80106978
80101384:	e8 58 f2 ff ff       	call   801005e1 <cprintf>
}
80101389:	83 c4 30             	add    $0x30,%esp
8010138c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010138f:	5b                   	pop    %ebx
80101390:	5e                   	pop    %esi
80101391:	5d                   	pop    %ebp
80101392:	c3                   	ret    

80101393 <ialloc>:
{
80101393:	55                   	push   %ebp
80101394:	89 e5                	mov    %esp,%ebp
80101396:	57                   	push   %edi
80101397:	56                   	push   %esi
80101398:	53                   	push   %ebx
80101399:	83 ec 1c             	sub    $0x1c,%esp
8010139c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010139f:	89 45 e0             	mov    %eax,-0x20(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
801013a2:	83 3d e8 09 11 80 01 	cmpl   $0x1,0x801109e8
801013a9:	76 4d                	jbe    801013f8 <ialloc+0x65>
801013ab:	bb 01 00 00 00       	mov    $0x1,%ebx
801013b0:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
    bp = bread(dev, IBLOCK(inum, sb));
801013b3:	83 ec 08             	sub    $0x8,%esp
801013b6:	89 d8                	mov    %ebx,%eax
801013b8:	c1 e8 03             	shr    $0x3,%eax
801013bb:	03 05 f4 09 11 80    	add    0x801109f4,%eax
801013c1:	50                   	push   %eax
801013c2:	ff 75 08             	pushl  0x8(%ebp)
801013c5:	e8 e0 ec ff ff       	call   801000aa <bread>
801013ca:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + inum%IPB;
801013cc:	89 d8                	mov    %ebx,%eax
801013ce:	83 e0 07             	and    $0x7,%eax
801013d1:	c1 e0 06             	shl    $0x6,%eax
801013d4:	8d 7c 06 5c          	lea    0x5c(%esi,%eax,1),%edi
    if(dip->type == 0){  // a free inode
801013d8:	83 c4 10             	add    $0x10,%esp
801013db:	66 83 3f 00          	cmpw   $0x0,(%edi)
801013df:	74 24                	je     80101405 <ialloc+0x72>
    brelse(bp);
801013e1:	83 ec 0c             	sub    $0xc,%esp
801013e4:	56                   	push   %esi
801013e5:	e8 d7 ed ff ff       	call   801001c1 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
801013ea:	83 c3 01             	add    $0x1,%ebx
801013ed:	83 c4 10             	add    $0x10,%esp
801013f0:	39 1d e8 09 11 80    	cmp    %ebx,0x801109e8
801013f6:	77 b8                	ja     801013b0 <ialloc+0x1d>
  panic("ialloc: no inodes");
801013f8:	83 ec 0c             	sub    $0xc,%esp
801013fb:	68 18 69 10 80       	push   $0x80106918
80101400:	e8 3f ef ff ff       	call   80100344 <panic>
      memset(dip, 0, sizeof(*dip));
80101405:	83 ec 04             	sub    $0x4,%esp
80101408:	6a 40                	push   $0x40
8010140a:	6a 00                	push   $0x0
8010140c:	57                   	push   %edi
8010140d:	e8 ee 2b 00 00       	call   80104000 <memset>
      dip->type = type;
80101412:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
80101416:	66 89 07             	mov    %ax,(%edi)
      log_write(bp);   // mark it allocated on the disk
80101419:	89 34 24             	mov    %esi,(%esp)
8010141c:	e8 4c 15 00 00       	call   8010296d <log_write>
      brelse(bp);
80101421:	89 34 24             	mov    %esi,(%esp)
80101424:	e8 98 ed ff ff       	call   801001c1 <brelse>
      return iget(dev, inum);
80101429:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010142c:	8b 45 08             	mov    0x8(%ebp),%eax
8010142f:	e8 ed fd ff ff       	call   80101221 <iget>
}
80101434:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101437:	5b                   	pop    %ebx
80101438:	5e                   	pop    %esi
80101439:	5f                   	pop    %edi
8010143a:	5d                   	pop    %ebp
8010143b:	c3                   	ret    

8010143c <iupdate>:
{
8010143c:	55                   	push   %ebp
8010143d:	89 e5                	mov    %esp,%ebp
8010143f:	56                   	push   %esi
80101440:	53                   	push   %ebx
80101441:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80101444:	83 ec 08             	sub    $0x8,%esp
80101447:	8b 43 04             	mov    0x4(%ebx),%eax
8010144a:	c1 e8 03             	shr    $0x3,%eax
8010144d:	03 05 f4 09 11 80    	add    0x801109f4,%eax
80101453:	50                   	push   %eax
80101454:	ff 33                	pushl  (%ebx)
80101456:	e8 4f ec ff ff       	call   801000aa <bread>
8010145b:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
8010145d:	8b 43 04             	mov    0x4(%ebx),%eax
80101460:	83 e0 07             	and    $0x7,%eax
80101463:	c1 e0 06             	shl    $0x6,%eax
80101466:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
  dip->type = ip->type;
8010146a:	0f b7 53 50          	movzwl 0x50(%ebx),%edx
8010146e:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
80101471:	0f b7 53 52          	movzwl 0x52(%ebx),%edx
80101475:	66 89 50 02          	mov    %dx,0x2(%eax)
  dip->minor = ip->minor;
80101479:	0f b7 53 54          	movzwl 0x54(%ebx),%edx
8010147d:	66 89 50 04          	mov    %dx,0x4(%eax)
  dip->nlink = ip->nlink;
80101481:	0f b7 53 56          	movzwl 0x56(%ebx),%edx
80101485:	66 89 50 06          	mov    %dx,0x6(%eax)
  dip->size = ip->size;
80101489:	8b 53 58             	mov    0x58(%ebx),%edx
8010148c:	89 50 08             	mov    %edx,0x8(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010148f:	83 c4 0c             	add    $0xc,%esp
80101492:	6a 34                	push   $0x34
80101494:	83 c3 5c             	add    $0x5c,%ebx
80101497:	53                   	push   %ebx
80101498:	83 c0 0c             	add    $0xc,%eax
8010149b:	50                   	push   %eax
8010149c:	e8 f4 2b 00 00       	call   80104095 <memmove>
  log_write(bp);
801014a1:	89 34 24             	mov    %esi,(%esp)
801014a4:	e8 c4 14 00 00       	call   8010296d <log_write>
  brelse(bp);
801014a9:	89 34 24             	mov    %esi,(%esp)
801014ac:	e8 10 ed ff ff       	call   801001c1 <brelse>
}
801014b1:	83 c4 10             	add    $0x10,%esp
801014b4:	8d 65 f8             	lea    -0x8(%ebp),%esp
801014b7:	5b                   	pop    %ebx
801014b8:	5e                   	pop    %esi
801014b9:	5d                   	pop    %ebp
801014ba:	c3                   	ret    

801014bb <idup>:
{
801014bb:	55                   	push   %ebp
801014bc:	89 e5                	mov    %esp,%ebp
801014be:	53                   	push   %ebx
801014bf:	83 ec 10             	sub    $0x10,%esp
801014c2:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
801014c5:	68 00 0a 11 80       	push   $0x80110a00
801014ca:	e8 83 2a 00 00       	call   80103f52 <acquire>
  ip->ref++;
801014cf:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
801014d3:	c7 04 24 00 0a 11 80 	movl   $0x80110a00,(%esp)
801014da:	e8 da 2a 00 00       	call   80103fb9 <release>
}
801014df:	89 d8                	mov    %ebx,%eax
801014e1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801014e4:	c9                   	leave  
801014e5:	c3                   	ret    

801014e6 <ilock>:
{
801014e6:	55                   	push   %ebp
801014e7:	89 e5                	mov    %esp,%ebp
801014e9:	56                   	push   %esi
801014ea:	53                   	push   %ebx
801014eb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
801014ee:	85 db                	test   %ebx,%ebx
801014f0:	74 22                	je     80101514 <ilock+0x2e>
801014f2:	83 7b 08 00          	cmpl   $0x0,0x8(%ebx)
801014f6:	7e 1c                	jle    80101514 <ilock+0x2e>
  acquiresleep(&ip->lock);
801014f8:	83 ec 0c             	sub    $0xc,%esp
801014fb:	8d 43 0c             	lea    0xc(%ebx),%eax
801014fe:	50                   	push   %eax
801014ff:	e8 2f 28 00 00       	call   80103d33 <acquiresleep>
  if(ip->valid == 0){
80101504:	83 c4 10             	add    $0x10,%esp
80101507:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
8010150b:	74 14                	je     80101521 <ilock+0x3b>
}
8010150d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101510:	5b                   	pop    %ebx
80101511:	5e                   	pop    %esi
80101512:	5d                   	pop    %ebp
80101513:	c3                   	ret    
    panic("ilock");
80101514:	83 ec 0c             	sub    $0xc,%esp
80101517:	68 2a 69 10 80       	push   $0x8010692a
8010151c:	e8 23 ee ff ff       	call   80100344 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80101521:	83 ec 08             	sub    $0x8,%esp
80101524:	8b 43 04             	mov    0x4(%ebx),%eax
80101527:	c1 e8 03             	shr    $0x3,%eax
8010152a:	03 05 f4 09 11 80    	add    0x801109f4,%eax
80101530:	50                   	push   %eax
80101531:	ff 33                	pushl  (%ebx)
80101533:	e8 72 eb ff ff       	call   801000aa <bread>
80101538:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + ip->inum%IPB;
8010153a:	8b 43 04             	mov    0x4(%ebx),%eax
8010153d:	83 e0 07             	and    $0x7,%eax
80101540:	c1 e0 06             	shl    $0x6,%eax
80101543:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    ip->type = dip->type;
80101547:	0f b7 10             	movzwl (%eax),%edx
8010154a:	66 89 53 50          	mov    %dx,0x50(%ebx)
    ip->major = dip->major;
8010154e:	0f b7 50 02          	movzwl 0x2(%eax),%edx
80101552:	66 89 53 52          	mov    %dx,0x52(%ebx)
    ip->minor = dip->minor;
80101556:	0f b7 50 04          	movzwl 0x4(%eax),%edx
8010155a:	66 89 53 54          	mov    %dx,0x54(%ebx)
    ip->nlink = dip->nlink;
8010155e:	0f b7 50 06          	movzwl 0x6(%eax),%edx
80101562:	66 89 53 56          	mov    %dx,0x56(%ebx)
    ip->size = dip->size;
80101566:	8b 50 08             	mov    0x8(%eax),%edx
80101569:	89 53 58             	mov    %edx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
8010156c:	83 c4 0c             	add    $0xc,%esp
8010156f:	6a 34                	push   $0x34
80101571:	83 c0 0c             	add    $0xc,%eax
80101574:	50                   	push   %eax
80101575:	8d 43 5c             	lea    0x5c(%ebx),%eax
80101578:	50                   	push   %eax
80101579:	e8 17 2b 00 00       	call   80104095 <memmove>
    brelse(bp);
8010157e:	89 34 24             	mov    %esi,(%esp)
80101581:	e8 3b ec ff ff       	call   801001c1 <brelse>
    ip->valid = 1;
80101586:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
8010158d:	83 c4 10             	add    $0x10,%esp
80101590:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
80101595:	0f 85 72 ff ff ff    	jne    8010150d <ilock+0x27>
      panic("ilock: no type");
8010159b:	83 ec 0c             	sub    $0xc,%esp
8010159e:	68 30 69 10 80       	push   $0x80106930
801015a3:	e8 9c ed ff ff       	call   80100344 <panic>

801015a8 <iunlock>:
{
801015a8:	55                   	push   %ebp
801015a9:	89 e5                	mov    %esp,%ebp
801015ab:	56                   	push   %esi
801015ac:	53                   	push   %ebx
801015ad:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
801015b0:	85 db                	test   %ebx,%ebx
801015b2:	74 2c                	je     801015e0 <iunlock+0x38>
801015b4:	8d 73 0c             	lea    0xc(%ebx),%esi
801015b7:	83 ec 0c             	sub    $0xc,%esp
801015ba:	56                   	push   %esi
801015bb:	e8 00 28 00 00       	call   80103dc0 <holdingsleep>
801015c0:	83 c4 10             	add    $0x10,%esp
801015c3:	85 c0                	test   %eax,%eax
801015c5:	74 19                	je     801015e0 <iunlock+0x38>
801015c7:	83 7b 08 00          	cmpl   $0x0,0x8(%ebx)
801015cb:	7e 13                	jle    801015e0 <iunlock+0x38>
  releasesleep(&ip->lock);
801015cd:	83 ec 0c             	sub    $0xc,%esp
801015d0:	56                   	push   %esi
801015d1:	e8 af 27 00 00       	call   80103d85 <releasesleep>
}
801015d6:	83 c4 10             	add    $0x10,%esp
801015d9:	8d 65 f8             	lea    -0x8(%ebp),%esp
801015dc:	5b                   	pop    %ebx
801015dd:	5e                   	pop    %esi
801015de:	5d                   	pop    %ebp
801015df:	c3                   	ret    
    panic("iunlock");
801015e0:	83 ec 0c             	sub    $0xc,%esp
801015e3:	68 3f 69 10 80       	push   $0x8010693f
801015e8:	e8 57 ed ff ff       	call   80100344 <panic>

801015ed <iput>:
{
801015ed:	55                   	push   %ebp
801015ee:	89 e5                	mov    %esp,%ebp
801015f0:	57                   	push   %edi
801015f1:	56                   	push   %esi
801015f2:	53                   	push   %ebx
801015f3:	83 ec 28             	sub    $0x28,%esp
801015f6:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquiresleep(&ip->lock);
801015f9:	8d 73 0c             	lea    0xc(%ebx),%esi
801015fc:	56                   	push   %esi
801015fd:	e8 31 27 00 00       	call   80103d33 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
80101602:	83 c4 10             	add    $0x10,%esp
80101605:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
80101609:	74 07                	je     80101612 <iput+0x25>
8010160b:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80101610:	74 30                	je     80101642 <iput+0x55>
  releasesleep(&ip->lock);
80101612:	83 ec 0c             	sub    $0xc,%esp
80101615:	56                   	push   %esi
80101616:	e8 6a 27 00 00       	call   80103d85 <releasesleep>
  acquire(&icache.lock);
8010161b:	c7 04 24 00 0a 11 80 	movl   $0x80110a00,(%esp)
80101622:	e8 2b 29 00 00       	call   80103f52 <acquire>
  ip->ref--;
80101627:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
8010162b:	c7 04 24 00 0a 11 80 	movl   $0x80110a00,(%esp)
80101632:	e8 82 29 00 00       	call   80103fb9 <release>
}
80101637:	83 c4 10             	add    $0x10,%esp
8010163a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010163d:	5b                   	pop    %ebx
8010163e:	5e                   	pop    %esi
8010163f:	5f                   	pop    %edi
80101640:	5d                   	pop    %ebp
80101641:	c3                   	ret    
    acquire(&icache.lock);
80101642:	83 ec 0c             	sub    $0xc,%esp
80101645:	68 00 0a 11 80       	push   $0x80110a00
8010164a:	e8 03 29 00 00       	call   80103f52 <acquire>
    int r = ip->ref;
8010164f:	8b 7b 08             	mov    0x8(%ebx),%edi
    release(&icache.lock);
80101652:	c7 04 24 00 0a 11 80 	movl   $0x80110a00,(%esp)
80101659:	e8 5b 29 00 00       	call   80103fb9 <release>
    if(r == 1){
8010165e:	83 c4 10             	add    $0x10,%esp
80101661:	83 ff 01             	cmp    $0x1,%edi
80101664:	75 ac                	jne    80101612 <iput+0x25>
80101666:	8d 7b 5c             	lea    0x5c(%ebx),%edi
80101669:	8d 83 8c 00 00 00    	lea    0x8c(%ebx),%eax
8010166f:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80101672:	89 c6                	mov    %eax,%esi
80101674:	eb 07                	jmp    8010167d <iput+0x90>
80101676:	83 c7 04             	add    $0x4,%edi
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101679:	39 f7                	cmp    %esi,%edi
8010167b:	74 15                	je     80101692 <iput+0xa5>
    if(ip->addrs[i]){
8010167d:	8b 17                	mov    (%edi),%edx
8010167f:	85 d2                	test   %edx,%edx
80101681:	74 f3                	je     80101676 <iput+0x89>
      bfree(ip->dev, ip->addrs[i]);
80101683:	8b 03                	mov    (%ebx),%eax
80101685:	e8 2a f9 ff ff       	call   80100fb4 <bfree>
      ip->addrs[i] = 0;
8010168a:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
80101690:	eb e4                	jmp    80101676 <iput+0x89>
80101692:	8b 75 e4             	mov    -0x1c(%ebp),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80101695:	8b 83 8c 00 00 00    	mov    0x8c(%ebx),%eax
8010169b:	85 c0                	test   %eax,%eax
8010169d:	75 2d                	jne    801016cc <iput+0xdf>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
8010169f:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
801016a6:	83 ec 0c             	sub    $0xc,%esp
801016a9:	53                   	push   %ebx
801016aa:	e8 8d fd ff ff       	call   8010143c <iupdate>
      ip->type = 0;
801016af:	66 c7 43 50 00 00    	movw   $0x0,0x50(%ebx)
      iupdate(ip);
801016b5:	89 1c 24             	mov    %ebx,(%esp)
801016b8:	e8 7f fd ff ff       	call   8010143c <iupdate>
      ip->valid = 0;
801016bd:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
801016c4:	83 c4 10             	add    $0x10,%esp
801016c7:	e9 46 ff ff ff       	jmp    80101612 <iput+0x25>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
801016cc:	83 ec 08             	sub    $0x8,%esp
801016cf:	50                   	push   %eax
801016d0:	ff 33                	pushl  (%ebx)
801016d2:	e8 d3 e9 ff ff       	call   801000aa <bread>
801016d7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    a = (uint*)bp->data;
801016da:	8d 78 5c             	lea    0x5c(%eax),%edi
801016dd:	05 5c 02 00 00       	add    $0x25c,%eax
801016e2:	83 c4 10             	add    $0x10,%esp
801016e5:	89 75 e0             	mov    %esi,-0x20(%ebp)
801016e8:	89 c6                	mov    %eax,%esi
801016ea:	eb 07                	jmp    801016f3 <iput+0x106>
801016ec:	83 c7 04             	add    $0x4,%edi
    for(j = 0; j < NINDIRECT; j++){
801016ef:	39 fe                	cmp    %edi,%esi
801016f1:	74 0f                	je     80101702 <iput+0x115>
      if(a[j])
801016f3:	8b 17                	mov    (%edi),%edx
801016f5:	85 d2                	test   %edx,%edx
801016f7:	74 f3                	je     801016ec <iput+0xff>
        bfree(ip->dev, a[j]);
801016f9:	8b 03                	mov    (%ebx),%eax
801016fb:	e8 b4 f8 ff ff       	call   80100fb4 <bfree>
80101700:	eb ea                	jmp    801016ec <iput+0xff>
80101702:	8b 75 e0             	mov    -0x20(%ebp),%esi
    brelse(bp);
80101705:	83 ec 0c             	sub    $0xc,%esp
80101708:	ff 75 e4             	pushl  -0x1c(%ebp)
8010170b:	e8 b1 ea ff ff       	call   801001c1 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101710:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
80101716:	8b 03                	mov    (%ebx),%eax
80101718:	e8 97 f8 ff ff       	call   80100fb4 <bfree>
    ip->addrs[NDIRECT] = 0;
8010171d:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
80101724:	00 00 00 
80101727:	83 c4 10             	add    $0x10,%esp
8010172a:	e9 70 ff ff ff       	jmp    8010169f <iput+0xb2>

8010172f <iunlockput>:
{
8010172f:	55                   	push   %ebp
80101730:	89 e5                	mov    %esp,%ebp
80101732:	53                   	push   %ebx
80101733:	83 ec 10             	sub    $0x10,%esp
80101736:	8b 5d 08             	mov    0x8(%ebp),%ebx
  iunlock(ip);
80101739:	53                   	push   %ebx
8010173a:	e8 69 fe ff ff       	call   801015a8 <iunlock>
  iput(ip);
8010173f:	89 1c 24             	mov    %ebx,(%esp)
80101742:	e8 a6 fe ff ff       	call   801015ed <iput>
}
80101747:	83 c4 10             	add    $0x10,%esp
8010174a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010174d:	c9                   	leave  
8010174e:	c3                   	ret    

8010174f <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
8010174f:	55                   	push   %ebp
80101750:	89 e5                	mov    %esp,%ebp
80101752:	8b 55 08             	mov    0x8(%ebp),%edx
80101755:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101758:	8b 0a                	mov    (%edx),%ecx
8010175a:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
8010175d:	8b 4a 04             	mov    0x4(%edx),%ecx
80101760:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80101763:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80101767:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
8010176a:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
8010176e:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80101772:	8b 52 58             	mov    0x58(%edx),%edx
80101775:	89 50 10             	mov    %edx,0x10(%eax)
}
80101778:	5d                   	pop    %ebp
80101779:	c3                   	ret    

8010177a <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
8010177a:	55                   	push   %ebp
8010177b:	89 e5                	mov    %esp,%ebp
8010177d:	57                   	push   %edi
8010177e:	56                   	push   %esi
8010177f:	53                   	push   %ebx
80101780:	83 ec 1c             	sub    $0x1c,%esp
80101783:	8b 7d 10             	mov    0x10(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101786:	8b 45 08             	mov    0x8(%ebp),%eax
80101789:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
8010178e:	0f 84 9d 00 00 00    	je     80101831 <readi+0xb7>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80101794:	8b 45 08             	mov    0x8(%ebp),%eax
80101797:	8b 40 58             	mov    0x58(%eax),%eax
8010179a:	39 f8                	cmp    %edi,%eax
8010179c:	0f 82 c6 00 00 00    	jb     80101868 <readi+0xee>
801017a2:	89 fa                	mov    %edi,%edx
801017a4:	03 55 14             	add    0x14(%ebp),%edx
801017a7:	0f 82 c2 00 00 00    	jb     8010186f <readi+0xf5>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
801017ad:	89 c1                	mov    %eax,%ecx
801017af:	29 f9                	sub    %edi,%ecx
801017b1:	39 d0                	cmp    %edx,%eax
801017b3:	0f 43 4d 14          	cmovae 0x14(%ebp),%ecx
801017b7:	89 4d 14             	mov    %ecx,0x14(%ebp)

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
801017ba:	85 c9                	test   %ecx,%ecx
801017bc:	74 68                	je     80101826 <readi+0xac>
801017be:	be 00 00 00 00       	mov    $0x0,%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801017c3:	89 fa                	mov    %edi,%edx
801017c5:	c1 ea 09             	shr    $0x9,%edx
801017c8:	8b 45 08             	mov    0x8(%ebp),%eax
801017cb:	e8 ac f9 ff ff       	call   8010117c <bmap>
801017d0:	83 ec 08             	sub    $0x8,%esp
801017d3:	50                   	push   %eax
801017d4:	8b 45 08             	mov    0x8(%ebp),%eax
801017d7:	ff 30                	pushl  (%eax)
801017d9:	e8 cc e8 ff ff       	call   801000aa <bread>
801017de:	89 c1                	mov    %eax,%ecx
    m = min(n - tot, BSIZE - off%BSIZE);
801017e0:	89 f8                	mov    %edi,%eax
801017e2:	25 ff 01 00 00       	and    $0x1ff,%eax
801017e7:	bb 00 02 00 00       	mov    $0x200,%ebx
801017ec:	29 c3                	sub    %eax,%ebx
801017ee:	8b 55 14             	mov    0x14(%ebp),%edx
801017f1:	29 f2                	sub    %esi,%edx
801017f3:	83 c4 0c             	add    $0xc,%esp
801017f6:	39 d3                	cmp    %edx,%ebx
801017f8:	0f 47 da             	cmova  %edx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
801017fb:	53                   	push   %ebx
801017fc:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801017ff:	8d 44 01 5c          	lea    0x5c(%ecx,%eax,1),%eax
80101803:	50                   	push   %eax
80101804:	ff 75 0c             	pushl  0xc(%ebp)
80101807:	e8 89 28 00 00       	call   80104095 <memmove>
    brelse(bp);
8010180c:	83 c4 04             	add    $0x4,%esp
8010180f:	ff 75 e4             	pushl  -0x1c(%ebp)
80101812:	e8 aa e9 ff ff       	call   801001c1 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101817:	01 de                	add    %ebx,%esi
80101819:	01 df                	add    %ebx,%edi
8010181b:	01 5d 0c             	add    %ebx,0xc(%ebp)
8010181e:	83 c4 10             	add    $0x10,%esp
80101821:	39 75 14             	cmp    %esi,0x14(%ebp)
80101824:	77 9d                	ja     801017c3 <readi+0x49>
  }
  return n;
80101826:	8b 45 14             	mov    0x14(%ebp),%eax
}
80101829:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010182c:	5b                   	pop    %ebx
8010182d:	5e                   	pop    %esi
8010182e:	5f                   	pop    %edi
8010182f:	5d                   	pop    %ebp
80101830:	c3                   	ret    
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101831:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101835:	66 83 f8 09          	cmp    $0x9,%ax
80101839:	77 1f                	ja     8010185a <readi+0xe0>
8010183b:	98                   	cwtl   
8010183c:	8b 04 c5 80 09 11 80 	mov    -0x7feef680(,%eax,8),%eax
80101843:	85 c0                	test   %eax,%eax
80101845:	74 1a                	je     80101861 <readi+0xe7>
    return devsw[ip->major].read(ip, dst, n);
80101847:	83 ec 04             	sub    $0x4,%esp
8010184a:	ff 75 14             	pushl  0x14(%ebp)
8010184d:	ff 75 0c             	pushl  0xc(%ebp)
80101850:	ff 75 08             	pushl  0x8(%ebp)
80101853:	ff d0                	call   *%eax
80101855:	83 c4 10             	add    $0x10,%esp
80101858:	eb cf                	jmp    80101829 <readi+0xaf>
      return -1;
8010185a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010185f:	eb c8                	jmp    80101829 <readi+0xaf>
80101861:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101866:	eb c1                	jmp    80101829 <readi+0xaf>
    return -1;
80101868:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010186d:	eb ba                	jmp    80101829 <readi+0xaf>
8010186f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101874:	eb b3                	jmp    80101829 <readi+0xaf>

80101876 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80101876:	55                   	push   %ebp
80101877:	89 e5                	mov    %esp,%ebp
80101879:	57                   	push   %edi
8010187a:	56                   	push   %esi
8010187b:	53                   	push   %ebx
8010187c:	83 ec 1c             	sub    $0x1c,%esp
8010187f:	8b 75 10             	mov    0x10(%ebp),%esi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101882:	8b 45 08             	mov    0x8(%ebp),%eax
80101885:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
8010188a:	0f 84 ae 00 00 00    	je     8010193e <writei+0xc8>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80101890:	8b 45 08             	mov    0x8(%ebp),%eax
80101893:	39 70 58             	cmp    %esi,0x58(%eax)
80101896:	0f 82 ed 00 00 00    	jb     80101989 <writei+0x113>
8010189c:	89 f0                	mov    %esi,%eax
8010189e:	03 45 14             	add    0x14(%ebp),%eax
    return -1;
  if(off + n > MAXFILE*BSIZE)
801018a1:	3d 00 18 01 00       	cmp    $0x11800,%eax
801018a6:	0f 87 e4 00 00 00    	ja     80101990 <writei+0x11a>
801018ac:	39 f0                	cmp    %esi,%eax
801018ae:	0f 82 dc 00 00 00    	jb     80101990 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
801018b4:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
801018b8:	74 79                	je     80101933 <writei+0xbd>
801018ba:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801018c1:	89 f2                	mov    %esi,%edx
801018c3:	c1 ea 09             	shr    $0x9,%edx
801018c6:	8b 45 08             	mov    0x8(%ebp),%eax
801018c9:	e8 ae f8 ff ff       	call   8010117c <bmap>
801018ce:	83 ec 08             	sub    $0x8,%esp
801018d1:	50                   	push   %eax
801018d2:	8b 45 08             	mov    0x8(%ebp),%eax
801018d5:	ff 30                	pushl  (%eax)
801018d7:	e8 ce e7 ff ff       	call   801000aa <bread>
801018dc:	89 c7                	mov    %eax,%edi
    m = min(n - tot, BSIZE - off%BSIZE);
801018de:	89 f0                	mov    %esi,%eax
801018e0:	25 ff 01 00 00       	and    $0x1ff,%eax
801018e5:	bb 00 02 00 00       	mov    $0x200,%ebx
801018ea:	29 c3                	sub    %eax,%ebx
801018ec:	8b 55 14             	mov    0x14(%ebp),%edx
801018ef:	2b 55 e4             	sub    -0x1c(%ebp),%edx
801018f2:	83 c4 0c             	add    $0xc,%esp
801018f5:	39 d3                	cmp    %edx,%ebx
801018f7:	0f 47 da             	cmova  %edx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
801018fa:	53                   	push   %ebx
801018fb:	ff 75 0c             	pushl  0xc(%ebp)
801018fe:	8d 44 07 5c          	lea    0x5c(%edi,%eax,1),%eax
80101902:	50                   	push   %eax
80101903:	e8 8d 27 00 00       	call   80104095 <memmove>
    log_write(bp);
80101908:	89 3c 24             	mov    %edi,(%esp)
8010190b:	e8 5d 10 00 00       	call   8010296d <log_write>
    brelse(bp);
80101910:	89 3c 24             	mov    %edi,(%esp)
80101913:	e8 a9 e8 ff ff       	call   801001c1 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101918:	01 5d e4             	add    %ebx,-0x1c(%ebp)
8010191b:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010191e:	01 de                	add    %ebx,%esi
80101920:	01 5d 0c             	add    %ebx,0xc(%ebp)
80101923:	83 c4 10             	add    $0x10,%esp
80101926:	39 4d 14             	cmp    %ecx,0x14(%ebp)
80101929:	77 96                	ja     801018c1 <writei+0x4b>
  }

  if(n > 0 && off > ip->size){
8010192b:	8b 45 08             	mov    0x8(%ebp),%eax
8010192e:	39 70 58             	cmp    %esi,0x58(%eax)
80101931:	72 34                	jb     80101967 <writei+0xf1>
    ip->size = off;
    iupdate(ip);
  }
  return n;
80101933:	8b 45 14             	mov    0x14(%ebp),%eax
}
80101936:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101939:	5b                   	pop    %ebx
8010193a:	5e                   	pop    %esi
8010193b:	5f                   	pop    %edi
8010193c:	5d                   	pop    %ebp
8010193d:	c3                   	ret    
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
8010193e:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101942:	66 83 f8 09          	cmp    $0x9,%ax
80101946:	77 33                	ja     8010197b <writei+0x105>
80101948:	98                   	cwtl   
80101949:	8b 04 c5 84 09 11 80 	mov    -0x7feef67c(,%eax,8),%eax
80101950:	85 c0                	test   %eax,%eax
80101952:	74 2e                	je     80101982 <writei+0x10c>
    return devsw[ip->major].write(ip, src, n);
80101954:	83 ec 04             	sub    $0x4,%esp
80101957:	ff 75 14             	pushl  0x14(%ebp)
8010195a:	ff 75 0c             	pushl  0xc(%ebp)
8010195d:	ff 75 08             	pushl  0x8(%ebp)
80101960:	ff d0                	call   *%eax
80101962:	83 c4 10             	add    $0x10,%esp
80101965:	eb cf                	jmp    80101936 <writei+0xc0>
    ip->size = off;
80101967:	8b 45 08             	mov    0x8(%ebp),%eax
8010196a:	89 70 58             	mov    %esi,0x58(%eax)
    iupdate(ip);
8010196d:	83 ec 0c             	sub    $0xc,%esp
80101970:	50                   	push   %eax
80101971:	e8 c6 fa ff ff       	call   8010143c <iupdate>
80101976:	83 c4 10             	add    $0x10,%esp
80101979:	eb b8                	jmp    80101933 <writei+0xbd>
      return -1;
8010197b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101980:	eb b4                	jmp    80101936 <writei+0xc0>
80101982:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101987:	eb ad                	jmp    80101936 <writei+0xc0>
    return -1;
80101989:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010198e:	eb a6                	jmp    80101936 <writei+0xc0>
    return -1;
80101990:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101995:	eb 9f                	jmp    80101936 <writei+0xc0>

80101997 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80101997:	55                   	push   %ebp
80101998:	89 e5                	mov    %esp,%ebp
8010199a:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
8010199d:	6a 0e                	push   $0xe
8010199f:	ff 75 0c             	pushl  0xc(%ebp)
801019a2:	ff 75 08             	pushl  0x8(%ebp)
801019a5:	e8 4a 27 00 00       	call   801040f4 <strncmp>
}
801019aa:	c9                   	leave  
801019ab:	c3                   	ret    

801019ac <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
801019ac:	55                   	push   %ebp
801019ad:	89 e5                	mov    %esp,%ebp
801019af:	57                   	push   %edi
801019b0:	56                   	push   %esi
801019b1:	53                   	push   %ebx
801019b2:	83 ec 1c             	sub    $0x1c,%esp
801019b5:	8b 75 08             	mov    0x8(%ebp),%esi
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
801019b8:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
801019bd:	75 15                	jne    801019d4 <dirlookup+0x28>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
801019bf:	bb 00 00 00 00       	mov    $0x0,%ebx
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801019c4:	8d 7d d8             	lea    -0x28(%ebp),%edi
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
801019c7:	b8 00 00 00 00       	mov    $0x0,%eax
  for(off = 0; off < dp->size; off += sizeof(de)){
801019cc:	83 7e 58 00          	cmpl   $0x0,0x58(%esi)
801019d0:	75 24                	jne    801019f6 <dirlookup+0x4a>
801019d2:	eb 6e                	jmp    80101a42 <dirlookup+0x96>
    panic("dirlookup not DIR");
801019d4:	83 ec 0c             	sub    $0xc,%esp
801019d7:	68 47 69 10 80       	push   $0x80106947
801019dc:	e8 63 e9 ff ff       	call   80100344 <panic>
      panic("dirlookup read");
801019e1:	83 ec 0c             	sub    $0xc,%esp
801019e4:	68 59 69 10 80       	push   $0x80106959
801019e9:	e8 56 e9 ff ff       	call   80100344 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
801019ee:	83 c3 10             	add    $0x10,%ebx
801019f1:	39 5e 58             	cmp    %ebx,0x58(%esi)
801019f4:	76 47                	jbe    80101a3d <dirlookup+0x91>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801019f6:	6a 10                	push   $0x10
801019f8:	53                   	push   %ebx
801019f9:	57                   	push   %edi
801019fa:	56                   	push   %esi
801019fb:	e8 7a fd ff ff       	call   8010177a <readi>
80101a00:	83 c4 10             	add    $0x10,%esp
80101a03:	83 f8 10             	cmp    $0x10,%eax
80101a06:	75 d9                	jne    801019e1 <dirlookup+0x35>
    if(de.inum == 0)
80101a08:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101a0d:	74 df                	je     801019ee <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
80101a0f:	83 ec 08             	sub    $0x8,%esp
80101a12:	8d 45 da             	lea    -0x26(%ebp),%eax
80101a15:	50                   	push   %eax
80101a16:	ff 75 0c             	pushl  0xc(%ebp)
80101a19:	e8 79 ff ff ff       	call   80101997 <namecmp>
80101a1e:	83 c4 10             	add    $0x10,%esp
80101a21:	85 c0                	test   %eax,%eax
80101a23:	75 c9                	jne    801019ee <dirlookup+0x42>
      if(poff)
80101a25:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80101a29:	74 05                	je     80101a30 <dirlookup+0x84>
        *poff = off;
80101a2b:	8b 45 10             	mov    0x10(%ebp),%eax
80101a2e:	89 18                	mov    %ebx,(%eax)
      inum = de.inum;
80101a30:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80101a34:	8b 06                	mov    (%esi),%eax
80101a36:	e8 e6 f7 ff ff       	call   80101221 <iget>
80101a3b:	eb 05                	jmp    80101a42 <dirlookup+0x96>
  return 0;
80101a3d:	b8 00 00 00 00       	mov    $0x0,%eax
}
80101a42:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101a45:	5b                   	pop    %ebx
80101a46:	5e                   	pop    %esi
80101a47:	5f                   	pop    %edi
80101a48:	5d                   	pop    %ebp
80101a49:	c3                   	ret    

80101a4a <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80101a4a:	55                   	push   %ebp
80101a4b:	89 e5                	mov    %esp,%ebp
80101a4d:	57                   	push   %edi
80101a4e:	56                   	push   %esi
80101a4f:	53                   	push   %ebx
80101a50:	83 ec 1c             	sub    $0x1c,%esp
80101a53:	89 c6                	mov    %eax,%esi
80101a55:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101a58:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  struct inode *ip, *next;

  if(*path == '/')
80101a5b:	80 38 2f             	cmpb   $0x2f,(%eax)
80101a5e:	74 1a                	je     80101a7a <namex+0x30>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80101a60:	e8 e0 18 00 00       	call   80103345 <myproc>
80101a65:	83 ec 0c             	sub    $0xc,%esp
80101a68:	ff 70 68             	pushl  0x68(%eax)
80101a6b:	e8 4b fa ff ff       	call   801014bb <idup>
80101a70:	89 c7                	mov    %eax,%edi
80101a72:	83 c4 10             	add    $0x10,%esp
80101a75:	e9 d4 00 00 00       	jmp    80101b4e <namex+0x104>
    ip = iget(ROOTDEV, ROOTINO);
80101a7a:	ba 01 00 00 00       	mov    $0x1,%edx
80101a7f:	b8 01 00 00 00       	mov    $0x1,%eax
80101a84:	e8 98 f7 ff ff       	call   80101221 <iget>
80101a89:	89 c7                	mov    %eax,%edi
80101a8b:	e9 be 00 00 00       	jmp    80101b4e <namex+0x104>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
      iunlockput(ip);
80101a90:	83 ec 0c             	sub    $0xc,%esp
80101a93:	57                   	push   %edi
80101a94:	e8 96 fc ff ff       	call   8010172f <iunlockput>
      return 0;
80101a99:	83 c4 10             	add    $0x10,%esp
80101a9c:	bf 00 00 00 00       	mov    $0x0,%edi
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
80101aa1:	89 f8                	mov    %edi,%eax
80101aa3:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101aa6:	5b                   	pop    %ebx
80101aa7:	5e                   	pop    %esi
80101aa8:	5f                   	pop    %edi
80101aa9:	5d                   	pop    %ebp
80101aaa:	c3                   	ret    
      iunlock(ip);
80101aab:	83 ec 0c             	sub    $0xc,%esp
80101aae:	57                   	push   %edi
80101aaf:	e8 f4 fa ff ff       	call   801015a8 <iunlock>
      return ip;
80101ab4:	83 c4 10             	add    $0x10,%esp
80101ab7:	eb e8                	jmp    80101aa1 <namex+0x57>
      iunlockput(ip);
80101ab9:	83 ec 0c             	sub    $0xc,%esp
80101abc:	57                   	push   %edi
80101abd:	e8 6d fc ff ff       	call   8010172f <iunlockput>
      return 0;
80101ac2:	83 c4 10             	add    $0x10,%esp
80101ac5:	89 f7                	mov    %esi,%edi
80101ac7:	eb d8                	jmp    80101aa1 <namex+0x57>
  while(*path != '/' && *path != 0)
80101ac9:	89 f3                	mov    %esi,%ebx
  len = path - s;
80101acb:	89 d8                	mov    %ebx,%eax
80101acd:	29 f0                	sub    %esi,%eax
80101acf:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if(len >= DIRSIZ)
80101ad2:	83 f8 0d             	cmp    $0xd,%eax
80101ad5:	0f 8e b4 00 00 00    	jle    80101b8f <namex+0x145>
    memmove(name, s, DIRSIZ);
80101adb:	83 ec 04             	sub    $0x4,%esp
80101ade:	6a 0e                	push   $0xe
80101ae0:	56                   	push   %esi
80101ae1:	ff 75 e4             	pushl  -0x1c(%ebp)
80101ae4:	e8 ac 25 00 00       	call   80104095 <memmove>
80101ae9:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101aec:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101aef:	75 08                	jne    80101af9 <namex+0xaf>
    path++;
80101af1:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101af4:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101af7:	74 f8                	je     80101af1 <namex+0xa7>
  while((path = skipelem(path, name)) != 0){
80101af9:	85 db                	test   %ebx,%ebx
80101afb:	0f 84 ad 00 00 00    	je     80101bae <namex+0x164>
    ilock(ip);
80101b01:	83 ec 0c             	sub    $0xc,%esp
80101b04:	57                   	push   %edi
80101b05:	e8 dc f9 ff ff       	call   801014e6 <ilock>
    if(ip->type != T_DIR){
80101b0a:	83 c4 10             	add    $0x10,%esp
80101b0d:	66 83 7f 50 01       	cmpw   $0x1,0x50(%edi)
80101b12:	0f 85 78 ff ff ff    	jne    80101a90 <namex+0x46>
    if(nameiparent && *path == '\0'){
80101b18:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
80101b1c:	74 05                	je     80101b23 <namex+0xd9>
80101b1e:	80 3b 00             	cmpb   $0x0,(%ebx)
80101b21:	74 88                	je     80101aab <namex+0x61>
    if((next = dirlookup(ip, name, 0)) == 0){
80101b23:	83 ec 04             	sub    $0x4,%esp
80101b26:	6a 00                	push   $0x0
80101b28:	ff 75 e4             	pushl  -0x1c(%ebp)
80101b2b:	57                   	push   %edi
80101b2c:	e8 7b fe ff ff       	call   801019ac <dirlookup>
80101b31:	89 c6                	mov    %eax,%esi
80101b33:	83 c4 10             	add    $0x10,%esp
80101b36:	85 c0                	test   %eax,%eax
80101b38:	0f 84 7b ff ff ff    	je     80101ab9 <namex+0x6f>
    iunlockput(ip);
80101b3e:	83 ec 0c             	sub    $0xc,%esp
80101b41:	57                   	push   %edi
80101b42:	e8 e8 fb ff ff       	call   8010172f <iunlockput>
    ip = next;
80101b47:	83 c4 10             	add    $0x10,%esp
80101b4a:	89 f7                	mov    %esi,%edi
80101b4c:	89 de                	mov    %ebx,%esi
  while(*path == '/')
80101b4e:	0f b6 06             	movzbl (%esi),%eax
80101b51:	3c 2f                	cmp    $0x2f,%al
80101b53:	75 0a                	jne    80101b5f <namex+0x115>
    path++;
80101b55:	83 c6 01             	add    $0x1,%esi
  while(*path == '/')
80101b58:	0f b6 06             	movzbl (%esi),%eax
80101b5b:	3c 2f                	cmp    $0x2f,%al
80101b5d:	74 f6                	je     80101b55 <namex+0x10b>
  if(*path == 0)
80101b5f:	84 c0                	test   %al,%al
80101b61:	74 4b                	je     80101bae <namex+0x164>
  while(*path != '/' && *path != 0)
80101b63:	0f b6 06             	movzbl (%esi),%eax
80101b66:	3c 2f                	cmp    $0x2f,%al
80101b68:	0f 84 5b ff ff ff    	je     80101ac9 <namex+0x7f>
80101b6e:	84 c0                	test   %al,%al
80101b70:	0f 84 53 ff ff ff    	je     80101ac9 <namex+0x7f>
80101b76:	89 f3                	mov    %esi,%ebx
    path++;
80101b78:	83 c3 01             	add    $0x1,%ebx
  while(*path != '/' && *path != 0)
80101b7b:	0f b6 03             	movzbl (%ebx),%eax
80101b7e:	3c 2f                	cmp    $0x2f,%al
80101b80:	0f 84 45 ff ff ff    	je     80101acb <namex+0x81>
80101b86:	84 c0                	test   %al,%al
80101b88:	75 ee                	jne    80101b78 <namex+0x12e>
80101b8a:	e9 3c ff ff ff       	jmp    80101acb <namex+0x81>
    memmove(name, s, len);
80101b8f:	83 ec 04             	sub    $0x4,%esp
80101b92:	ff 75 e0             	pushl  -0x20(%ebp)
80101b95:	56                   	push   %esi
80101b96:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101b99:	56                   	push   %esi
80101b9a:	e8 f6 24 00 00       	call   80104095 <memmove>
    name[len] = 0;
80101b9f:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101ba2:	c6 04 0e 00          	movb   $0x0,(%esi,%ecx,1)
80101ba6:	83 c4 10             	add    $0x10,%esp
80101ba9:	e9 3e ff ff ff       	jmp    80101aec <namex+0xa2>
  if(nameiparent){
80101bae:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
80101bb2:	0f 84 e9 fe ff ff    	je     80101aa1 <namex+0x57>
    iput(ip);
80101bb8:	83 ec 0c             	sub    $0xc,%esp
80101bbb:	57                   	push   %edi
80101bbc:	e8 2c fa ff ff       	call   801015ed <iput>
    return 0;
80101bc1:	83 c4 10             	add    $0x10,%esp
80101bc4:	bf 00 00 00 00       	mov    $0x0,%edi
80101bc9:	e9 d3 fe ff ff       	jmp    80101aa1 <namex+0x57>

80101bce <dirlink>:
{
80101bce:	55                   	push   %ebp
80101bcf:	89 e5                	mov    %esp,%ebp
80101bd1:	57                   	push   %edi
80101bd2:	56                   	push   %esi
80101bd3:	53                   	push   %ebx
80101bd4:	83 ec 20             	sub    $0x20,%esp
80101bd7:	8b 75 08             	mov    0x8(%ebp),%esi
  if((ip = dirlookup(dp, name, 0)) != 0){
80101bda:	6a 00                	push   $0x0
80101bdc:	ff 75 0c             	pushl  0xc(%ebp)
80101bdf:	56                   	push   %esi
80101be0:	e8 c7 fd ff ff       	call   801019ac <dirlookup>
80101be5:	83 c4 10             	add    $0x10,%esp
80101be8:	85 c0                	test   %eax,%eax
80101bea:	75 6a                	jne    80101c56 <dirlink+0x88>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101bec:	8b 5e 58             	mov    0x58(%esi),%ebx
80101bef:	85 db                	test   %ebx,%ebx
80101bf1:	74 29                	je     80101c1c <dirlink+0x4e>
80101bf3:	bb 00 00 00 00       	mov    $0x0,%ebx
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101bf8:	8d 7d d8             	lea    -0x28(%ebp),%edi
80101bfb:	6a 10                	push   $0x10
80101bfd:	53                   	push   %ebx
80101bfe:	57                   	push   %edi
80101bff:	56                   	push   %esi
80101c00:	e8 75 fb ff ff       	call   8010177a <readi>
80101c05:	83 c4 10             	add    $0x10,%esp
80101c08:	83 f8 10             	cmp    $0x10,%eax
80101c0b:	75 5c                	jne    80101c69 <dirlink+0x9b>
    if(de.inum == 0)
80101c0d:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101c12:	74 08                	je     80101c1c <dirlink+0x4e>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101c14:	83 c3 10             	add    $0x10,%ebx
80101c17:	3b 5e 58             	cmp    0x58(%esi),%ebx
80101c1a:	72 df                	jb     80101bfb <dirlink+0x2d>
  strncpy(de.name, name, DIRSIZ);
80101c1c:	83 ec 04             	sub    $0x4,%esp
80101c1f:	6a 0e                	push   $0xe
80101c21:	ff 75 0c             	pushl  0xc(%ebp)
80101c24:	8d 7d d8             	lea    -0x28(%ebp),%edi
80101c27:	8d 45 da             	lea    -0x26(%ebp),%eax
80101c2a:	50                   	push   %eax
80101c2b:	e8 10 25 00 00       	call   80104140 <strncpy>
  de.inum = inum;
80101c30:	8b 45 10             	mov    0x10(%ebp),%eax
80101c33:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101c37:	6a 10                	push   $0x10
80101c39:	53                   	push   %ebx
80101c3a:	57                   	push   %edi
80101c3b:	56                   	push   %esi
80101c3c:	e8 35 fc ff ff       	call   80101876 <writei>
80101c41:	83 c4 20             	add    $0x20,%esp
80101c44:	83 f8 10             	cmp    $0x10,%eax
80101c47:	75 2d                	jne    80101c76 <dirlink+0xa8>
  return 0;
80101c49:	b8 00 00 00 00       	mov    $0x0,%eax
}
80101c4e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c51:	5b                   	pop    %ebx
80101c52:	5e                   	pop    %esi
80101c53:	5f                   	pop    %edi
80101c54:	5d                   	pop    %ebp
80101c55:	c3                   	ret    
    iput(ip);
80101c56:	83 ec 0c             	sub    $0xc,%esp
80101c59:	50                   	push   %eax
80101c5a:	e8 8e f9 ff ff       	call   801015ed <iput>
    return -1;
80101c5f:	83 c4 10             	add    $0x10,%esp
80101c62:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101c67:	eb e5                	jmp    80101c4e <dirlink+0x80>
      panic("dirlink read");
80101c69:	83 ec 0c             	sub    $0xc,%esp
80101c6c:	68 68 69 10 80       	push   $0x80106968
80101c71:	e8 ce e6 ff ff       	call   80100344 <panic>
    panic("dirlink");
80101c76:	83 ec 0c             	sub    $0xc,%esp
80101c79:	68 62 6f 10 80       	push   $0x80106f62
80101c7e:	e8 c1 e6 ff ff       	call   80100344 <panic>

80101c83 <namei>:

struct inode*
namei(char *path)
{
80101c83:	55                   	push   %ebp
80101c84:	89 e5                	mov    %esp,%ebp
80101c86:	83 ec 18             	sub    $0x18,%esp
  char name[DIRSIZ];
  return namex(path, 0, name);
80101c89:	8d 4d ea             	lea    -0x16(%ebp),%ecx
80101c8c:	ba 00 00 00 00       	mov    $0x0,%edx
80101c91:	8b 45 08             	mov    0x8(%ebp),%eax
80101c94:	e8 b1 fd ff ff       	call   80101a4a <namex>
}
80101c99:	c9                   	leave  
80101c9a:	c3                   	ret    

80101c9b <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80101c9b:	55                   	push   %ebp
80101c9c:	89 e5                	mov    %esp,%ebp
80101c9e:	83 ec 08             	sub    $0x8,%esp
  return namex(path, 1, name);
80101ca1:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80101ca4:	ba 01 00 00 00       	mov    $0x1,%edx
80101ca9:	8b 45 08             	mov    0x8(%ebp),%eax
80101cac:	e8 99 fd ff ff       	call   80101a4a <namex>
}
80101cb1:	c9                   	leave  
80101cb2:	c3                   	ret    

80101cb3 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
80101cb3:	55                   	push   %ebp
80101cb4:	89 e5                	mov    %esp,%ebp
80101cb6:	56                   	push   %esi
80101cb7:	53                   	push   %ebx
  if(b == 0)
80101cb8:	85 c0                	test   %eax,%eax
80101cba:	0f 84 84 00 00 00    	je     80101d44 <idestart+0x91>
80101cc0:	89 c6                	mov    %eax,%esi
    panic("idestart");
  if(b->blockno >= FSSIZE)
80101cc2:	8b 58 08             	mov    0x8(%eax),%ebx
80101cc5:	81 fb e7 03 00 00    	cmp    $0x3e7,%ebx
80101ccb:	0f 87 80 00 00 00    	ja     80101d51 <idestart+0x9e>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101cd1:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101cd6:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101cd7:	83 e0 c0             	and    $0xffffffc0,%eax
80101cda:	3c 40                	cmp    $0x40,%al
80101cdc:	75 f8                	jne    80101cd6 <idestart+0x23>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101cde:	b8 00 00 00 00       	mov    $0x0,%eax
80101ce3:	ba f6 03 00 00       	mov    $0x3f6,%edx
80101ce8:	ee                   	out    %al,(%dx)
80101ce9:	b8 01 00 00 00       	mov    $0x1,%eax
80101cee:	ba f2 01 00 00       	mov    $0x1f2,%edx
80101cf3:	ee                   	out    %al,(%dx)
80101cf4:	ba f3 01 00 00       	mov    $0x1f3,%edx
80101cf9:	89 d8                	mov    %ebx,%eax
80101cfb:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80101cfc:	89 d8                	mov    %ebx,%eax
80101cfe:	c1 f8 08             	sar    $0x8,%eax
80101d01:	ba f4 01 00 00       	mov    $0x1f4,%edx
80101d06:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
80101d07:	89 d8                	mov    %ebx,%eax
80101d09:	c1 f8 10             	sar    $0x10,%eax
80101d0c:	ba f5 01 00 00       	mov    $0x1f5,%edx
80101d11:	ee                   	out    %al,(%dx)
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
80101d12:	0f b6 46 04          	movzbl 0x4(%esi),%eax
80101d16:	c1 e0 04             	shl    $0x4,%eax
80101d19:	83 e0 10             	and    $0x10,%eax
80101d1c:	83 c8 e0             	or     $0xffffffe0,%eax
80101d1f:	c1 fb 18             	sar    $0x18,%ebx
80101d22:	83 e3 0f             	and    $0xf,%ebx
80101d25:	09 d8                	or     %ebx,%eax
80101d27:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101d2c:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
80101d2d:	f6 06 04             	testb  $0x4,(%esi)
80101d30:	75 2c                	jne    80101d5e <idestart+0xab>
80101d32:	b8 20 00 00 00       	mov    $0x20,%eax
80101d37:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101d3c:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
80101d3d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101d40:	5b                   	pop    %ebx
80101d41:	5e                   	pop    %esi
80101d42:	5d                   	pop    %ebp
80101d43:	c3                   	ret    
    panic("idestart");
80101d44:	83 ec 0c             	sub    $0xc,%esp
80101d47:	68 cb 69 10 80       	push   $0x801069cb
80101d4c:	e8 f3 e5 ff ff       	call   80100344 <panic>
    panic("incorrect blockno");
80101d51:	83 ec 0c             	sub    $0xc,%esp
80101d54:	68 d4 69 10 80       	push   $0x801069d4
80101d59:	e8 e6 e5 ff ff       	call   80100344 <panic>
80101d5e:	b8 30 00 00 00       	mov    $0x30,%eax
80101d63:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101d68:	ee                   	out    %al,(%dx)
    outsl(0x1f0, b->data, BSIZE/4);
80101d69:	83 c6 5c             	add    $0x5c,%esi
  asm volatile("cld; rep outsl" :
80101d6c:	b9 80 00 00 00       	mov    $0x80,%ecx
80101d71:	ba f0 01 00 00       	mov    $0x1f0,%edx
80101d76:	fc                   	cld    
80101d77:	f3 6f                	rep outsl %ds:(%esi),(%dx)
80101d79:	eb c2                	jmp    80101d3d <idestart+0x8a>

80101d7b <ideinit>:
{
80101d7b:	55                   	push   %ebp
80101d7c:	89 e5                	mov    %esp,%ebp
80101d7e:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
80101d81:	68 e6 69 10 80       	push   $0x801069e6
80101d86:	68 80 a5 10 80       	push   $0x8010a580
80101d8b:	e8 7a 20 00 00       	call   80103e0a <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
80101d90:	83 c4 08             	add    $0x8,%esp
80101d93:	a1 20 2d 11 80       	mov    0x80112d20,%eax
80101d98:	83 e8 01             	sub    $0x1,%eax
80101d9b:	50                   	push   %eax
80101d9c:	6a 0e                	push   $0xe
80101d9e:	e8 63 02 00 00       	call   80102006 <ioapicenable>
80101da3:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101da6:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101dab:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101dac:	83 e0 c0             	and    $0xffffffc0,%eax
80101daf:	3c 40                	cmp    $0x40,%al
80101db1:	75 f8                	jne    80101dab <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101db3:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
80101db8:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101dbd:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101dbe:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101dc3:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80101dc4:	84 c0                	test   %al,%al
80101dc6:	75 11                	jne    80101dd9 <ideinit+0x5e>
80101dc8:	b9 e7 03 00 00       	mov    $0x3e7,%ecx
80101dcd:	ec                   	in     (%dx),%al
80101dce:	84 c0                	test   %al,%al
80101dd0:	75 07                	jne    80101dd9 <ideinit+0x5e>
  for(i=0; i<1000; i++){
80101dd2:	83 e9 01             	sub    $0x1,%ecx
80101dd5:	75 f6                	jne    80101dcd <ideinit+0x52>
80101dd7:	eb 0a                	jmp    80101de3 <ideinit+0x68>
      havedisk1 = 1;
80101dd9:	c7 05 60 a5 10 80 01 	movl   $0x1,0x8010a560
80101de0:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101de3:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80101de8:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101ded:	ee                   	out    %al,(%dx)
}
80101dee:	c9                   	leave  
80101def:	c3                   	ret    

80101df0 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80101df0:	55                   	push   %ebp
80101df1:	89 e5                	mov    %esp,%ebp
80101df3:	57                   	push   %edi
80101df4:	53                   	push   %ebx
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80101df5:	83 ec 0c             	sub    $0xc,%esp
80101df8:	68 80 a5 10 80       	push   $0x8010a580
80101dfd:	e8 50 21 00 00       	call   80103f52 <acquire>

  if((b = idequeue) == 0){
80101e02:	8b 1d 64 a5 10 80    	mov    0x8010a564,%ebx
80101e08:	83 c4 10             	add    $0x10,%esp
80101e0b:	85 db                	test   %ebx,%ebx
80101e0d:	74 48                	je     80101e57 <ideintr+0x67>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80101e0f:	8b 43 58             	mov    0x58(%ebx),%eax
80101e12:	a3 64 a5 10 80       	mov    %eax,0x8010a564

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80101e17:	f6 03 04             	testb  $0x4,(%ebx)
80101e1a:	74 4d                	je     80101e69 <ideintr+0x79>
    insl(0x1f0, b->data, BSIZE/4);

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
  b->flags &= ~B_DIRTY;
80101e1c:	8b 03                	mov    (%ebx),%eax
80101e1e:	83 e0 fb             	and    $0xfffffffb,%eax
80101e21:	83 c8 02             	or     $0x2,%eax
80101e24:	89 03                	mov    %eax,(%ebx)
  wakeup(b);
80101e26:	83 ec 0c             	sub    $0xc,%esp
80101e29:	53                   	push   %ebx
80101e2a:	e8 58 1d 00 00       	call   80103b87 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
80101e2f:	a1 64 a5 10 80       	mov    0x8010a564,%eax
80101e34:	83 c4 10             	add    $0x10,%esp
80101e37:	85 c0                	test   %eax,%eax
80101e39:	74 05                	je     80101e40 <ideintr+0x50>
    idestart(idequeue);
80101e3b:	e8 73 fe ff ff       	call   80101cb3 <idestart>

  release(&idelock);
80101e40:	83 ec 0c             	sub    $0xc,%esp
80101e43:	68 80 a5 10 80       	push   $0x8010a580
80101e48:	e8 6c 21 00 00       	call   80103fb9 <release>
80101e4d:	83 c4 10             	add    $0x10,%esp
}
80101e50:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101e53:	5b                   	pop    %ebx
80101e54:	5f                   	pop    %edi
80101e55:	5d                   	pop    %ebp
80101e56:	c3                   	ret    
    release(&idelock);
80101e57:	83 ec 0c             	sub    $0xc,%esp
80101e5a:	68 80 a5 10 80       	push   $0x8010a580
80101e5f:	e8 55 21 00 00       	call   80103fb9 <release>
    return;
80101e64:	83 c4 10             	add    $0x10,%esp
80101e67:	eb e7                	jmp    80101e50 <ideintr+0x60>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101e69:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101e6e:	ec                   	in     (%dx),%al
80101e6f:	89 c1                	mov    %eax,%ecx
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101e71:	83 e0 c0             	and    $0xffffffc0,%eax
80101e74:	3c 40                	cmp    $0x40,%al
80101e76:	75 f6                	jne    80101e6e <ideintr+0x7e>
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80101e78:	f6 c1 21             	test   $0x21,%cl
80101e7b:	75 9f                	jne    80101e1c <ideintr+0x2c>
    insl(0x1f0, b->data, BSIZE/4);
80101e7d:	8d 7b 5c             	lea    0x5c(%ebx),%edi
  asm volatile("cld; rep insl" :
80101e80:	b9 80 00 00 00       	mov    $0x80,%ecx
80101e85:	ba f0 01 00 00       	mov    $0x1f0,%edx
80101e8a:	fc                   	cld    
80101e8b:	f3 6d                	rep insl (%dx),%es:(%edi)
80101e8d:	eb 8d                	jmp    80101e1c <ideintr+0x2c>

80101e8f <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
80101e8f:	55                   	push   %ebp
80101e90:	89 e5                	mov    %esp,%ebp
80101e92:	53                   	push   %ebx
80101e93:	83 ec 10             	sub    $0x10,%esp
80101e96:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
80101e99:	8d 43 0c             	lea    0xc(%ebx),%eax
80101e9c:	50                   	push   %eax
80101e9d:	e8 1e 1f 00 00       	call   80103dc0 <holdingsleep>
80101ea2:	83 c4 10             	add    $0x10,%esp
80101ea5:	85 c0                	test   %eax,%eax
80101ea7:	74 41                	je     80101eea <iderw+0x5b>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
80101ea9:	8b 03                	mov    (%ebx),%eax
80101eab:	83 e0 06             	and    $0x6,%eax
80101eae:	83 f8 02             	cmp    $0x2,%eax
80101eb1:	74 44                	je     80101ef7 <iderw+0x68>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
80101eb3:	83 7b 04 00          	cmpl   $0x0,0x4(%ebx)
80101eb7:	74 09                	je     80101ec2 <iderw+0x33>
80101eb9:	83 3d 60 a5 10 80 00 	cmpl   $0x0,0x8010a560
80101ec0:	74 42                	je     80101f04 <iderw+0x75>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80101ec2:	83 ec 0c             	sub    $0xc,%esp
80101ec5:	68 80 a5 10 80       	push   $0x8010a580
80101eca:	e8 83 20 00 00       	call   80103f52 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
80101ecf:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80101ed6:	8b 15 64 a5 10 80    	mov    0x8010a564,%edx
80101edc:	83 c4 10             	add    $0x10,%esp
80101edf:	85 d2                	test   %edx,%edx
80101ee1:	75 30                	jne    80101f13 <iderw+0x84>
80101ee3:	ba 64 a5 10 80       	mov    $0x8010a564,%edx
80101ee8:	eb 33                	jmp    80101f1d <iderw+0x8e>
    panic("iderw: buf not locked");
80101eea:	83 ec 0c             	sub    $0xc,%esp
80101eed:	68 ea 69 10 80       	push   $0x801069ea
80101ef2:	e8 4d e4 ff ff       	call   80100344 <panic>
    panic("iderw: nothing to do");
80101ef7:	83 ec 0c             	sub    $0xc,%esp
80101efa:	68 00 6a 10 80       	push   $0x80106a00
80101eff:	e8 40 e4 ff ff       	call   80100344 <panic>
    panic("iderw: ide disk 1 not present");
80101f04:	83 ec 0c             	sub    $0xc,%esp
80101f07:	68 15 6a 10 80       	push   $0x80106a15
80101f0c:	e8 33 e4 ff ff       	call   80100344 <panic>
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80101f11:	89 c2                	mov    %eax,%edx
80101f13:	8b 42 58             	mov    0x58(%edx),%eax
80101f16:	85 c0                	test   %eax,%eax
80101f18:	75 f7                	jne    80101f11 <iderw+0x82>
80101f1a:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
80101f1d:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
80101f1f:	39 1d 64 a5 10 80    	cmp    %ebx,0x8010a564
80101f25:	74 3a                	je     80101f61 <iderw+0xd2>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80101f27:	8b 03                	mov    (%ebx),%eax
80101f29:	83 e0 06             	and    $0x6,%eax
80101f2c:	83 f8 02             	cmp    $0x2,%eax
80101f2f:	74 1b                	je     80101f4c <iderw+0xbd>
    sleep(b, &idelock);
80101f31:	83 ec 08             	sub    $0x8,%esp
80101f34:	68 80 a5 10 80       	push   $0x8010a580
80101f39:	53                   	push   %ebx
80101f3a:	e8 c8 1a 00 00       	call   80103a07 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80101f3f:	8b 03                	mov    (%ebx),%eax
80101f41:	83 e0 06             	and    $0x6,%eax
80101f44:	83 c4 10             	add    $0x10,%esp
80101f47:	83 f8 02             	cmp    $0x2,%eax
80101f4a:	75 e5                	jne    80101f31 <iderw+0xa2>
  }


  release(&idelock);
80101f4c:	83 ec 0c             	sub    $0xc,%esp
80101f4f:	68 80 a5 10 80       	push   $0x8010a580
80101f54:	e8 60 20 00 00       	call   80103fb9 <release>
}
80101f59:	83 c4 10             	add    $0x10,%esp
80101f5c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101f5f:	c9                   	leave  
80101f60:	c3                   	ret    
    idestart(b);
80101f61:	89 d8                	mov    %ebx,%eax
80101f63:	e8 4b fd ff ff       	call   80101cb3 <idestart>
80101f68:	eb bd                	jmp    80101f27 <iderw+0x98>

80101f6a <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
80101f6a:	55                   	push   %ebp
80101f6b:	89 e5                	mov    %esp,%ebp
80101f6d:	56                   	push   %esi
80101f6e:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80101f6f:	c7 05 54 26 11 80 00 	movl   $0xfec00000,0x80112654
80101f76:	00 c0 fe 
  ioapic->reg = reg;
80101f79:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
80101f80:	00 00 00 
  return ioapic->data;
80101f83:	a1 54 26 11 80       	mov    0x80112654,%eax
80101f88:	8b 58 10             	mov    0x10(%eax),%ebx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80101f8b:	c1 eb 10             	shr    $0x10,%ebx
80101f8e:	0f b6 db             	movzbl %bl,%ebx
  ioapic->reg = reg;
80101f91:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  return ioapic->data;
80101f97:	a1 54 26 11 80       	mov    0x80112654,%eax
80101f9c:	8b 40 10             	mov    0x10(%eax),%eax
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
80101f9f:	0f b6 15 80 27 11 80 	movzbl 0x80112780,%edx
  id = ioapicread(REG_ID) >> 24;
80101fa6:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80101fa9:	39 c2                	cmp    %eax,%edx
80101fab:	75 47                	jne    80101ff4 <ioapicinit+0x8a>
{
80101fad:	ba 10 00 00 00       	mov    $0x10,%edx
80101fb2:	b8 00 00 00 00       	mov    $0x0,%eax
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
80101fb7:	8d 48 20             	lea    0x20(%eax),%ecx
80101fba:	81 c9 00 00 01 00    	or     $0x10000,%ecx
  ioapic->reg = reg;
80101fc0:	8b 35 54 26 11 80    	mov    0x80112654,%esi
80101fc6:	89 16                	mov    %edx,(%esi)
  ioapic->data = data;
80101fc8:	8b 35 54 26 11 80    	mov    0x80112654,%esi
80101fce:	89 4e 10             	mov    %ecx,0x10(%esi)
80101fd1:	8d 4a 01             	lea    0x1(%edx),%ecx
  ioapic->reg = reg;
80101fd4:	89 0e                	mov    %ecx,(%esi)
  ioapic->data = data;
80101fd6:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
80101fdc:	c7 41 10 00 00 00 00 	movl   $0x0,0x10(%ecx)
  for(i = 0; i <= maxintr; i++){
80101fe3:	83 c0 01             	add    $0x1,%eax
80101fe6:	83 c2 02             	add    $0x2,%edx
80101fe9:	39 c3                	cmp    %eax,%ebx
80101feb:	7d ca                	jge    80101fb7 <ioapicinit+0x4d>
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
80101fed:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101ff0:	5b                   	pop    %ebx
80101ff1:	5e                   	pop    %esi
80101ff2:	5d                   	pop    %ebp
80101ff3:	c3                   	ret    
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80101ff4:	83 ec 0c             	sub    $0xc,%esp
80101ff7:	68 34 6a 10 80       	push   $0x80106a34
80101ffc:	e8 e0 e5 ff ff       	call   801005e1 <cprintf>
80102001:	83 c4 10             	add    $0x10,%esp
80102004:	eb a7                	jmp    80101fad <ioapicinit+0x43>

80102006 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102006:	55                   	push   %ebp
80102007:	89 e5                	mov    %esp,%ebp
80102009:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
8010200c:	8d 50 20             	lea    0x20(%eax),%edx
8010200f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102013:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
80102019:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
8010201b:	8b 0d 54 26 11 80    	mov    0x80112654,%ecx
80102021:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102024:	8b 55 0c             	mov    0xc(%ebp),%edx
80102027:	c1 e2 18             	shl    $0x18,%edx
8010202a:	83 c0 01             	add    $0x1,%eax
  ioapic->reg = reg;
8010202d:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
8010202f:	a1 54 26 11 80       	mov    0x80112654,%eax
80102034:	89 50 10             	mov    %edx,0x10(%eax)
}
80102037:	5d                   	pop    %ebp
80102038:	c3                   	ret    

80102039 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102039:	55                   	push   %ebp
8010203a:	89 e5                	mov    %esp,%ebp
8010203c:	53                   	push   %ebx
8010203d:	83 ec 04             	sub    $0x4,%esp
80102040:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
80102043:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80102049:	75 4c                	jne    80102097 <kfree+0x5e>
8010204b:	81 fb c8 57 11 80    	cmp    $0x801157c8,%ebx
80102051:	72 44                	jb     80102097 <kfree+0x5e>
80102053:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80102059:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
8010205e:	77 37                	ja     80102097 <kfree+0x5e>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80102060:	83 ec 04             	sub    $0x4,%esp
80102063:	68 00 10 00 00       	push   $0x1000
80102068:	6a 01                	push   $0x1
8010206a:	53                   	push   %ebx
8010206b:	e8 90 1f 00 00       	call   80104000 <memset>

  if(kmem.use_lock)
80102070:	83 c4 10             	add    $0x10,%esp
80102073:	83 3d 94 26 11 80 00 	cmpl   $0x0,0x80112694
8010207a:	75 28                	jne    801020a4 <kfree+0x6b>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
8010207c:	a1 98 26 11 80       	mov    0x80112698,%eax
80102081:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
80102083:	89 1d 98 26 11 80    	mov    %ebx,0x80112698
  if(kmem.use_lock)
80102089:	83 3d 94 26 11 80 00 	cmpl   $0x0,0x80112694
80102090:	75 24                	jne    801020b6 <kfree+0x7d>
    release(&kmem.lock);
}
80102092:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102095:	c9                   	leave  
80102096:	c3                   	ret    
    panic("kfree");
80102097:	83 ec 0c             	sub    $0xc,%esp
8010209a:	68 66 6a 10 80       	push   $0x80106a66
8010209f:	e8 a0 e2 ff ff       	call   80100344 <panic>
    acquire(&kmem.lock);
801020a4:	83 ec 0c             	sub    $0xc,%esp
801020a7:	68 60 26 11 80       	push   $0x80112660
801020ac:	e8 a1 1e 00 00       	call   80103f52 <acquire>
801020b1:	83 c4 10             	add    $0x10,%esp
801020b4:	eb c6                	jmp    8010207c <kfree+0x43>
    release(&kmem.lock);
801020b6:	83 ec 0c             	sub    $0xc,%esp
801020b9:	68 60 26 11 80       	push   $0x80112660
801020be:	e8 f6 1e 00 00       	call   80103fb9 <release>
801020c3:	83 c4 10             	add    $0x10,%esp
}
801020c6:	eb ca                	jmp    80102092 <kfree+0x59>

801020c8 <freerange>:
{
801020c8:	55                   	push   %ebp
801020c9:	89 e5                	mov    %esp,%ebp
801020cb:	56                   	push   %esi
801020cc:	53                   	push   %ebx
801020cd:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801020d0:	8b 45 08             	mov    0x8(%ebp),%eax
801020d3:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801020d9:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801020df:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801020e5:	39 de                	cmp    %ebx,%esi
801020e7:	72 1c                	jb     80102105 <freerange+0x3d>
    kfree(p);
801020e9:	83 ec 0c             	sub    $0xc,%esp
801020ec:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
801020f2:	50                   	push   %eax
801020f3:	e8 41 ff ff ff       	call   80102039 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801020f8:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801020fe:	83 c4 10             	add    $0x10,%esp
80102101:	39 f3                	cmp    %esi,%ebx
80102103:	76 e4                	jbe    801020e9 <freerange+0x21>
}
80102105:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102108:	5b                   	pop    %ebx
80102109:	5e                   	pop    %esi
8010210a:	5d                   	pop    %ebp
8010210b:	c3                   	ret    

8010210c <kinit1>:
{
8010210c:	55                   	push   %ebp
8010210d:	89 e5                	mov    %esp,%ebp
8010210f:	83 ec 10             	sub    $0x10,%esp
  initlock(&kmem.lock, "kmem");
80102112:	68 6c 6a 10 80       	push   $0x80106a6c
80102117:	68 60 26 11 80       	push   $0x80112660
8010211c:	e8 e9 1c 00 00       	call   80103e0a <initlock>
  kmem.use_lock = 0;
80102121:	c7 05 94 26 11 80 00 	movl   $0x0,0x80112694
80102128:	00 00 00 
  freerange(vstart, vend);
8010212b:	83 c4 08             	add    $0x8,%esp
8010212e:	ff 75 0c             	pushl  0xc(%ebp)
80102131:	ff 75 08             	pushl  0x8(%ebp)
80102134:	e8 8f ff ff ff       	call   801020c8 <freerange>
}
80102139:	83 c4 10             	add    $0x10,%esp
8010213c:	c9                   	leave  
8010213d:	c3                   	ret    

8010213e <kinit2>:
{
8010213e:	55                   	push   %ebp
8010213f:	89 e5                	mov    %esp,%ebp
80102141:	83 ec 10             	sub    $0x10,%esp
  freerange(vstart, vend);
80102144:	ff 75 0c             	pushl  0xc(%ebp)
80102147:	ff 75 08             	pushl  0x8(%ebp)
8010214a:	e8 79 ff ff ff       	call   801020c8 <freerange>
  kmem.use_lock = 1;
8010214f:	c7 05 94 26 11 80 01 	movl   $0x1,0x80112694
80102156:	00 00 00 
}
80102159:	83 c4 10             	add    $0x10,%esp
8010215c:	c9                   	leave  
8010215d:	c3                   	ret    

8010215e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
8010215e:	55                   	push   %ebp
8010215f:	89 e5                	mov    %esp,%ebp
80102161:	53                   	push   %ebx
80102162:	83 ec 04             	sub    $0x4,%esp
  struct run *r;

  if(kmem.use_lock)
80102165:	83 3d 94 26 11 80 00 	cmpl   $0x0,0x80112694
8010216c:	75 21                	jne    8010218f <kalloc+0x31>
    acquire(&kmem.lock);
  r = kmem.freelist;
8010216e:	8b 1d 98 26 11 80    	mov    0x80112698,%ebx
  if(r)
80102174:	85 db                	test   %ebx,%ebx
80102176:	74 10                	je     80102188 <kalloc+0x2a>
    kmem.freelist = r->next;
80102178:	8b 03                	mov    (%ebx),%eax
8010217a:	a3 98 26 11 80       	mov    %eax,0x80112698
  if(kmem.use_lock)
8010217f:	83 3d 94 26 11 80 00 	cmpl   $0x0,0x80112694
80102186:	75 23                	jne    801021ab <kalloc+0x4d>
    release(&kmem.lock);
  return (char*)r;
}
80102188:	89 d8                	mov    %ebx,%eax
8010218a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010218d:	c9                   	leave  
8010218e:	c3                   	ret    
    acquire(&kmem.lock);
8010218f:	83 ec 0c             	sub    $0xc,%esp
80102192:	68 60 26 11 80       	push   $0x80112660
80102197:	e8 b6 1d 00 00       	call   80103f52 <acquire>
  r = kmem.freelist;
8010219c:	8b 1d 98 26 11 80    	mov    0x80112698,%ebx
  if(r)
801021a2:	83 c4 10             	add    $0x10,%esp
801021a5:	85 db                	test   %ebx,%ebx
801021a7:	75 cf                	jne    80102178 <kalloc+0x1a>
801021a9:	eb d4                	jmp    8010217f <kalloc+0x21>
    release(&kmem.lock);
801021ab:	83 ec 0c             	sub    $0xc,%esp
801021ae:	68 60 26 11 80       	push   $0x80112660
801021b3:	e8 01 1e 00 00       	call   80103fb9 <release>
801021b8:	83 c4 10             	add    $0x10,%esp
  return (char*)r;
801021bb:	eb cb                	jmp    80102188 <kalloc+0x2a>

801021bd <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801021bd:	ba 64 00 00 00       	mov    $0x64,%edx
801021c2:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
801021c3:	a8 01                	test   $0x1,%al
801021c5:	0f 84 bb 00 00 00    	je     80102286 <kbdgetc+0xc9>
801021cb:	ba 60 00 00 00       	mov    $0x60,%edx
801021d0:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);
801021d1:	0f b6 d0             	movzbl %al,%edx

  if(data == 0xE0){
801021d4:	81 fa e0 00 00 00    	cmp    $0xe0,%edx
801021da:	74 5b                	je     80102237 <kbdgetc+0x7a>
    shift |= E0ESC;
    return 0;
  } else if(data & 0x80){
801021dc:	84 c0                	test   %al,%al
801021de:	78 64                	js     80102244 <kbdgetc+0x87>
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
801021e0:	8b 0d b4 a5 10 80    	mov    0x8010a5b4,%ecx
801021e6:	f6 c1 40             	test   $0x40,%cl
801021e9:	74 0f                	je     801021fa <kbdgetc+0x3d>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
801021eb:	83 c8 80             	or     $0xffffff80,%eax
801021ee:	0f b6 d0             	movzbl %al,%edx
    shift &= ~E0ESC;
801021f1:	83 e1 bf             	and    $0xffffffbf,%ecx
801021f4:	89 0d b4 a5 10 80    	mov    %ecx,0x8010a5b4
  }

  shift |= shiftcode[data];
801021fa:	0f b6 8a a0 6b 10 80 	movzbl -0x7fef9460(%edx),%ecx
80102201:	0b 0d b4 a5 10 80    	or     0x8010a5b4,%ecx
  shift ^= togglecode[data];
80102207:	0f b6 82 a0 6a 10 80 	movzbl -0x7fef9560(%edx),%eax
8010220e:	31 c1                	xor    %eax,%ecx
80102210:	89 0d b4 a5 10 80    	mov    %ecx,0x8010a5b4
  c = charcode[shift & (CTL | SHIFT)][data];
80102216:	89 c8                	mov    %ecx,%eax
80102218:	83 e0 03             	and    $0x3,%eax
8010221b:	8b 04 85 80 6a 10 80 	mov    -0x7fef9580(,%eax,4),%eax
80102222:	0f b6 04 10          	movzbl (%eax,%edx,1),%eax
  if(shift & CAPSLOCK){
80102226:	f6 c1 08             	test   $0x8,%cl
80102229:	74 61                	je     8010228c <kbdgetc+0xcf>
    if('a' <= c && c <= 'z')
8010222b:	8d 50 9f             	lea    -0x61(%eax),%edx
8010222e:	83 fa 19             	cmp    $0x19,%edx
80102231:	77 46                	ja     80102279 <kbdgetc+0xbc>
      c += 'A' - 'a';
80102233:	83 e8 20             	sub    $0x20,%eax
80102236:	c3                   	ret    
    shift |= E0ESC;
80102237:	83 0d b4 a5 10 80 40 	orl    $0x40,0x8010a5b4
    return 0;
8010223e:	b8 00 00 00 00       	mov    $0x0,%eax
80102243:	c3                   	ret    
{
80102244:	55                   	push   %ebp
80102245:	89 e5                	mov    %esp,%ebp
80102247:	53                   	push   %ebx
    data = (shift & E0ESC ? data : data & 0x7F);
80102248:	8b 0d b4 a5 10 80    	mov    0x8010a5b4,%ecx
8010224e:	89 cb                	mov    %ecx,%ebx
80102250:	83 e3 40             	and    $0x40,%ebx
80102253:	83 e0 7f             	and    $0x7f,%eax
80102256:	85 db                	test   %ebx,%ebx
80102258:	0f 44 d0             	cmove  %eax,%edx
    shift &= ~(shiftcode[data] | E0ESC);
8010225b:	0f b6 82 a0 6b 10 80 	movzbl -0x7fef9460(%edx),%eax
80102262:	83 c8 40             	or     $0x40,%eax
80102265:	0f b6 c0             	movzbl %al,%eax
80102268:	f7 d0                	not    %eax
8010226a:	21 c8                	and    %ecx,%eax
8010226c:	a3 b4 a5 10 80       	mov    %eax,0x8010a5b4
    return 0;
80102271:	b8 00 00 00 00       	mov    $0x0,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
80102276:	5b                   	pop    %ebx
80102277:	5d                   	pop    %ebp
80102278:	c3                   	ret    
    else if('A' <= c && c <= 'Z')
80102279:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010227c:	8d 50 20             	lea    0x20(%eax),%edx
8010227f:	83 f9 1a             	cmp    $0x1a,%ecx
80102282:	0f 42 c2             	cmovb  %edx,%eax
  return c;
80102285:	c3                   	ret    
    return -1;
80102286:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010228b:	c3                   	ret    
}
8010228c:	f3 c3                	repz ret 

8010228e <kbdintr>:

void
kbdintr(void)
{
8010228e:	55                   	push   %ebp
8010228f:	89 e5                	mov    %esp,%ebp
80102291:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102294:	68 bd 21 10 80       	push   $0x801021bd
80102299:	e8 9d e4 ff ff       	call   8010073b <consoleintr>
}
8010229e:	83 c4 10             	add    $0x10,%esp
801022a1:	c9                   	leave  
801022a2:	c3                   	ret    

801022a3 <lapicw>:
volatile uint *lapic;  // Initialized in mp.c

//PAGEBREAK!
static void
lapicw(int index, int value)
{
801022a3:	55                   	push   %ebp
801022a4:	89 e5                	mov    %esp,%ebp
  lapic[index] = value;
801022a6:	8b 0d 9c 26 11 80    	mov    0x8011269c,%ecx
801022ac:	8d 04 81             	lea    (%ecx,%eax,4),%eax
801022af:	89 10                	mov    %edx,(%eax)
  lapic[ID];  // wait for write to finish, by reading
801022b1:	a1 9c 26 11 80       	mov    0x8011269c,%eax
801022b6:	8b 40 20             	mov    0x20(%eax),%eax
}
801022b9:	5d                   	pop    %ebp
801022ba:	c3                   	ret    

801022bb <fill_rtcdate>:
  return inb(CMOS_RETURN);
}

static void
fill_rtcdate(struct rtcdate *r)
{
801022bb:	55                   	push   %ebp
801022bc:	89 e5                	mov    %esp,%ebp
801022be:	56                   	push   %esi
801022bf:	53                   	push   %ebx
801022c0:	89 c3                	mov    %eax,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022c2:	be 70 00 00 00       	mov    $0x70,%esi
801022c7:	b8 00 00 00 00       	mov    $0x0,%eax
801022cc:	89 f2                	mov    %esi,%edx
801022ce:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022cf:	b9 71 00 00 00       	mov    $0x71,%ecx
801022d4:	89 ca                	mov    %ecx,%edx
801022d6:	ec                   	in     (%dx),%al
  return inb(CMOS_RETURN);
801022d7:	0f b6 c0             	movzbl %al,%eax
801022da:	89 03                	mov    %eax,(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022dc:	b8 02 00 00 00       	mov    $0x2,%eax
801022e1:	89 f2                	mov    %esi,%edx
801022e3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022e4:	89 ca                	mov    %ecx,%edx
801022e6:	ec                   	in     (%dx),%al
801022e7:	0f b6 c0             	movzbl %al,%eax
801022ea:	89 43 04             	mov    %eax,0x4(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022ed:	b8 04 00 00 00       	mov    $0x4,%eax
801022f2:	89 f2                	mov    %esi,%edx
801022f4:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022f5:	89 ca                	mov    %ecx,%edx
801022f7:	ec                   	in     (%dx),%al
801022f8:	0f b6 c0             	movzbl %al,%eax
801022fb:	89 43 08             	mov    %eax,0x8(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022fe:	b8 07 00 00 00       	mov    $0x7,%eax
80102303:	89 f2                	mov    %esi,%edx
80102305:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102306:	89 ca                	mov    %ecx,%edx
80102308:	ec                   	in     (%dx),%al
80102309:	0f b6 c0             	movzbl %al,%eax
8010230c:	89 43 0c             	mov    %eax,0xc(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010230f:	b8 08 00 00 00       	mov    $0x8,%eax
80102314:	89 f2                	mov    %esi,%edx
80102316:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102317:	89 ca                	mov    %ecx,%edx
80102319:	ec                   	in     (%dx),%al
8010231a:	0f b6 c0             	movzbl %al,%eax
8010231d:	89 43 10             	mov    %eax,0x10(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102320:	b8 09 00 00 00       	mov    $0x9,%eax
80102325:	89 f2                	mov    %esi,%edx
80102327:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102328:	89 ca                	mov    %ecx,%edx
8010232a:	ec                   	in     (%dx),%al
8010232b:	0f b6 c0             	movzbl %al,%eax
8010232e:	89 43 14             	mov    %eax,0x14(%ebx)
  r->minute = cmos_read(MINS);
  r->hour   = cmos_read(HOURS);
  r->day    = cmos_read(DAY);
  r->month  = cmos_read(MONTH);
  r->year   = cmos_read(YEAR);
}
80102331:	5b                   	pop    %ebx
80102332:	5e                   	pop    %esi
80102333:	5d                   	pop    %ebp
80102334:	c3                   	ret    

80102335 <lapicinit>:
  if(!lapic)
80102335:	83 3d 9c 26 11 80 00 	cmpl   $0x0,0x8011269c
8010233c:	0f 84 fc 00 00 00    	je     8010243e <lapicinit+0x109>
{
80102342:	55                   	push   %ebp
80102343:	89 e5                	mov    %esp,%ebp
  lapicw(SVR, ENABLE | (T_IRQ0 + IRQ_SPURIOUS));
80102345:	ba 3f 01 00 00       	mov    $0x13f,%edx
8010234a:	b8 3c 00 00 00       	mov    $0x3c,%eax
8010234f:	e8 4f ff ff ff       	call   801022a3 <lapicw>
  lapicw(TDCR, X1);
80102354:	ba 0b 00 00 00       	mov    $0xb,%edx
80102359:	b8 f8 00 00 00       	mov    $0xf8,%eax
8010235e:	e8 40 ff ff ff       	call   801022a3 <lapicw>
  lapicw(TIMER, PERIODIC | (T_IRQ0 + IRQ_TIMER));
80102363:	ba 20 00 02 00       	mov    $0x20020,%edx
80102368:	b8 c8 00 00 00       	mov    $0xc8,%eax
8010236d:	e8 31 ff ff ff       	call   801022a3 <lapicw>
  lapicw(TICR, 10000000);
80102372:	ba 80 96 98 00       	mov    $0x989680,%edx
80102377:	b8 e0 00 00 00       	mov    $0xe0,%eax
8010237c:	e8 22 ff ff ff       	call   801022a3 <lapicw>
  lapicw(LINT0, MASKED);
80102381:	ba 00 00 01 00       	mov    $0x10000,%edx
80102386:	b8 d4 00 00 00       	mov    $0xd4,%eax
8010238b:	e8 13 ff ff ff       	call   801022a3 <lapicw>
  lapicw(LINT1, MASKED);
80102390:	ba 00 00 01 00       	mov    $0x10000,%edx
80102395:	b8 d8 00 00 00       	mov    $0xd8,%eax
8010239a:	e8 04 ff ff ff       	call   801022a3 <lapicw>
  if(((lapic[VER]>>16) & 0xFF) >= 4)
8010239f:	a1 9c 26 11 80       	mov    0x8011269c,%eax
801023a4:	8b 40 30             	mov    0x30(%eax),%eax
801023a7:	c1 e8 10             	shr    $0x10,%eax
801023aa:	3c 03                	cmp    $0x3,%al
801023ac:	77 7c                	ja     8010242a <lapicinit+0xf5>
  lapicw(ERROR, T_IRQ0 + IRQ_ERROR);
801023ae:	ba 33 00 00 00       	mov    $0x33,%edx
801023b3:	b8 dc 00 00 00       	mov    $0xdc,%eax
801023b8:	e8 e6 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ESR, 0);
801023bd:	ba 00 00 00 00       	mov    $0x0,%edx
801023c2:	b8 a0 00 00 00       	mov    $0xa0,%eax
801023c7:	e8 d7 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ESR, 0);
801023cc:	ba 00 00 00 00       	mov    $0x0,%edx
801023d1:	b8 a0 00 00 00       	mov    $0xa0,%eax
801023d6:	e8 c8 fe ff ff       	call   801022a3 <lapicw>
  lapicw(EOI, 0);
801023db:	ba 00 00 00 00       	mov    $0x0,%edx
801023e0:	b8 2c 00 00 00       	mov    $0x2c,%eax
801023e5:	e8 b9 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ICRHI, 0);
801023ea:	ba 00 00 00 00       	mov    $0x0,%edx
801023ef:	b8 c4 00 00 00       	mov    $0xc4,%eax
801023f4:	e8 aa fe ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, BCAST | INIT | LEVEL);
801023f9:	ba 00 85 08 00       	mov    $0x88500,%edx
801023fe:	b8 c0 00 00 00       	mov    $0xc0,%eax
80102403:	e8 9b fe ff ff       	call   801022a3 <lapicw>
  while(lapic[ICRLO] & DELIVS)
80102408:	8b 15 9c 26 11 80    	mov    0x8011269c,%edx
8010240e:	8b 82 00 03 00 00    	mov    0x300(%edx),%eax
80102414:	f6 c4 10             	test   $0x10,%ah
80102417:	75 f5                	jne    8010240e <lapicinit+0xd9>
  lapicw(TPR, 0);
80102419:	ba 00 00 00 00       	mov    $0x0,%edx
8010241e:	b8 20 00 00 00       	mov    $0x20,%eax
80102423:	e8 7b fe ff ff       	call   801022a3 <lapicw>
}
80102428:	5d                   	pop    %ebp
80102429:	c3                   	ret    
    lapicw(PCINT, MASKED);
8010242a:	ba 00 00 01 00       	mov    $0x10000,%edx
8010242f:	b8 d0 00 00 00       	mov    $0xd0,%eax
80102434:	e8 6a fe ff ff       	call   801022a3 <lapicw>
80102439:	e9 70 ff ff ff       	jmp    801023ae <lapicinit+0x79>
8010243e:	f3 c3                	repz ret 

80102440 <lapicid>:
{
80102440:	55                   	push   %ebp
80102441:	89 e5                	mov    %esp,%ebp
  if (!lapic)
80102443:	8b 15 9c 26 11 80    	mov    0x8011269c,%edx
    return 0;
80102449:	b8 00 00 00 00       	mov    $0x0,%eax
  if (!lapic)
8010244e:	85 d2                	test   %edx,%edx
80102450:	74 06                	je     80102458 <lapicid+0x18>
  return lapic[ID] >> 24;
80102452:	8b 42 20             	mov    0x20(%edx),%eax
80102455:	c1 e8 18             	shr    $0x18,%eax
}
80102458:	5d                   	pop    %ebp
80102459:	c3                   	ret    

8010245a <lapiceoi>:
  if(lapic)
8010245a:	83 3d 9c 26 11 80 00 	cmpl   $0x0,0x8011269c
80102461:	74 14                	je     80102477 <lapiceoi+0x1d>
{
80102463:	55                   	push   %ebp
80102464:	89 e5                	mov    %esp,%ebp
    lapicw(EOI, 0);
80102466:	ba 00 00 00 00       	mov    $0x0,%edx
8010246b:	b8 2c 00 00 00       	mov    $0x2c,%eax
80102470:	e8 2e fe ff ff       	call   801022a3 <lapicw>
}
80102475:	5d                   	pop    %ebp
80102476:	c3                   	ret    
80102477:	f3 c3                	repz ret 

80102479 <microdelay>:
{
80102479:	55                   	push   %ebp
8010247a:	89 e5                	mov    %esp,%ebp
}
8010247c:	5d                   	pop    %ebp
8010247d:	c3                   	ret    

8010247e <lapicstartap>:
{
8010247e:	55                   	push   %ebp
8010247f:	89 e5                	mov    %esp,%ebp
80102481:	56                   	push   %esi
80102482:	53                   	push   %ebx
80102483:	8b 75 08             	mov    0x8(%ebp),%esi
80102486:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102489:	b8 0f 00 00 00       	mov    $0xf,%eax
8010248e:	ba 70 00 00 00       	mov    $0x70,%edx
80102493:	ee                   	out    %al,(%dx)
80102494:	b8 0a 00 00 00       	mov    $0xa,%eax
80102499:	ba 71 00 00 00       	mov    $0x71,%edx
8010249e:	ee                   	out    %al,(%dx)
  wrv[0] = 0;
8010249f:	66 c7 05 67 04 00 80 	movw   $0x0,0x80000467
801024a6:	00 00 
  wrv[1] = addr >> 4;
801024a8:	89 d8                	mov    %ebx,%eax
801024aa:	c1 e8 04             	shr    $0x4,%eax
801024ad:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapicw(ICRHI, apicid<<24);
801024b3:	c1 e6 18             	shl    $0x18,%esi
801024b6:	89 f2                	mov    %esi,%edx
801024b8:	b8 c4 00 00 00       	mov    $0xc4,%eax
801024bd:	e8 e1 fd ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, INIT | LEVEL | ASSERT);
801024c2:	ba 00 c5 00 00       	mov    $0xc500,%edx
801024c7:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024cc:	e8 d2 fd ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, INIT | LEVEL);
801024d1:	ba 00 85 00 00       	mov    $0x8500,%edx
801024d6:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024db:	e8 c3 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
801024e0:	c1 eb 0c             	shr    $0xc,%ebx
801024e3:	80 cf 06             	or     $0x6,%bh
    lapicw(ICRHI, apicid<<24);
801024e6:	89 f2                	mov    %esi,%edx
801024e8:	b8 c4 00 00 00       	mov    $0xc4,%eax
801024ed:	e8 b1 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
801024f2:	89 da                	mov    %ebx,%edx
801024f4:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024f9:	e8 a5 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRHI, apicid<<24);
801024fe:	89 f2                	mov    %esi,%edx
80102500:	b8 c4 00 00 00       	mov    $0xc4,%eax
80102505:	e8 99 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
8010250a:	89 da                	mov    %ebx,%edx
8010250c:	b8 c0 00 00 00       	mov    $0xc0,%eax
80102511:	e8 8d fd ff ff       	call   801022a3 <lapicw>
}
80102516:	5b                   	pop    %ebx
80102517:	5e                   	pop    %esi
80102518:	5d                   	pop    %ebp
80102519:	c3                   	ret    

8010251a <cmostime>:

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
8010251a:	55                   	push   %ebp
8010251b:	89 e5                	mov    %esp,%ebp
8010251d:	57                   	push   %edi
8010251e:	56                   	push   %esi
8010251f:	53                   	push   %ebx
80102520:	83 ec 4c             	sub    $0x4c,%esp
80102523:	8b 7d 08             	mov    0x8(%ebp),%edi
80102526:	b8 0b 00 00 00       	mov    $0xb,%eax
8010252b:	ba 70 00 00 00       	mov    $0x70,%edx
80102530:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102531:	ba 71 00 00 00       	mov    $0x71,%edx
80102536:	ec                   	in     (%dx),%al
80102537:	83 e0 04             	and    $0x4,%eax
8010253a:	88 45 b7             	mov    %al,-0x49(%ebp)

  bcd = (sb & (1 << 2)) == 0;

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
8010253d:	8d 75 d0             	lea    -0x30(%ebp),%esi
80102540:	89 f0                	mov    %esi,%eax
80102542:	e8 74 fd ff ff       	call   801022bb <fill_rtcdate>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102547:	ba 70 00 00 00       	mov    $0x70,%edx
8010254c:	b8 0a 00 00 00       	mov    $0xa,%eax
80102551:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102552:	ba 71 00 00 00       	mov    $0x71,%edx
80102557:	ec                   	in     (%dx),%al
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80102558:	84 c0                	test   %al,%al
8010255a:	78 e4                	js     80102540 <cmostime+0x26>
        continue;
    fill_rtcdate(&t2);
8010255c:	8d 5d b8             	lea    -0x48(%ebp),%ebx
8010255f:	89 d8                	mov    %ebx,%eax
80102561:	e8 55 fd ff ff       	call   801022bb <fill_rtcdate>
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102566:	83 ec 04             	sub    $0x4,%esp
80102569:	6a 18                	push   $0x18
8010256b:	53                   	push   %ebx
8010256c:	56                   	push   %esi
8010256d:	e8 d2 1a 00 00       	call   80104044 <memcmp>
80102572:	83 c4 10             	add    $0x10,%esp
80102575:	85 c0                	test   %eax,%eax
80102577:	75 c7                	jne    80102540 <cmostime+0x26>
      break;
  }

  // convert
  if(bcd) {
80102579:	80 7d b7 00          	cmpb   $0x0,-0x49(%ebp)
8010257d:	75 78                	jne    801025f7 <cmostime+0xdd>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
8010257f:	8b 45 d0             	mov    -0x30(%ebp),%eax
80102582:	89 c2                	mov    %eax,%edx
80102584:	c1 ea 04             	shr    $0x4,%edx
80102587:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010258a:	83 e0 0f             	and    $0xf,%eax
8010258d:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102590:	89 45 d0             	mov    %eax,-0x30(%ebp)
    CONV(minute);
80102593:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80102596:	89 c2                	mov    %eax,%edx
80102598:	c1 ea 04             	shr    $0x4,%edx
8010259b:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010259e:	83 e0 0f             	and    $0xf,%eax
801025a1:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025a4:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    CONV(hour  );
801025a7:	8b 45 d8             	mov    -0x28(%ebp),%eax
801025aa:	89 c2                	mov    %eax,%edx
801025ac:	c1 ea 04             	shr    $0x4,%edx
801025af:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025b2:	83 e0 0f             	and    $0xf,%eax
801025b5:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025b8:	89 45 d8             	mov    %eax,-0x28(%ebp)
    CONV(day   );
801025bb:	8b 45 dc             	mov    -0x24(%ebp),%eax
801025be:	89 c2                	mov    %eax,%edx
801025c0:	c1 ea 04             	shr    $0x4,%edx
801025c3:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025c6:	83 e0 0f             	and    $0xf,%eax
801025c9:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025cc:	89 45 dc             	mov    %eax,-0x24(%ebp)
    CONV(month );
801025cf:	8b 45 e0             	mov    -0x20(%ebp),%eax
801025d2:	89 c2                	mov    %eax,%edx
801025d4:	c1 ea 04             	shr    $0x4,%edx
801025d7:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025da:	83 e0 0f             	and    $0xf,%eax
801025dd:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025e0:	89 45 e0             	mov    %eax,-0x20(%ebp)
    CONV(year  );
801025e3:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801025e6:	89 c2                	mov    %eax,%edx
801025e8:	c1 ea 04             	shr    $0x4,%edx
801025eb:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025ee:	83 e0 0f             	and    $0xf,%eax
801025f1:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025f4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
#undef     CONV
  }

  *r = t1;
801025f7:	8b 45 d0             	mov    -0x30(%ebp),%eax
801025fa:	89 07                	mov    %eax,(%edi)
801025fc:	8b 45 d4             	mov    -0x2c(%ebp),%eax
801025ff:	89 47 04             	mov    %eax,0x4(%edi)
80102602:	8b 45 d8             	mov    -0x28(%ebp),%eax
80102605:	89 47 08             	mov    %eax,0x8(%edi)
80102608:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010260b:	89 47 0c             	mov    %eax,0xc(%edi)
8010260e:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102611:	89 47 10             	mov    %eax,0x10(%edi)
80102614:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80102617:	89 47 14             	mov    %eax,0x14(%edi)
  r->year += 2000;
8010261a:	81 47 14 d0 07 00 00 	addl   $0x7d0,0x14(%edi)
}
80102621:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102624:	5b                   	pop    %ebx
80102625:	5e                   	pop    %esi
80102626:	5f                   	pop    %edi
80102627:	5d                   	pop    %ebp
80102628:	c3                   	ret    

80102629 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80102629:	83 3d e8 26 11 80 00 	cmpl   $0x0,0x801126e8
80102630:	0f 8e 84 00 00 00    	jle    801026ba <install_trans+0x91>
{
80102636:	55                   	push   %ebp
80102637:	89 e5                	mov    %esp,%ebp
80102639:	57                   	push   %edi
8010263a:	56                   	push   %esi
8010263b:	53                   	push   %ebx
8010263c:	83 ec 1c             	sub    $0x1c,%esp
  for (tail = 0; tail < log.lh.n; tail++) {
8010263f:	bb 00 00 00 00       	mov    $0x0,%ebx
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80102644:	be a0 26 11 80       	mov    $0x801126a0,%esi
80102649:	83 ec 08             	sub    $0x8,%esp
8010264c:	89 d8                	mov    %ebx,%eax
8010264e:	03 46 34             	add    0x34(%esi),%eax
80102651:	83 c0 01             	add    $0x1,%eax
80102654:	50                   	push   %eax
80102655:	ff 76 44             	pushl  0x44(%esi)
80102658:	e8 4d da ff ff       	call   801000aa <bread>
8010265d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102660:	83 c4 08             	add    $0x8,%esp
80102663:	ff 34 9d ec 26 11 80 	pushl  -0x7feed914(,%ebx,4)
8010266a:	ff 76 44             	pushl  0x44(%esi)
8010266d:	e8 38 da ff ff       	call   801000aa <bread>
80102672:	89 c7                	mov    %eax,%edi
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102674:	83 c4 0c             	add    $0xc,%esp
80102677:	68 00 02 00 00       	push   $0x200
8010267c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010267f:	83 c0 5c             	add    $0x5c,%eax
80102682:	50                   	push   %eax
80102683:	8d 47 5c             	lea    0x5c(%edi),%eax
80102686:	50                   	push   %eax
80102687:	e8 09 1a 00 00       	call   80104095 <memmove>
    bwrite(dbuf);  // write dst to disk
8010268c:	89 3c 24             	mov    %edi,(%esp)
8010268f:	e8 f2 da ff ff       	call   80100186 <bwrite>
    brelse(lbuf);
80102694:	83 c4 04             	add    $0x4,%esp
80102697:	ff 75 e4             	pushl  -0x1c(%ebp)
8010269a:	e8 22 db ff ff       	call   801001c1 <brelse>
    brelse(dbuf);
8010269f:	89 3c 24             	mov    %edi,(%esp)
801026a2:	e8 1a db ff ff       	call   801001c1 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801026a7:	83 c3 01             	add    $0x1,%ebx
801026aa:	83 c4 10             	add    $0x10,%esp
801026ad:	39 5e 48             	cmp    %ebx,0x48(%esi)
801026b0:	7f 97                	jg     80102649 <install_trans+0x20>
  }
}
801026b2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801026b5:	5b                   	pop    %ebx
801026b6:	5e                   	pop    %esi
801026b7:	5f                   	pop    %edi
801026b8:	5d                   	pop    %ebp
801026b9:	c3                   	ret    
801026ba:	f3 c3                	repz ret 

801026bc <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
801026bc:	55                   	push   %ebp
801026bd:	89 e5                	mov    %esp,%ebp
801026bf:	53                   	push   %ebx
801026c0:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
801026c3:	ff 35 d4 26 11 80    	pushl  0x801126d4
801026c9:	ff 35 e4 26 11 80    	pushl  0x801126e4
801026cf:	e8 d6 d9 ff ff       	call   801000aa <bread>
801026d4:	89 c3                	mov    %eax,%ebx
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
801026d6:	8b 0d e8 26 11 80    	mov    0x801126e8,%ecx
801026dc:	89 48 5c             	mov    %ecx,0x5c(%eax)
  for (i = 0; i < log.lh.n; i++) {
801026df:	83 c4 10             	add    $0x10,%esp
801026e2:	85 c9                	test   %ecx,%ecx
801026e4:	7e 19                	jle    801026ff <write_head+0x43>
801026e6:	c1 e1 02             	shl    $0x2,%ecx
801026e9:	b8 00 00 00 00       	mov    $0x0,%eax
    hb->block[i] = log.lh.block[i];
801026ee:	8b 90 ec 26 11 80    	mov    -0x7feed914(%eax),%edx
801026f4:	89 54 03 60          	mov    %edx,0x60(%ebx,%eax,1)
801026f8:	83 c0 04             	add    $0x4,%eax
  for (i = 0; i < log.lh.n; i++) {
801026fb:	39 c8                	cmp    %ecx,%eax
801026fd:	75 ef                	jne    801026ee <write_head+0x32>
  }
  bwrite(buf);
801026ff:	83 ec 0c             	sub    $0xc,%esp
80102702:	53                   	push   %ebx
80102703:	e8 7e da ff ff       	call   80100186 <bwrite>
  brelse(buf);
80102708:	89 1c 24             	mov    %ebx,(%esp)
8010270b:	e8 b1 da ff ff       	call   801001c1 <brelse>
}
80102710:	83 c4 10             	add    $0x10,%esp
80102713:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102716:	c9                   	leave  
80102717:	c3                   	ret    

80102718 <initlog>:
{
80102718:	55                   	push   %ebp
80102719:	89 e5                	mov    %esp,%ebp
8010271b:	53                   	push   %ebx
8010271c:	83 ec 2c             	sub    $0x2c,%esp
8010271f:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
80102722:	68 a0 6c 10 80       	push   $0x80106ca0
80102727:	68 a0 26 11 80       	push   $0x801126a0
8010272c:	e8 d9 16 00 00       	call   80103e0a <initlock>
  readsb(dev, &sb);
80102731:	83 c4 08             	add    $0x8,%esp
80102734:	8d 45 dc             	lea    -0x24(%ebp),%eax
80102737:	50                   	push   %eax
80102738:	53                   	push   %ebx
80102739:	e8 94 eb ff ff       	call   801012d2 <readsb>
  log.start = sb.logstart;
8010273e:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102741:	a3 d4 26 11 80       	mov    %eax,0x801126d4
  log.size = sb.nlog;
80102746:	8b 55 e8             	mov    -0x18(%ebp),%edx
80102749:	89 15 d8 26 11 80    	mov    %edx,0x801126d8
  log.dev = dev;
8010274f:	89 1d e4 26 11 80    	mov    %ebx,0x801126e4
  struct buf *buf = bread(log.dev, log.start);
80102755:	83 c4 08             	add    $0x8,%esp
80102758:	50                   	push   %eax
80102759:	53                   	push   %ebx
8010275a:	e8 4b d9 ff ff       	call   801000aa <bread>
  log.lh.n = lh->n;
8010275f:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102762:	89 1d e8 26 11 80    	mov    %ebx,0x801126e8
  for (i = 0; i < log.lh.n; i++) {
80102768:	83 c4 10             	add    $0x10,%esp
8010276b:	85 db                	test   %ebx,%ebx
8010276d:	7e 19                	jle    80102788 <initlog+0x70>
8010276f:	c1 e3 02             	shl    $0x2,%ebx
80102772:	ba 00 00 00 00       	mov    $0x0,%edx
    log.lh.block[i] = lh->block[i];
80102777:	8b 4c 10 60          	mov    0x60(%eax,%edx,1),%ecx
8010277b:	89 8a ec 26 11 80    	mov    %ecx,-0x7feed914(%edx)
80102781:	83 c2 04             	add    $0x4,%edx
  for (i = 0; i < log.lh.n; i++) {
80102784:	39 d3                	cmp    %edx,%ebx
80102786:	75 ef                	jne    80102777 <initlog+0x5f>
  brelse(buf);
80102788:	83 ec 0c             	sub    $0xc,%esp
8010278b:	50                   	push   %eax
8010278c:	e8 30 da ff ff       	call   801001c1 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
80102791:	e8 93 fe ff ff       	call   80102629 <install_trans>
  log.lh.n = 0;
80102796:	c7 05 e8 26 11 80 00 	movl   $0x0,0x801126e8
8010279d:	00 00 00 
  write_head(); // clear the log
801027a0:	e8 17 ff ff ff       	call   801026bc <write_head>
}
801027a5:	83 c4 10             	add    $0x10,%esp
801027a8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801027ab:	c9                   	leave  
801027ac:	c3                   	ret    

801027ad <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
801027ad:	55                   	push   %ebp
801027ae:	89 e5                	mov    %esp,%ebp
801027b0:	53                   	push   %ebx
801027b1:	83 ec 10             	sub    $0x10,%esp
  acquire(&log.lock);
801027b4:	68 a0 26 11 80       	push   $0x801126a0
801027b9:	e8 94 17 00 00       	call   80103f52 <acquire>
801027be:	83 c4 10             	add    $0x10,%esp
  while(1){
    if(log.committing){
801027c1:	bb a0 26 11 80       	mov    $0x801126a0,%ebx
801027c6:	eb 15                	jmp    801027dd <begin_op+0x30>
      sleep(&log, &log.lock);
801027c8:	83 ec 08             	sub    $0x8,%esp
801027cb:	68 a0 26 11 80       	push   $0x801126a0
801027d0:	68 a0 26 11 80       	push   $0x801126a0
801027d5:	e8 2d 12 00 00       	call   80103a07 <sleep>
801027da:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
801027dd:	83 7b 40 00          	cmpl   $0x0,0x40(%ebx)
801027e1:	75 e5                	jne    801027c8 <begin_op+0x1b>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
801027e3:	8b 43 3c             	mov    0x3c(%ebx),%eax
801027e6:	83 c0 01             	add    $0x1,%eax
801027e9:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
801027ec:	8b 53 48             	mov    0x48(%ebx),%edx
801027ef:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
801027f2:	83 fa 1e             	cmp    $0x1e,%edx
801027f5:	7e 17                	jle    8010280e <begin_op+0x61>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
801027f7:	83 ec 08             	sub    $0x8,%esp
801027fa:	68 a0 26 11 80       	push   $0x801126a0
801027ff:	68 a0 26 11 80       	push   $0x801126a0
80102804:	e8 fe 11 00 00       	call   80103a07 <sleep>
80102809:	83 c4 10             	add    $0x10,%esp
8010280c:	eb cf                	jmp    801027dd <begin_op+0x30>
    } else {
      log.outstanding += 1;
8010280e:	a3 dc 26 11 80       	mov    %eax,0x801126dc
      release(&log.lock);
80102813:	83 ec 0c             	sub    $0xc,%esp
80102816:	68 a0 26 11 80       	push   $0x801126a0
8010281b:	e8 99 17 00 00       	call   80103fb9 <release>
      break;
    }
  }
}
80102820:	83 c4 10             	add    $0x10,%esp
80102823:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102826:	c9                   	leave  
80102827:	c3                   	ret    

80102828 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80102828:	55                   	push   %ebp
80102829:	89 e5                	mov    %esp,%ebp
8010282b:	57                   	push   %edi
8010282c:	56                   	push   %esi
8010282d:	53                   	push   %ebx
8010282e:	83 ec 28             	sub    $0x28,%esp
  int do_commit = 0;

  acquire(&log.lock);
80102831:	68 a0 26 11 80       	push   $0x801126a0
80102836:	e8 17 17 00 00       	call   80103f52 <acquire>
  log.outstanding -= 1;
8010283b:	a1 dc 26 11 80       	mov    0x801126dc,%eax
80102840:	8d 58 ff             	lea    -0x1(%eax),%ebx
80102843:	89 1d dc 26 11 80    	mov    %ebx,0x801126dc
  if(log.committing)
80102849:	83 c4 10             	add    $0x10,%esp
8010284c:	83 3d e0 26 11 80 00 	cmpl   $0x0,0x801126e0
80102853:	0f 85 e9 00 00 00    	jne    80102942 <end_op+0x11a>
    panic("log.committing");
  if(log.outstanding == 0){
80102859:	85 db                	test   %ebx,%ebx
8010285b:	0f 85 ee 00 00 00    	jne    8010294f <end_op+0x127>
    do_commit = 1;
    log.committing = 1;
80102861:	c7 05 e0 26 11 80 01 	movl   $0x1,0x801126e0
80102868:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
8010286b:	83 ec 0c             	sub    $0xc,%esp
8010286e:	68 a0 26 11 80       	push   $0x801126a0
80102873:	e8 41 17 00 00       	call   80103fb9 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80102878:	83 c4 10             	add    $0x10,%esp
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
8010287b:	be a0 26 11 80       	mov    $0x801126a0,%esi
  if (log.lh.n > 0) {
80102880:	83 3d e8 26 11 80 00 	cmpl   $0x0,0x801126e8
80102887:	7e 7f                	jle    80102908 <end_op+0xe0>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80102889:	83 ec 08             	sub    $0x8,%esp
8010288c:	89 d8                	mov    %ebx,%eax
8010288e:	03 46 34             	add    0x34(%esi),%eax
80102891:	83 c0 01             	add    $0x1,%eax
80102894:	50                   	push   %eax
80102895:	ff 76 44             	pushl  0x44(%esi)
80102898:	e8 0d d8 ff ff       	call   801000aa <bread>
8010289d:	89 c7                	mov    %eax,%edi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010289f:	83 c4 08             	add    $0x8,%esp
801028a2:	ff 34 9d ec 26 11 80 	pushl  -0x7feed914(,%ebx,4)
801028a9:	ff 76 44             	pushl  0x44(%esi)
801028ac:	e8 f9 d7 ff ff       	call   801000aa <bread>
    memmove(to->data, from->data, BSIZE);
801028b1:	83 c4 0c             	add    $0xc,%esp
801028b4:	68 00 02 00 00       	push   $0x200
801028b9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801028bc:	83 c0 5c             	add    $0x5c,%eax
801028bf:	50                   	push   %eax
801028c0:	8d 47 5c             	lea    0x5c(%edi),%eax
801028c3:	50                   	push   %eax
801028c4:	e8 cc 17 00 00       	call   80104095 <memmove>
    bwrite(to);  // write the log
801028c9:	89 3c 24             	mov    %edi,(%esp)
801028cc:	e8 b5 d8 ff ff       	call   80100186 <bwrite>
    brelse(from);
801028d1:	83 c4 04             	add    $0x4,%esp
801028d4:	ff 75 e4             	pushl  -0x1c(%ebp)
801028d7:	e8 e5 d8 ff ff       	call   801001c1 <brelse>
    brelse(to);
801028dc:	89 3c 24             	mov    %edi,(%esp)
801028df:	e8 dd d8 ff ff       	call   801001c1 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801028e4:	83 c3 01             	add    $0x1,%ebx
801028e7:	83 c4 10             	add    $0x10,%esp
801028ea:	3b 5e 48             	cmp    0x48(%esi),%ebx
801028ed:	7c 9a                	jl     80102889 <end_op+0x61>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
801028ef:	e8 c8 fd ff ff       	call   801026bc <write_head>
    install_trans(); // Now install writes to home locations
801028f4:	e8 30 fd ff ff       	call   80102629 <install_trans>
    log.lh.n = 0;
801028f9:	c7 05 e8 26 11 80 00 	movl   $0x0,0x801126e8
80102900:	00 00 00 
    write_head();    // Erase the transaction from the log
80102903:	e8 b4 fd ff ff       	call   801026bc <write_head>
    acquire(&log.lock);
80102908:	83 ec 0c             	sub    $0xc,%esp
8010290b:	68 a0 26 11 80       	push   $0x801126a0
80102910:	e8 3d 16 00 00       	call   80103f52 <acquire>
    log.committing = 0;
80102915:	c7 05 e0 26 11 80 00 	movl   $0x0,0x801126e0
8010291c:	00 00 00 
    wakeup(&log);
8010291f:	c7 04 24 a0 26 11 80 	movl   $0x801126a0,(%esp)
80102926:	e8 5c 12 00 00       	call   80103b87 <wakeup>
    release(&log.lock);
8010292b:	c7 04 24 a0 26 11 80 	movl   $0x801126a0,(%esp)
80102932:	e8 82 16 00 00       	call   80103fb9 <release>
80102937:	83 c4 10             	add    $0x10,%esp
}
8010293a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010293d:	5b                   	pop    %ebx
8010293e:	5e                   	pop    %esi
8010293f:	5f                   	pop    %edi
80102940:	5d                   	pop    %ebp
80102941:	c3                   	ret    
    panic("log.committing");
80102942:	83 ec 0c             	sub    $0xc,%esp
80102945:	68 a4 6c 10 80       	push   $0x80106ca4
8010294a:	e8 f5 d9 ff ff       	call   80100344 <panic>
    wakeup(&log);
8010294f:	83 ec 0c             	sub    $0xc,%esp
80102952:	68 a0 26 11 80       	push   $0x801126a0
80102957:	e8 2b 12 00 00       	call   80103b87 <wakeup>
  release(&log.lock);
8010295c:	c7 04 24 a0 26 11 80 	movl   $0x801126a0,(%esp)
80102963:	e8 51 16 00 00       	call   80103fb9 <release>
80102968:	83 c4 10             	add    $0x10,%esp
8010296b:	eb cd                	jmp    8010293a <end_op+0x112>

8010296d <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
8010296d:	55                   	push   %ebp
8010296e:	89 e5                	mov    %esp,%ebp
80102970:	53                   	push   %ebx
80102971:	83 ec 04             	sub    $0x4,%esp
80102974:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80102977:	8b 15 e8 26 11 80    	mov    0x801126e8,%edx
8010297d:	83 fa 1d             	cmp    $0x1d,%edx
80102980:	7f 6b                	jg     801029ed <log_write+0x80>
80102982:	a1 d8 26 11 80       	mov    0x801126d8,%eax
80102987:	83 e8 01             	sub    $0x1,%eax
8010298a:	39 c2                	cmp    %eax,%edx
8010298c:	7d 5f                	jge    801029ed <log_write+0x80>
    panic("too big a transaction");
  if (log.outstanding < 1)
8010298e:	83 3d dc 26 11 80 00 	cmpl   $0x0,0x801126dc
80102995:	7e 63                	jle    801029fa <log_write+0x8d>
    panic("log_write outside of trans");

  acquire(&log.lock);
80102997:	83 ec 0c             	sub    $0xc,%esp
8010299a:	68 a0 26 11 80       	push   $0x801126a0
8010299f:	e8 ae 15 00 00       	call   80103f52 <acquire>
  for (i = 0; i < log.lh.n; i++) {
801029a4:	8b 15 e8 26 11 80    	mov    0x801126e8,%edx
801029aa:	83 c4 10             	add    $0x10,%esp
801029ad:	85 d2                	test   %edx,%edx
801029af:	7e 56                	jle    80102a07 <log_write+0x9a>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
801029b1:	8b 4b 08             	mov    0x8(%ebx),%ecx
801029b4:	39 0d ec 26 11 80    	cmp    %ecx,0x801126ec
801029ba:	74 5b                	je     80102a17 <log_write+0xaa>
  for (i = 0; i < log.lh.n; i++) {
801029bc:	b8 00 00 00 00       	mov    $0x0,%eax
801029c1:	83 c0 01             	add    $0x1,%eax
801029c4:	39 d0                	cmp    %edx,%eax
801029c6:	74 56                	je     80102a1e <log_write+0xb1>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
801029c8:	39 0c 85 ec 26 11 80 	cmp    %ecx,-0x7feed914(,%eax,4)
801029cf:	75 f0                	jne    801029c1 <log_write+0x54>
      break;
  }
  log.lh.block[i] = b->blockno;
801029d1:	89 0c 85 ec 26 11 80 	mov    %ecx,-0x7feed914(,%eax,4)
  if (i == log.lh.n)
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
801029d8:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
801029db:	83 ec 0c             	sub    $0xc,%esp
801029de:	68 a0 26 11 80       	push   $0x801126a0
801029e3:	e8 d1 15 00 00       	call   80103fb9 <release>
}
801029e8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801029eb:	c9                   	leave  
801029ec:	c3                   	ret    
    panic("too big a transaction");
801029ed:	83 ec 0c             	sub    $0xc,%esp
801029f0:	68 b3 6c 10 80       	push   $0x80106cb3
801029f5:	e8 4a d9 ff ff       	call   80100344 <panic>
    panic("log_write outside of trans");
801029fa:	83 ec 0c             	sub    $0xc,%esp
801029fd:	68 c9 6c 10 80       	push   $0x80106cc9
80102a02:	e8 3d d9 ff ff       	call   80100344 <panic>
  log.lh.block[i] = b->blockno;
80102a07:	8b 43 08             	mov    0x8(%ebx),%eax
80102a0a:	a3 ec 26 11 80       	mov    %eax,0x801126ec
  if (i == log.lh.n)
80102a0f:	85 d2                	test   %edx,%edx
80102a11:	75 c5                	jne    801029d8 <log_write+0x6b>
  for (i = 0; i < log.lh.n; i++) {
80102a13:	89 d0                	mov    %edx,%eax
80102a15:	eb 11                	jmp    80102a28 <log_write+0xbb>
80102a17:	b8 00 00 00 00       	mov    $0x0,%eax
80102a1c:	eb b3                	jmp    801029d1 <log_write+0x64>
  log.lh.block[i] = b->blockno;
80102a1e:	8b 53 08             	mov    0x8(%ebx),%edx
80102a21:	89 14 85 ec 26 11 80 	mov    %edx,-0x7feed914(,%eax,4)
    log.lh.n++;
80102a28:	83 c0 01             	add    $0x1,%eax
80102a2b:	a3 e8 26 11 80       	mov    %eax,0x801126e8
80102a30:	eb a6                	jmp    801029d8 <log_write+0x6b>

80102a32 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
80102a32:	55                   	push   %ebp
80102a33:	89 e5                	mov    %esp,%ebp
80102a35:	53                   	push   %ebx
80102a36:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
80102a39:	e8 ec 08 00 00       	call   8010332a <cpuid>
80102a3e:	89 c3                	mov    %eax,%ebx
80102a40:	e8 e5 08 00 00       	call   8010332a <cpuid>
80102a45:	83 ec 04             	sub    $0x4,%esp
80102a48:	53                   	push   %ebx
80102a49:	50                   	push   %eax
80102a4a:	68 e4 6c 10 80       	push   $0x80106ce4
80102a4f:	e8 8d db ff ff       	call   801005e1 <cprintf>
  idtinit();       // load idt register
80102a54:	e8 04 27 00 00       	call   8010515d <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
80102a59:	e8 55 08 00 00       	call   801032b3 <mycpu>
80102a5e:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
80102a60:	b8 01 00 00 00       	mov    $0x1,%eax
80102a65:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
80102a6c:	e8 6b 0b 00 00       	call   801035dc <scheduler>

80102a71 <mpenter>:
{
80102a71:	55                   	push   %ebp
80102a72:	89 e5                	mov    %esp,%ebp
80102a74:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80102a77:	e8 17 37 00 00       	call   80106193 <switchkvm>
  seginit();
80102a7c:	e8 2b 36 00 00       	call   801060ac <seginit>
  lapicinit();
80102a81:	e8 af f8 ff ff       	call   80102335 <lapicinit>
  mpmain();
80102a86:	e8 a7 ff ff ff       	call   80102a32 <mpmain>

80102a8b <main>:
{
80102a8b:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80102a8f:	83 e4 f0             	and    $0xfffffff0,%esp
80102a92:	ff 71 fc             	pushl  -0x4(%ecx)
80102a95:	55                   	push   %ebp
80102a96:	89 e5                	mov    %esp,%ebp
80102a98:	53                   	push   %ebx
80102a99:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
80102a9a:	83 ec 08             	sub    $0x8,%esp
80102a9d:	68 00 00 40 80       	push   $0x80400000
80102aa2:	68 c8 57 11 80       	push   $0x801157c8
80102aa7:	e8 60 f6 ff ff       	call   8010210c <kinit1>
  kvmalloc();      // kernel page table
80102aac:	e8 67 3b 00 00       	call   80106618 <kvmalloc>
  mpinit();        // detect other processors
80102ab1:	e8 50 01 00 00       	call   80102c06 <mpinit>
  lapicinit();     // interrupt controller
80102ab6:	e8 7a f8 ff ff       	call   80102335 <lapicinit>
  seginit();       // segment descriptors
80102abb:	e8 ec 35 00 00       	call   801060ac <seginit>
  picinit();       // disable pic
80102ac0:	e8 01 03 00 00       	call   80102dc6 <picinit>
  ioapicinit();    // another interrupt controller
80102ac5:	e8 a0 f4 ff ff       	call   80101f6a <ioapicinit>
  consoleinit();   // console hardware
80102aca:	e8 ff dd ff ff       	call   801008ce <consoleinit>
  uartinit();      // serial port
80102acf:	e8 bf 29 00 00       	call   80105493 <uartinit>
  pinit();         // process table
80102ad4:	e8 c0 07 00 00       	call   80103299 <pinit>
  tvinit();        // trap vectors
80102ad9:	e8 f4 25 00 00       	call   801050d2 <tvinit>
  binit();         // buffer cache
80102ade:	e8 51 d5 ff ff       	call   80100034 <binit>
  fileinit();      // file table
80102ae3:	e8 78 e1 ff ff       	call   80100c60 <fileinit>
  ideinit();       // disk 
80102ae8:	e8 8e f2 ff ff       	call   80101d7b <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80102aed:	83 c4 0c             	add    $0xc,%esp
80102af0:	68 8a 00 00 00       	push   $0x8a
80102af5:	68 8c a4 10 80       	push   $0x8010a48c
80102afa:	68 00 70 00 80       	push   $0x80007000
80102aff:	e8 91 15 00 00       	call   80104095 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
80102b04:	69 05 20 2d 11 80 b0 	imul   $0xb0,0x80112d20,%eax
80102b0b:	00 00 00 
80102b0e:	05 a0 27 11 80       	add    $0x801127a0,%eax
80102b13:	83 c4 10             	add    $0x10,%esp
80102b16:	3d a0 27 11 80       	cmp    $0x801127a0,%eax
80102b1b:	76 6c                	jbe    80102b89 <main+0xfe>
80102b1d:	bb a0 27 11 80       	mov    $0x801127a0,%ebx
80102b22:	eb 19                	jmp    80102b3d <main+0xb2>
80102b24:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80102b2a:	69 05 20 2d 11 80 b0 	imul   $0xb0,0x80112d20,%eax
80102b31:	00 00 00 
80102b34:	05 a0 27 11 80       	add    $0x801127a0,%eax
80102b39:	39 c3                	cmp    %eax,%ebx
80102b3b:	73 4c                	jae    80102b89 <main+0xfe>
    if(c == mycpu())  // We've started already.
80102b3d:	e8 71 07 00 00       	call   801032b3 <mycpu>
80102b42:	39 d8                	cmp    %ebx,%eax
80102b44:	74 de                	je     80102b24 <main+0x99>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80102b46:	e8 13 f6 ff ff       	call   8010215e <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
80102b4b:	05 00 10 00 00       	add    $0x1000,%eax
80102b50:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    *(void(**)(void))(code-8) = mpenter;
80102b55:	c7 05 f8 6f 00 80 71 	movl   $0x80102a71,0x80006ff8
80102b5c:	2a 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80102b5f:	c7 05 f4 6f 00 80 00 	movl   $0x109000,0x80006ff4
80102b66:	90 10 00 

    lapicstartap(c->apicid, V2P(code));
80102b69:	83 ec 08             	sub    $0x8,%esp
80102b6c:	68 00 70 00 00       	push   $0x7000
80102b71:	0f b6 03             	movzbl (%ebx),%eax
80102b74:	50                   	push   %eax
80102b75:	e8 04 f9 ff ff       	call   8010247e <lapicstartap>
80102b7a:	83 c4 10             	add    $0x10,%esp

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80102b7d:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80102b83:	85 c0                	test   %eax,%eax
80102b85:	74 f6                	je     80102b7d <main+0xf2>
80102b87:	eb 9b                	jmp    80102b24 <main+0x99>
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80102b89:	83 ec 08             	sub    $0x8,%esp
80102b8c:	68 00 00 00 8e       	push   $0x8e000000
80102b91:	68 00 00 40 80       	push   $0x80400000
80102b96:	e8 a3 f5 ff ff       	call   8010213e <kinit2>
  userinit();      // first user process
80102b9b:	e8 c9 07 00 00       	call   80103369 <userinit>
  mpmain();        // finish this processor's setup
80102ba0:	e8 8d fe ff ff       	call   80102a32 <mpmain>

80102ba5 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80102ba5:	55                   	push   %ebp
80102ba6:	89 e5                	mov    %esp,%ebp
80102ba8:	57                   	push   %edi
80102ba9:	56                   	push   %esi
80102baa:	53                   	push   %ebx
80102bab:	83 ec 0c             	sub    $0xc,%esp
  uchar *e, *p, *addr;

  addr = P2V(a);
80102bae:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
  e = addr+len;
80102bb4:	8d 34 13             	lea    (%ebx,%edx,1),%esi
  for(p = addr; p < e; p += sizeof(struct mp))
80102bb7:	39 f3                	cmp    %esi,%ebx
80102bb9:	72 12                	jb     80102bcd <mpsearch1+0x28>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
      return (struct mp*)p;
  return 0;
80102bbb:	bb 00 00 00 00       	mov    $0x0,%ebx
80102bc0:	eb 3a                	jmp    80102bfc <mpsearch1+0x57>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80102bc2:	84 c0                	test   %al,%al
80102bc4:	74 36                	je     80102bfc <mpsearch1+0x57>
  for(p = addr; p < e; p += sizeof(struct mp))
80102bc6:	83 c3 10             	add    $0x10,%ebx
80102bc9:	39 de                	cmp    %ebx,%esi
80102bcb:	76 2a                	jbe    80102bf7 <mpsearch1+0x52>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80102bcd:	83 ec 04             	sub    $0x4,%esp
80102bd0:	6a 04                	push   $0x4
80102bd2:	68 f8 6c 10 80       	push   $0x80106cf8
80102bd7:	53                   	push   %ebx
80102bd8:	e8 67 14 00 00       	call   80104044 <memcmp>
80102bdd:	83 c4 10             	add    $0x10,%esp
80102be0:	85 c0                	test   %eax,%eax
80102be2:	75 e2                	jne    80102bc6 <mpsearch1+0x21>
80102be4:	89 d9                	mov    %ebx,%ecx
80102be6:	8d 7b 10             	lea    0x10(%ebx),%edi
    sum += addr[i];
80102be9:	0f b6 11             	movzbl (%ecx),%edx
80102bec:	01 d0                	add    %edx,%eax
80102bee:	83 c1 01             	add    $0x1,%ecx
  for(i=0; i<len; i++)
80102bf1:	39 f9                	cmp    %edi,%ecx
80102bf3:	75 f4                	jne    80102be9 <mpsearch1+0x44>
80102bf5:	eb cb                	jmp    80102bc2 <mpsearch1+0x1d>
  return 0;
80102bf7:	bb 00 00 00 00       	mov    $0x0,%ebx
}
80102bfc:	89 d8                	mov    %ebx,%eax
80102bfe:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102c01:	5b                   	pop    %ebx
80102c02:	5e                   	pop    %esi
80102c03:	5f                   	pop    %edi
80102c04:	5d                   	pop    %ebp
80102c05:	c3                   	ret    

80102c06 <mpinit>:
  return conf;
}

void
mpinit(void)
{
80102c06:	55                   	push   %ebp
80102c07:	89 e5                	mov    %esp,%ebp
80102c09:	57                   	push   %edi
80102c0a:	56                   	push   %esi
80102c0b:	53                   	push   %ebx
80102c0c:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80102c0f:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80102c16:	c1 e0 08             	shl    $0x8,%eax
80102c19:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80102c20:	09 d0                	or     %edx,%eax
80102c22:	c1 e0 04             	shl    $0x4,%eax
80102c25:	85 c0                	test   %eax,%eax
80102c27:	0f 84 b0 00 00 00    	je     80102cdd <mpinit+0xd7>
    if((mp = mpsearch1(p, 1024)))
80102c2d:	ba 00 04 00 00       	mov    $0x400,%edx
80102c32:	e8 6e ff ff ff       	call   80102ba5 <mpsearch1>
80102c37:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102c3a:	85 c0                	test   %eax,%eax
80102c3c:	0f 84 cb 00 00 00    	je     80102d0d <mpinit+0x107>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80102c42:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102c45:	8b 58 04             	mov    0x4(%eax),%ebx
80102c48:	85 db                	test   %ebx,%ebx
80102c4a:	0f 84 d7 00 00 00    	je     80102d27 <mpinit+0x121>
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80102c50:	8d b3 00 00 00 80    	lea    -0x80000000(%ebx),%esi
  if(memcmp(conf, "PCMP", 4) != 0)
80102c56:	83 ec 04             	sub    $0x4,%esp
80102c59:	6a 04                	push   $0x4
80102c5b:	68 fd 6c 10 80       	push   $0x80106cfd
80102c60:	56                   	push   %esi
80102c61:	e8 de 13 00 00       	call   80104044 <memcmp>
80102c66:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80102c69:	83 c4 10             	add    $0x10,%esp
80102c6c:	85 c0                	test   %eax,%eax
80102c6e:	0f 85 b3 00 00 00    	jne    80102d27 <mpinit+0x121>
  if(conf->version != 1 && conf->version != 4)
80102c74:	0f b6 83 06 00 00 80 	movzbl -0x7ffffffa(%ebx),%eax
80102c7b:	3c 01                	cmp    $0x1,%al
80102c7d:	74 08                	je     80102c87 <mpinit+0x81>
80102c7f:	3c 04                	cmp    $0x4,%al
80102c81:	0f 85 a0 00 00 00    	jne    80102d27 <mpinit+0x121>
  if(sum((uchar*)conf, conf->length) != 0)
80102c87:	0f b7 93 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edx
  for(i=0; i<len; i++)
80102c8e:	66 85 d2             	test   %dx,%dx
80102c91:	74 1f                	je     80102cb2 <mpinit+0xac>
80102c93:	89 f0                	mov    %esi,%eax
80102c95:	0f b7 d2             	movzwl %dx,%edx
80102c98:	8d bc 13 00 00 00 80 	lea    -0x80000000(%ebx,%edx,1),%edi
  sum = 0;
80102c9f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
    sum += addr[i];
80102ca2:	0f b6 08             	movzbl (%eax),%ecx
80102ca5:	01 ca                	add    %ecx,%edx
80102ca7:	83 c0 01             	add    $0x1,%eax
  for(i=0; i<len; i++)
80102caa:	39 c7                	cmp    %eax,%edi
80102cac:	75 f4                	jne    80102ca2 <mpinit+0x9c>
  if(sum((uchar*)conf, conf->length) != 0)
80102cae:	84 d2                	test   %dl,%dl
80102cb0:	75 75                	jne    80102d27 <mpinit+0x121>
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
80102cb2:	85 f6                	test   %esi,%esi
80102cb4:	74 71                	je     80102d27 <mpinit+0x121>
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
80102cb6:	8b 83 24 00 00 80    	mov    -0x7fffffdc(%ebx),%eax
80102cbc:	a3 9c 26 11 80       	mov    %eax,0x8011269c
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102cc1:	8d 83 2c 00 00 80    	lea    -0x7fffffd4(%ebx),%eax
80102cc7:	0f b7 93 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edx
80102cce:	01 d6                	add    %edx,%esi
  ismp = 1;
80102cd0:	b9 01 00 00 00       	mov    $0x1,%ecx
    case MPIOINTR:
    case MPLINTR:
      p += 8;
      continue;
    default:
      ismp = 0;
80102cd5:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102cd8:	e9 88 00 00 00       	jmp    80102d65 <mpinit+0x15f>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80102cdd:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80102ce4:	c1 e0 08             	shl    $0x8,%eax
80102ce7:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
80102cee:	09 d0                	or     %edx,%eax
80102cf0:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80102cf3:	2d 00 04 00 00       	sub    $0x400,%eax
80102cf8:	ba 00 04 00 00       	mov    $0x400,%edx
80102cfd:	e8 a3 fe ff ff       	call   80102ba5 <mpsearch1>
80102d02:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102d05:	85 c0                	test   %eax,%eax
80102d07:	0f 85 35 ff ff ff    	jne    80102c42 <mpinit+0x3c>
  return mpsearch1(0xF0000, 0x10000);
80102d0d:	ba 00 00 01 00       	mov    $0x10000,%edx
80102d12:	b8 00 00 0f 00       	mov    $0xf0000,%eax
80102d17:	e8 89 fe ff ff       	call   80102ba5 <mpsearch1>
80102d1c:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80102d1f:	85 c0                	test   %eax,%eax
80102d21:	0f 85 1b ff ff ff    	jne    80102c42 <mpinit+0x3c>
    panic("Expect to run on an SMP");
80102d27:	83 ec 0c             	sub    $0xc,%esp
80102d2a:	68 02 6d 10 80       	push   $0x80106d02
80102d2f:	e8 10 d6 ff ff       	call   80100344 <panic>
      ismp = 0;
80102d34:	89 f9                	mov    %edi,%ecx
80102d36:	eb 34                	jmp    80102d6c <mpinit+0x166>
      if(ncpu < NCPU) {
80102d38:	8b 15 20 2d 11 80    	mov    0x80112d20,%edx
80102d3e:	83 fa 07             	cmp    $0x7,%edx
80102d41:	7f 1f                	jg     80102d62 <mpinit+0x15c>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80102d43:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80102d46:	69 da b0 00 00 00    	imul   $0xb0,%edx,%ebx
80102d4c:	0f b6 50 01          	movzbl 0x1(%eax),%edx
80102d50:	88 93 a0 27 11 80    	mov    %dl,-0x7feed860(%ebx)
        ncpu++;
80102d56:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80102d59:	83 c2 01             	add    $0x1,%edx
80102d5c:	89 15 20 2d 11 80    	mov    %edx,0x80112d20
      p += sizeof(struct mpproc);
80102d62:	83 c0 14             	add    $0x14,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102d65:	39 f0                	cmp    %esi,%eax
80102d67:	73 26                	jae    80102d8f <mpinit+0x189>
    switch(*p){
80102d69:	0f b6 10             	movzbl (%eax),%edx
80102d6c:	80 fa 04             	cmp    $0x4,%dl
80102d6f:	77 c3                	ja     80102d34 <mpinit+0x12e>
80102d71:	0f b6 d2             	movzbl %dl,%edx
80102d74:	ff 24 95 3c 6d 10 80 	jmp    *-0x7fef92c4(,%edx,4)
      ioapicid = ioapic->apicno;
80102d7b:	0f b6 50 01          	movzbl 0x1(%eax),%edx
80102d7f:	88 15 80 27 11 80    	mov    %dl,0x80112780
      p += sizeof(struct mpioapic);
80102d85:	83 c0 08             	add    $0x8,%eax
      continue;
80102d88:	eb db                	jmp    80102d65 <mpinit+0x15f>
      p += 8;
80102d8a:	83 c0 08             	add    $0x8,%eax
      continue;
80102d8d:	eb d6                	jmp    80102d65 <mpinit+0x15f>
      break;
    }
  }
  if(!ismp)
80102d8f:	85 c9                	test   %ecx,%ecx
80102d91:	74 26                	je     80102db9 <mpinit+0x1b3>
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
80102d93:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102d96:	80 78 0c 00          	cmpb   $0x0,0xc(%eax)
80102d9a:	74 15                	je     80102db1 <mpinit+0x1ab>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102d9c:	b8 70 00 00 00       	mov    $0x70,%eax
80102da1:	ba 22 00 00 00       	mov    $0x22,%edx
80102da6:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102da7:	ba 23 00 00 00       	mov    $0x23,%edx
80102dac:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
80102dad:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102db0:	ee                   	out    %al,(%dx)
  }
}
80102db1:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102db4:	5b                   	pop    %ebx
80102db5:	5e                   	pop    %esi
80102db6:	5f                   	pop    %edi
80102db7:	5d                   	pop    %ebp
80102db8:	c3                   	ret    
    panic("Didn't find a suitable machine");
80102db9:	83 ec 0c             	sub    $0xc,%esp
80102dbc:	68 1c 6d 10 80       	push   $0x80106d1c
80102dc1:	e8 7e d5 ff ff       	call   80100344 <panic>

80102dc6 <picinit>:
#define IO_PIC2         0xA0    // Slave (IRQs 8-15)

// Don't use the 8259A interrupt controllers.  Xv6 assumes SMP hardware.
void
picinit(void)
{
80102dc6:	55                   	push   %ebp
80102dc7:	89 e5                	mov    %esp,%ebp
80102dc9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102dce:	ba 21 00 00 00       	mov    $0x21,%edx
80102dd3:	ee                   	out    %al,(%dx)
80102dd4:	ba a1 00 00 00       	mov    $0xa1,%edx
80102dd9:	ee                   	out    %al,(%dx)
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80102dda:	5d                   	pop    %ebp
80102ddb:	c3                   	ret    

80102ddc <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80102ddc:	55                   	push   %ebp
80102ddd:	89 e5                	mov    %esp,%ebp
80102ddf:	57                   	push   %edi
80102de0:	56                   	push   %esi
80102de1:	53                   	push   %ebx
80102de2:	83 ec 0c             	sub    $0xc,%esp
80102de5:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102de8:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
80102deb:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80102df1:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
80102df7:	e8 7e de ff ff       	call   80100c7a <filealloc>
80102dfc:	89 03                	mov    %eax,(%ebx)
80102dfe:	85 c0                	test   %eax,%eax
80102e00:	0f 84 a9 00 00 00    	je     80102eaf <pipealloc+0xd3>
80102e06:	e8 6f de ff ff       	call   80100c7a <filealloc>
80102e0b:	89 06                	mov    %eax,(%esi)
80102e0d:	85 c0                	test   %eax,%eax
80102e0f:	0f 84 88 00 00 00    	je     80102e9d <pipealloc+0xc1>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80102e15:	e8 44 f3 ff ff       	call   8010215e <kalloc>
80102e1a:	89 c7                	mov    %eax,%edi
80102e1c:	85 c0                	test   %eax,%eax
80102e1e:	75 0b                	jne    80102e2b <pipealloc+0x4f>

//PAGEBREAK: 20
 bad:
  if(p)
    kfree((char*)p);
  if(*f0)
80102e20:	8b 03                	mov    (%ebx),%eax
80102e22:	85 c0                	test   %eax,%eax
80102e24:	75 7d                	jne    80102ea3 <pipealloc+0xc7>
80102e26:	e9 84 00 00 00       	jmp    80102eaf <pipealloc+0xd3>
  p->readopen = 1;
80102e2b:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
80102e32:	00 00 00 
  p->writeopen = 1;
80102e35:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
80102e3c:	00 00 00 
  p->nwrite = 0;
80102e3f:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80102e46:	00 00 00 
  p->nread = 0;
80102e49:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80102e50:	00 00 00 
  initlock(&p->lock, "pipe");
80102e53:	83 ec 08             	sub    $0x8,%esp
80102e56:	68 50 6d 10 80       	push   $0x80106d50
80102e5b:	50                   	push   %eax
80102e5c:	e8 a9 0f 00 00       	call   80103e0a <initlock>
  (*f0)->type = FD_PIPE;
80102e61:	8b 03                	mov    (%ebx),%eax
80102e63:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80102e69:	8b 03                	mov    (%ebx),%eax
80102e6b:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
80102e6f:	8b 03                	mov    (%ebx),%eax
80102e71:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80102e75:	8b 03                	mov    (%ebx),%eax
80102e77:	89 78 0c             	mov    %edi,0xc(%eax)
  (*f1)->type = FD_PIPE;
80102e7a:	8b 06                	mov    (%esi),%eax
80102e7c:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80102e82:	8b 06                	mov    (%esi),%eax
80102e84:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80102e88:	8b 06                	mov    (%esi),%eax
80102e8a:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
80102e8e:	8b 06                	mov    (%esi),%eax
80102e90:	89 78 0c             	mov    %edi,0xc(%eax)
  return 0;
80102e93:	83 c4 10             	add    $0x10,%esp
80102e96:	b8 00 00 00 00       	mov    $0x0,%eax
80102e9b:	eb 2e                	jmp    80102ecb <pipealloc+0xef>
  if(*f0)
80102e9d:	8b 03                	mov    (%ebx),%eax
80102e9f:	85 c0                	test   %eax,%eax
80102ea1:	74 30                	je     80102ed3 <pipealloc+0xf7>
    fileclose(*f0);
80102ea3:	83 ec 0c             	sub    $0xc,%esp
80102ea6:	50                   	push   %eax
80102ea7:	e8 80 de ff ff       	call   80100d2c <fileclose>
80102eac:	83 c4 10             	add    $0x10,%esp
  if(*f1)
80102eaf:	8b 16                	mov    (%esi),%edx
    fileclose(*f1);
  return -1;
80102eb1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  if(*f1)
80102eb6:	85 d2                	test   %edx,%edx
80102eb8:	74 11                	je     80102ecb <pipealloc+0xef>
    fileclose(*f1);
80102eba:	83 ec 0c             	sub    $0xc,%esp
80102ebd:	52                   	push   %edx
80102ebe:	e8 69 de ff ff       	call   80100d2c <fileclose>
80102ec3:	83 c4 10             	add    $0x10,%esp
  return -1;
80102ec6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80102ecb:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102ece:	5b                   	pop    %ebx
80102ecf:	5e                   	pop    %esi
80102ed0:	5f                   	pop    %edi
80102ed1:	5d                   	pop    %ebp
80102ed2:	c3                   	ret    
  return -1;
80102ed3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102ed8:	eb f1                	jmp    80102ecb <pipealloc+0xef>

80102eda <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80102eda:	55                   	push   %ebp
80102edb:	89 e5                	mov    %esp,%ebp
80102edd:	53                   	push   %ebx
80102ede:	83 ec 10             	sub    $0x10,%esp
80102ee1:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&p->lock);
80102ee4:	53                   	push   %ebx
80102ee5:	e8 68 10 00 00       	call   80103f52 <acquire>
  if(writable){
80102eea:	83 c4 10             	add    $0x10,%esp
80102eed:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80102ef1:	74 3f                	je     80102f32 <pipeclose+0x58>
    p->writeopen = 0;
80102ef3:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
80102efa:	00 00 00 
    wakeup(&p->nread);
80102efd:	83 ec 0c             	sub    $0xc,%esp
80102f00:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80102f06:	50                   	push   %eax
80102f07:	e8 7b 0c 00 00       	call   80103b87 <wakeup>
80102f0c:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
80102f0f:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80102f16:	75 09                	jne    80102f21 <pipeclose+0x47>
80102f18:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
80102f1f:	74 2f                	je     80102f50 <pipeclose+0x76>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
80102f21:	83 ec 0c             	sub    $0xc,%esp
80102f24:	53                   	push   %ebx
80102f25:	e8 8f 10 00 00       	call   80103fb9 <release>
80102f2a:	83 c4 10             	add    $0x10,%esp
}
80102f2d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102f30:	c9                   	leave  
80102f31:	c3                   	ret    
    p->readopen = 0;
80102f32:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80102f39:	00 00 00 
    wakeup(&p->nwrite);
80102f3c:	83 ec 0c             	sub    $0xc,%esp
80102f3f:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
80102f45:	50                   	push   %eax
80102f46:	e8 3c 0c 00 00       	call   80103b87 <wakeup>
80102f4b:	83 c4 10             	add    $0x10,%esp
80102f4e:	eb bf                	jmp    80102f0f <pipeclose+0x35>
    release(&p->lock);
80102f50:	83 ec 0c             	sub    $0xc,%esp
80102f53:	53                   	push   %ebx
80102f54:	e8 60 10 00 00       	call   80103fb9 <release>
    kfree((char*)p);
80102f59:	89 1c 24             	mov    %ebx,(%esp)
80102f5c:	e8 d8 f0 ff ff       	call   80102039 <kfree>
80102f61:	83 c4 10             	add    $0x10,%esp
80102f64:	eb c7                	jmp    80102f2d <pipeclose+0x53>

80102f66 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80102f66:	55                   	push   %ebp
80102f67:	89 e5                	mov    %esp,%ebp
80102f69:	57                   	push   %edi
80102f6a:	56                   	push   %esi
80102f6b:	53                   	push   %ebx
80102f6c:	83 ec 28             	sub    $0x28,%esp
80102f6f:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102f72:	8b 75 0c             	mov    0xc(%ebp),%esi
  int i;

  acquire(&p->lock);
80102f75:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80102f78:	53                   	push   %ebx
80102f79:	e8 d4 0f 00 00       	call   80103f52 <acquire>
  for(i = 0; i < n; i++){
80102f7e:	83 c4 10             	add    $0x10,%esp
80102f81:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80102f85:	0f 8e b5 00 00 00    	jle    80103040 <pipewrite+0xda>
80102f8b:	89 75 e0             	mov    %esi,-0x20(%ebp)
80102f8e:	03 75 10             	add    0x10(%ebp),%esi
80102f91:	89 75 dc             	mov    %esi,-0x24(%ebp)
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80102f94:	8d bb 34 02 00 00    	lea    0x234(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80102f9a:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80102fa0:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80102fa6:	05 00 02 00 00       	add    $0x200,%eax
80102fab:	39 c2                	cmp    %eax,%edx
80102fad:	75 69                	jne    80103018 <pipewrite+0xb2>
      if(p->readopen == 0 || myproc()->killed){
80102faf:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80102fb6:	74 47                	je     80102fff <pipewrite+0x99>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80102fb8:	8d b3 38 02 00 00    	lea    0x238(%ebx),%esi
      if(p->readopen == 0 || myproc()->killed){
80102fbe:	e8 82 03 00 00       	call   80103345 <myproc>
80102fc3:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80102fc7:	75 36                	jne    80102fff <pipewrite+0x99>
      wakeup(&p->nread);
80102fc9:	83 ec 0c             	sub    $0xc,%esp
80102fcc:	57                   	push   %edi
80102fcd:	e8 b5 0b 00 00       	call   80103b87 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80102fd2:	83 c4 08             	add    $0x8,%esp
80102fd5:	ff 75 e4             	pushl  -0x1c(%ebp)
80102fd8:	56                   	push   %esi
80102fd9:	e8 29 0a 00 00       	call   80103a07 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80102fde:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80102fe4:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80102fea:	05 00 02 00 00       	add    $0x200,%eax
80102fef:	83 c4 10             	add    $0x10,%esp
80102ff2:	39 c2                	cmp    %eax,%edx
80102ff4:	75 22                	jne    80103018 <pipewrite+0xb2>
      if(p->readopen == 0 || myproc()->killed){
80102ff6:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80102ffd:	75 bf                	jne    80102fbe <pipewrite+0x58>
        release(&p->lock);
80102fff:	83 ec 0c             	sub    $0xc,%esp
80103002:	53                   	push   %ebx
80103003:	e8 b1 0f 00 00       	call   80103fb9 <release>
        return -1;
80103008:	83 c4 10             	add    $0x10,%esp
8010300b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
80103010:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103013:	5b                   	pop    %ebx
80103014:	5e                   	pop    %esi
80103015:	5f                   	pop    %edi
80103016:	5d                   	pop    %ebp
80103017:	c3                   	ret    
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
80103018:	8d 42 01             	lea    0x1(%edx),%eax
8010301b:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
80103021:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80103024:	0f b6 01             	movzbl (%ecx),%eax
80103027:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
8010302d:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
80103031:	83 c1 01             	add    $0x1,%ecx
80103034:	89 4d e0             	mov    %ecx,-0x20(%ebp)
  for(i = 0; i < n; i++){
80103037:	3b 4d dc             	cmp    -0x24(%ebp),%ecx
8010303a:	0f 85 5a ff ff ff    	jne    80102f9a <pipewrite+0x34>
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
80103040:	83 ec 0c             	sub    $0xc,%esp
80103043:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103049:	50                   	push   %eax
8010304a:	e8 38 0b 00 00       	call   80103b87 <wakeup>
  release(&p->lock);
8010304f:	89 1c 24             	mov    %ebx,(%esp)
80103052:	e8 62 0f 00 00       	call   80103fb9 <release>
  return n;
80103057:	83 c4 10             	add    $0x10,%esp
8010305a:	8b 45 10             	mov    0x10(%ebp),%eax
8010305d:	eb b1                	jmp    80103010 <pipewrite+0xaa>

8010305f <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
8010305f:	55                   	push   %ebp
80103060:	89 e5                	mov    %esp,%ebp
80103062:	57                   	push   %edi
80103063:	56                   	push   %esi
80103064:	53                   	push   %ebx
80103065:	83 ec 18             	sub    $0x18,%esp
80103068:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int i;

  acquire(&p->lock);
8010306b:	53                   	push   %ebx
8010306c:	e8 e1 0e 00 00       	call   80103f52 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
80103071:	83 c4 10             	add    $0x10,%esp
80103074:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
8010307a:	39 83 34 02 00 00    	cmp    %eax,0x234(%ebx)
80103080:	75 7c                	jne    801030fe <piperead+0x9f>
80103082:	89 de                	mov    %ebx,%esi
80103084:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
8010308b:	74 35                	je     801030c2 <piperead+0x63>
    if(myproc()->killed){
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
8010308d:	8d bb 34 02 00 00    	lea    0x234(%ebx),%edi
    if(myproc()->killed){
80103093:	e8 ad 02 00 00       	call   80103345 <myproc>
80103098:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010309c:	75 4d                	jne    801030eb <piperead+0x8c>
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
8010309e:	83 ec 08             	sub    $0x8,%esp
801030a1:	56                   	push   %esi
801030a2:	57                   	push   %edi
801030a3:	e8 5f 09 00 00       	call   80103a07 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
801030a8:	83 c4 10             	add    $0x10,%esp
801030ab:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
801030b1:	39 83 34 02 00 00    	cmp    %eax,0x234(%ebx)
801030b7:	75 45                	jne    801030fe <piperead+0x9f>
801030b9:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
801030c0:	75 d1                	jne    80103093 <piperead+0x34>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801030c2:	be 00 00 00 00       	mov    $0x0,%esi
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
801030c7:	83 ec 0c             	sub    $0xc,%esp
801030ca:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
801030d0:	50                   	push   %eax
801030d1:	e8 b1 0a 00 00       	call   80103b87 <wakeup>
  release(&p->lock);
801030d6:	89 1c 24             	mov    %ebx,(%esp)
801030d9:	e8 db 0e 00 00       	call   80103fb9 <release>
  return i;
801030de:	83 c4 10             	add    $0x10,%esp
}
801030e1:	89 f0                	mov    %esi,%eax
801030e3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801030e6:	5b                   	pop    %ebx
801030e7:	5e                   	pop    %esi
801030e8:	5f                   	pop    %edi
801030e9:	5d                   	pop    %ebp
801030ea:	c3                   	ret    
      release(&p->lock);
801030eb:	83 ec 0c             	sub    $0xc,%esp
801030ee:	53                   	push   %ebx
801030ef:	e8 c5 0e 00 00       	call   80103fb9 <release>
      return -1;
801030f4:	83 c4 10             	add    $0x10,%esp
801030f7:	be ff ff ff ff       	mov    $0xffffffff,%esi
801030fc:	eb e3                	jmp    801030e1 <piperead+0x82>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801030fe:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80103102:	7e 3c                	jle    80103140 <piperead+0xe1>
    if(p->nread == p->nwrite)
80103104:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
8010310a:	be 00 00 00 00       	mov    $0x0,%esi
    addr[i] = p->data[p->nread++ % PIPESIZE];
8010310f:	8d 50 01             	lea    0x1(%eax),%edx
80103112:	89 93 34 02 00 00    	mov    %edx,0x234(%ebx)
80103118:	25 ff 01 00 00       	and    $0x1ff,%eax
8010311d:	0f b6 44 03 34       	movzbl 0x34(%ebx,%eax,1),%eax
80103122:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103125:	88 04 31             	mov    %al,(%ecx,%esi,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103128:	83 c6 01             	add    $0x1,%esi
8010312b:	39 75 10             	cmp    %esi,0x10(%ebp)
8010312e:	74 97                	je     801030c7 <piperead+0x68>
    if(p->nread == p->nwrite)
80103130:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80103136:	3b 83 38 02 00 00    	cmp    0x238(%ebx),%eax
8010313c:	75 d1                	jne    8010310f <piperead+0xb0>
8010313e:	eb 87                	jmp    801030c7 <piperead+0x68>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103140:	be 00 00 00 00       	mov    $0x0,%esi
80103145:	eb 80                	jmp    801030c7 <piperead+0x68>

80103147 <wakeup1>:
//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
80103147:	55                   	push   %ebp
80103148:	89 e5                	mov    %esp,%ebp
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010314a:	ba 74 2d 11 80       	mov    $0x80112d74,%edx
8010314f:	eb 0e                	jmp    8010315f <wakeup1+0x18>
80103151:	81 c2 88 00 00 00    	add    $0x88,%edx
80103157:	81 fa 74 4f 11 80    	cmp    $0x80114f74,%edx
8010315d:	73 14                	jae    80103173 <wakeup1+0x2c>
    if(p->state == SLEEPING && p->chan == chan)
8010315f:	83 7a 0c 02          	cmpl   $0x2,0xc(%edx)
80103163:	75 ec                	jne    80103151 <wakeup1+0xa>
80103165:	39 42 20             	cmp    %eax,0x20(%edx)
80103168:	75 e7                	jne    80103151 <wakeup1+0xa>
      p->state = RUNNABLE;
8010316a:	c7 42 0c 03 00 00 00 	movl   $0x3,0xc(%edx)
80103171:	eb de                	jmp    80103151 <wakeup1+0xa>
}
80103173:	5d                   	pop    %ebp
80103174:	c3                   	ret    

80103175 <allocproc>:
{
80103175:	55                   	push   %ebp
80103176:	89 e5                	mov    %esp,%ebp
80103178:	53                   	push   %ebx
80103179:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
8010317c:	68 40 2d 11 80       	push   $0x80112d40
80103181:	e8 cc 0d 00 00       	call   80103f52 <acquire>
    if(p->state == UNUSED)
80103186:	83 c4 10             	add    $0x10,%esp
80103189:	83 3d 80 2d 11 80 00 	cmpl   $0x0,0x80112d80
80103190:	74 30                	je     801031c2 <allocproc+0x4d>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103192:	bb fc 2d 11 80       	mov    $0x80112dfc,%ebx
    if(p->state == UNUSED)
80103197:	83 7b 0c 00          	cmpl   $0x0,0xc(%ebx)
8010319b:	74 2a                	je     801031c7 <allocproc+0x52>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010319d:	81 c3 88 00 00 00    	add    $0x88,%ebx
801031a3:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
801031a9:	72 ec                	jb     80103197 <allocproc+0x22>
  release(&ptable.lock);
801031ab:	83 ec 0c             	sub    $0xc,%esp
801031ae:	68 40 2d 11 80       	push   $0x80112d40
801031b3:	e8 01 0e 00 00       	call   80103fb9 <release>
  return 0;
801031b8:	83 c4 10             	add    $0x10,%esp
801031bb:	bb 00 00 00 00       	mov    $0x0,%ebx
801031c0:	eb 7f                	jmp    80103241 <allocproc+0xcc>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801031c2:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
  p->state = EMBRYO;
801031c7:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
801031ce:	a1 04 a0 10 80       	mov    0x8010a004,%eax
801031d3:	8d 50 01             	lea    0x1(%eax),%edx
801031d6:	89 15 04 a0 10 80    	mov    %edx,0x8010a004
801031dc:	89 43 10             	mov    %eax,0x10(%ebx)
  p->priority = 20;
801031df:	c7 43 7c 14 00 00 00 	movl   $0x14,0x7c(%ebx)
  p->rt_rr = 0;
801031e6:	c7 83 80 00 00 00 00 	movl   $0x0,0x80(%ebx)
801031ed:	00 00 00 
  release(&ptable.lock);
801031f0:	83 ec 0c             	sub    $0xc,%esp
801031f3:	68 40 2d 11 80       	push   $0x80112d40
801031f8:	e8 bc 0d 00 00       	call   80103fb9 <release>
  if((p->kstack = kalloc()) == 0){
801031fd:	e8 5c ef ff ff       	call   8010215e <kalloc>
80103202:	89 43 08             	mov    %eax,0x8(%ebx)
80103205:	83 c4 10             	add    $0x10,%esp
80103208:	85 c0                	test   %eax,%eax
8010320a:	74 3c                	je     80103248 <allocproc+0xd3>
  sp -= sizeof *p->tf;
8010320c:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
80103212:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
80103215:	c7 80 b0 0f 00 00 c7 	movl   $0x801050c7,0xfb0(%eax)
8010321c:	50 10 80 
  sp -= sizeof *p->context;
8010321f:	05 9c 0f 00 00       	add    $0xf9c,%eax
  p->context = (struct context*)sp;
80103224:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
80103227:	83 ec 04             	sub    $0x4,%esp
8010322a:	6a 14                	push   $0x14
8010322c:	6a 00                	push   $0x0
8010322e:	50                   	push   %eax
8010322f:	e8 cc 0d 00 00       	call   80104000 <memset>
  p->context->eip = (uint)forkret;
80103234:	8b 43 1c             	mov    0x1c(%ebx),%eax
80103237:	c7 40 10 56 32 10 80 	movl   $0x80103256,0x10(%eax)
  return p;
8010323e:	83 c4 10             	add    $0x10,%esp
}
80103241:	89 d8                	mov    %ebx,%eax
80103243:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103246:	c9                   	leave  
80103247:	c3                   	ret    
    p->state = UNUSED;
80103248:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return 0;
8010324f:	bb 00 00 00 00       	mov    $0x0,%ebx
80103254:	eb eb                	jmp    80103241 <allocproc+0xcc>

80103256 <forkret>:
{
80103256:	55                   	push   %ebp
80103257:	89 e5                	mov    %esp,%ebp
80103259:	83 ec 14             	sub    $0x14,%esp
  release(&ptable.lock);
8010325c:	68 40 2d 11 80       	push   $0x80112d40
80103261:	e8 53 0d 00 00       	call   80103fb9 <release>
  if (first) {
80103266:	83 c4 10             	add    $0x10,%esp
80103269:	83 3d 00 a0 10 80 00 	cmpl   $0x0,0x8010a000
80103270:	75 02                	jne    80103274 <forkret+0x1e>
}
80103272:	c9                   	leave  
80103273:	c3                   	ret    
    first = 0;
80103274:	c7 05 00 a0 10 80 00 	movl   $0x0,0x8010a000
8010327b:	00 00 00 
    iinit(ROOTDEV);
8010327e:	83 ec 0c             	sub    $0xc,%esp
80103281:	6a 01                	push   $0x1
80103283:	e8 7e e0 ff ff       	call   80101306 <iinit>
    initlog(ROOTDEV);
80103288:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
8010328f:	e8 84 f4 ff ff       	call   80102718 <initlog>
80103294:	83 c4 10             	add    $0x10,%esp
}
80103297:	eb d9                	jmp    80103272 <forkret+0x1c>

80103299 <pinit>:
{
80103299:	55                   	push   %ebp
8010329a:	89 e5                	mov    %esp,%ebp
8010329c:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
8010329f:	68 55 6d 10 80       	push   $0x80106d55
801032a4:	68 40 2d 11 80       	push   $0x80112d40
801032a9:	e8 5c 0b 00 00       	call   80103e0a <initlock>
}
801032ae:	83 c4 10             	add    $0x10,%esp
801032b1:	c9                   	leave  
801032b2:	c3                   	ret    

801032b3 <mycpu>:
{
801032b3:	55                   	push   %ebp
801032b4:	89 e5                	mov    %esp,%ebp
801032b6:	56                   	push   %esi
801032b7:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
801032b8:	9c                   	pushf  
801032b9:	58                   	pop    %eax
  if(readeflags()&FL_IF)
801032ba:	f6 c4 02             	test   $0x2,%ah
801032bd:	75 4a                	jne    80103309 <mycpu+0x56>
  apicid = lapicid();
801032bf:	e8 7c f1 ff ff       	call   80102440 <lapicid>
  for (i = 0; i < ncpu; ++i) {
801032c4:	8b 35 20 2d 11 80    	mov    0x80112d20,%esi
801032ca:	85 f6                	test   %esi,%esi
801032cc:	7e 4f                	jle    8010331d <mycpu+0x6a>
    if (cpus[i].apicid == apicid)
801032ce:	0f b6 15 a0 27 11 80 	movzbl 0x801127a0,%edx
801032d5:	39 d0                	cmp    %edx,%eax
801032d7:	74 3d                	je     80103316 <mycpu+0x63>
801032d9:	b9 50 28 11 80       	mov    $0x80112850,%ecx
  for (i = 0; i < ncpu; ++i) {
801032de:	ba 00 00 00 00       	mov    $0x0,%edx
801032e3:	83 c2 01             	add    $0x1,%edx
801032e6:	39 f2                	cmp    %esi,%edx
801032e8:	74 33                	je     8010331d <mycpu+0x6a>
    if (cpus[i].apicid == apicid)
801032ea:	0f b6 19             	movzbl (%ecx),%ebx
801032ed:	81 c1 b0 00 00 00    	add    $0xb0,%ecx
801032f3:	39 c3                	cmp    %eax,%ebx
801032f5:	75 ec                	jne    801032e3 <mycpu+0x30>
      return &cpus[i];
801032f7:	69 c2 b0 00 00 00    	imul   $0xb0,%edx,%eax
801032fd:	05 a0 27 11 80       	add    $0x801127a0,%eax
}
80103302:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103305:	5b                   	pop    %ebx
80103306:	5e                   	pop    %esi
80103307:	5d                   	pop    %ebp
80103308:	c3                   	ret    
    panic("mycpu called with interrupts enabled\n");
80103309:	83 ec 0c             	sub    $0xc,%esp
8010330c:	68 38 6e 10 80       	push   $0x80106e38
80103311:	e8 2e d0 ff ff       	call   80100344 <panic>
  for (i = 0; i < ncpu; ++i) {
80103316:	ba 00 00 00 00       	mov    $0x0,%edx
8010331b:	eb da                	jmp    801032f7 <mycpu+0x44>
  panic("unknown apicid\n");
8010331d:	83 ec 0c             	sub    $0xc,%esp
80103320:	68 5c 6d 10 80       	push   $0x80106d5c
80103325:	e8 1a d0 ff ff       	call   80100344 <panic>

8010332a <cpuid>:
cpuid() {
8010332a:	55                   	push   %ebp
8010332b:	89 e5                	mov    %esp,%ebp
8010332d:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
80103330:	e8 7e ff ff ff       	call   801032b3 <mycpu>
80103335:	2d a0 27 11 80       	sub    $0x801127a0,%eax
8010333a:	c1 f8 04             	sar    $0x4,%eax
8010333d:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
80103343:	c9                   	leave  
80103344:	c3                   	ret    

80103345 <myproc>:
myproc(void) {
80103345:	55                   	push   %ebp
80103346:	89 e5                	mov    %esp,%ebp
80103348:	53                   	push   %ebx
80103349:	83 ec 04             	sub    $0x4,%esp
  pushcli();
8010334c:	e8 30 0b 00 00       	call   80103e81 <pushcli>
  c = mycpu();
80103351:	e8 5d ff ff ff       	call   801032b3 <mycpu>
  p = c->proc;
80103356:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
8010335c:	e8 5d 0b 00 00       	call   80103ebe <popcli>
}
80103361:	89 d8                	mov    %ebx,%eax
80103363:	83 c4 04             	add    $0x4,%esp
80103366:	5b                   	pop    %ebx
80103367:	5d                   	pop    %ebp
80103368:	c3                   	ret    

80103369 <userinit>:
{
80103369:	55                   	push   %ebp
8010336a:	89 e5                	mov    %esp,%ebp
8010336c:	53                   	push   %ebx
8010336d:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80103370:	e8 00 fe ff ff       	call   80103175 <allocproc>
80103375:	89 c3                	mov    %eax,%ebx
  initproc = p;
80103377:	a3 bc a5 10 80       	mov    %eax,0x8010a5bc
  if((p->pgdir = setupkvm()) == 0)
8010337c:	e8 29 32 00 00       	call   801065aa <setupkvm>
80103381:	89 43 04             	mov    %eax,0x4(%ebx)
80103384:	85 c0                	test   %eax,%eax
80103386:	0f 84 b7 00 00 00    	je     80103443 <userinit+0xda>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
8010338c:	83 ec 04             	sub    $0x4,%esp
8010338f:	68 2c 00 00 00       	push   $0x2c
80103394:	68 60 a4 10 80       	push   $0x8010a460
80103399:	50                   	push   %eax
8010339a:	e8 04 2f 00 00       	call   801062a3 <inituvm>
  p->sz = PGSIZE;
8010339f:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
801033a5:	83 c4 0c             	add    $0xc,%esp
801033a8:	6a 4c                	push   $0x4c
801033aa:	6a 00                	push   $0x0
801033ac:	ff 73 18             	pushl  0x18(%ebx)
801033af:	e8 4c 0c 00 00       	call   80104000 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
801033b4:	8b 43 18             	mov    0x18(%ebx),%eax
801033b7:	66 c7 40 3c 1b 00    	movw   $0x1b,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
801033bd:	8b 43 18             	mov    0x18(%ebx),%eax
801033c0:	66 c7 40 2c 23 00    	movw   $0x23,0x2c(%eax)
  p->tf->es = p->tf->ds;
801033c6:	8b 43 18             	mov    0x18(%ebx),%eax
801033c9:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
801033cd:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
801033d1:	8b 43 18             	mov    0x18(%ebx),%eax
801033d4:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
801033d8:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
801033dc:	8b 43 18             	mov    0x18(%ebx),%eax
801033df:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
801033e6:	8b 43 18             	mov    0x18(%ebx),%eax
801033e9:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
801033f0:	8b 43 18             	mov    0x18(%ebx),%eax
801033f3:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
801033fa:	83 c4 0c             	add    $0xc,%esp
801033fd:	6a 10                	push   $0x10
801033ff:	68 85 6d 10 80       	push   $0x80106d85
80103404:	8d 43 6c             	lea    0x6c(%ebx),%eax
80103407:	50                   	push   %eax
80103408:	e8 82 0d 00 00       	call   8010418f <safestrcpy>
  p->cwd = namei("/");
8010340d:	c7 04 24 8e 6d 10 80 	movl   $0x80106d8e,(%esp)
80103414:	e8 6a e8 ff ff       	call   80101c83 <namei>
80103419:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
8010341c:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103423:	e8 2a 0b 00 00       	call   80103f52 <acquire>
  p->state = RUNNABLE;
80103428:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
8010342f:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103436:	e8 7e 0b 00 00       	call   80103fb9 <release>
}
8010343b:	83 c4 10             	add    $0x10,%esp
8010343e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103441:	c9                   	leave  
80103442:	c3                   	ret    
    panic("userinit: out of memory?");
80103443:	83 ec 0c             	sub    $0xc,%esp
80103446:	68 6c 6d 10 80       	push   $0x80106d6c
8010344b:	e8 f4 ce ff ff       	call   80100344 <panic>

80103450 <growproc>:
{
80103450:	55                   	push   %ebp
80103451:	89 e5                	mov    %esp,%ebp
80103453:	56                   	push   %esi
80103454:	53                   	push   %ebx
80103455:	8b 75 08             	mov    0x8(%ebp),%esi
  struct proc *curproc = myproc();
80103458:	e8 e8 fe ff ff       	call   80103345 <myproc>
8010345d:	89 c3                	mov    %eax,%ebx
  sz = curproc->sz;
8010345f:	8b 00                	mov    (%eax),%eax
  if(n > 0){
80103461:	85 f6                	test   %esi,%esi
80103463:	7f 21                	jg     80103486 <growproc+0x36>
  } else if(n < 0){
80103465:	85 f6                	test   %esi,%esi
80103467:	79 33                	jns    8010349c <growproc+0x4c>
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103469:	83 ec 04             	sub    $0x4,%esp
8010346c:	01 c6                	add    %eax,%esi
8010346e:	56                   	push   %esi
8010346f:	50                   	push   %eax
80103470:	ff 73 04             	pushl  0x4(%ebx)
80103473:	e8 42 2f 00 00       	call   801063ba <deallocuvm>
80103478:	83 c4 10             	add    $0x10,%esp
8010347b:	85 c0                	test   %eax,%eax
8010347d:	75 1d                	jne    8010349c <growproc+0x4c>
      return -1;
8010347f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103484:	eb 29                	jmp    801034af <growproc+0x5f>
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103486:	83 ec 04             	sub    $0x4,%esp
80103489:	01 c6                	add    %eax,%esi
8010348b:	56                   	push   %esi
8010348c:	50                   	push   %eax
8010348d:	ff 73 04             	pushl  0x4(%ebx)
80103490:	e8 b4 2f 00 00       	call   80106449 <allocuvm>
80103495:	83 c4 10             	add    $0x10,%esp
80103498:	85 c0                	test   %eax,%eax
8010349a:	74 1a                	je     801034b6 <growproc+0x66>
  curproc->sz = sz;
8010349c:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
8010349e:	83 ec 0c             	sub    $0xc,%esp
801034a1:	53                   	push   %ebx
801034a2:	e8 fe 2c 00 00       	call   801061a5 <switchuvm>
  return 0;
801034a7:	83 c4 10             	add    $0x10,%esp
801034aa:	b8 00 00 00 00       	mov    $0x0,%eax
}
801034af:	8d 65 f8             	lea    -0x8(%ebp),%esp
801034b2:	5b                   	pop    %ebx
801034b3:	5e                   	pop    %esi
801034b4:	5d                   	pop    %ebp
801034b5:	c3                   	ret    
      return -1;
801034b6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801034bb:	eb f2                	jmp    801034af <growproc+0x5f>

801034bd <fork>:
{
801034bd:	55                   	push   %ebp
801034be:	89 e5                	mov    %esp,%ebp
801034c0:	57                   	push   %edi
801034c1:	56                   	push   %esi
801034c2:	53                   	push   %ebx
801034c3:	83 ec 1c             	sub    $0x1c,%esp
  struct proc *curproc = myproc();
801034c6:	e8 7a fe ff ff       	call   80103345 <myproc>
801034cb:	89 c3                	mov    %eax,%ebx
  if((np = allocproc()) == 0){
801034cd:	e8 a3 fc ff ff       	call   80103175 <allocproc>
801034d2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801034d5:	85 c0                	test   %eax,%eax
801034d7:	0f 84 f8 00 00 00    	je     801035d5 <fork+0x118>
801034dd:	89 c7                	mov    %eax,%edi
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
801034df:	83 ec 08             	sub    $0x8,%esp
801034e2:	ff 33                	pushl  (%ebx)
801034e4:	ff 73 04             	pushl  0x4(%ebx)
801034e7:	e8 6f 31 00 00       	call   8010665b <copyuvm>
801034ec:	89 47 04             	mov    %eax,0x4(%edi)
801034ef:	83 c4 10             	add    $0x10,%esp
801034f2:	85 c0                	test   %eax,%eax
801034f4:	74 42                	je     80103538 <fork+0x7b>
  np->sz = curproc->sz;
801034f6:	8b 03                	mov    (%ebx),%eax
801034f8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801034fb:	89 02                	mov    %eax,(%edx)
  np->parent = curproc;
801034fd:	89 5a 14             	mov    %ebx,0x14(%edx)
  *np->tf = *curproc->tf;
80103500:	8b 73 18             	mov    0x18(%ebx),%esi
80103503:	8b 7a 18             	mov    0x18(%edx),%edi
80103506:	b9 13 00 00 00       	mov    $0x13,%ecx
8010350b:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  np->priority = curproc->priority;
8010350d:	8b 43 7c             	mov    0x7c(%ebx),%eax
80103510:	89 42 7c             	mov    %eax,0x7c(%edx)
  np->rt_rr = 0;
80103513:	c7 82 80 00 00 00 00 	movl   $0x0,0x80(%edx)
8010351a:	00 00 00 
  np->aging_time = 0;
8010351d:	c7 82 84 00 00 00 00 	movl   $0x0,0x84(%edx)
80103524:	00 00 00 
  np->tf->eax = 0;
80103527:	8b 42 18             	mov    0x18(%edx),%eax
8010352a:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
  for(i = 0; i < NOFILE; i++)
80103531:	be 00 00 00 00       	mov    $0x0,%esi
80103536:	eb 2e                	jmp    80103566 <fork+0xa9>
    kfree(np->kstack);
80103538:	83 ec 0c             	sub    $0xc,%esp
8010353b:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
8010353e:	ff 73 08             	pushl  0x8(%ebx)
80103541:	e8 f3 ea ff ff       	call   80102039 <kfree>
    np->kstack = 0;
80103546:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    np->state = UNUSED;
8010354d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80103554:	83 c4 10             	add    $0x10,%esp
80103557:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
8010355c:	eb 6d                	jmp    801035cb <fork+0x10e>
  for(i = 0; i < NOFILE; i++)
8010355e:	83 c6 01             	add    $0x1,%esi
80103561:	83 fe 10             	cmp    $0x10,%esi
80103564:	74 1d                	je     80103583 <fork+0xc6>
    if(curproc->ofile[i])
80103566:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
8010356a:	85 c0                	test   %eax,%eax
8010356c:	74 f0                	je     8010355e <fork+0xa1>
      np->ofile[i] = filedup(curproc->ofile[i]);
8010356e:	83 ec 0c             	sub    $0xc,%esp
80103571:	50                   	push   %eax
80103572:	e8 70 d7 ff ff       	call   80100ce7 <filedup>
80103577:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010357a:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
8010357e:	83 c4 10             	add    $0x10,%esp
80103581:	eb db                	jmp    8010355e <fork+0xa1>
  np->cwd = idup(curproc->cwd);
80103583:	83 ec 0c             	sub    $0xc,%esp
80103586:	ff 73 68             	pushl  0x68(%ebx)
80103589:	e8 2d df ff ff       	call   801014bb <idup>
8010358e:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80103591:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103594:	83 c4 0c             	add    $0xc,%esp
80103597:	6a 10                	push   $0x10
80103599:	83 c3 6c             	add    $0x6c,%ebx
8010359c:	53                   	push   %ebx
8010359d:	8d 47 6c             	lea    0x6c(%edi),%eax
801035a0:	50                   	push   %eax
801035a1:	e8 e9 0b 00 00       	call   8010418f <safestrcpy>
  pid = np->pid;
801035a6:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
801035a9:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801035b0:	e8 9d 09 00 00       	call   80103f52 <acquire>
  np->state = RUNNABLE;
801035b5:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
801035bc:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801035c3:	e8 f1 09 00 00       	call   80103fb9 <release>
  return pid;
801035c8:	83 c4 10             	add    $0x10,%esp
}
801035cb:	89 d8                	mov    %ebx,%eax
801035cd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801035d0:	5b                   	pop    %ebx
801035d1:	5e                   	pop    %esi
801035d2:	5f                   	pop    %edi
801035d3:	5d                   	pop    %ebp
801035d4:	c3                   	ret    
    return -1;
801035d5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801035da:	eb ef                	jmp    801035cb <fork+0x10e>

801035dc <scheduler>:
{
801035dc:	55                   	push   %ebp
801035dd:	89 e5                	mov    %esp,%ebp
801035df:	57                   	push   %edi
801035e0:	56                   	push   %esi
801035e1:	53                   	push   %ebx
801035e2:	83 ec 1c             	sub    $0x1c,%esp
  struct cpu *c = mycpu();
801035e5:	e8 c9 fc ff ff       	call   801032b3 <mycpu>
801035ea:	89 45 e0             	mov    %eax,-0x20(%ebp)
  c->proc = 0;
801035ed:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
801035f4:	00 00 00 
                swtch(&(c->scheduler), p->context);
801035f7:	83 c0 04             	add    $0x4,%eax
801035fa:	89 45 dc             	mov    %eax,-0x24(%ebp)
801035fd:	e9 20 01 00 00       	jmp    80103722 <scheduler+0x146>
    for(p = ptable.proc ; p < &ptable.proc[NPROC] ; p++)
80103602:	05 88 00 00 00       	add    $0x88,%eax
80103607:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
8010360c:	73 1e                	jae    8010362c <scheduler+0x50>
        if(p->state == RUNNABLE && p->priority < min_pri && p->rt_rr == 1)
8010360e:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103612:	75 ee                	jne    80103602 <scheduler+0x26>
80103614:	8b 50 7c             	mov    0x7c(%eax),%edx
80103617:	39 da                	cmp    %ebx,%edx
80103619:	7d e7                	jge    80103602 <scheduler+0x26>
8010361b:	8b 88 80 00 00 00    	mov    0x80(%eax),%ecx
                min_pri = p->priority;
80103621:	83 f9 01             	cmp    $0x1,%ecx
80103624:	0f 44 da             	cmove  %edx,%ebx
80103627:	0f 44 f9             	cmove  %ecx,%edi
8010362a:	eb d6                	jmp    80103602 <scheduler+0x26>
    if(check == -1)
8010362c:	83 ff ff             	cmp    $0xffffffff,%edi
8010362f:	74 0e                	je     8010363f <scheduler+0x63>
80103631:	8b 15 b8 a5 10 80    	mov    0x8010a5b8,%edx
80103637:	8d 72 40             	lea    0x40(%edx),%esi
8010363a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
8010363d:	eb 39                	jmp    80103678 <scheduler+0x9c>
	    for(p = ptable.proc ; p<&ptable.proc[NPROC] ; p++)
8010363f:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103644:	eb 0c                	jmp    80103652 <scheduler+0x76>
80103646:	05 88 00 00 00       	add    $0x88,%eax
8010364b:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103650:	73 14                	jae    80103666 <scheduler+0x8a>
		    if(p->state == RUNNABLE && p->rt_rr == 0)
80103652:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103656:	75 ee                	jne    80103646 <scheduler+0x6a>
80103658:	83 b8 80 00 00 00 00 	cmpl   $0x0,0x80(%eax)
8010365f:	75 e5                	jne    80103646 <scheduler+0x6a>
			    min_pri = p->priority;
80103661:	8b 58 7c             	mov    0x7c(%eax),%ebx
80103664:	eb e0                	jmp    80103646 <scheduler+0x6a>
	    check = 0;
80103666:	bf 00 00 00 00       	mov    $0x0,%edi
8010366b:	eb c4                	jmp    80103631 <scheduler+0x55>
8010366d:	83 c2 01             	add    $0x1,%edx
    for(int i = 0 ; i < NPROC ; i++)
80103670:	39 f2                	cmp    %esi,%edx
80103672:	0f 84 9a 00 00 00    	je     80103712 <scheduler+0x136>
        int idx = (rr_index + i) % NPROC;
80103678:	89 d1                	mov    %edx,%ecx
8010367a:	c1 f9 1f             	sar    $0x1f,%ecx
8010367d:	c1 e9 1a             	shr    $0x1a,%ecx
80103680:	8d 04 0a             	lea    (%edx,%ecx,1),%eax
80103683:	83 e0 3f             	and    $0x3f,%eax
80103686:	29 c8                	sub    %ecx,%eax
80103688:	89 c7                	mov    %eax,%edi
        if(p->state == RUNNABLE && p->priority == min_pri && p->rt_rr == check)
8010368a:	69 c8 88 00 00 00    	imul   $0x88,%eax,%ecx
80103690:	83 b9 80 2d 11 80 03 	cmpl   $0x3,-0x7feed280(%ecx)
80103697:	75 d4                	jne    8010366d <scheduler+0x91>
80103699:	39 99 f0 2d 11 80    	cmp    %ebx,-0x7feed210(%ecx)
8010369f:	75 cc                	jne    8010366d <scheduler+0x91>
801036a1:	89 c8                	mov    %ecx,%eax
801036a3:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
801036a6:	39 88 f4 2d 11 80    	cmp    %ecx,-0x7feed20c(%eax)
801036ac:	75 bf                	jne    8010366d <scheduler+0x91>
801036ae:	89 f8                	mov    %edi,%eax
        p = &ptable.proc[idx];
801036b0:	69 df 88 00 00 00    	imul   $0x88,%edi,%ebx
801036b6:	8d 93 74 2d 11 80    	lea    -0x7feed28c(%ebx),%edx
                rr_index = (idx + 1) % NPROC;
801036bc:	83 c0 01             	add    $0x1,%eax
801036bf:	89 c1                	mov    %eax,%ecx
801036c1:	c1 f9 1f             	sar    $0x1f,%ecx
801036c4:	c1 e9 1a             	shr    $0x1a,%ecx
801036c7:	01 c8                	add    %ecx,%eax
801036c9:	83 e0 3f             	and    $0x3f,%eax
801036cc:	29 c8                	sub    %ecx,%eax
801036ce:	a3 b8 a5 10 80       	mov    %eax,0x8010a5b8
                c->proc = p;
801036d3:	8b 75 e0             	mov    -0x20(%ebp),%esi
801036d6:	89 96 ac 00 00 00    	mov    %edx,0xac(%esi)
                switchuvm(p);
801036dc:	83 ec 0c             	sub    $0xc,%esp
801036df:	52                   	push   %edx
801036e0:	e8 c0 2a 00 00       	call   801061a5 <switchuvm>
                p->state = RUNNING;
801036e5:	c7 83 80 2d 11 80 04 	movl   $0x4,-0x7feed280(%ebx)
801036ec:	00 00 00 
                swtch(&(c->scheduler), p->context);
801036ef:	83 c4 08             	add    $0x8,%esp
801036f2:	ff b3 90 2d 11 80    	pushl  -0x7feed270(%ebx)
801036f8:	ff 75 dc             	pushl  -0x24(%ebp)
801036fb:	e8 e5 0a 00 00       	call   801041e5 <swtch>
                switchkvm();
80103700:	e8 8e 2a 00 00       	call   80106193 <switchkvm>
                c->proc = 0;
80103705:	c7 86 ac 00 00 00 00 	movl   $0x0,0xac(%esi)
8010370c:	00 00 00 
                break;
8010370f:	83 c4 10             	add    $0x10,%esp
    release(&ptable.lock);
80103712:	83 ec 0c             	sub    $0xc,%esp
80103715:	68 40 2d 11 80       	push   $0x80112d40
8010371a:	e8 9a 08 00 00       	call   80103fb9 <release>
  {
8010371f:	83 c4 10             	add    $0x10,%esp
  asm volatile("sti");
80103722:	fb                   	sti    
    acquire(&ptable.lock);
80103723:	83 ec 0c             	sub    $0xc,%esp
80103726:	68 40 2d 11 80       	push   $0x80112d40
8010372b:	e8 22 08 00 00       	call   80103f52 <acquire>
80103730:	83 c4 10             	add    $0x10,%esp
    int min_pri = MAX_PRIORITY;
80103733:	bb 64 00 00 00       	mov    $0x64,%ebx
    int check = -1;
80103738:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    for(p = ptable.proc ; p < &ptable.proc[NPROC] ; p++)
8010373d:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103742:	e9 c7 fe ff ff       	jmp    8010360e <scheduler+0x32>

80103747 <sched>:
{
80103747:	55                   	push   %ebp
80103748:	89 e5                	mov    %esp,%ebp
8010374a:	56                   	push   %esi
8010374b:	53                   	push   %ebx
  struct proc *p = myproc();
8010374c:	e8 f4 fb ff ff       	call   80103345 <myproc>
80103751:	89 c3                	mov    %eax,%ebx
  if(!holding(&ptable.lock))
80103753:	83 ec 0c             	sub    $0xc,%esp
80103756:	68 40 2d 11 80       	push   $0x80112d40
8010375b:	e8 be 07 00 00       	call   80103f1e <holding>
80103760:	83 c4 10             	add    $0x10,%esp
80103763:	85 c0                	test   %eax,%eax
80103765:	74 4f                	je     801037b6 <sched+0x6f>
  if(mycpu()->ncli != 1)
80103767:	e8 47 fb ff ff       	call   801032b3 <mycpu>
8010376c:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103773:	75 4e                	jne    801037c3 <sched+0x7c>
  if(p->state == RUNNING)
80103775:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80103779:	74 55                	je     801037d0 <sched+0x89>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
8010377b:	9c                   	pushf  
8010377c:	58                   	pop    %eax
  if(readeflags()&FL_IF)
8010377d:	f6 c4 02             	test   $0x2,%ah
80103780:	75 5b                	jne    801037dd <sched+0x96>
  intena = mycpu()->intena;
80103782:	e8 2c fb ff ff       	call   801032b3 <mycpu>
80103787:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
8010378d:	e8 21 fb ff ff       	call   801032b3 <mycpu>
80103792:	83 ec 08             	sub    $0x8,%esp
80103795:	ff 70 04             	pushl  0x4(%eax)
80103798:	83 c3 1c             	add    $0x1c,%ebx
8010379b:	53                   	push   %ebx
8010379c:	e8 44 0a 00 00       	call   801041e5 <swtch>
  mycpu()->intena = intena;
801037a1:	e8 0d fb ff ff       	call   801032b3 <mycpu>
801037a6:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
801037ac:	83 c4 10             	add    $0x10,%esp
801037af:	8d 65 f8             	lea    -0x8(%ebp),%esp
801037b2:	5b                   	pop    %ebx
801037b3:	5e                   	pop    %esi
801037b4:	5d                   	pop    %ebp
801037b5:	c3                   	ret    
    panic("sched ptable.lock");
801037b6:	83 ec 0c             	sub    $0xc,%esp
801037b9:	68 90 6d 10 80       	push   $0x80106d90
801037be:	e8 81 cb ff ff       	call   80100344 <panic>
    panic("sched locks");
801037c3:	83 ec 0c             	sub    $0xc,%esp
801037c6:	68 a2 6d 10 80       	push   $0x80106da2
801037cb:	e8 74 cb ff ff       	call   80100344 <panic>
    panic("sched running");
801037d0:	83 ec 0c             	sub    $0xc,%esp
801037d3:	68 ae 6d 10 80       	push   $0x80106dae
801037d8:	e8 67 cb ff ff       	call   80100344 <panic>
    panic("sched interruptible");
801037dd:	83 ec 0c             	sub    $0xc,%esp
801037e0:	68 bc 6d 10 80       	push   $0x80106dbc
801037e5:	e8 5a cb ff ff       	call   80100344 <panic>

801037ea <exit>:
{
801037ea:	55                   	push   %ebp
801037eb:	89 e5                	mov    %esp,%ebp
801037ed:	57                   	push   %edi
801037ee:	56                   	push   %esi
801037ef:	53                   	push   %ebx
801037f0:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
801037f3:	e8 4d fb ff ff       	call   80103345 <myproc>
801037f8:	89 c6                	mov    %eax,%esi
801037fa:	8d 58 28             	lea    0x28(%eax),%ebx
801037fd:	8d 78 68             	lea    0x68(%eax),%edi
  if(curproc == initproc)
80103800:	39 05 bc a5 10 80    	cmp    %eax,0x8010a5bc
80103806:	75 14                	jne    8010381c <exit+0x32>
    panic("init exiting");
80103808:	83 ec 0c             	sub    $0xc,%esp
8010380b:	68 d0 6d 10 80       	push   $0x80106dd0
80103810:	e8 2f cb ff ff       	call   80100344 <panic>
80103815:	83 c3 04             	add    $0x4,%ebx
  for(fd = 0; fd < NOFILE; fd++){
80103818:	39 df                	cmp    %ebx,%edi
8010381a:	74 1a                	je     80103836 <exit+0x4c>
    if(curproc->ofile[fd]){
8010381c:	8b 03                	mov    (%ebx),%eax
8010381e:	85 c0                	test   %eax,%eax
80103820:	74 f3                	je     80103815 <exit+0x2b>
      fileclose(curproc->ofile[fd]);
80103822:	83 ec 0c             	sub    $0xc,%esp
80103825:	50                   	push   %eax
80103826:	e8 01 d5 ff ff       	call   80100d2c <fileclose>
      curproc->ofile[fd] = 0;
8010382b:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80103831:	83 c4 10             	add    $0x10,%esp
80103834:	eb df                	jmp    80103815 <exit+0x2b>
  begin_op();
80103836:	e8 72 ef ff ff       	call   801027ad <begin_op>
  iput(curproc->cwd);
8010383b:	83 ec 0c             	sub    $0xc,%esp
8010383e:	ff 76 68             	pushl  0x68(%esi)
80103841:	e8 a7 dd ff ff       	call   801015ed <iput>
  end_op();
80103846:	e8 dd ef ff ff       	call   80102828 <end_op>
  curproc->cwd = 0;
8010384b:	c7 46 68 00 00 00 00 	movl   $0x0,0x68(%esi)
  acquire(&ptable.lock);
80103852:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103859:	e8 f4 06 00 00       	call   80103f52 <acquire>
  wakeup1(curproc->parent);
8010385e:	8b 46 14             	mov    0x14(%esi),%eax
80103861:	e8 e1 f8 ff ff       	call   80103147 <wakeup1>
80103866:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103869:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
8010386e:	eb 0e                	jmp    8010387e <exit+0x94>
80103870:	81 c3 88 00 00 00    	add    $0x88,%ebx
80103876:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
8010387c:	73 1a                	jae    80103898 <exit+0xae>
    if(p->parent == curproc){
8010387e:	39 73 14             	cmp    %esi,0x14(%ebx)
80103881:	75 ed                	jne    80103870 <exit+0x86>
      p->parent = initproc;
80103883:	a1 bc a5 10 80       	mov    0x8010a5bc,%eax
80103888:	89 43 14             	mov    %eax,0x14(%ebx)
      if(p->state == ZOMBIE)
8010388b:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
8010388f:	75 df                	jne    80103870 <exit+0x86>
        wakeup1(initproc);
80103891:	e8 b1 f8 ff ff       	call   80103147 <wakeup1>
80103896:	eb d8                	jmp    80103870 <exit+0x86>
  curproc->state = ZOMBIE;
80103898:	c7 46 0c 05 00 00 00 	movl   $0x5,0xc(%esi)
  sched();
8010389f:	e8 a3 fe ff ff       	call   80103747 <sched>
  panic("zombie exit");
801038a4:	83 ec 0c             	sub    $0xc,%esp
801038a7:	68 dd 6d 10 80       	push   $0x80106ddd
801038ac:	e8 93 ca ff ff       	call   80100344 <panic>

801038b1 <yield>:
{
801038b1:	55                   	push   %ebp
801038b2:	89 e5                	mov    %esp,%ebp
801038b4:	83 ec 14             	sub    $0x14,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
801038b7:	68 40 2d 11 80       	push   $0x80112d40
801038bc:	e8 91 06 00 00       	call   80103f52 <acquire>
  myproc()->state = RUNNABLE;
801038c1:	e8 7f fa ff ff       	call   80103345 <myproc>
801038c6:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  sched();
801038cd:	e8 75 fe ff ff       	call   80103747 <sched>
  release(&ptable.lock);
801038d2:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801038d9:	e8 db 06 00 00       	call   80103fb9 <release>
}
801038de:	83 c4 10             	add    $0x10,%esp
801038e1:	c9                   	leave  
801038e2:	c3                   	ret    

801038e3 <fork_rt>:
{
801038e3:	55                   	push   %ebp
801038e4:	89 e5                	mov    %esp,%ebp
801038e6:	57                   	push   %edi
801038e7:	56                   	push   %esi
801038e8:	53                   	push   %ebx
801038e9:	83 ec 1c             	sub    $0x1c,%esp
  struct proc *curproc = myproc();
801038ec:	e8 54 fa ff ff       	call   80103345 <myproc>
801038f1:	89 c3                	mov    %eax,%ebx
  if((np = allocproc()) == 0){
801038f3:	e8 7d f8 ff ff       	call   80103175 <allocproc>
801038f8:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801038fb:	85 c0                	test   %eax,%eax
801038fd:	0f 84 fd 00 00 00    	je     80103a00 <fork_rt+0x11d>
80103903:	89 c7                	mov    %eax,%edi
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
80103905:	83 ec 08             	sub    $0x8,%esp
80103908:	ff 33                	pushl  (%ebx)
8010390a:	ff 73 04             	pushl  0x4(%ebx)
8010390d:	e8 49 2d 00 00       	call   8010665b <copyuvm>
80103912:	89 47 04             	mov    %eax,0x4(%edi)
80103915:	83 c4 10             	add    $0x10,%esp
80103918:	85 c0                	test   %eax,%eax
8010391a:	74 42                	je     8010395e <fork_rt+0x7b>
  np->sz = curproc->sz;
8010391c:	8b 03                	mov    (%ebx),%eax
8010391e:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80103921:	89 02                	mov    %eax,(%edx)
  np->parent = curproc;
80103923:	89 5a 14             	mov    %ebx,0x14(%edx)
  *np->tf = *curproc->tf;
80103926:	8b 73 18             	mov    0x18(%ebx),%esi
80103929:	8b 7a 18             	mov    0x18(%edx),%edi
8010392c:	b9 13 00 00 00       	mov    $0x13,%ecx
80103931:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  np->priority = priority;
80103933:	8b 45 08             	mov    0x8(%ebp),%eax
80103936:	89 42 7c             	mov    %eax,0x7c(%edx)
  np->rt_rr = 1;
80103939:	c7 82 80 00 00 00 01 	movl   $0x1,0x80(%edx)
80103940:	00 00 00 
  np->aging_time = 0;
80103943:	c7 82 84 00 00 00 00 	movl   $0x0,0x84(%edx)
8010394a:	00 00 00 
  np->tf->eax = 0;
8010394d:	8b 42 18             	mov    0x18(%edx),%eax
80103950:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
  for(i = 0; i < NOFILE; i++)
80103957:	be 00 00 00 00       	mov    $0x0,%esi
8010395c:	eb 2e                	jmp    8010398c <fork_rt+0xa9>
    kfree(np->kstack);
8010395e:	83 ec 0c             	sub    $0xc,%esp
80103961:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103964:	ff 73 08             	pushl  0x8(%ebx)
80103967:	e8 cd e6 ff ff       	call   80102039 <kfree>
    np->kstack = 0;
8010396c:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    np->state = UNUSED;
80103973:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
8010397a:	83 c4 10             	add    $0x10,%esp
8010397d:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103982:	eb 72                	jmp    801039f6 <fork_rt+0x113>
  for(i = 0; i < NOFILE; i++)
80103984:	83 c6 01             	add    $0x1,%esi
80103987:	83 fe 10             	cmp    $0x10,%esi
8010398a:	74 1d                	je     801039a9 <fork_rt+0xc6>
    if(curproc->ofile[i])
8010398c:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
80103990:	85 c0                	test   %eax,%eax
80103992:	74 f0                	je     80103984 <fork_rt+0xa1>
      np->ofile[i] = filedup(curproc->ofile[i]);
80103994:	83 ec 0c             	sub    $0xc,%esp
80103997:	50                   	push   %eax
80103998:	e8 4a d3 ff ff       	call   80100ce7 <filedup>
8010399d:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801039a0:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
801039a4:	83 c4 10             	add    $0x10,%esp
801039a7:	eb db                	jmp    80103984 <fork_rt+0xa1>
  np->cwd = idup(curproc->cwd);
801039a9:	83 ec 0c             	sub    $0xc,%esp
801039ac:	ff 73 68             	pushl  0x68(%ebx)
801039af:	e8 07 db ff ff       	call   801014bb <idup>
801039b4:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801039b7:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
801039ba:	83 c4 0c             	add    $0xc,%esp
801039bd:	6a 10                	push   $0x10
801039bf:	83 c3 6c             	add    $0x6c,%ebx
801039c2:	53                   	push   %ebx
801039c3:	8d 47 6c             	lea    0x6c(%edi),%eax
801039c6:	50                   	push   %eax
801039c7:	e8 c3 07 00 00       	call   8010418f <safestrcpy>
  pid = np->pid;
801039cc:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
801039cf:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801039d6:	e8 77 05 00 00       	call   80103f52 <acquire>
  np->state = RUNNABLE;
801039db:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
801039e2:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801039e9:	e8 cb 05 00 00       	call   80103fb9 <release>
  yield();
801039ee:	e8 be fe ff ff       	call   801038b1 <yield>
  return pid;
801039f3:	83 c4 10             	add    $0x10,%esp
}
801039f6:	89 d8                	mov    %ebx,%eax
801039f8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801039fb:	5b                   	pop    %ebx
801039fc:	5e                   	pop    %esi
801039fd:	5f                   	pop    %edi
801039fe:	5d                   	pop    %ebp
801039ff:	c3                   	ret    
    return -1;
80103a00:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103a05:	eb ef                	jmp    801039f6 <fork_rt+0x113>

80103a07 <sleep>:
{
80103a07:	55                   	push   %ebp
80103a08:	89 e5                	mov    %esp,%ebp
80103a0a:	57                   	push   %edi
80103a0b:	56                   	push   %esi
80103a0c:	53                   	push   %ebx
80103a0d:	83 ec 0c             	sub    $0xc,%esp
80103a10:	8b 7d 08             	mov    0x8(%ebp),%edi
80103a13:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct proc *p = myproc();
80103a16:	e8 2a f9 ff ff       	call   80103345 <myproc>
  if(p == 0)
80103a1b:	85 c0                	test   %eax,%eax
80103a1d:	74 58                	je     80103a77 <sleep+0x70>
80103a1f:	89 c3                	mov    %eax,%ebx
  if(lk == 0)
80103a21:	85 f6                	test   %esi,%esi
80103a23:	74 5f                	je     80103a84 <sleep+0x7d>
  if(lk != &ptable.lock){  //DOC: sleeplock0
80103a25:	81 fe 40 2d 11 80    	cmp    $0x80112d40,%esi
80103a2b:	74 64                	je     80103a91 <sleep+0x8a>
    acquire(&ptable.lock);  //DOC: sleeplock1
80103a2d:	83 ec 0c             	sub    $0xc,%esp
80103a30:	68 40 2d 11 80       	push   $0x80112d40
80103a35:	e8 18 05 00 00       	call   80103f52 <acquire>
    release(lk);
80103a3a:	89 34 24             	mov    %esi,(%esp)
80103a3d:	e8 77 05 00 00       	call   80103fb9 <release>
  p->chan = chan;
80103a42:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80103a45:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80103a4c:	e8 f6 fc ff ff       	call   80103747 <sched>
  p->chan = 0;
80103a51:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80103a58:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103a5f:	e8 55 05 00 00       	call   80103fb9 <release>
    acquire(lk);
80103a64:	89 34 24             	mov    %esi,(%esp)
80103a67:	e8 e6 04 00 00       	call   80103f52 <acquire>
80103a6c:	83 c4 10             	add    $0x10,%esp
}
80103a6f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103a72:	5b                   	pop    %ebx
80103a73:	5e                   	pop    %esi
80103a74:	5f                   	pop    %edi
80103a75:	5d                   	pop    %ebp
80103a76:	c3                   	ret    
    panic("sleep");
80103a77:	83 ec 0c             	sub    $0xc,%esp
80103a7a:	68 e9 6d 10 80       	push   $0x80106de9
80103a7f:	e8 c0 c8 ff ff       	call   80100344 <panic>
    panic("sleep without lk");
80103a84:	83 ec 0c             	sub    $0xc,%esp
80103a87:	68 ef 6d 10 80       	push   $0x80106def
80103a8c:	e8 b3 c8 ff ff       	call   80100344 <panic>
  p->chan = chan;
80103a91:	89 78 20             	mov    %edi,0x20(%eax)
  p->state = SLEEPING;
80103a94:	c7 40 0c 02 00 00 00 	movl   $0x2,0xc(%eax)
  sched();
80103a9b:	e8 a7 fc ff ff       	call   80103747 <sched>
  p->chan = 0;
80103aa0:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
80103aa7:	eb c6                	jmp    80103a6f <sleep+0x68>

80103aa9 <wait>:
{
80103aa9:	55                   	push   %ebp
80103aaa:	89 e5                	mov    %esp,%ebp
80103aac:	57                   	push   %edi
80103aad:	56                   	push   %esi
80103aae:	53                   	push   %ebx
80103aaf:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
80103ab2:	e8 8e f8 ff ff       	call   80103345 <myproc>
80103ab7:	89 c6                	mov    %eax,%esi
  acquire(&ptable.lock);
80103ab9:	83 ec 0c             	sub    $0xc,%esp
80103abc:	68 40 2d 11 80       	push   $0x80112d40
80103ac1:	e8 8c 04 00 00       	call   80103f52 <acquire>
80103ac6:	83 c4 10             	add    $0x10,%esp
      havekids = 1;
80103ac9:	bf 01 00 00 00       	mov    $0x1,%edi
    havekids = 0;
80103ace:	b8 00 00 00 00       	mov    $0x0,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ad3:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
80103ad8:	eb 67                	jmp    80103b41 <wait+0x98>
        pid = p->pid;
80103ada:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
80103add:	83 ec 0c             	sub    $0xc,%esp
80103ae0:	ff 73 08             	pushl  0x8(%ebx)
80103ae3:	e8 51 e5 ff ff       	call   80102039 <kfree>
        p->kstack = 0;
80103ae8:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
80103aef:	83 c4 04             	add    $0x4,%esp
80103af2:	ff 73 04             	pushl  0x4(%ebx)
80103af5:	e8 3d 2a 00 00       	call   80106537 <freevm>
        p->pid = 0;
80103afa:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
80103b01:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
80103b08:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80103b0c:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
80103b13:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
80103b1a:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103b21:	e8 93 04 00 00       	call   80103fb9 <release>
        return pid;
80103b26:	83 c4 10             	add    $0x10,%esp
}
80103b29:	89 f0                	mov    %esi,%eax
80103b2b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103b2e:	5b                   	pop    %ebx
80103b2f:	5e                   	pop    %esi
80103b30:	5f                   	pop    %edi
80103b31:	5d                   	pop    %ebp
80103b32:	c3                   	ret    
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103b33:	81 c3 88 00 00 00    	add    $0x88,%ebx
80103b39:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
80103b3f:	73 0f                	jae    80103b50 <wait+0xa7>
      if(p->parent != curproc)
80103b41:	39 73 14             	cmp    %esi,0x14(%ebx)
80103b44:	75 ed                	jne    80103b33 <wait+0x8a>
      if(p->state == ZOMBIE){
80103b46:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80103b4a:	74 8e                	je     80103ada <wait+0x31>
      havekids = 1;
80103b4c:	89 f8                	mov    %edi,%eax
80103b4e:	eb e3                	jmp    80103b33 <wait+0x8a>
    if(!havekids || curproc->killed){
80103b50:	85 c0                	test   %eax,%eax
80103b52:	74 06                	je     80103b5a <wait+0xb1>
80103b54:	83 7e 24 00          	cmpl   $0x0,0x24(%esi)
80103b58:	74 17                	je     80103b71 <wait+0xc8>
      release(&ptable.lock);
80103b5a:	83 ec 0c             	sub    $0xc,%esp
80103b5d:	68 40 2d 11 80       	push   $0x80112d40
80103b62:	e8 52 04 00 00       	call   80103fb9 <release>
      return -1;
80103b67:	83 c4 10             	add    $0x10,%esp
80103b6a:	be ff ff ff ff       	mov    $0xffffffff,%esi
80103b6f:	eb b8                	jmp    80103b29 <wait+0x80>
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
80103b71:	83 ec 08             	sub    $0x8,%esp
80103b74:	68 40 2d 11 80       	push   $0x80112d40
80103b79:	56                   	push   %esi
80103b7a:	e8 88 fe ff ff       	call   80103a07 <sleep>
    havekids = 0;
80103b7f:	83 c4 10             	add    $0x10,%esp
80103b82:	e9 47 ff ff ff       	jmp    80103ace <wait+0x25>

80103b87 <wakeup>:

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
80103b87:	55                   	push   %ebp
80103b88:	89 e5                	mov    %esp,%ebp
80103b8a:	83 ec 14             	sub    $0x14,%esp
  acquire(&ptable.lock);
80103b8d:	68 40 2d 11 80       	push   $0x80112d40
80103b92:	e8 bb 03 00 00       	call   80103f52 <acquire>
  wakeup1(chan);
80103b97:	8b 45 08             	mov    0x8(%ebp),%eax
80103b9a:	e8 a8 f5 ff ff       	call   80103147 <wakeup1>
  release(&ptable.lock);
80103b9f:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103ba6:	e8 0e 04 00 00       	call   80103fb9 <release>
}
80103bab:	83 c4 10             	add    $0x10,%esp
80103bae:	c9                   	leave  
80103baf:	c3                   	ret    

80103bb0 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
80103bb0:	55                   	push   %ebp
80103bb1:	89 e5                	mov    %esp,%ebp
80103bb3:	53                   	push   %ebx
80103bb4:	83 ec 10             	sub    $0x10,%esp
80103bb7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
80103bba:	68 40 2d 11 80       	push   $0x80112d40
80103bbf:	e8 8e 03 00 00       	call   80103f52 <acquire>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
80103bc4:	83 c4 10             	add    $0x10,%esp
80103bc7:	3b 1d 84 2d 11 80    	cmp    0x80112d84,%ebx
80103bcd:	74 2d                	je     80103bfc <kill+0x4c>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103bcf:	b8 fc 2d 11 80       	mov    $0x80112dfc,%eax
    if(p->pid == pid){
80103bd4:	39 58 10             	cmp    %ebx,0x10(%eax)
80103bd7:	74 28                	je     80103c01 <kill+0x51>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103bd9:	05 88 00 00 00       	add    $0x88,%eax
80103bde:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103be3:	72 ef                	jb     80103bd4 <kill+0x24>
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
80103be5:	83 ec 0c             	sub    $0xc,%esp
80103be8:	68 40 2d 11 80       	push   $0x80112d40
80103bed:	e8 c7 03 00 00       	call   80103fb9 <release>
  return -1;
80103bf2:	83 c4 10             	add    $0x10,%esp
80103bf5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103bfa:	eb 27                	jmp    80103c23 <kill+0x73>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103bfc:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
      p->killed = 1;
80103c01:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      if(p->state == SLEEPING)
80103c08:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103c0c:	74 1a                	je     80103c28 <kill+0x78>
      release(&ptable.lock);
80103c0e:	83 ec 0c             	sub    $0xc,%esp
80103c11:	68 40 2d 11 80       	push   $0x80112d40
80103c16:	e8 9e 03 00 00       	call   80103fb9 <release>
      return 0;
80103c1b:	83 c4 10             	add    $0x10,%esp
80103c1e:	b8 00 00 00 00       	mov    $0x0,%eax
}
80103c23:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103c26:	c9                   	leave  
80103c27:	c3                   	ret    
        p->state = RUNNABLE;
80103c28:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103c2f:	eb dd                	jmp    80103c0e <kill+0x5e>

80103c31 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80103c31:	55                   	push   %ebp
80103c32:	89 e5                	mov    %esp,%ebp
80103c34:	57                   	push   %edi
80103c35:	56                   	push   %esi
80103c36:	53                   	push   %ebx
80103c37:	83 ec 3c             	sub    $0x3c,%esp
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103c3a:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
80103c3f:	8d 7d e8             	lea    -0x18(%ebp),%edi
80103c42:	eb 39                	jmp    80103c7d <procdump+0x4c>
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
80103c44:	8d 53 6c             	lea    0x6c(%ebx),%edx
80103c47:	52                   	push   %edx
80103c48:	50                   	push   %eax
80103c49:	ff 73 10             	pushl  0x10(%ebx)
80103c4c:	68 04 6e 10 80       	push   $0x80106e04
80103c51:	e8 8b c9 ff ff       	call   801005e1 <cprintf>
    if(p->state == SLEEPING){
80103c56:	83 c4 10             	add    $0x10,%esp
80103c59:	83 7b 0c 02          	cmpl   $0x2,0xc(%ebx)
80103c5d:	74 42                	je     80103ca1 <procdump+0x70>
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
80103c5f:	83 ec 0c             	sub    $0xc,%esp
80103c62:	68 7b 71 10 80       	push   $0x8010717b
80103c67:	e8 75 c9 ff ff       	call   801005e1 <cprintf>
80103c6c:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103c6f:	81 c3 88 00 00 00    	add    $0x88,%ebx
80103c75:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
80103c7b:	73 7b                	jae    80103cf8 <procdump+0xc7>
    if(p->state == UNUSED)
80103c7d:	8b 53 0c             	mov    0xc(%ebx),%edx
80103c80:	85 d2                	test   %edx,%edx
80103c82:	74 eb                	je     80103c6f <procdump+0x3e>
      state = "???";
80103c84:	b8 00 6e 10 80       	mov    $0x80106e00,%eax
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80103c89:	83 fa 05             	cmp    $0x5,%edx
80103c8c:	77 b6                	ja     80103c44 <procdump+0x13>
80103c8e:	8b 04 95 60 6e 10 80 	mov    -0x7fef91a0(,%edx,4),%eax
80103c95:	85 c0                	test   %eax,%eax
      state = "???";
80103c97:	ba 00 6e 10 80       	mov    $0x80106e00,%edx
80103c9c:	0f 44 c2             	cmove  %edx,%eax
80103c9f:	eb a3                	jmp    80103c44 <procdump+0x13>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80103ca1:	83 ec 08             	sub    $0x8,%esp
80103ca4:	8d 45 c0             	lea    -0x40(%ebp),%eax
80103ca7:	50                   	push   %eax
80103ca8:	8b 43 1c             	mov    0x1c(%ebx),%eax
80103cab:	8b 40 0c             	mov    0xc(%eax),%eax
80103cae:	83 c0 08             	add    $0x8,%eax
80103cb1:	50                   	push   %eax
80103cb2:	e8 6e 01 00 00       	call   80103e25 <getcallerpcs>
      for(i=0; i<10 && pc[i] != 0; i++)
80103cb7:	8b 45 c0             	mov    -0x40(%ebp),%eax
80103cba:	83 c4 10             	add    $0x10,%esp
80103cbd:	85 c0                	test   %eax,%eax
80103cbf:	74 9e                	je     80103c5f <procdump+0x2e>
        cprintf(" %p", pc[i]);
80103cc1:	83 ec 08             	sub    $0x8,%esp
80103cc4:	50                   	push   %eax
80103cc5:	68 41 68 10 80       	push   $0x80106841
80103cca:	e8 12 c9 ff ff       	call   801005e1 <cprintf>
80103ccf:	8d 75 c4             	lea    -0x3c(%ebp),%esi
80103cd2:	83 c4 10             	add    $0x10,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80103cd5:	8b 06                	mov    (%esi),%eax
80103cd7:	85 c0                	test   %eax,%eax
80103cd9:	74 84                	je     80103c5f <procdump+0x2e>
        cprintf(" %p", pc[i]);
80103cdb:	83 ec 08             	sub    $0x8,%esp
80103cde:	50                   	push   %eax
80103cdf:	68 41 68 10 80       	push   $0x80106841
80103ce4:	e8 f8 c8 ff ff       	call   801005e1 <cprintf>
80103ce9:	83 c6 04             	add    $0x4,%esi
      for(i=0; i<10 && pc[i] != 0; i++)
80103cec:	83 c4 10             	add    $0x10,%esp
80103cef:	39 f7                	cmp    %esi,%edi
80103cf1:	75 e2                	jne    80103cd5 <procdump+0xa4>
80103cf3:	e9 67 ff ff ff       	jmp    80103c5f <procdump+0x2e>
  }
}
80103cf8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103cfb:	5b                   	pop    %ebx
80103cfc:	5e                   	pop    %esi
80103cfd:	5f                   	pop    %edi
80103cfe:	5d                   	pop    %ebp
80103cff:	c3                   	ret    

80103d00 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80103d00:	55                   	push   %ebp
80103d01:	89 e5                	mov    %esp,%ebp
80103d03:	53                   	push   %ebx
80103d04:	83 ec 0c             	sub    $0xc,%esp
80103d07:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
80103d0a:	68 78 6e 10 80       	push   $0x80106e78
80103d0f:	8d 43 04             	lea    0x4(%ebx),%eax
80103d12:	50                   	push   %eax
80103d13:	e8 f2 00 00 00       	call   80103e0a <initlock>
  lk->name = name;
80103d18:	8b 45 0c             	mov    0xc(%ebp),%eax
80103d1b:	89 43 38             	mov    %eax,0x38(%ebx)
  lk->locked = 0;
80103d1e:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80103d24:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
}
80103d2b:	83 c4 10             	add    $0x10,%esp
80103d2e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103d31:	c9                   	leave  
80103d32:	c3                   	ret    

80103d33 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80103d33:	55                   	push   %ebp
80103d34:	89 e5                	mov    %esp,%ebp
80103d36:	56                   	push   %esi
80103d37:	53                   	push   %ebx
80103d38:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80103d3b:	8d 73 04             	lea    0x4(%ebx),%esi
80103d3e:	83 ec 0c             	sub    $0xc,%esp
80103d41:	56                   	push   %esi
80103d42:	e8 0b 02 00 00       	call   80103f52 <acquire>
  while (lk->locked) {
80103d47:	83 c4 10             	add    $0x10,%esp
80103d4a:	83 3b 00             	cmpl   $0x0,(%ebx)
80103d4d:	74 12                	je     80103d61 <acquiresleep+0x2e>
    sleep(lk, &lk->lk);
80103d4f:	83 ec 08             	sub    $0x8,%esp
80103d52:	56                   	push   %esi
80103d53:	53                   	push   %ebx
80103d54:	e8 ae fc ff ff       	call   80103a07 <sleep>
  while (lk->locked) {
80103d59:	83 c4 10             	add    $0x10,%esp
80103d5c:	83 3b 00             	cmpl   $0x0,(%ebx)
80103d5f:	75 ee                	jne    80103d4f <acquiresleep+0x1c>
  }
  lk->locked = 1;
80103d61:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
80103d67:	e8 d9 f5 ff ff       	call   80103345 <myproc>
80103d6c:	8b 40 10             	mov    0x10(%eax),%eax
80103d6f:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
80103d72:	83 ec 0c             	sub    $0xc,%esp
80103d75:	56                   	push   %esi
80103d76:	e8 3e 02 00 00       	call   80103fb9 <release>
}
80103d7b:	83 c4 10             	add    $0x10,%esp
80103d7e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103d81:	5b                   	pop    %ebx
80103d82:	5e                   	pop    %esi
80103d83:	5d                   	pop    %ebp
80103d84:	c3                   	ret    

80103d85 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80103d85:	55                   	push   %ebp
80103d86:	89 e5                	mov    %esp,%ebp
80103d88:	56                   	push   %esi
80103d89:	53                   	push   %ebx
80103d8a:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80103d8d:	8d 73 04             	lea    0x4(%ebx),%esi
80103d90:	83 ec 0c             	sub    $0xc,%esp
80103d93:	56                   	push   %esi
80103d94:	e8 b9 01 00 00       	call   80103f52 <acquire>
  lk->locked = 0;
80103d99:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80103d9f:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
80103da6:	89 1c 24             	mov    %ebx,(%esp)
80103da9:	e8 d9 fd ff ff       	call   80103b87 <wakeup>
  release(&lk->lk);
80103dae:	89 34 24             	mov    %esi,(%esp)
80103db1:	e8 03 02 00 00       	call   80103fb9 <release>
}
80103db6:	83 c4 10             	add    $0x10,%esp
80103db9:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103dbc:	5b                   	pop    %ebx
80103dbd:	5e                   	pop    %esi
80103dbe:	5d                   	pop    %ebp
80103dbf:	c3                   	ret    

80103dc0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80103dc0:	55                   	push   %ebp
80103dc1:	89 e5                	mov    %esp,%ebp
80103dc3:	57                   	push   %edi
80103dc4:	56                   	push   %esi
80103dc5:	53                   	push   %ebx
80103dc6:	83 ec 18             	sub    $0x18,%esp
80103dc9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
80103dcc:	8d 73 04             	lea    0x4(%ebx),%esi
80103dcf:	56                   	push   %esi
80103dd0:	e8 7d 01 00 00       	call   80103f52 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
80103dd5:	83 c4 10             	add    $0x10,%esp
80103dd8:	bf 00 00 00 00       	mov    $0x0,%edi
80103ddd:	83 3b 00             	cmpl   $0x0,(%ebx)
80103de0:	75 13                	jne    80103df5 <holdingsleep+0x35>
  release(&lk->lk);
80103de2:	83 ec 0c             	sub    $0xc,%esp
80103de5:	56                   	push   %esi
80103de6:	e8 ce 01 00 00       	call   80103fb9 <release>
  return r;
}
80103deb:	89 f8                	mov    %edi,%eax
80103ded:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103df0:	5b                   	pop    %ebx
80103df1:	5e                   	pop    %esi
80103df2:	5f                   	pop    %edi
80103df3:	5d                   	pop    %ebp
80103df4:	c3                   	ret    
  r = lk->locked && (lk->pid == myproc()->pid);
80103df5:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
80103df8:	e8 48 f5 ff ff       	call   80103345 <myproc>
80103dfd:	39 58 10             	cmp    %ebx,0x10(%eax)
80103e00:	0f 94 c0             	sete   %al
80103e03:	0f b6 c0             	movzbl %al,%eax
80103e06:	89 c7                	mov    %eax,%edi
80103e08:	eb d8                	jmp    80103de2 <holdingsleep+0x22>

80103e0a <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80103e0a:	55                   	push   %ebp
80103e0b:	89 e5                	mov    %esp,%ebp
80103e0d:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80103e10:	8b 55 0c             	mov    0xc(%ebp),%edx
80103e13:	89 50 04             	mov    %edx,0x4(%eax)
  lk->locked = 0;
80103e16:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->cpu = 0;
80103e1c:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80103e23:	5d                   	pop    %ebp
80103e24:	c3                   	ret    

80103e25 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80103e25:	55                   	push   %ebp
80103e26:	89 e5                	mov    %esp,%ebp
80103e28:	53                   	push   %ebx
80103e29:	8b 45 08             	mov    0x8(%ebp),%eax
80103e2c:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80103e2f:	8d 90 f8 ff ff 7f    	lea    0x7ffffff8(%eax),%edx
80103e35:	81 fa fe ff ff 7f    	cmp    $0x7ffffffe,%edx
80103e3b:	77 2d                	ja     80103e6a <getcallerpcs+0x45>
      break;
    pcs[i] = ebp[1];     // saved %eip
80103e3d:	8b 50 fc             	mov    -0x4(%eax),%edx
80103e40:	89 11                	mov    %edx,(%ecx)
    ebp = (uint*)ebp[0]; // saved %ebp
80103e42:	8b 50 f8             	mov    -0x8(%eax),%edx
  for(i = 0; i < 10; i++){
80103e45:	b8 01 00 00 00       	mov    $0x1,%eax
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80103e4a:	8d 9a 00 00 00 80    	lea    -0x80000000(%edx),%ebx
80103e50:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80103e56:	77 17                	ja     80103e6f <getcallerpcs+0x4a>
    pcs[i] = ebp[1];     // saved %eip
80103e58:	8b 5a 04             	mov    0x4(%edx),%ebx
80103e5b:	89 1c 81             	mov    %ebx,(%ecx,%eax,4)
    ebp = (uint*)ebp[0]; // saved %ebp
80103e5e:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
80103e60:	83 c0 01             	add    $0x1,%eax
80103e63:	83 f8 0a             	cmp    $0xa,%eax
80103e66:	75 e2                	jne    80103e4a <getcallerpcs+0x25>
80103e68:	eb 14                	jmp    80103e7e <getcallerpcs+0x59>
80103e6a:	b8 00 00 00 00       	mov    $0x0,%eax
  }
  for(; i < 10; i++)
    pcs[i] = 0;
80103e6f:	c7 04 81 00 00 00 00 	movl   $0x0,(%ecx,%eax,4)
  for(; i < 10; i++)
80103e76:	83 c0 01             	add    $0x1,%eax
80103e79:	83 f8 09             	cmp    $0x9,%eax
80103e7c:	7e f1                	jle    80103e6f <getcallerpcs+0x4a>
}
80103e7e:	5b                   	pop    %ebx
80103e7f:	5d                   	pop    %ebp
80103e80:	c3                   	ret    

80103e81 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
80103e81:	55                   	push   %ebp
80103e82:	89 e5                	mov    %esp,%ebp
80103e84:	53                   	push   %ebx
80103e85:	83 ec 04             	sub    $0x4,%esp
80103e88:	9c                   	pushf  
80103e89:	5b                   	pop    %ebx
  asm volatile("cli");
80103e8a:	fa                   	cli    
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
80103e8b:	e8 23 f4 ff ff       	call   801032b3 <mycpu>
80103e90:	83 b8 a4 00 00 00 00 	cmpl   $0x0,0xa4(%eax)
80103e97:	74 12                	je     80103eab <pushcli+0x2a>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
80103e99:	e8 15 f4 ff ff       	call   801032b3 <mycpu>
80103e9e:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80103ea5:	83 c4 04             	add    $0x4,%esp
80103ea8:	5b                   	pop    %ebx
80103ea9:	5d                   	pop    %ebp
80103eaa:	c3                   	ret    
    mycpu()->intena = eflags & FL_IF;
80103eab:	e8 03 f4 ff ff       	call   801032b3 <mycpu>
80103eb0:	81 e3 00 02 00 00    	and    $0x200,%ebx
80103eb6:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80103ebc:	eb db                	jmp    80103e99 <pushcli+0x18>

80103ebe <popcli>:

void
popcli(void)
{
80103ebe:	55                   	push   %ebp
80103ebf:	89 e5                	mov    %esp,%ebp
80103ec1:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103ec4:	9c                   	pushf  
80103ec5:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103ec6:	f6 c4 02             	test   $0x2,%ah
80103ec9:	75 28                	jne    80103ef3 <popcli+0x35>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
80103ecb:	e8 e3 f3 ff ff       	call   801032b3 <mycpu>
80103ed0:	8b 88 a4 00 00 00    	mov    0xa4(%eax),%ecx
80103ed6:	8d 51 ff             	lea    -0x1(%ecx),%edx
80103ed9:	89 90 a4 00 00 00    	mov    %edx,0xa4(%eax)
80103edf:	85 d2                	test   %edx,%edx
80103ee1:	78 1d                	js     80103f00 <popcli+0x42>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
80103ee3:	e8 cb f3 ff ff       	call   801032b3 <mycpu>
80103ee8:	83 b8 a4 00 00 00 00 	cmpl   $0x0,0xa4(%eax)
80103eef:	74 1c                	je     80103f0d <popcli+0x4f>
    sti();
}
80103ef1:	c9                   	leave  
80103ef2:	c3                   	ret    
    panic("popcli - interruptible");
80103ef3:	83 ec 0c             	sub    $0xc,%esp
80103ef6:	68 83 6e 10 80       	push   $0x80106e83
80103efb:	e8 44 c4 ff ff       	call   80100344 <panic>
    panic("popcli");
80103f00:	83 ec 0c             	sub    $0xc,%esp
80103f03:	68 9a 6e 10 80       	push   $0x80106e9a
80103f08:	e8 37 c4 ff ff       	call   80100344 <panic>
  if(mycpu()->ncli == 0 && mycpu()->intena)
80103f0d:	e8 a1 f3 ff ff       	call   801032b3 <mycpu>
80103f12:	83 b8 a8 00 00 00 00 	cmpl   $0x0,0xa8(%eax)
80103f19:	74 d6                	je     80103ef1 <popcli+0x33>
  asm volatile("sti");
80103f1b:	fb                   	sti    
}
80103f1c:	eb d3                	jmp    80103ef1 <popcli+0x33>

80103f1e <holding>:
{
80103f1e:	55                   	push   %ebp
80103f1f:	89 e5                	mov    %esp,%ebp
80103f21:	56                   	push   %esi
80103f22:	53                   	push   %ebx
80103f23:	8b 75 08             	mov    0x8(%ebp),%esi
  pushcli();
80103f26:	e8 56 ff ff ff       	call   80103e81 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80103f2b:	bb 00 00 00 00       	mov    $0x0,%ebx
80103f30:	83 3e 00             	cmpl   $0x0,(%esi)
80103f33:	75 0b                	jne    80103f40 <holding+0x22>
  popcli();
80103f35:	e8 84 ff ff ff       	call   80103ebe <popcli>
}
80103f3a:	89 d8                	mov    %ebx,%eax
80103f3c:	5b                   	pop    %ebx
80103f3d:	5e                   	pop    %esi
80103f3e:	5d                   	pop    %ebp
80103f3f:	c3                   	ret    
  r = lock->locked && lock->cpu == mycpu();
80103f40:	8b 5e 08             	mov    0x8(%esi),%ebx
80103f43:	e8 6b f3 ff ff       	call   801032b3 <mycpu>
80103f48:	39 c3                	cmp    %eax,%ebx
80103f4a:	0f 94 c3             	sete   %bl
80103f4d:	0f b6 db             	movzbl %bl,%ebx
80103f50:	eb e3                	jmp    80103f35 <holding+0x17>

80103f52 <acquire>:
{
80103f52:	55                   	push   %ebp
80103f53:	89 e5                	mov    %esp,%ebp
80103f55:	53                   	push   %ebx
80103f56:	83 ec 04             	sub    $0x4,%esp
  pushcli(); // disable interrupts to avoid deadlock.
80103f59:	e8 23 ff ff ff       	call   80103e81 <pushcli>
  if(holding(lk))
80103f5e:	83 ec 0c             	sub    $0xc,%esp
80103f61:	ff 75 08             	pushl  0x8(%ebp)
80103f64:	e8 b5 ff ff ff       	call   80103f1e <holding>
80103f69:	83 c4 10             	add    $0x10,%esp
80103f6c:	85 c0                	test   %eax,%eax
80103f6e:	75 3c                	jne    80103fac <acquire+0x5a>
  asm volatile("lock; xchgl %0, %1" :
80103f70:	b9 01 00 00 00       	mov    $0x1,%ecx
  while(xchg(&lk->locked, 1) != 0)
80103f75:	8b 55 08             	mov    0x8(%ebp),%edx
80103f78:	89 c8                	mov    %ecx,%eax
80103f7a:	f0 87 02             	lock xchg %eax,(%edx)
80103f7d:	85 c0                	test   %eax,%eax
80103f7f:	75 f4                	jne    80103f75 <acquire+0x23>
  __sync_synchronize();
80103f81:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80103f86:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103f89:	e8 25 f3 ff ff       	call   801032b3 <mycpu>
80103f8e:	89 43 08             	mov    %eax,0x8(%ebx)
  getcallerpcs(&lk, lk->pcs);
80103f91:	83 ec 08             	sub    $0x8,%esp
80103f94:	8b 45 08             	mov    0x8(%ebp),%eax
80103f97:	83 c0 0c             	add    $0xc,%eax
80103f9a:	50                   	push   %eax
80103f9b:	8d 45 08             	lea    0x8(%ebp),%eax
80103f9e:	50                   	push   %eax
80103f9f:	e8 81 fe ff ff       	call   80103e25 <getcallerpcs>
}
80103fa4:	83 c4 10             	add    $0x10,%esp
80103fa7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103faa:	c9                   	leave  
80103fab:	c3                   	ret    
    panic("acquire");
80103fac:	83 ec 0c             	sub    $0xc,%esp
80103faf:	68 a1 6e 10 80       	push   $0x80106ea1
80103fb4:	e8 8b c3 ff ff       	call   80100344 <panic>

80103fb9 <release>:
{
80103fb9:	55                   	push   %ebp
80103fba:	89 e5                	mov    %esp,%ebp
80103fbc:	53                   	push   %ebx
80103fbd:	83 ec 10             	sub    $0x10,%esp
80103fc0:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holding(lk))
80103fc3:	53                   	push   %ebx
80103fc4:	e8 55 ff ff ff       	call   80103f1e <holding>
80103fc9:	83 c4 10             	add    $0x10,%esp
80103fcc:	85 c0                	test   %eax,%eax
80103fce:	74 23                	je     80103ff3 <release+0x3a>
  lk->pcs[0] = 0;
80103fd0:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80103fd7:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80103fde:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
80103fe3:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  popcli();
80103fe9:	e8 d0 fe ff ff       	call   80103ebe <popcli>
}
80103fee:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103ff1:	c9                   	leave  
80103ff2:	c3                   	ret    
    panic("release");
80103ff3:	83 ec 0c             	sub    $0xc,%esp
80103ff6:	68 a9 6e 10 80       	push   $0x80106ea9
80103ffb:	e8 44 c3 ff ff       	call   80100344 <panic>

80104000 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
80104000:	55                   	push   %ebp
80104001:	89 e5                	mov    %esp,%ebp
80104003:	57                   	push   %edi
80104004:	53                   	push   %ebx
80104005:	8b 55 08             	mov    0x8(%ebp),%edx
80104008:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
8010400b:	f6 c2 03             	test   $0x3,%dl
8010400e:	75 05                	jne    80104015 <memset+0x15>
80104010:	f6 c1 03             	test   $0x3,%cl
80104013:	74 0e                	je     80104023 <memset+0x23>
  asm volatile("cld; rep stosb" :
80104015:	89 d7                	mov    %edx,%edi
80104017:	8b 45 0c             	mov    0xc(%ebp),%eax
8010401a:	fc                   	cld    
8010401b:	f3 aa                	rep stos %al,%es:(%edi)
    c &= 0xFF;
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
  } else
    stosb(dst, c, n);
  return dst;
}
8010401d:	89 d0                	mov    %edx,%eax
8010401f:	5b                   	pop    %ebx
80104020:	5f                   	pop    %edi
80104021:	5d                   	pop    %ebp
80104022:	c3                   	ret    
    c &= 0xFF;
80104023:	0f b6 7d 0c          	movzbl 0xc(%ebp),%edi
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80104027:	c1 e9 02             	shr    $0x2,%ecx
8010402a:	89 f8                	mov    %edi,%eax
8010402c:	c1 e0 18             	shl    $0x18,%eax
8010402f:	89 fb                	mov    %edi,%ebx
80104031:	c1 e3 10             	shl    $0x10,%ebx
80104034:	09 d8                	or     %ebx,%eax
80104036:	09 f8                	or     %edi,%eax
80104038:	c1 e7 08             	shl    $0x8,%edi
8010403b:	09 f8                	or     %edi,%eax
  asm volatile("cld; rep stosl" :
8010403d:	89 d7                	mov    %edx,%edi
8010403f:	fc                   	cld    
80104040:	f3 ab                	rep stos %eax,%es:(%edi)
80104042:	eb d9                	jmp    8010401d <memset+0x1d>

80104044 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80104044:	55                   	push   %ebp
80104045:	89 e5                	mov    %esp,%ebp
80104047:	57                   	push   %edi
80104048:	56                   	push   %esi
80104049:	53                   	push   %ebx
8010404a:	8b 75 08             	mov    0x8(%ebp),%esi
8010404d:	8b 7d 0c             	mov    0xc(%ebp),%edi
80104050:	8b 5d 10             	mov    0x10(%ebp),%ebx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
80104053:	85 db                	test   %ebx,%ebx
80104055:	74 37                	je     8010408e <memcmp+0x4a>
    if(*s1 != *s2)
80104057:	0f b6 16             	movzbl (%esi),%edx
8010405a:	0f b6 0f             	movzbl (%edi),%ecx
8010405d:	38 ca                	cmp    %cl,%dl
8010405f:	75 19                	jne    8010407a <memcmp+0x36>
80104061:	b8 01 00 00 00       	mov    $0x1,%eax
  while(n-- > 0){
80104066:	39 d8                	cmp    %ebx,%eax
80104068:	74 1d                	je     80104087 <memcmp+0x43>
    if(*s1 != *s2)
8010406a:	0f b6 14 06          	movzbl (%esi,%eax,1),%edx
8010406e:	83 c0 01             	add    $0x1,%eax
80104071:	0f b6 4c 07 ff       	movzbl -0x1(%edi,%eax,1),%ecx
80104076:	38 ca                	cmp    %cl,%dl
80104078:	74 ec                	je     80104066 <memcmp+0x22>
      return *s1 - *s2;
8010407a:	0f b6 c2             	movzbl %dl,%eax
8010407d:	0f b6 c9             	movzbl %cl,%ecx
80104080:	29 c8                	sub    %ecx,%eax
    s1++, s2++;
  }

  return 0;
}
80104082:	5b                   	pop    %ebx
80104083:	5e                   	pop    %esi
80104084:	5f                   	pop    %edi
80104085:	5d                   	pop    %ebp
80104086:	c3                   	ret    
  return 0;
80104087:	b8 00 00 00 00       	mov    $0x0,%eax
8010408c:	eb f4                	jmp    80104082 <memcmp+0x3e>
8010408e:	b8 00 00 00 00       	mov    $0x0,%eax
80104093:	eb ed                	jmp    80104082 <memcmp+0x3e>

80104095 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80104095:	55                   	push   %ebp
80104096:	89 e5                	mov    %esp,%ebp
80104098:	56                   	push   %esi
80104099:	53                   	push   %ebx
8010409a:	8b 45 08             	mov    0x8(%ebp),%eax
8010409d:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801040a0:	8b 75 10             	mov    0x10(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
801040a3:	39 c3                	cmp    %eax,%ebx
801040a5:	72 1b                	jb     801040c2 <memmove+0x2d>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
801040a7:	ba 00 00 00 00       	mov    $0x0,%edx
801040ac:	85 f6                	test   %esi,%esi
801040ae:	74 0e                	je     801040be <memmove+0x29>
      *d++ = *s++;
801040b0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
801040b4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
801040b7:	83 c2 01             	add    $0x1,%edx
    while(n-- > 0)
801040ba:	39 d6                	cmp    %edx,%esi
801040bc:	75 f2                	jne    801040b0 <memmove+0x1b>

  return dst;
}
801040be:	5b                   	pop    %ebx
801040bf:	5e                   	pop    %esi
801040c0:	5d                   	pop    %ebp
801040c1:	c3                   	ret    
  if(s < d && s + n > d){
801040c2:	8d 14 33             	lea    (%ebx,%esi,1),%edx
801040c5:	39 d0                	cmp    %edx,%eax
801040c7:	73 de                	jae    801040a7 <memmove+0x12>
    while(n-- > 0)
801040c9:	8d 56 ff             	lea    -0x1(%esi),%edx
801040cc:	85 f6                	test   %esi,%esi
801040ce:	74 ee                	je     801040be <memmove+0x29>
      *--d = *--s;
801040d0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
801040d4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
    while(n-- > 0)
801040d7:	83 ea 01             	sub    $0x1,%edx
801040da:	83 fa ff             	cmp    $0xffffffff,%edx
801040dd:	75 f1                	jne    801040d0 <memmove+0x3b>
801040df:	eb dd                	jmp    801040be <memmove+0x29>

801040e1 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
801040e1:	55                   	push   %ebp
801040e2:	89 e5                	mov    %esp,%ebp
  return memmove(dst, src, n);
801040e4:	ff 75 10             	pushl  0x10(%ebp)
801040e7:	ff 75 0c             	pushl  0xc(%ebp)
801040ea:	ff 75 08             	pushl  0x8(%ebp)
801040ed:	e8 a3 ff ff ff       	call   80104095 <memmove>
}
801040f2:	c9                   	leave  
801040f3:	c3                   	ret    

801040f4 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
801040f4:	55                   	push   %ebp
801040f5:	89 e5                	mov    %esp,%ebp
801040f7:	53                   	push   %ebx
801040f8:	8b 45 08             	mov    0x8(%ebp),%eax
801040fb:	8b 55 0c             	mov    0xc(%ebp),%edx
801040fe:	8b 5d 10             	mov    0x10(%ebp),%ebx
  while(n > 0 && *p && *p == *q)
80104101:	85 db                	test   %ebx,%ebx
80104103:	74 2d                	je     80104132 <strncmp+0x3e>
80104105:	0f b6 08             	movzbl (%eax),%ecx
80104108:	84 c9                	test   %cl,%cl
8010410a:	74 1b                	je     80104127 <strncmp+0x33>
8010410c:	3a 0a                	cmp    (%edx),%cl
8010410e:	75 17                	jne    80104127 <strncmp+0x33>
80104110:	01 c3                	add    %eax,%ebx
    n--, p++, q++;
80104112:	83 c0 01             	add    $0x1,%eax
80104115:	83 c2 01             	add    $0x1,%edx
  while(n > 0 && *p && *p == *q)
80104118:	39 d8                	cmp    %ebx,%eax
8010411a:	74 1d                	je     80104139 <strncmp+0x45>
8010411c:	0f b6 08             	movzbl (%eax),%ecx
8010411f:	84 c9                	test   %cl,%cl
80104121:	74 04                	je     80104127 <strncmp+0x33>
80104123:	3a 0a                	cmp    (%edx),%cl
80104125:	74 eb                	je     80104112 <strncmp+0x1e>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
80104127:	0f b6 00             	movzbl (%eax),%eax
8010412a:	0f b6 12             	movzbl (%edx),%edx
8010412d:	29 d0                	sub    %edx,%eax
}
8010412f:	5b                   	pop    %ebx
80104130:	5d                   	pop    %ebp
80104131:	c3                   	ret    
    return 0;
80104132:	b8 00 00 00 00       	mov    $0x0,%eax
80104137:	eb f6                	jmp    8010412f <strncmp+0x3b>
80104139:	b8 00 00 00 00       	mov    $0x0,%eax
8010413e:	eb ef                	jmp    8010412f <strncmp+0x3b>

80104140 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80104140:	55                   	push   %ebp
80104141:	89 e5                	mov    %esp,%ebp
80104143:	57                   	push   %edi
80104144:	56                   	push   %esi
80104145:	53                   	push   %ebx
80104146:	8b 7d 08             	mov    0x8(%ebp),%edi
80104149:	8b 5d 0c             	mov    0xc(%ebp),%ebx
8010414c:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
8010414f:	89 f9                	mov    %edi,%ecx
80104151:	eb 02                	jmp    80104155 <strncpy+0x15>
80104153:	89 f2                	mov    %esi,%edx
80104155:	8d 72 ff             	lea    -0x1(%edx),%esi
80104158:	85 d2                	test   %edx,%edx
8010415a:	7e 11                	jle    8010416d <strncpy+0x2d>
8010415c:	83 c3 01             	add    $0x1,%ebx
8010415f:	83 c1 01             	add    $0x1,%ecx
80104162:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
80104166:	88 41 ff             	mov    %al,-0x1(%ecx)
80104169:	84 c0                	test   %al,%al
8010416b:	75 e6                	jne    80104153 <strncpy+0x13>
    ;
  while(n-- > 0)
8010416d:	bb 00 00 00 00       	mov    $0x0,%ebx
80104172:	83 ea 01             	sub    $0x1,%edx
80104175:	85 f6                	test   %esi,%esi
80104177:	7e 0f                	jle    80104188 <strncpy+0x48>
    *s++ = 0;
80104179:	c6 04 19 00          	movb   $0x0,(%ecx,%ebx,1)
8010417d:	83 c3 01             	add    $0x1,%ebx
80104180:	89 d6                	mov    %edx,%esi
80104182:	29 de                	sub    %ebx,%esi
  while(n-- > 0)
80104184:	85 f6                	test   %esi,%esi
80104186:	7f f1                	jg     80104179 <strncpy+0x39>
  return os;
}
80104188:	89 f8                	mov    %edi,%eax
8010418a:	5b                   	pop    %ebx
8010418b:	5e                   	pop    %esi
8010418c:	5f                   	pop    %edi
8010418d:	5d                   	pop    %ebp
8010418e:	c3                   	ret    

8010418f <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
8010418f:	55                   	push   %ebp
80104190:	89 e5                	mov    %esp,%ebp
80104192:	56                   	push   %esi
80104193:	53                   	push   %ebx
80104194:	8b 45 08             	mov    0x8(%ebp),%eax
80104197:	8b 55 0c             	mov    0xc(%ebp),%edx
8010419a:	8b 4d 10             	mov    0x10(%ebp),%ecx
  char *os;

  os = s;
  if(n <= 0)
8010419d:	85 c9                	test   %ecx,%ecx
8010419f:	7e 1e                	jle    801041bf <safestrcpy+0x30>
801041a1:	8d 74 0a ff          	lea    -0x1(%edx,%ecx,1),%esi
801041a5:	89 c1                	mov    %eax,%ecx
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
801041a7:	39 f2                	cmp    %esi,%edx
801041a9:	74 11                	je     801041bc <safestrcpy+0x2d>
801041ab:	83 c2 01             	add    $0x1,%edx
801041ae:	83 c1 01             	add    $0x1,%ecx
801041b1:	0f b6 5a ff          	movzbl -0x1(%edx),%ebx
801041b5:	88 59 ff             	mov    %bl,-0x1(%ecx)
801041b8:	84 db                	test   %bl,%bl
801041ba:	75 eb                	jne    801041a7 <safestrcpy+0x18>
    ;
  *s = 0;
801041bc:	c6 01 00             	movb   $0x0,(%ecx)
  return os;
}
801041bf:	5b                   	pop    %ebx
801041c0:	5e                   	pop    %esi
801041c1:	5d                   	pop    %ebp
801041c2:	c3                   	ret    

801041c3 <strlen>:

int
strlen(const char *s)
{
801041c3:	55                   	push   %ebp
801041c4:	89 e5                	mov    %esp,%ebp
801041c6:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
801041c9:	80 3a 00             	cmpb   $0x0,(%edx)
801041cc:	74 10                	je     801041de <strlen+0x1b>
801041ce:	b8 00 00 00 00       	mov    $0x0,%eax
801041d3:	83 c0 01             	add    $0x1,%eax
801041d6:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
801041da:	75 f7                	jne    801041d3 <strlen+0x10>
    ;
  return n;
}
801041dc:	5d                   	pop    %ebp
801041dd:	c3                   	ret    
  for(n = 0; s[n]; n++)
801041de:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
801041e3:	eb f7                	jmp    801041dc <strlen+0x19>

801041e5 <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
801041e5:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
801041e9:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
801041ed:	55                   	push   %ebp
  pushl %ebx
801041ee:	53                   	push   %ebx
  pushl %esi
801041ef:	56                   	push   %esi
  pushl %edi
801041f0:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
801041f1:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
801041f3:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
801041f5:	5f                   	pop    %edi
  popl %esi
801041f6:	5e                   	pop    %esi
  popl %ebx
801041f7:	5b                   	pop    %ebx
  popl %ebp
801041f8:	5d                   	pop    %ebp
  ret
801041f9:	c3                   	ret    

801041fa <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
801041fa:	55                   	push   %ebp
801041fb:	89 e5                	mov    %esp,%ebp
801041fd:	53                   	push   %ebx
801041fe:	83 ec 04             	sub    $0x4,%esp
80104201:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
80104204:	e8 3c f1 ff ff       	call   80103345 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104209:	8b 00                	mov    (%eax),%eax
8010420b:	39 d8                	cmp    %ebx,%eax
8010420d:	76 19                	jbe    80104228 <fetchint+0x2e>
8010420f:	8d 53 04             	lea    0x4(%ebx),%edx
80104212:	39 d0                	cmp    %edx,%eax
80104214:	72 19                	jb     8010422f <fetchint+0x35>
    return -1;
  *ip = *(int*)(addr);
80104216:	8b 13                	mov    (%ebx),%edx
80104218:	8b 45 0c             	mov    0xc(%ebp),%eax
8010421b:	89 10                	mov    %edx,(%eax)
  return 0;
8010421d:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104222:	83 c4 04             	add    $0x4,%esp
80104225:	5b                   	pop    %ebx
80104226:	5d                   	pop    %ebp
80104227:	c3                   	ret    
    return -1;
80104228:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010422d:	eb f3                	jmp    80104222 <fetchint+0x28>
8010422f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104234:	eb ec                	jmp    80104222 <fetchint+0x28>

80104236 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80104236:	55                   	push   %ebp
80104237:	89 e5                	mov    %esp,%ebp
80104239:	53                   	push   %ebx
8010423a:	83 ec 04             	sub    $0x4,%esp
8010423d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
80104240:	e8 00 f1 ff ff       	call   80103345 <myproc>

  if(addr >= curproc->sz)
80104245:	39 18                	cmp    %ebx,(%eax)
80104247:	76 2f                	jbe    80104278 <fetchstr+0x42>
    return -1;
  *pp = (char*)addr;
80104249:	89 da                	mov    %ebx,%edx
8010424b:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010424e:	89 19                	mov    %ebx,(%ecx)
  ep = (char*)curproc->sz;
80104250:	8b 00                	mov    (%eax),%eax
  for(s = *pp; s < ep; s++){
80104252:	39 c3                	cmp    %eax,%ebx
80104254:	73 29                	jae    8010427f <fetchstr+0x49>
    if(*s == 0)
80104256:	80 3b 00             	cmpb   $0x0,(%ebx)
80104259:	74 0c                	je     80104267 <fetchstr+0x31>
  for(s = *pp; s < ep; s++){
8010425b:	83 c2 01             	add    $0x1,%edx
8010425e:	39 d0                	cmp    %edx,%eax
80104260:	76 0f                	jbe    80104271 <fetchstr+0x3b>
    if(*s == 0)
80104262:	80 3a 00             	cmpb   $0x0,(%edx)
80104265:	75 f4                	jne    8010425b <fetchstr+0x25>
      return s - *pp;
80104267:	89 d0                	mov    %edx,%eax
80104269:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
8010426b:	83 c4 04             	add    $0x4,%esp
8010426e:	5b                   	pop    %ebx
8010426f:	5d                   	pop    %ebp
80104270:	c3                   	ret    
  return -1;
80104271:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104276:	eb f3                	jmp    8010426b <fetchstr+0x35>
    return -1;
80104278:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010427d:	eb ec                	jmp    8010426b <fetchstr+0x35>
  return -1;
8010427f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104284:	eb e5                	jmp    8010426b <fetchstr+0x35>

80104286 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104286:	55                   	push   %ebp
80104287:	89 e5                	mov    %esp,%ebp
80104289:	83 ec 08             	sub    $0x8,%esp
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
8010428c:	e8 b4 f0 ff ff       	call   80103345 <myproc>
80104291:	83 ec 08             	sub    $0x8,%esp
80104294:	ff 75 0c             	pushl  0xc(%ebp)
80104297:	8b 40 18             	mov    0x18(%eax),%eax
8010429a:	8b 40 44             	mov    0x44(%eax),%eax
8010429d:	8b 55 08             	mov    0x8(%ebp),%edx
801042a0:	8d 44 90 04          	lea    0x4(%eax,%edx,4),%eax
801042a4:	50                   	push   %eax
801042a5:	e8 50 ff ff ff       	call   801041fa <fetchint>
}
801042aa:	c9                   	leave  
801042ab:	c3                   	ret    

801042ac <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
801042ac:	55                   	push   %ebp
801042ad:	89 e5                	mov    %esp,%ebp
801042af:	56                   	push   %esi
801042b0:	53                   	push   %ebx
801042b1:	83 ec 10             	sub    $0x10,%esp
801042b4:	8b 5d 10             	mov    0x10(%ebp),%ebx
  int i;
  struct proc *curproc = myproc();
801042b7:	e8 89 f0 ff ff       	call   80103345 <myproc>
801042bc:	89 c6                	mov    %eax,%esi
 
  if(argint(n, &i) < 0)
801042be:	83 ec 08             	sub    $0x8,%esp
801042c1:	8d 45 f4             	lea    -0xc(%ebp),%eax
801042c4:	50                   	push   %eax
801042c5:	ff 75 08             	pushl  0x8(%ebp)
801042c8:	e8 b9 ff ff ff       	call   80104286 <argint>
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
801042cd:	83 c4 10             	add    $0x10,%esp
801042d0:	85 db                	test   %ebx,%ebx
801042d2:	78 24                	js     801042f8 <argptr+0x4c>
801042d4:	85 c0                	test   %eax,%eax
801042d6:	78 20                	js     801042f8 <argptr+0x4c>
801042d8:	8b 16                	mov    (%esi),%edx
801042da:	8b 45 f4             	mov    -0xc(%ebp),%eax
801042dd:	39 c2                	cmp    %eax,%edx
801042df:	76 1e                	jbe    801042ff <argptr+0x53>
801042e1:	01 c3                	add    %eax,%ebx
801042e3:	39 da                	cmp    %ebx,%edx
801042e5:	72 1f                	jb     80104306 <argptr+0x5a>
    return -1;
  *pp = (char*)i;
801042e7:	8b 55 0c             	mov    0xc(%ebp),%edx
801042ea:	89 02                	mov    %eax,(%edx)
  return 0;
801042ec:	b8 00 00 00 00       	mov    $0x0,%eax
}
801042f1:	8d 65 f8             	lea    -0x8(%ebp),%esp
801042f4:	5b                   	pop    %ebx
801042f5:	5e                   	pop    %esi
801042f6:	5d                   	pop    %ebp
801042f7:	c3                   	ret    
    return -1;
801042f8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801042fd:	eb f2                	jmp    801042f1 <argptr+0x45>
801042ff:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104304:	eb eb                	jmp    801042f1 <argptr+0x45>
80104306:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010430b:	eb e4                	jmp    801042f1 <argptr+0x45>

8010430d <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
8010430d:	55                   	push   %ebp
8010430e:	89 e5                	mov    %esp,%ebp
80104310:	83 ec 20             	sub    $0x20,%esp
  int addr;
  if(argint(n, &addr) < 0)
80104313:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104316:	50                   	push   %eax
80104317:	ff 75 08             	pushl  0x8(%ebp)
8010431a:	e8 67 ff ff ff       	call   80104286 <argint>
8010431f:	83 c4 10             	add    $0x10,%esp
80104322:	85 c0                	test   %eax,%eax
80104324:	78 13                	js     80104339 <argstr+0x2c>
    return -1;
  return fetchstr(addr, pp);
80104326:	83 ec 08             	sub    $0x8,%esp
80104329:	ff 75 0c             	pushl  0xc(%ebp)
8010432c:	ff 75 f4             	pushl  -0xc(%ebp)
8010432f:	e8 02 ff ff ff       	call   80104236 <fetchstr>
80104334:	83 c4 10             	add    $0x10,%esp
}
80104337:	c9                   	leave  
80104338:	c3                   	ret    
    return -1;
80104339:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010433e:	eb f7                	jmp    80104337 <argstr+0x2a>

80104340 <syscall>:
[SYS_fork_rt] sys_fork_rt,
};

void
syscall(void)
{
80104340:	55                   	push   %ebp
80104341:	89 e5                	mov    %esp,%ebp
80104343:	53                   	push   %ebx
80104344:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
80104347:	e8 f9 ef ff ff       	call   80103345 <myproc>
8010434c:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
8010434e:	8b 40 18             	mov    0x18(%eax),%eax
80104351:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80104354:	8d 50 ff             	lea    -0x1(%eax),%edx
80104357:	83 fa 15             	cmp    $0x15,%edx
8010435a:	77 18                	ja     80104374 <syscall+0x34>
8010435c:	8b 14 85 e0 6e 10 80 	mov    -0x7fef9120(,%eax,4),%edx
80104363:	85 d2                	test   %edx,%edx
80104365:	74 0d                	je     80104374 <syscall+0x34>
    curproc->tf->eax = syscalls[num]();
80104367:	ff d2                	call   *%edx
80104369:	8b 53 18             	mov    0x18(%ebx),%edx
8010436c:	89 42 1c             	mov    %eax,0x1c(%edx)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
8010436f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104372:	c9                   	leave  
80104373:	c3                   	ret    
    cprintf("%d %s: unknown sys call %d\n",
80104374:	50                   	push   %eax
            curproc->pid, curproc->name, num);
80104375:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
80104378:	50                   	push   %eax
80104379:	ff 73 10             	pushl  0x10(%ebx)
8010437c:	68 b1 6e 10 80       	push   $0x80106eb1
80104381:	e8 5b c2 ff ff       	call   801005e1 <cprintf>
    curproc->tf->eax = -1;
80104386:	8b 43 18             	mov    0x18(%ebx),%eax
80104389:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
80104390:	83 c4 10             	add    $0x10,%esp
}
80104393:	eb da                	jmp    8010436f <syscall+0x2f>

80104395 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
80104395:	55                   	push   %ebp
80104396:	89 e5                	mov    %esp,%ebp
80104398:	56                   	push   %esi
80104399:	53                   	push   %ebx
8010439a:	83 ec 18             	sub    $0x18,%esp
8010439d:	89 d6                	mov    %edx,%esi
8010439f:	89 cb                	mov    %ecx,%ebx
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
801043a1:	8d 55 f4             	lea    -0xc(%ebp),%edx
801043a4:	52                   	push   %edx
801043a5:	50                   	push   %eax
801043a6:	e8 db fe ff ff       	call   80104286 <argint>
801043ab:	83 c4 10             	add    $0x10,%esp
801043ae:	85 c0                	test   %eax,%eax
801043b0:	78 2e                	js     801043e0 <argfd+0x4b>
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
801043b2:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
801043b6:	77 2f                	ja     801043e7 <argfd+0x52>
801043b8:	e8 88 ef ff ff       	call   80103345 <myproc>
801043bd:	8b 4d f4             	mov    -0xc(%ebp),%ecx
801043c0:	8b 54 88 28          	mov    0x28(%eax,%ecx,4),%edx
801043c4:	85 d2                	test   %edx,%edx
801043c6:	74 26                	je     801043ee <argfd+0x59>
    return -1;
  if(pfd)
801043c8:	85 f6                	test   %esi,%esi
801043ca:	74 02                	je     801043ce <argfd+0x39>
    *pfd = fd;
801043cc:	89 0e                	mov    %ecx,(%esi)
  if(pf)
    *pf = f;
  return 0;
801043ce:	b8 00 00 00 00       	mov    $0x0,%eax
  if(pf)
801043d3:	85 db                	test   %ebx,%ebx
801043d5:	74 02                	je     801043d9 <argfd+0x44>
    *pf = f;
801043d7:	89 13                	mov    %edx,(%ebx)
}
801043d9:	8d 65 f8             	lea    -0x8(%ebp),%esp
801043dc:	5b                   	pop    %ebx
801043dd:	5e                   	pop    %esi
801043de:	5d                   	pop    %ebp
801043df:	c3                   	ret    
    return -1;
801043e0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801043e5:	eb f2                	jmp    801043d9 <argfd+0x44>
    return -1;
801043e7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801043ec:	eb eb                	jmp    801043d9 <argfd+0x44>
801043ee:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801043f3:	eb e4                	jmp    801043d9 <argfd+0x44>

801043f5 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
801043f5:	55                   	push   %ebp
801043f6:	89 e5                	mov    %esp,%ebp
801043f8:	53                   	push   %ebx
801043f9:	83 ec 04             	sub    $0x4,%esp
801043fc:	89 c3                	mov    %eax,%ebx
  int fd;
  struct proc *curproc = myproc();
801043fe:	e8 42 ef ff ff       	call   80103345 <myproc>

  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd] == 0){
80104403:	83 78 28 00          	cmpl   $0x0,0x28(%eax)
80104407:	74 1b                	je     80104424 <fdalloc+0x2f>
  for(fd = 0; fd < NOFILE; fd++){
80104409:	ba 01 00 00 00       	mov    $0x1,%edx
    if(curproc->ofile[fd] == 0){
8010440e:	83 7c 90 28 00       	cmpl   $0x0,0x28(%eax,%edx,4)
80104413:	74 14                	je     80104429 <fdalloc+0x34>
  for(fd = 0; fd < NOFILE; fd++){
80104415:	83 c2 01             	add    $0x1,%edx
80104418:	83 fa 10             	cmp    $0x10,%edx
8010441b:	75 f1                	jne    8010440e <fdalloc+0x19>
      curproc->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
8010441d:	ba ff ff ff ff       	mov    $0xffffffff,%edx
80104422:	eb 09                	jmp    8010442d <fdalloc+0x38>
  for(fd = 0; fd < NOFILE; fd++){
80104424:	ba 00 00 00 00       	mov    $0x0,%edx
      curproc->ofile[fd] = f;
80104429:	89 5c 90 28          	mov    %ebx,0x28(%eax,%edx,4)
}
8010442d:	89 d0                	mov    %edx,%eax
8010442f:	83 c4 04             	add    $0x4,%esp
80104432:	5b                   	pop    %ebx
80104433:	5d                   	pop    %ebp
80104434:	c3                   	ret    

80104435 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80104435:	55                   	push   %ebp
80104436:	89 e5                	mov    %esp,%ebp
80104438:	57                   	push   %edi
80104439:	56                   	push   %esi
8010443a:	53                   	push   %ebx
8010443b:	83 ec 34             	sub    $0x34,%esp
8010443e:	89 55 d4             	mov    %edx,-0x2c(%ebp)
80104441:	89 4d d0             	mov    %ecx,-0x30(%ebp)
80104444:	8b 7d 08             	mov    0x8(%ebp),%edi
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80104447:	8d 55 da             	lea    -0x26(%ebp),%edx
8010444a:	52                   	push   %edx
8010444b:	50                   	push   %eax
8010444c:	e8 4a d8 ff ff       	call   80101c9b <nameiparent>
80104451:	89 c6                	mov    %eax,%esi
80104453:	83 c4 10             	add    $0x10,%esp
80104456:	85 c0                	test   %eax,%eax
80104458:	0f 84 32 01 00 00    	je     80104590 <create+0x15b>
    return 0;
  ilock(dp);
8010445e:	83 ec 0c             	sub    $0xc,%esp
80104461:	50                   	push   %eax
80104462:	e8 7f d0 ff ff       	call   801014e6 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
80104467:	83 c4 0c             	add    $0xc,%esp
8010446a:	6a 00                	push   $0x0
8010446c:	8d 45 da             	lea    -0x26(%ebp),%eax
8010446f:	50                   	push   %eax
80104470:	56                   	push   %esi
80104471:	e8 36 d5 ff ff       	call   801019ac <dirlookup>
80104476:	89 c3                	mov    %eax,%ebx
80104478:	83 c4 10             	add    $0x10,%esp
8010447b:	85 c0                	test   %eax,%eax
8010447d:	74 3f                	je     801044be <create+0x89>
    iunlockput(dp);
8010447f:	83 ec 0c             	sub    $0xc,%esp
80104482:	56                   	push   %esi
80104483:	e8 a7 d2 ff ff       	call   8010172f <iunlockput>
    ilock(ip);
80104488:	89 1c 24             	mov    %ebx,(%esp)
8010448b:	e8 56 d0 ff ff       	call   801014e6 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
80104490:	83 c4 10             	add    $0x10,%esp
80104493:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
80104498:	75 11                	jne    801044ab <create+0x76>
8010449a:	66 83 7b 50 02       	cmpw   $0x2,0x50(%ebx)
8010449f:	75 0a                	jne    801044ab <create+0x76>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
801044a1:	89 d8                	mov    %ebx,%eax
801044a3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801044a6:	5b                   	pop    %ebx
801044a7:	5e                   	pop    %esi
801044a8:	5f                   	pop    %edi
801044a9:	5d                   	pop    %ebp
801044aa:	c3                   	ret    
    iunlockput(ip);
801044ab:	83 ec 0c             	sub    $0xc,%esp
801044ae:	53                   	push   %ebx
801044af:	e8 7b d2 ff ff       	call   8010172f <iunlockput>
    return 0;
801044b4:	83 c4 10             	add    $0x10,%esp
801044b7:	bb 00 00 00 00       	mov    $0x0,%ebx
801044bc:	eb e3                	jmp    801044a1 <create+0x6c>
  if((ip = ialloc(dp->dev, type)) == 0)
801044be:	83 ec 08             	sub    $0x8,%esp
801044c1:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
801044c5:	50                   	push   %eax
801044c6:	ff 36                	pushl  (%esi)
801044c8:	e8 c6 ce ff ff       	call   80101393 <ialloc>
801044cd:	89 c3                	mov    %eax,%ebx
801044cf:	83 c4 10             	add    $0x10,%esp
801044d2:	85 c0                	test   %eax,%eax
801044d4:	74 55                	je     8010452b <create+0xf6>
  ilock(ip);
801044d6:	83 ec 0c             	sub    $0xc,%esp
801044d9:	50                   	push   %eax
801044da:	e8 07 d0 ff ff       	call   801014e6 <ilock>
  ip->major = major;
801044df:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
801044e3:	66 89 43 52          	mov    %ax,0x52(%ebx)
  ip->minor = minor;
801044e7:	66 89 7b 54          	mov    %di,0x54(%ebx)
  ip->nlink = 1;
801044eb:	66 c7 43 56 01 00    	movw   $0x1,0x56(%ebx)
  iupdate(ip);
801044f1:	89 1c 24             	mov    %ebx,(%esp)
801044f4:	e8 43 cf ff ff       	call   8010143c <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
801044f9:	83 c4 10             	add    $0x10,%esp
801044fc:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
80104501:	74 35                	je     80104538 <create+0x103>
  if(dirlink(dp, name, ip->inum) < 0)
80104503:	83 ec 04             	sub    $0x4,%esp
80104506:	ff 73 04             	pushl  0x4(%ebx)
80104509:	8d 45 da             	lea    -0x26(%ebp),%eax
8010450c:	50                   	push   %eax
8010450d:	56                   	push   %esi
8010450e:	e8 bb d6 ff ff       	call   80101bce <dirlink>
80104513:	83 c4 10             	add    $0x10,%esp
80104516:	85 c0                	test   %eax,%eax
80104518:	78 69                	js     80104583 <create+0x14e>
  iunlockput(dp);
8010451a:	83 ec 0c             	sub    $0xc,%esp
8010451d:	56                   	push   %esi
8010451e:	e8 0c d2 ff ff       	call   8010172f <iunlockput>
  return ip;
80104523:	83 c4 10             	add    $0x10,%esp
80104526:	e9 76 ff ff ff       	jmp    801044a1 <create+0x6c>
    panic("create: ialloc");
8010452b:	83 ec 0c             	sub    $0xc,%esp
8010452e:	68 3c 6f 10 80       	push   $0x80106f3c
80104533:	e8 0c be ff ff       	call   80100344 <panic>
    dp->nlink++;  // for ".."
80104538:	66 83 46 56 01       	addw   $0x1,0x56(%esi)
    iupdate(dp);
8010453d:	83 ec 0c             	sub    $0xc,%esp
80104540:	56                   	push   %esi
80104541:	e8 f6 ce ff ff       	call   8010143c <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
80104546:	83 c4 0c             	add    $0xc,%esp
80104549:	ff 73 04             	pushl  0x4(%ebx)
8010454c:	68 4c 6f 10 80       	push   $0x80106f4c
80104551:	53                   	push   %ebx
80104552:	e8 77 d6 ff ff       	call   80101bce <dirlink>
80104557:	83 c4 10             	add    $0x10,%esp
8010455a:	85 c0                	test   %eax,%eax
8010455c:	78 18                	js     80104576 <create+0x141>
8010455e:	83 ec 04             	sub    $0x4,%esp
80104561:	ff 76 04             	pushl  0x4(%esi)
80104564:	68 4b 6f 10 80       	push   $0x80106f4b
80104569:	53                   	push   %ebx
8010456a:	e8 5f d6 ff ff       	call   80101bce <dirlink>
8010456f:	83 c4 10             	add    $0x10,%esp
80104572:	85 c0                	test   %eax,%eax
80104574:	79 8d                	jns    80104503 <create+0xce>
      panic("create dots");
80104576:	83 ec 0c             	sub    $0xc,%esp
80104579:	68 4e 6f 10 80       	push   $0x80106f4e
8010457e:	e8 c1 bd ff ff       	call   80100344 <panic>
    panic("create: dirlink");
80104583:	83 ec 0c             	sub    $0xc,%esp
80104586:	68 5a 6f 10 80       	push   $0x80106f5a
8010458b:	e8 b4 bd ff ff       	call   80100344 <panic>
    return 0;
80104590:	89 c3                	mov    %eax,%ebx
80104592:	e9 0a ff ff ff       	jmp    801044a1 <create+0x6c>

80104597 <sys_dup>:
{
80104597:	55                   	push   %ebp
80104598:	89 e5                	mov    %esp,%ebp
8010459a:	53                   	push   %ebx
8010459b:	83 ec 14             	sub    $0x14,%esp
  if(argfd(0, 0, &f) < 0)
8010459e:	8d 4d f4             	lea    -0xc(%ebp),%ecx
801045a1:	ba 00 00 00 00       	mov    $0x0,%edx
801045a6:	b8 00 00 00 00       	mov    $0x0,%eax
801045ab:	e8 e5 fd ff ff       	call   80104395 <argfd>
801045b0:	85 c0                	test   %eax,%eax
801045b2:	78 23                	js     801045d7 <sys_dup+0x40>
  if((fd=fdalloc(f)) < 0)
801045b4:	8b 45 f4             	mov    -0xc(%ebp),%eax
801045b7:	e8 39 fe ff ff       	call   801043f5 <fdalloc>
801045bc:	89 c3                	mov    %eax,%ebx
801045be:	85 c0                	test   %eax,%eax
801045c0:	78 1c                	js     801045de <sys_dup+0x47>
  filedup(f);
801045c2:	83 ec 0c             	sub    $0xc,%esp
801045c5:	ff 75 f4             	pushl  -0xc(%ebp)
801045c8:	e8 1a c7 ff ff       	call   80100ce7 <filedup>
  return fd;
801045cd:	83 c4 10             	add    $0x10,%esp
}
801045d0:	89 d8                	mov    %ebx,%eax
801045d2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801045d5:	c9                   	leave  
801045d6:	c3                   	ret    
    return -1;
801045d7:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801045dc:	eb f2                	jmp    801045d0 <sys_dup+0x39>
    return -1;
801045de:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801045e3:	eb eb                	jmp    801045d0 <sys_dup+0x39>

801045e5 <sys_read>:
{
801045e5:	55                   	push   %ebp
801045e6:	89 e5                	mov    %esp,%ebp
801045e8:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801045eb:	8d 4d f4             	lea    -0xc(%ebp),%ecx
801045ee:	ba 00 00 00 00       	mov    $0x0,%edx
801045f3:	b8 00 00 00 00       	mov    $0x0,%eax
801045f8:	e8 98 fd ff ff       	call   80104395 <argfd>
801045fd:	85 c0                	test   %eax,%eax
801045ff:	78 43                	js     80104644 <sys_read+0x5f>
80104601:	83 ec 08             	sub    $0x8,%esp
80104604:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104607:	50                   	push   %eax
80104608:	6a 02                	push   $0x2
8010460a:	e8 77 fc ff ff       	call   80104286 <argint>
8010460f:	83 c4 10             	add    $0x10,%esp
80104612:	85 c0                	test   %eax,%eax
80104614:	78 35                	js     8010464b <sys_read+0x66>
80104616:	83 ec 04             	sub    $0x4,%esp
80104619:	ff 75 f0             	pushl  -0x10(%ebp)
8010461c:	8d 45 ec             	lea    -0x14(%ebp),%eax
8010461f:	50                   	push   %eax
80104620:	6a 01                	push   $0x1
80104622:	e8 85 fc ff ff       	call   801042ac <argptr>
80104627:	83 c4 10             	add    $0x10,%esp
8010462a:	85 c0                	test   %eax,%eax
8010462c:	78 24                	js     80104652 <sys_read+0x6d>
  return fileread(f, p, n);
8010462e:	83 ec 04             	sub    $0x4,%esp
80104631:	ff 75 f0             	pushl  -0x10(%ebp)
80104634:	ff 75 ec             	pushl  -0x14(%ebp)
80104637:	ff 75 f4             	pushl  -0xc(%ebp)
8010463a:	e8 e9 c7 ff ff       	call   80100e28 <fileread>
8010463f:	83 c4 10             	add    $0x10,%esp
}
80104642:	c9                   	leave  
80104643:	c3                   	ret    
    return -1;
80104644:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104649:	eb f7                	jmp    80104642 <sys_read+0x5d>
8010464b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104650:	eb f0                	jmp    80104642 <sys_read+0x5d>
80104652:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104657:	eb e9                	jmp    80104642 <sys_read+0x5d>

80104659 <sys_write>:
{
80104659:	55                   	push   %ebp
8010465a:	89 e5                	mov    %esp,%ebp
8010465c:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
8010465f:	8d 4d f4             	lea    -0xc(%ebp),%ecx
80104662:	ba 00 00 00 00       	mov    $0x0,%edx
80104667:	b8 00 00 00 00       	mov    $0x0,%eax
8010466c:	e8 24 fd ff ff       	call   80104395 <argfd>
80104671:	85 c0                	test   %eax,%eax
80104673:	78 43                	js     801046b8 <sys_write+0x5f>
80104675:	83 ec 08             	sub    $0x8,%esp
80104678:	8d 45 f0             	lea    -0x10(%ebp),%eax
8010467b:	50                   	push   %eax
8010467c:	6a 02                	push   $0x2
8010467e:	e8 03 fc ff ff       	call   80104286 <argint>
80104683:	83 c4 10             	add    $0x10,%esp
80104686:	85 c0                	test   %eax,%eax
80104688:	78 35                	js     801046bf <sys_write+0x66>
8010468a:	83 ec 04             	sub    $0x4,%esp
8010468d:	ff 75 f0             	pushl  -0x10(%ebp)
80104690:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104693:	50                   	push   %eax
80104694:	6a 01                	push   $0x1
80104696:	e8 11 fc ff ff       	call   801042ac <argptr>
8010469b:	83 c4 10             	add    $0x10,%esp
8010469e:	85 c0                	test   %eax,%eax
801046a0:	78 24                	js     801046c6 <sys_write+0x6d>
  return filewrite(f, p, n);
801046a2:	83 ec 04             	sub    $0x4,%esp
801046a5:	ff 75 f0             	pushl  -0x10(%ebp)
801046a8:	ff 75 ec             	pushl  -0x14(%ebp)
801046ab:	ff 75 f4             	pushl  -0xc(%ebp)
801046ae:	e8 fa c7 ff ff       	call   80100ead <filewrite>
801046b3:	83 c4 10             	add    $0x10,%esp
}
801046b6:	c9                   	leave  
801046b7:	c3                   	ret    
    return -1;
801046b8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801046bd:	eb f7                	jmp    801046b6 <sys_write+0x5d>
801046bf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801046c4:	eb f0                	jmp    801046b6 <sys_write+0x5d>
801046c6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801046cb:	eb e9                	jmp    801046b6 <sys_write+0x5d>

801046cd <sys_close>:
{
801046cd:	55                   	push   %ebp
801046ce:	89 e5                	mov    %esp,%ebp
801046d0:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, &fd, &f) < 0)
801046d3:	8d 4d f0             	lea    -0x10(%ebp),%ecx
801046d6:	8d 55 f4             	lea    -0xc(%ebp),%edx
801046d9:	b8 00 00 00 00       	mov    $0x0,%eax
801046de:	e8 b2 fc ff ff       	call   80104395 <argfd>
801046e3:	85 c0                	test   %eax,%eax
801046e5:	78 25                	js     8010470c <sys_close+0x3f>
  myproc()->ofile[fd] = 0;
801046e7:	e8 59 ec ff ff       	call   80103345 <myproc>
801046ec:	8b 55 f4             	mov    -0xc(%ebp),%edx
801046ef:	c7 44 90 28 00 00 00 	movl   $0x0,0x28(%eax,%edx,4)
801046f6:	00 
  fileclose(f);
801046f7:	83 ec 0c             	sub    $0xc,%esp
801046fa:	ff 75 f0             	pushl  -0x10(%ebp)
801046fd:	e8 2a c6 ff ff       	call   80100d2c <fileclose>
  return 0;
80104702:	83 c4 10             	add    $0x10,%esp
80104705:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010470a:	c9                   	leave  
8010470b:	c3                   	ret    
    return -1;
8010470c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104711:	eb f7                	jmp    8010470a <sys_close+0x3d>

80104713 <sys_fstat>:
{
80104713:	55                   	push   %ebp
80104714:	89 e5                	mov    %esp,%ebp
80104716:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
80104719:	8d 4d f4             	lea    -0xc(%ebp),%ecx
8010471c:	ba 00 00 00 00       	mov    $0x0,%edx
80104721:	b8 00 00 00 00       	mov    $0x0,%eax
80104726:	e8 6a fc ff ff       	call   80104395 <argfd>
8010472b:	85 c0                	test   %eax,%eax
8010472d:	78 2a                	js     80104759 <sys_fstat+0x46>
8010472f:	83 ec 04             	sub    $0x4,%esp
80104732:	6a 14                	push   $0x14
80104734:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104737:	50                   	push   %eax
80104738:	6a 01                	push   $0x1
8010473a:	e8 6d fb ff ff       	call   801042ac <argptr>
8010473f:	83 c4 10             	add    $0x10,%esp
80104742:	85 c0                	test   %eax,%eax
80104744:	78 1a                	js     80104760 <sys_fstat+0x4d>
  return filestat(f, st);
80104746:	83 ec 08             	sub    $0x8,%esp
80104749:	ff 75 f0             	pushl  -0x10(%ebp)
8010474c:	ff 75 f4             	pushl  -0xc(%ebp)
8010474f:	e8 8d c6 ff ff       	call   80100de1 <filestat>
80104754:	83 c4 10             	add    $0x10,%esp
}
80104757:	c9                   	leave  
80104758:	c3                   	ret    
    return -1;
80104759:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010475e:	eb f7                	jmp    80104757 <sys_fstat+0x44>
80104760:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104765:	eb f0                	jmp    80104757 <sys_fstat+0x44>

80104767 <sys_link>:
{
80104767:	55                   	push   %ebp
80104768:	89 e5                	mov    %esp,%ebp
8010476a:	56                   	push   %esi
8010476b:	53                   	push   %ebx
8010476c:	83 ec 28             	sub    $0x28,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
8010476f:	8d 45 e0             	lea    -0x20(%ebp),%eax
80104772:	50                   	push   %eax
80104773:	6a 00                	push   $0x0
80104775:	e8 93 fb ff ff       	call   8010430d <argstr>
8010477a:	83 c4 10             	add    $0x10,%esp
8010477d:	85 c0                	test   %eax,%eax
8010477f:	0f 88 26 01 00 00    	js     801048ab <sys_link+0x144>
80104785:	83 ec 08             	sub    $0x8,%esp
80104788:	8d 45 e4             	lea    -0x1c(%ebp),%eax
8010478b:	50                   	push   %eax
8010478c:	6a 01                	push   $0x1
8010478e:	e8 7a fb ff ff       	call   8010430d <argstr>
80104793:	83 c4 10             	add    $0x10,%esp
80104796:	85 c0                	test   %eax,%eax
80104798:	0f 88 14 01 00 00    	js     801048b2 <sys_link+0x14b>
  begin_op();
8010479e:	e8 0a e0 ff ff       	call   801027ad <begin_op>
  if((ip = namei(old)) == 0){
801047a3:	83 ec 0c             	sub    $0xc,%esp
801047a6:	ff 75 e0             	pushl  -0x20(%ebp)
801047a9:	e8 d5 d4 ff ff       	call   80101c83 <namei>
801047ae:	89 c3                	mov    %eax,%ebx
801047b0:	83 c4 10             	add    $0x10,%esp
801047b3:	85 c0                	test   %eax,%eax
801047b5:	0f 84 93 00 00 00    	je     8010484e <sys_link+0xe7>
  ilock(ip);
801047bb:	83 ec 0c             	sub    $0xc,%esp
801047be:	50                   	push   %eax
801047bf:	e8 22 cd ff ff       	call   801014e6 <ilock>
  if(ip->type == T_DIR){
801047c4:	83 c4 10             	add    $0x10,%esp
801047c7:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
801047cc:	0f 84 88 00 00 00    	je     8010485a <sys_link+0xf3>
  ip->nlink++;
801047d2:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  iupdate(ip);
801047d7:	83 ec 0c             	sub    $0xc,%esp
801047da:	53                   	push   %ebx
801047db:	e8 5c cc ff ff       	call   8010143c <iupdate>
  iunlock(ip);
801047e0:	89 1c 24             	mov    %ebx,(%esp)
801047e3:	e8 c0 cd ff ff       	call   801015a8 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
801047e8:	83 c4 08             	add    $0x8,%esp
801047eb:	8d 45 ea             	lea    -0x16(%ebp),%eax
801047ee:	50                   	push   %eax
801047ef:	ff 75 e4             	pushl  -0x1c(%ebp)
801047f2:	e8 a4 d4 ff ff       	call   80101c9b <nameiparent>
801047f7:	89 c6                	mov    %eax,%esi
801047f9:	83 c4 10             	add    $0x10,%esp
801047fc:	85 c0                	test   %eax,%eax
801047fe:	74 7e                	je     8010487e <sys_link+0x117>
  ilock(dp);
80104800:	83 ec 0c             	sub    $0xc,%esp
80104803:	50                   	push   %eax
80104804:	e8 dd cc ff ff       	call   801014e6 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
80104809:	83 c4 10             	add    $0x10,%esp
8010480c:	8b 03                	mov    (%ebx),%eax
8010480e:	39 06                	cmp    %eax,(%esi)
80104810:	75 60                	jne    80104872 <sys_link+0x10b>
80104812:	83 ec 04             	sub    $0x4,%esp
80104815:	ff 73 04             	pushl  0x4(%ebx)
80104818:	8d 45 ea             	lea    -0x16(%ebp),%eax
8010481b:	50                   	push   %eax
8010481c:	56                   	push   %esi
8010481d:	e8 ac d3 ff ff       	call   80101bce <dirlink>
80104822:	83 c4 10             	add    $0x10,%esp
80104825:	85 c0                	test   %eax,%eax
80104827:	78 49                	js     80104872 <sys_link+0x10b>
  iunlockput(dp);
80104829:	83 ec 0c             	sub    $0xc,%esp
8010482c:	56                   	push   %esi
8010482d:	e8 fd ce ff ff       	call   8010172f <iunlockput>
  iput(ip);
80104832:	89 1c 24             	mov    %ebx,(%esp)
80104835:	e8 b3 cd ff ff       	call   801015ed <iput>
  end_op();
8010483a:	e8 e9 df ff ff       	call   80102828 <end_op>
  return 0;
8010483f:	83 c4 10             	add    $0x10,%esp
80104842:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104847:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010484a:	5b                   	pop    %ebx
8010484b:	5e                   	pop    %esi
8010484c:	5d                   	pop    %ebp
8010484d:	c3                   	ret    
    end_op();
8010484e:	e8 d5 df ff ff       	call   80102828 <end_op>
    return -1;
80104853:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104858:	eb ed                	jmp    80104847 <sys_link+0xe0>
    iunlockput(ip);
8010485a:	83 ec 0c             	sub    $0xc,%esp
8010485d:	53                   	push   %ebx
8010485e:	e8 cc ce ff ff       	call   8010172f <iunlockput>
    end_op();
80104863:	e8 c0 df ff ff       	call   80102828 <end_op>
    return -1;
80104868:	83 c4 10             	add    $0x10,%esp
8010486b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104870:	eb d5                	jmp    80104847 <sys_link+0xe0>
    iunlockput(dp);
80104872:	83 ec 0c             	sub    $0xc,%esp
80104875:	56                   	push   %esi
80104876:	e8 b4 ce ff ff       	call   8010172f <iunlockput>
    goto bad;
8010487b:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
8010487e:	83 ec 0c             	sub    $0xc,%esp
80104881:	53                   	push   %ebx
80104882:	e8 5f cc ff ff       	call   801014e6 <ilock>
  ip->nlink--;
80104887:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010488c:	89 1c 24             	mov    %ebx,(%esp)
8010488f:	e8 a8 cb ff ff       	call   8010143c <iupdate>
  iunlockput(ip);
80104894:	89 1c 24             	mov    %ebx,(%esp)
80104897:	e8 93 ce ff ff       	call   8010172f <iunlockput>
  end_op();
8010489c:	e8 87 df ff ff       	call   80102828 <end_op>
  return -1;
801048a1:	83 c4 10             	add    $0x10,%esp
801048a4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048a9:	eb 9c                	jmp    80104847 <sys_link+0xe0>
    return -1;
801048ab:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048b0:	eb 95                	jmp    80104847 <sys_link+0xe0>
801048b2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048b7:	eb 8e                	jmp    80104847 <sys_link+0xe0>

801048b9 <sys_unlink>:
{
801048b9:	55                   	push   %ebp
801048ba:	89 e5                	mov    %esp,%ebp
801048bc:	57                   	push   %edi
801048bd:	56                   	push   %esi
801048be:	53                   	push   %ebx
801048bf:	83 ec 54             	sub    $0x54,%esp
  if(argstr(0, &path) < 0)
801048c2:	8d 45 c4             	lea    -0x3c(%ebp),%eax
801048c5:	50                   	push   %eax
801048c6:	6a 00                	push   $0x0
801048c8:	e8 40 fa ff ff       	call   8010430d <argstr>
801048cd:	83 c4 10             	add    $0x10,%esp
801048d0:	85 c0                	test   %eax,%eax
801048d2:	0f 88 81 01 00 00    	js     80104a59 <sys_unlink+0x1a0>
  begin_op();
801048d8:	e8 d0 de ff ff       	call   801027ad <begin_op>
  if((dp = nameiparent(path, name)) == 0){
801048dd:	83 ec 08             	sub    $0x8,%esp
801048e0:	8d 45 ca             	lea    -0x36(%ebp),%eax
801048e3:	50                   	push   %eax
801048e4:	ff 75 c4             	pushl  -0x3c(%ebp)
801048e7:	e8 af d3 ff ff       	call   80101c9b <nameiparent>
801048ec:	89 c7                	mov    %eax,%edi
801048ee:	83 c4 10             	add    $0x10,%esp
801048f1:	85 c0                	test   %eax,%eax
801048f3:	0f 84 df 00 00 00    	je     801049d8 <sys_unlink+0x11f>
  ilock(dp);
801048f9:	83 ec 0c             	sub    $0xc,%esp
801048fc:	50                   	push   %eax
801048fd:	e8 e4 cb ff ff       	call   801014e6 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
80104902:	83 c4 08             	add    $0x8,%esp
80104905:	68 4c 6f 10 80       	push   $0x80106f4c
8010490a:	8d 45 ca             	lea    -0x36(%ebp),%eax
8010490d:	50                   	push   %eax
8010490e:	e8 84 d0 ff ff       	call   80101997 <namecmp>
80104913:	83 c4 10             	add    $0x10,%esp
80104916:	85 c0                	test   %eax,%eax
80104918:	0f 84 51 01 00 00    	je     80104a6f <sys_unlink+0x1b6>
8010491e:	83 ec 08             	sub    $0x8,%esp
80104921:	68 4b 6f 10 80       	push   $0x80106f4b
80104926:	8d 45 ca             	lea    -0x36(%ebp),%eax
80104929:	50                   	push   %eax
8010492a:	e8 68 d0 ff ff       	call   80101997 <namecmp>
8010492f:	83 c4 10             	add    $0x10,%esp
80104932:	85 c0                	test   %eax,%eax
80104934:	0f 84 35 01 00 00    	je     80104a6f <sys_unlink+0x1b6>
  if((ip = dirlookup(dp, name, &off)) == 0)
8010493a:	83 ec 04             	sub    $0x4,%esp
8010493d:	8d 45 c0             	lea    -0x40(%ebp),%eax
80104940:	50                   	push   %eax
80104941:	8d 45 ca             	lea    -0x36(%ebp),%eax
80104944:	50                   	push   %eax
80104945:	57                   	push   %edi
80104946:	e8 61 d0 ff ff       	call   801019ac <dirlookup>
8010494b:	89 c3                	mov    %eax,%ebx
8010494d:	83 c4 10             	add    $0x10,%esp
80104950:	85 c0                	test   %eax,%eax
80104952:	0f 84 17 01 00 00    	je     80104a6f <sys_unlink+0x1b6>
  ilock(ip);
80104958:	83 ec 0c             	sub    $0xc,%esp
8010495b:	50                   	push   %eax
8010495c:	e8 85 cb ff ff       	call   801014e6 <ilock>
  if(ip->nlink < 1)
80104961:	83 c4 10             	add    $0x10,%esp
80104964:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80104969:	7e 79                	jle    801049e4 <sys_unlink+0x12b>
  if(ip->type == T_DIR && !isdirempty(ip)){
8010496b:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104970:	74 7f                	je     801049f1 <sys_unlink+0x138>
  memset(&de, 0, sizeof(de));
80104972:	83 ec 04             	sub    $0x4,%esp
80104975:	6a 10                	push   $0x10
80104977:	6a 00                	push   $0x0
80104979:	8d 75 d8             	lea    -0x28(%ebp),%esi
8010497c:	56                   	push   %esi
8010497d:	e8 7e f6 ff ff       	call   80104000 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80104982:	6a 10                	push   $0x10
80104984:	ff 75 c0             	pushl  -0x40(%ebp)
80104987:	56                   	push   %esi
80104988:	57                   	push   %edi
80104989:	e8 e8 ce ff ff       	call   80101876 <writei>
8010498e:	83 c4 20             	add    $0x20,%esp
80104991:	83 f8 10             	cmp    $0x10,%eax
80104994:	0f 85 9c 00 00 00    	jne    80104a36 <sys_unlink+0x17d>
  if(ip->type == T_DIR){
8010499a:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
8010499f:	0f 84 9e 00 00 00    	je     80104a43 <sys_unlink+0x18a>
  iunlockput(dp);
801049a5:	83 ec 0c             	sub    $0xc,%esp
801049a8:	57                   	push   %edi
801049a9:	e8 81 cd ff ff       	call   8010172f <iunlockput>
  ip->nlink--;
801049ae:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
801049b3:	89 1c 24             	mov    %ebx,(%esp)
801049b6:	e8 81 ca ff ff       	call   8010143c <iupdate>
  iunlockput(ip);
801049bb:	89 1c 24             	mov    %ebx,(%esp)
801049be:	e8 6c cd ff ff       	call   8010172f <iunlockput>
  end_op();
801049c3:	e8 60 de ff ff       	call   80102828 <end_op>
  return 0;
801049c8:	83 c4 10             	add    $0x10,%esp
801049cb:	b8 00 00 00 00       	mov    $0x0,%eax
}
801049d0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801049d3:	5b                   	pop    %ebx
801049d4:	5e                   	pop    %esi
801049d5:	5f                   	pop    %edi
801049d6:	5d                   	pop    %ebp
801049d7:	c3                   	ret    
    end_op();
801049d8:	e8 4b de ff ff       	call   80102828 <end_op>
    return -1;
801049dd:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801049e2:	eb ec                	jmp    801049d0 <sys_unlink+0x117>
    panic("unlink: nlink < 1");
801049e4:	83 ec 0c             	sub    $0xc,%esp
801049e7:	68 6a 6f 10 80       	push   $0x80106f6a
801049ec:	e8 53 b9 ff ff       	call   80100344 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
801049f1:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
801049f5:	0f 86 77 ff ff ff    	jbe    80104972 <sys_unlink+0xb9>
801049fb:	be 20 00 00 00       	mov    $0x20,%esi
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80104a00:	6a 10                	push   $0x10
80104a02:	56                   	push   %esi
80104a03:	8d 45 b0             	lea    -0x50(%ebp),%eax
80104a06:	50                   	push   %eax
80104a07:	53                   	push   %ebx
80104a08:	e8 6d cd ff ff       	call   8010177a <readi>
80104a0d:	83 c4 10             	add    $0x10,%esp
80104a10:	83 f8 10             	cmp    $0x10,%eax
80104a13:	75 14                	jne    80104a29 <sys_unlink+0x170>
    if(de.inum != 0)
80104a15:	66 83 7d b0 00       	cmpw   $0x0,-0x50(%ebp)
80104a1a:	75 47                	jne    80104a63 <sys_unlink+0x1aa>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80104a1c:	83 c6 10             	add    $0x10,%esi
80104a1f:	3b 73 58             	cmp    0x58(%ebx),%esi
80104a22:	72 dc                	jb     80104a00 <sys_unlink+0x147>
80104a24:	e9 49 ff ff ff       	jmp    80104972 <sys_unlink+0xb9>
      panic("isdirempty: readi");
80104a29:	83 ec 0c             	sub    $0xc,%esp
80104a2c:	68 7c 6f 10 80       	push   $0x80106f7c
80104a31:	e8 0e b9 ff ff       	call   80100344 <panic>
    panic("unlink: writei");
80104a36:	83 ec 0c             	sub    $0xc,%esp
80104a39:	68 8e 6f 10 80       	push   $0x80106f8e
80104a3e:	e8 01 b9 ff ff       	call   80100344 <panic>
    dp->nlink--;
80104a43:	66 83 6f 56 01       	subw   $0x1,0x56(%edi)
    iupdate(dp);
80104a48:	83 ec 0c             	sub    $0xc,%esp
80104a4b:	57                   	push   %edi
80104a4c:	e8 eb c9 ff ff       	call   8010143c <iupdate>
80104a51:	83 c4 10             	add    $0x10,%esp
80104a54:	e9 4c ff ff ff       	jmp    801049a5 <sys_unlink+0xec>
    return -1;
80104a59:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104a5e:	e9 6d ff ff ff       	jmp    801049d0 <sys_unlink+0x117>
    iunlockput(ip);
80104a63:	83 ec 0c             	sub    $0xc,%esp
80104a66:	53                   	push   %ebx
80104a67:	e8 c3 cc ff ff       	call   8010172f <iunlockput>
    goto bad;
80104a6c:	83 c4 10             	add    $0x10,%esp
  iunlockput(dp);
80104a6f:	83 ec 0c             	sub    $0xc,%esp
80104a72:	57                   	push   %edi
80104a73:	e8 b7 cc ff ff       	call   8010172f <iunlockput>
  end_op();
80104a78:	e8 ab dd ff ff       	call   80102828 <end_op>
  return -1;
80104a7d:	83 c4 10             	add    $0x10,%esp
80104a80:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104a85:	e9 46 ff ff ff       	jmp    801049d0 <sys_unlink+0x117>

80104a8a <sys_open>:

int
sys_open(void)
{
80104a8a:	55                   	push   %ebp
80104a8b:	89 e5                	mov    %esp,%ebp
80104a8d:	57                   	push   %edi
80104a8e:	56                   	push   %esi
80104a8f:	53                   	push   %ebx
80104a90:	83 ec 24             	sub    $0x24,%esp
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80104a93:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104a96:	50                   	push   %eax
80104a97:	6a 00                	push   $0x0
80104a99:	e8 6f f8 ff ff       	call   8010430d <argstr>
80104a9e:	83 c4 10             	add    $0x10,%esp
80104aa1:	85 c0                	test   %eax,%eax
80104aa3:	0f 88 0b 01 00 00    	js     80104bb4 <sys_open+0x12a>
80104aa9:	83 ec 08             	sub    $0x8,%esp
80104aac:	8d 45 e0             	lea    -0x20(%ebp),%eax
80104aaf:	50                   	push   %eax
80104ab0:	6a 01                	push   $0x1
80104ab2:	e8 cf f7 ff ff       	call   80104286 <argint>
80104ab7:	83 c4 10             	add    $0x10,%esp
80104aba:	85 c0                	test   %eax,%eax
80104abc:	0f 88 f9 00 00 00    	js     80104bbb <sys_open+0x131>
    return -1;

  begin_op();
80104ac2:	e8 e6 dc ff ff       	call   801027ad <begin_op>

  if(omode & O_CREATE){
80104ac7:	f6 45 e1 02          	testb  $0x2,-0x1f(%ebp)
80104acb:	0f 84 8a 00 00 00    	je     80104b5b <sys_open+0xd1>
    ip = create(path, T_FILE, 0, 0);
80104ad1:	83 ec 0c             	sub    $0xc,%esp
80104ad4:	6a 00                	push   $0x0
80104ad6:	b9 00 00 00 00       	mov    $0x0,%ecx
80104adb:	ba 02 00 00 00       	mov    $0x2,%edx
80104ae0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80104ae3:	e8 4d f9 ff ff       	call   80104435 <create>
80104ae8:	89 c6                	mov    %eax,%esi
    if(ip == 0){
80104aea:	83 c4 10             	add    $0x10,%esp
80104aed:	85 c0                	test   %eax,%eax
80104aef:	74 5e                	je     80104b4f <sys_open+0xc5>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
80104af1:	e8 84 c1 ff ff       	call   80100c7a <filealloc>
80104af6:	89 c3                	mov    %eax,%ebx
80104af8:	85 c0                	test   %eax,%eax
80104afa:	0f 84 ce 00 00 00    	je     80104bce <sys_open+0x144>
80104b00:	e8 f0 f8 ff ff       	call   801043f5 <fdalloc>
80104b05:	89 c7                	mov    %eax,%edi
80104b07:	85 c0                	test   %eax,%eax
80104b09:	0f 88 b3 00 00 00    	js     80104bc2 <sys_open+0x138>
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80104b0f:	83 ec 0c             	sub    $0xc,%esp
80104b12:	56                   	push   %esi
80104b13:	e8 90 ca ff ff       	call   801015a8 <iunlock>
  end_op();
80104b18:	e8 0b dd ff ff       	call   80102828 <end_op>

  f->type = FD_INODE;
80104b1d:	c7 03 02 00 00 00    	movl   $0x2,(%ebx)
  f->ip = ip;
80104b23:	89 73 10             	mov    %esi,0x10(%ebx)
  f->off = 0;
80104b26:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
  f->readable = !(omode & O_WRONLY);
80104b2d:	8b 55 e0             	mov    -0x20(%ebp),%edx
80104b30:	89 d0                	mov    %edx,%eax
80104b32:	83 f0 01             	xor    $0x1,%eax
80104b35:	83 e0 01             	and    $0x1,%eax
80104b38:	88 43 08             	mov    %al,0x8(%ebx)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80104b3b:	83 c4 10             	add    $0x10,%esp
80104b3e:	f6 c2 03             	test   $0x3,%dl
80104b41:	0f 95 43 09          	setne  0x9(%ebx)
  return fd;
}
80104b45:	89 f8                	mov    %edi,%eax
80104b47:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104b4a:	5b                   	pop    %ebx
80104b4b:	5e                   	pop    %esi
80104b4c:	5f                   	pop    %edi
80104b4d:	5d                   	pop    %ebp
80104b4e:	c3                   	ret    
      end_op();
80104b4f:	e8 d4 dc ff ff       	call   80102828 <end_op>
      return -1;
80104b54:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104b59:	eb ea                	jmp    80104b45 <sys_open+0xbb>
    if((ip = namei(path)) == 0){
80104b5b:	83 ec 0c             	sub    $0xc,%esp
80104b5e:	ff 75 e4             	pushl  -0x1c(%ebp)
80104b61:	e8 1d d1 ff ff       	call   80101c83 <namei>
80104b66:	89 c6                	mov    %eax,%esi
80104b68:	83 c4 10             	add    $0x10,%esp
80104b6b:	85 c0                	test   %eax,%eax
80104b6d:	74 39                	je     80104ba8 <sys_open+0x11e>
    ilock(ip);
80104b6f:	83 ec 0c             	sub    $0xc,%esp
80104b72:	50                   	push   %eax
80104b73:	e8 6e c9 ff ff       	call   801014e6 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
80104b78:	83 c4 10             	add    $0x10,%esp
80104b7b:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80104b80:	0f 85 6b ff ff ff    	jne    80104af1 <sys_open+0x67>
80104b86:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80104b8a:	0f 84 61 ff ff ff    	je     80104af1 <sys_open+0x67>
      iunlockput(ip);
80104b90:	83 ec 0c             	sub    $0xc,%esp
80104b93:	56                   	push   %esi
80104b94:	e8 96 cb ff ff       	call   8010172f <iunlockput>
      end_op();
80104b99:	e8 8a dc ff ff       	call   80102828 <end_op>
      return -1;
80104b9e:	83 c4 10             	add    $0x10,%esp
80104ba1:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104ba6:	eb 9d                	jmp    80104b45 <sys_open+0xbb>
      end_op();
80104ba8:	e8 7b dc ff ff       	call   80102828 <end_op>
      return -1;
80104bad:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104bb2:	eb 91                	jmp    80104b45 <sys_open+0xbb>
    return -1;
80104bb4:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104bb9:	eb 8a                	jmp    80104b45 <sys_open+0xbb>
80104bbb:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104bc0:	eb 83                	jmp    80104b45 <sys_open+0xbb>
      fileclose(f);
80104bc2:	83 ec 0c             	sub    $0xc,%esp
80104bc5:	53                   	push   %ebx
80104bc6:	e8 61 c1 ff ff       	call   80100d2c <fileclose>
80104bcb:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80104bce:	83 ec 0c             	sub    $0xc,%esp
80104bd1:	56                   	push   %esi
80104bd2:	e8 58 cb ff ff       	call   8010172f <iunlockput>
    end_op();
80104bd7:	e8 4c dc ff ff       	call   80102828 <end_op>
    return -1;
80104bdc:	83 c4 10             	add    $0x10,%esp
80104bdf:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104be4:	e9 5c ff ff ff       	jmp    80104b45 <sys_open+0xbb>

80104be9 <sys_mkdir>:

int
sys_mkdir(void)
{
80104be9:	55                   	push   %ebp
80104bea:	89 e5                	mov    %esp,%ebp
80104bec:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80104bef:	e8 b9 db ff ff       	call   801027ad <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
80104bf4:	83 ec 08             	sub    $0x8,%esp
80104bf7:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104bfa:	50                   	push   %eax
80104bfb:	6a 00                	push   $0x0
80104bfd:	e8 0b f7 ff ff       	call   8010430d <argstr>
80104c02:	83 c4 10             	add    $0x10,%esp
80104c05:	85 c0                	test   %eax,%eax
80104c07:	78 36                	js     80104c3f <sys_mkdir+0x56>
80104c09:	83 ec 0c             	sub    $0xc,%esp
80104c0c:	6a 00                	push   $0x0
80104c0e:	b9 00 00 00 00       	mov    $0x0,%ecx
80104c13:	ba 01 00 00 00       	mov    $0x1,%edx
80104c18:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104c1b:	e8 15 f8 ff ff       	call   80104435 <create>
80104c20:	83 c4 10             	add    $0x10,%esp
80104c23:	85 c0                	test   %eax,%eax
80104c25:	74 18                	je     80104c3f <sys_mkdir+0x56>
    end_op();
    return -1;
  }
  iunlockput(ip);
80104c27:	83 ec 0c             	sub    $0xc,%esp
80104c2a:	50                   	push   %eax
80104c2b:	e8 ff ca ff ff       	call   8010172f <iunlockput>
  end_op();
80104c30:	e8 f3 db ff ff       	call   80102828 <end_op>
  return 0;
80104c35:	83 c4 10             	add    $0x10,%esp
80104c38:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104c3d:	c9                   	leave  
80104c3e:	c3                   	ret    
    end_op();
80104c3f:	e8 e4 db ff ff       	call   80102828 <end_op>
    return -1;
80104c44:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104c49:	eb f2                	jmp    80104c3d <sys_mkdir+0x54>

80104c4b <sys_mknod>:

int
sys_mknod(void)
{
80104c4b:	55                   	push   %ebp
80104c4c:	89 e5                	mov    %esp,%ebp
80104c4e:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
80104c51:	e8 57 db ff ff       	call   801027ad <begin_op>
  if((argstr(0, &path)) < 0 ||
80104c56:	83 ec 08             	sub    $0x8,%esp
80104c59:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104c5c:	50                   	push   %eax
80104c5d:	6a 00                	push   $0x0
80104c5f:	e8 a9 f6 ff ff       	call   8010430d <argstr>
80104c64:	83 c4 10             	add    $0x10,%esp
80104c67:	85 c0                	test   %eax,%eax
80104c69:	78 62                	js     80104ccd <sys_mknod+0x82>
     argint(1, &major) < 0 ||
80104c6b:	83 ec 08             	sub    $0x8,%esp
80104c6e:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104c71:	50                   	push   %eax
80104c72:	6a 01                	push   $0x1
80104c74:	e8 0d f6 ff ff       	call   80104286 <argint>
  if((argstr(0, &path)) < 0 ||
80104c79:	83 c4 10             	add    $0x10,%esp
80104c7c:	85 c0                	test   %eax,%eax
80104c7e:	78 4d                	js     80104ccd <sys_mknod+0x82>
     argint(2, &minor) < 0 ||
80104c80:	83 ec 08             	sub    $0x8,%esp
80104c83:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104c86:	50                   	push   %eax
80104c87:	6a 02                	push   $0x2
80104c89:	e8 f8 f5 ff ff       	call   80104286 <argint>
     argint(1, &major) < 0 ||
80104c8e:	83 c4 10             	add    $0x10,%esp
80104c91:	85 c0                	test   %eax,%eax
80104c93:	78 38                	js     80104ccd <sys_mknod+0x82>
     (ip = create(path, T_DEV, major, minor)) == 0){
80104c95:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
     argint(2, &minor) < 0 ||
80104c99:	83 ec 0c             	sub    $0xc,%esp
     (ip = create(path, T_DEV, major, minor)) == 0){
80104c9c:	0f bf 45 ec          	movswl -0x14(%ebp),%eax
     argint(2, &minor) < 0 ||
80104ca0:	50                   	push   %eax
80104ca1:	ba 03 00 00 00       	mov    $0x3,%edx
80104ca6:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104ca9:	e8 87 f7 ff ff       	call   80104435 <create>
80104cae:	83 c4 10             	add    $0x10,%esp
80104cb1:	85 c0                	test   %eax,%eax
80104cb3:	74 18                	je     80104ccd <sys_mknod+0x82>
    end_op();
    return -1;
  }
  iunlockput(ip);
80104cb5:	83 ec 0c             	sub    $0xc,%esp
80104cb8:	50                   	push   %eax
80104cb9:	e8 71 ca ff ff       	call   8010172f <iunlockput>
  end_op();
80104cbe:	e8 65 db ff ff       	call   80102828 <end_op>
  return 0;
80104cc3:	83 c4 10             	add    $0x10,%esp
80104cc6:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104ccb:	c9                   	leave  
80104ccc:	c3                   	ret    
    end_op();
80104ccd:	e8 56 db ff ff       	call   80102828 <end_op>
    return -1;
80104cd2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104cd7:	eb f2                	jmp    80104ccb <sys_mknod+0x80>

80104cd9 <sys_chdir>:

int
sys_chdir(void)
{
80104cd9:	55                   	push   %ebp
80104cda:	89 e5                	mov    %esp,%ebp
80104cdc:	56                   	push   %esi
80104cdd:	53                   	push   %ebx
80104cde:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
80104ce1:	e8 5f e6 ff ff       	call   80103345 <myproc>
80104ce6:	89 c6                	mov    %eax,%esi
  
  begin_op();
80104ce8:	e8 c0 da ff ff       	call   801027ad <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
80104ced:	83 ec 08             	sub    $0x8,%esp
80104cf0:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104cf3:	50                   	push   %eax
80104cf4:	6a 00                	push   $0x0
80104cf6:	e8 12 f6 ff ff       	call   8010430d <argstr>
80104cfb:	83 c4 10             	add    $0x10,%esp
80104cfe:	85 c0                	test   %eax,%eax
80104d00:	78 52                	js     80104d54 <sys_chdir+0x7b>
80104d02:	83 ec 0c             	sub    $0xc,%esp
80104d05:	ff 75 f4             	pushl  -0xc(%ebp)
80104d08:	e8 76 cf ff ff       	call   80101c83 <namei>
80104d0d:	89 c3                	mov    %eax,%ebx
80104d0f:	83 c4 10             	add    $0x10,%esp
80104d12:	85 c0                	test   %eax,%eax
80104d14:	74 3e                	je     80104d54 <sys_chdir+0x7b>
    end_op();
    return -1;
  }
  ilock(ip);
80104d16:	83 ec 0c             	sub    $0xc,%esp
80104d19:	50                   	push   %eax
80104d1a:	e8 c7 c7 ff ff       	call   801014e6 <ilock>
  if(ip->type != T_DIR){
80104d1f:	83 c4 10             	add    $0x10,%esp
80104d22:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104d27:	75 37                	jne    80104d60 <sys_chdir+0x87>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80104d29:	83 ec 0c             	sub    $0xc,%esp
80104d2c:	53                   	push   %ebx
80104d2d:	e8 76 c8 ff ff       	call   801015a8 <iunlock>
  iput(curproc->cwd);
80104d32:	83 c4 04             	add    $0x4,%esp
80104d35:	ff 76 68             	pushl  0x68(%esi)
80104d38:	e8 b0 c8 ff ff       	call   801015ed <iput>
  end_op();
80104d3d:	e8 e6 da ff ff       	call   80102828 <end_op>
  curproc->cwd = ip;
80104d42:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
80104d45:	83 c4 10             	add    $0x10,%esp
80104d48:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104d4d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104d50:	5b                   	pop    %ebx
80104d51:	5e                   	pop    %esi
80104d52:	5d                   	pop    %ebp
80104d53:	c3                   	ret    
    end_op();
80104d54:	e8 cf da ff ff       	call   80102828 <end_op>
    return -1;
80104d59:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d5e:	eb ed                	jmp    80104d4d <sys_chdir+0x74>
    iunlockput(ip);
80104d60:	83 ec 0c             	sub    $0xc,%esp
80104d63:	53                   	push   %ebx
80104d64:	e8 c6 c9 ff ff       	call   8010172f <iunlockput>
    end_op();
80104d69:	e8 ba da ff ff       	call   80102828 <end_op>
    return -1;
80104d6e:	83 c4 10             	add    $0x10,%esp
80104d71:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d76:	eb d5                	jmp    80104d4d <sys_chdir+0x74>

80104d78 <sys_exec>:

int
sys_exec(void)
{
80104d78:	55                   	push   %ebp
80104d79:	89 e5                	mov    %esp,%ebp
80104d7b:	57                   	push   %edi
80104d7c:	56                   	push   %esi
80104d7d:	53                   	push   %ebx
80104d7e:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80104d84:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104d87:	50                   	push   %eax
80104d88:	6a 00                	push   $0x0
80104d8a:	e8 7e f5 ff ff       	call   8010430d <argstr>
80104d8f:	83 c4 10             	add    $0x10,%esp
80104d92:	85 c0                	test   %eax,%eax
80104d94:	0f 88 b4 00 00 00    	js     80104e4e <sys_exec+0xd6>
80104d9a:	83 ec 08             	sub    $0x8,%esp
80104d9d:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
80104da3:	50                   	push   %eax
80104da4:	6a 01                	push   $0x1
80104da6:	e8 db f4 ff ff       	call   80104286 <argint>
80104dab:	83 c4 10             	add    $0x10,%esp
80104dae:	85 c0                	test   %eax,%eax
80104db0:	0f 88 9f 00 00 00    	js     80104e55 <sys_exec+0xdd>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
80104db6:	83 ec 04             	sub    $0x4,%esp
80104db9:	68 80 00 00 00       	push   $0x80
80104dbe:	6a 00                	push   $0x0
80104dc0:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80104dc6:	50                   	push   %eax
80104dc7:	e8 34 f2 ff ff       	call   80104000 <memset>
80104dcc:	83 c4 10             	add    $0x10,%esp
  for(i=0;; i++){
80104dcf:	be 00 00 00 00       	mov    $0x0,%esi
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
80104dd4:	8d bd 5c ff ff ff    	lea    -0xa4(%ebp),%edi
80104dda:	8d 1c b5 00 00 00 00 	lea    0x0(,%esi,4),%ebx
80104de1:	83 ec 08             	sub    $0x8,%esp
80104de4:	57                   	push   %edi
80104de5:	89 d8                	mov    %ebx,%eax
80104de7:	03 85 60 ff ff ff    	add    -0xa0(%ebp),%eax
80104ded:	50                   	push   %eax
80104dee:	e8 07 f4 ff ff       	call   801041fa <fetchint>
80104df3:	83 c4 10             	add    $0x10,%esp
80104df6:	85 c0                	test   %eax,%eax
80104df8:	78 62                	js     80104e5c <sys_exec+0xe4>
      return -1;
    if(uarg == 0){
80104dfa:	8b 85 5c ff ff ff    	mov    -0xa4(%ebp),%eax
80104e00:	85 c0                	test   %eax,%eax
80104e02:	74 28                	je     80104e2c <sys_exec+0xb4>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
80104e04:	83 ec 08             	sub    $0x8,%esp
80104e07:	8d 95 64 ff ff ff    	lea    -0x9c(%ebp),%edx
80104e0d:	01 d3                	add    %edx,%ebx
80104e0f:	53                   	push   %ebx
80104e10:	50                   	push   %eax
80104e11:	e8 20 f4 ff ff       	call   80104236 <fetchstr>
80104e16:	83 c4 10             	add    $0x10,%esp
80104e19:	85 c0                	test   %eax,%eax
80104e1b:	78 4c                	js     80104e69 <sys_exec+0xf1>
  for(i=0;; i++){
80104e1d:	83 c6 01             	add    $0x1,%esi
    if(i >= NELEM(argv))
80104e20:	83 fe 20             	cmp    $0x20,%esi
80104e23:	75 b5                	jne    80104dda <sys_exec+0x62>
      return -1;
80104e25:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e2a:	eb 35                	jmp    80104e61 <sys_exec+0xe9>
      argv[i] = 0;
80104e2c:	c7 84 b5 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%esi,4)
80104e33:	00 00 00 00 
      return -1;
  }
  return exec(path, argv);
80104e37:	83 ec 08             	sub    $0x8,%esp
80104e3a:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80104e40:	50                   	push   %eax
80104e41:	ff 75 e4             	pushl  -0x1c(%ebp)
80104e44:	e8 c9 ba ff ff       	call   80100912 <exec>
80104e49:	83 c4 10             	add    $0x10,%esp
80104e4c:	eb 13                	jmp    80104e61 <sys_exec+0xe9>
    return -1;
80104e4e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e53:	eb 0c                	jmp    80104e61 <sys_exec+0xe9>
80104e55:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e5a:	eb 05                	jmp    80104e61 <sys_exec+0xe9>
      return -1;
80104e5c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104e61:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104e64:	5b                   	pop    %ebx
80104e65:	5e                   	pop    %esi
80104e66:	5f                   	pop    %edi
80104e67:	5d                   	pop    %ebp
80104e68:	c3                   	ret    
      return -1;
80104e69:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e6e:	eb f1                	jmp    80104e61 <sys_exec+0xe9>

80104e70 <sys_pipe>:

int
sys_pipe(void)
{
80104e70:	55                   	push   %ebp
80104e71:	89 e5                	mov    %esp,%ebp
80104e73:	53                   	push   %ebx
80104e74:	83 ec 18             	sub    $0x18,%esp
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80104e77:	6a 08                	push   $0x8
80104e79:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104e7c:	50                   	push   %eax
80104e7d:	6a 00                	push   $0x0
80104e7f:	e8 28 f4 ff ff       	call   801042ac <argptr>
80104e84:	83 c4 10             	add    $0x10,%esp
80104e87:	85 c0                	test   %eax,%eax
80104e89:	78 46                	js     80104ed1 <sys_pipe+0x61>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80104e8b:	83 ec 08             	sub    $0x8,%esp
80104e8e:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104e91:	50                   	push   %eax
80104e92:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104e95:	50                   	push   %eax
80104e96:	e8 41 df ff ff       	call   80102ddc <pipealloc>
80104e9b:	83 c4 10             	add    $0x10,%esp
80104e9e:	85 c0                	test   %eax,%eax
80104ea0:	78 36                	js     80104ed8 <sys_pipe+0x68>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80104ea2:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104ea5:	e8 4b f5 ff ff       	call   801043f5 <fdalloc>
80104eaa:	89 c3                	mov    %eax,%ebx
80104eac:	85 c0                	test   %eax,%eax
80104eae:	78 3c                	js     80104eec <sys_pipe+0x7c>
80104eb0:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104eb3:	e8 3d f5 ff ff       	call   801043f5 <fdalloc>
80104eb8:	85 c0                	test   %eax,%eax
80104eba:	78 23                	js     80104edf <sys_pipe+0x6f>
      myproc()->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  fd[0] = fd0;
80104ebc:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104ebf:	89 1a                	mov    %ebx,(%edx)
  fd[1] = fd1;
80104ec1:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104ec4:	89 42 04             	mov    %eax,0x4(%edx)
  return 0;
80104ec7:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104ecc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ecf:	c9                   	leave  
80104ed0:	c3                   	ret    
    return -1;
80104ed1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ed6:	eb f4                	jmp    80104ecc <sys_pipe+0x5c>
    return -1;
80104ed8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104edd:	eb ed                	jmp    80104ecc <sys_pipe+0x5c>
      myproc()->ofile[fd0] = 0;
80104edf:	e8 61 e4 ff ff       	call   80103345 <myproc>
80104ee4:	c7 44 98 28 00 00 00 	movl   $0x0,0x28(%eax,%ebx,4)
80104eeb:	00 
    fileclose(rf);
80104eec:	83 ec 0c             	sub    $0xc,%esp
80104eef:	ff 75 f0             	pushl  -0x10(%ebp)
80104ef2:	e8 35 be ff ff       	call   80100d2c <fileclose>
    fileclose(wf);
80104ef7:	83 c4 04             	add    $0x4,%esp
80104efa:	ff 75 ec             	pushl  -0x14(%ebp)
80104efd:	e8 2a be ff ff       	call   80100d2c <fileclose>
    return -1;
80104f02:	83 c4 10             	add    $0x10,%esp
80104f05:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104f0a:	eb c0                	jmp    80104ecc <sys_pipe+0x5c>

80104f0c <sys_fork>:
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
80104f0c:	55                   	push   %ebp
80104f0d:	89 e5                	mov    %esp,%ebp
80104f0f:	83 ec 08             	sub    $0x8,%esp
  return fork();
80104f12:	e8 a6 e5 ff ff       	call   801034bd <fork>
}
80104f17:	c9                   	leave  
80104f18:	c3                   	ret    

80104f19 <sys_exit>:


int
sys_exit(void)
{
80104f19:	55                   	push   %ebp
80104f1a:	89 e5                	mov    %esp,%ebp
80104f1c:	83 ec 08             	sub    $0x8,%esp
  exit();
80104f1f:	e8 c6 e8 ff ff       	call   801037ea <exit>
  return 0;  // not reached
}
80104f24:	b8 00 00 00 00       	mov    $0x0,%eax
80104f29:	c9                   	leave  
80104f2a:	c3                   	ret    

80104f2b <sys_wait>:

int
sys_wait(void)
{
80104f2b:	55                   	push   %ebp
80104f2c:	89 e5                	mov    %esp,%ebp
80104f2e:	83 ec 08             	sub    $0x8,%esp
  return wait();
80104f31:	e8 73 eb ff ff       	call   80103aa9 <wait>
}
80104f36:	c9                   	leave  
80104f37:	c3                   	ret    

80104f38 <sys_kill>:

int
sys_kill(void)
{
80104f38:	55                   	push   %ebp
80104f39:	89 e5                	mov    %esp,%ebp
80104f3b:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
80104f3e:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104f41:	50                   	push   %eax
80104f42:	6a 00                	push   $0x0
80104f44:	e8 3d f3 ff ff       	call   80104286 <argint>
80104f49:	83 c4 10             	add    $0x10,%esp
80104f4c:	85 c0                	test   %eax,%eax
80104f4e:	78 10                	js     80104f60 <sys_kill+0x28>
    return -1;
  return kill(pid);
80104f50:	83 ec 0c             	sub    $0xc,%esp
80104f53:	ff 75 f4             	pushl  -0xc(%ebp)
80104f56:	e8 55 ec ff ff       	call   80103bb0 <kill>
80104f5b:	83 c4 10             	add    $0x10,%esp
}
80104f5e:	c9                   	leave  
80104f5f:	c3                   	ret    
    return -1;
80104f60:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104f65:	eb f7                	jmp    80104f5e <sys_kill+0x26>

80104f67 <sys_getpid>:

int
sys_getpid(void)
{
80104f67:	55                   	push   %ebp
80104f68:	89 e5                	mov    %esp,%ebp
80104f6a:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80104f6d:	e8 d3 e3 ff ff       	call   80103345 <myproc>
80104f72:	8b 40 10             	mov    0x10(%eax),%eax
}
80104f75:	c9                   	leave  
80104f76:	c3                   	ret    

80104f77 <sys_sbrk>:

int
sys_sbrk(void)
{
80104f77:	55                   	push   %ebp
80104f78:	89 e5                	mov    %esp,%ebp
80104f7a:	53                   	push   %ebx
80104f7b:	83 ec 1c             	sub    $0x1c,%esp
  int addr;
  int n;

  if(argint(0, &n) < 0)
80104f7e:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104f81:	50                   	push   %eax
80104f82:	6a 00                	push   $0x0
80104f84:	e8 fd f2 ff ff       	call   80104286 <argint>
80104f89:	83 c4 10             	add    $0x10,%esp
80104f8c:	85 c0                	test   %eax,%eax
80104f8e:	78 26                	js     80104fb6 <sys_sbrk+0x3f>
    return -1;
  addr = myproc()->sz;
80104f90:	e8 b0 e3 ff ff       	call   80103345 <myproc>
80104f95:	8b 18                	mov    (%eax),%ebx
  if(growproc(n) < 0)
80104f97:	83 ec 0c             	sub    $0xc,%esp
80104f9a:	ff 75 f4             	pushl  -0xc(%ebp)
80104f9d:	e8 ae e4 ff ff       	call   80103450 <growproc>
80104fa2:	83 c4 10             	add    $0x10,%esp
80104fa5:	85 c0                	test   %eax,%eax
    return -1;
80104fa7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104fac:	0f 48 d8             	cmovs  %eax,%ebx
  return addr;
}
80104faf:	89 d8                	mov    %ebx,%eax
80104fb1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104fb4:	c9                   	leave  
80104fb5:	c3                   	ret    
    return -1;
80104fb6:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104fbb:	eb f2                	jmp    80104faf <sys_sbrk+0x38>

80104fbd <sys_sleep>:

int
sys_sleep(void)
{
80104fbd:	55                   	push   %ebp
80104fbe:	89 e5                	mov    %esp,%ebp
80104fc0:	53                   	push   %ebx
80104fc1:	83 ec 1c             	sub    $0x1c,%esp
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
80104fc4:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104fc7:	50                   	push   %eax
80104fc8:	6a 00                	push   $0x0
80104fca:	e8 b7 f2 ff ff       	call   80104286 <argint>
80104fcf:	83 c4 10             	add    $0x10,%esp
80104fd2:	85 c0                	test   %eax,%eax
80104fd4:	78 79                	js     8010504f <sys_sleep+0x92>
    return -1;
  acquire(&tickslock);
80104fd6:	83 ec 0c             	sub    $0xc,%esp
80104fd9:	68 80 4f 11 80       	push   $0x80114f80
80104fde:	e8 6f ef ff ff       	call   80103f52 <acquire>
  ticks0 = ticks;
80104fe3:	8b 1d c0 57 11 80    	mov    0x801157c0,%ebx
  while(ticks - ticks0 < n){
80104fe9:	83 c4 10             	add    $0x10,%esp
80104fec:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80104ff0:	74 2c                	je     8010501e <sys_sleep+0x61>
    if(myproc()->killed){
80104ff2:	e8 4e e3 ff ff       	call   80103345 <myproc>
80104ff7:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80104ffb:	75 3b                	jne    80105038 <sys_sleep+0x7b>
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80104ffd:	83 ec 08             	sub    $0x8,%esp
80105000:	68 80 4f 11 80       	push   $0x80114f80
80105005:	68 c0 57 11 80       	push   $0x801157c0
8010500a:	e8 f8 e9 ff ff       	call   80103a07 <sleep>
  while(ticks - ticks0 < n){
8010500f:	a1 c0 57 11 80       	mov    0x801157c0,%eax
80105014:	29 d8                	sub    %ebx,%eax
80105016:	83 c4 10             	add    $0x10,%esp
80105019:	3b 45 f4             	cmp    -0xc(%ebp),%eax
8010501c:	72 d4                	jb     80104ff2 <sys_sleep+0x35>
  }
  release(&tickslock);
8010501e:	83 ec 0c             	sub    $0xc,%esp
80105021:	68 80 4f 11 80       	push   $0x80114f80
80105026:	e8 8e ef ff ff       	call   80103fb9 <release>
  return 0;
8010502b:	83 c4 10             	add    $0x10,%esp
8010502e:	b8 00 00 00 00       	mov    $0x0,%eax
}
80105033:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105036:	c9                   	leave  
80105037:	c3                   	ret    
      release(&tickslock);
80105038:	83 ec 0c             	sub    $0xc,%esp
8010503b:	68 80 4f 11 80       	push   $0x80114f80
80105040:	e8 74 ef ff ff       	call   80103fb9 <release>
      return -1;
80105045:	83 c4 10             	add    $0x10,%esp
80105048:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010504d:	eb e4                	jmp    80105033 <sys_sleep+0x76>
    return -1;
8010504f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105054:	eb dd                	jmp    80105033 <sys_sleep+0x76>

80105056 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
80105056:	55                   	push   %ebp
80105057:	89 e5                	mov    %esp,%ebp
80105059:	53                   	push   %ebx
8010505a:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
8010505d:	68 80 4f 11 80       	push   $0x80114f80
80105062:	e8 eb ee ff ff       	call   80103f52 <acquire>
  xticks = ticks;
80105067:	8b 1d c0 57 11 80    	mov    0x801157c0,%ebx
  release(&tickslock);
8010506d:	c7 04 24 80 4f 11 80 	movl   $0x80114f80,(%esp)
80105074:	e8 40 ef ff ff       	call   80103fb9 <release>
  return xticks;
}
80105079:	89 d8                	mov    %ebx,%eax
8010507b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010507e:	c9                   	leave  
8010507f:	c3                   	ret    

80105080 <sys_fork_rt>:

int
sys_fork_rt(void)
{
80105080:	55                   	push   %ebp
80105081:	89 e5                	mov    %esp,%ebp
80105083:	83 ec 20             	sub    $0x20,%esp
	int pri;
	if(argint(0, &pri)<0)
80105086:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105089:	50                   	push   %eax
8010508a:	6a 00                	push   $0x0
8010508c:	e8 f5 f1 ff ff       	call   80104286 <argint>
80105091:	83 c4 10             	add    $0x10,%esp
80105094:	85 c0                	test   %eax,%eax
80105096:	78 10                	js     801050a8 <sys_fork_rt+0x28>
		return -1;
	return fork_rt(pri);
80105098:	83 ec 0c             	sub    $0xc,%esp
8010509b:	ff 75 f4             	pushl  -0xc(%ebp)
8010509e:	e8 40 e8 ff ff       	call   801038e3 <fork_rt>
801050a3:	83 c4 10             	add    $0x10,%esp
}
801050a6:	c9                   	leave  
801050a7:	c3                   	ret    
		return -1;
801050a8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801050ad:	eb f7                	jmp    801050a6 <sys_fork_rt+0x26>

801050af <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
801050af:	1e                   	push   %ds
  pushl %es
801050b0:	06                   	push   %es
  pushl %fs
801050b1:	0f a0                	push   %fs
  pushl %gs
801050b3:	0f a8                	push   %gs
  pushal
801050b5:	60                   	pusha  
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
801050b6:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
801050ba:	8e d8                	mov    %eax,%ds
  movw %ax, %es
801050bc:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
801050be:	54                   	push   %esp
  call trap
801050bf:	e8 bd 00 00 00       	call   80105181 <trap>
  addl $4, %esp
801050c4:	83 c4 04             	add    $0x4,%esp

801050c7 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
801050c7:	61                   	popa   
  popl %gs
801050c8:	0f a9                	pop    %gs
  popl %fs
801050ca:	0f a1                	pop    %fs
  popl %es
801050cc:	07                   	pop    %es
  popl %ds
801050cd:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
801050ce:	83 c4 08             	add    $0x8,%esp
  iret
801050d1:	cf                   	iret   

801050d2 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
801050d2:	55                   	push   %ebp
801050d3:	89 e5                	mov    %esp,%ebp
801050d5:	83 ec 08             	sub    $0x8,%esp
  int i;

  for(i = 0; i < 256; i++)
801050d8:	b8 00 00 00 00       	mov    $0x0,%eax
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
801050dd:	8b 14 85 08 a0 10 80 	mov    -0x7fef5ff8(,%eax,4),%edx
801050e4:	66 89 14 c5 c0 4f 11 	mov    %dx,-0x7feeb040(,%eax,8)
801050eb:	80 
801050ec:	66 c7 04 c5 c2 4f 11 	movw   $0x8,-0x7feeb03e(,%eax,8)
801050f3:	80 08 00 
801050f6:	c6 04 c5 c4 4f 11 80 	movb   $0x0,-0x7feeb03c(,%eax,8)
801050fd:	00 
801050fe:	c6 04 c5 c5 4f 11 80 	movb   $0x8e,-0x7feeb03b(,%eax,8)
80105105:	8e 
80105106:	c1 ea 10             	shr    $0x10,%edx
80105109:	66 89 14 c5 c6 4f 11 	mov    %dx,-0x7feeb03a(,%eax,8)
80105110:	80 
  for(i = 0; i < 256; i++)
80105111:	83 c0 01             	add    $0x1,%eax
80105114:	3d 00 01 00 00       	cmp    $0x100,%eax
80105119:	75 c2                	jne    801050dd <tvinit+0xb>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
8010511b:	a1 08 a1 10 80       	mov    0x8010a108,%eax
80105120:	66 a3 c0 51 11 80    	mov    %ax,0x801151c0
80105126:	66 c7 05 c2 51 11 80 	movw   $0x8,0x801151c2
8010512d:	08 00 
8010512f:	c6 05 c4 51 11 80 00 	movb   $0x0,0x801151c4
80105136:	c6 05 c5 51 11 80 ef 	movb   $0xef,0x801151c5
8010513d:	c1 e8 10             	shr    $0x10,%eax
80105140:	66 a3 c6 51 11 80    	mov    %ax,0x801151c6

  initlock(&tickslock, "time");
80105146:	83 ec 08             	sub    $0x8,%esp
80105149:	68 9d 6f 10 80       	push   $0x80106f9d
8010514e:	68 80 4f 11 80       	push   $0x80114f80
80105153:	e8 b2 ec ff ff       	call   80103e0a <initlock>
}
80105158:	83 c4 10             	add    $0x10,%esp
8010515b:	c9                   	leave  
8010515c:	c3                   	ret    

8010515d <idtinit>:

void
idtinit(void)
{
8010515d:	55                   	push   %ebp
8010515e:	89 e5                	mov    %esp,%ebp
80105160:	83 ec 10             	sub    $0x10,%esp
  pd[0] = size-1;
80105163:	66 c7 45 fa ff 07    	movw   $0x7ff,-0x6(%ebp)
  pd[1] = (uint)p;
80105169:	b8 c0 4f 11 80       	mov    $0x80114fc0,%eax
8010516e:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80105172:	c1 e8 10             	shr    $0x10,%eax
80105175:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80105179:	8d 45 fa             	lea    -0x6(%ebp),%eax
8010517c:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
8010517f:	c9                   	leave  
80105180:	c3                   	ret    

80105181 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80105181:	55                   	push   %ebp
80105182:	89 e5                	mov    %esp,%ebp
80105184:	57                   	push   %edi
80105185:	56                   	push   %esi
80105186:	53                   	push   %ebx
80105187:	83 ec 1c             	sub    $0x1c,%esp
8010518a:	8b 7d 08             	mov    0x8(%ebp),%edi
  if(tf->trapno == T_SYSCALL){
8010518d:	8b 47 30             	mov    0x30(%edi),%eax
80105190:	83 f8 40             	cmp    $0x40,%eax
80105193:	74 13                	je     801051a8 <trap+0x27>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
80105195:	83 e8 20             	sub    $0x20,%eax
80105198:	83 f8 1f             	cmp    $0x1f,%eax
8010519b:	0f 87 ad 01 00 00    	ja     8010534e <trap+0x1cd>
801051a1:	ff 24 85 44 70 10 80 	jmp    *-0x7fef8fbc(,%eax,4)
    if(myproc()->killed)
801051a8:	e8 98 e1 ff ff       	call   80103345 <myproc>
801051ad:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
801051b1:	75 26                	jne    801051d9 <trap+0x58>
    myproc()->tf = tf;
801051b3:	e8 8d e1 ff ff       	call   80103345 <myproc>
801051b8:	89 78 18             	mov    %edi,0x18(%eax)
    syscall();
801051bb:	e8 80 f1 ff ff       	call   80104340 <syscall>
    if(myproc()->killed)
801051c0:	e8 80 e1 ff ff       	call   80103345 <myproc>
801051c5:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
801051c9:	0f 84 a0 00 00 00    	je     8010526f <trap+0xee>
      exit();
801051cf:	e8 16 e6 ff ff       	call   801037ea <exit>
801051d4:	e9 96 00 00 00       	jmp    8010526f <trap+0xee>
      exit();
801051d9:	e8 0c e6 ff ff       	call   801037ea <exit>
801051de:	eb d3                	jmp    801051b3 <trap+0x32>
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
801051e0:	e8 45 e1 ff ff       	call   8010332a <cpuid>
801051e5:	85 c0                	test   %eax,%eax
801051e7:	0f 84 8a 00 00 00    	je     80105277 <trap+0xf6>
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
   
    if(myproc() && myproc()->rt_rr == 1 && myproc()->state == RUNNING)
801051ed:	e8 53 e1 ff ff       	call   80103345 <myproc>
801051f2:	85 c0                	test   %eax,%eax
801051f4:	74 12                	je     80105208 <trap+0x87>
801051f6:	e8 4a e1 ff ff       	call   80103345 <myproc>
801051fb:	83 b8 80 00 00 00 01 	cmpl   $0x1,0x80(%eax)
80105202:	0f 84 a3 00 00 00    	je     801052ab <trap+0x12a>
	    	myproc()->rt_rr = 0;
		myproc()->aging_time = 0;
	    }
    }

    lapiceoi();
80105208:	e8 4d d2 ff ff       	call   8010245a <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010520d:	e8 33 e1 ff ff       	call   80103345 <myproc>
80105212:	85 c0                	test   %eax,%eax
80105214:	74 1c                	je     80105232 <trap+0xb1>
80105216:	e8 2a e1 ff ff       	call   80103345 <myproc>
8010521b:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010521f:	74 11                	je     80105232 <trap+0xb1>
80105221:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
80105225:	83 e0 03             	and    $0x3,%eax
80105228:	66 83 f8 03          	cmp    $0x3,%ax
8010522c:	0f 84 b0 01 00 00    	je     801053e2 <trap+0x261>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80105232:	e8 0e e1 ff ff       	call   80103345 <myproc>
80105237:	85 c0                	test   %eax,%eax
80105239:	74 0f                	je     8010524a <trap+0xc9>
8010523b:	e8 05 e1 ff ff       	call   80103345 <myproc>
80105240:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
80105244:	0f 84 a2 01 00 00    	je     801053ec <trap+0x26b>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
8010524a:	e8 f6 e0 ff ff       	call   80103345 <myproc>
8010524f:	85 c0                	test   %eax,%eax
80105251:	74 1c                	je     8010526f <trap+0xee>
80105253:	e8 ed e0 ff ff       	call   80103345 <myproc>
80105258:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010525c:	74 11                	je     8010526f <trap+0xee>
8010525e:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
80105262:	83 e0 03             	and    $0x3,%eax
80105265:	66 83 f8 03          	cmp    $0x3,%ax
80105269:	0f 84 91 01 00 00    	je     80105400 <trap+0x27f>
    exit();
}
8010526f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105272:	5b                   	pop    %ebx
80105273:	5e                   	pop    %esi
80105274:	5f                   	pop    %edi
80105275:	5d                   	pop    %ebp
80105276:	c3                   	ret    
      acquire(&tickslock);
80105277:	83 ec 0c             	sub    $0xc,%esp
8010527a:	68 80 4f 11 80       	push   $0x80114f80
8010527f:	e8 ce ec ff ff       	call   80103f52 <acquire>
      ticks++;
80105284:	83 05 c0 57 11 80 01 	addl   $0x1,0x801157c0
      wakeup(&ticks);
8010528b:	c7 04 24 c0 57 11 80 	movl   $0x801157c0,(%esp)
80105292:	e8 f0 e8 ff ff       	call   80103b87 <wakeup>
      release(&tickslock);
80105297:	c7 04 24 80 4f 11 80 	movl   $0x80114f80,(%esp)
8010529e:	e8 16 ed ff ff       	call   80103fb9 <release>
801052a3:	83 c4 10             	add    $0x10,%esp
801052a6:	e9 42 ff ff ff       	jmp    801051ed <trap+0x6c>
    if(myproc() && myproc()->rt_rr == 1 && myproc()->state == RUNNING)
801052ab:	e8 95 e0 ff ff       	call   80103345 <myproc>
801052b0:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
801052b4:	0f 85 4e ff ff ff    	jne    80105208 <trap+0x87>
	    myproc()->aging_time++;
801052ba:	e8 86 e0 ff ff       	call   80103345 <myproc>
801052bf:	83 80 84 00 00 00 01 	addl   $0x1,0x84(%eax)
	    if(myproc()->aging_time > 100)
801052c6:	e8 7a e0 ff ff       	call   80103345 <myproc>
801052cb:	83 b8 84 00 00 00 64 	cmpl   $0x64,0x84(%eax)
801052d2:	0f 8e 30 ff ff ff    	jle    80105208 <trap+0x87>
	    	myproc()->rt_rr = 0;
801052d8:	e8 68 e0 ff ff       	call   80103345 <myproc>
801052dd:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
801052e4:	00 00 00 
		myproc()->aging_time = 0;
801052e7:	e8 59 e0 ff ff       	call   80103345 <myproc>
801052ec:	c7 80 84 00 00 00 00 	movl   $0x0,0x84(%eax)
801052f3:	00 00 00 
801052f6:	e9 0d ff ff ff       	jmp    80105208 <trap+0x87>
    ideintr();
801052fb:	e8 f0 ca ff ff       	call   80101df0 <ideintr>
    lapiceoi();
80105300:	e8 55 d1 ff ff       	call   8010245a <lapiceoi>
    break;
80105305:	e9 03 ff ff ff       	jmp    8010520d <trap+0x8c>
    kbdintr();
8010530a:	e8 7f cf ff ff       	call   8010228e <kbdintr>
    lapiceoi();
8010530f:	e8 46 d1 ff ff       	call   8010245a <lapiceoi>
    break;
80105314:	e9 f4 fe ff ff       	jmp    8010520d <trap+0x8c>
    uartintr();
80105319:	e8 1a 02 00 00       	call   80105538 <uartintr>
    lapiceoi();
8010531e:	e8 37 d1 ff ff       	call   8010245a <lapiceoi>
    break;
80105323:	e9 e5 fe ff ff       	jmp    8010520d <trap+0x8c>
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80105328:	8b 77 38             	mov    0x38(%edi),%esi
8010532b:	0f b7 5f 3c          	movzwl 0x3c(%edi),%ebx
8010532f:	e8 f6 df ff ff       	call   8010332a <cpuid>
80105334:	56                   	push   %esi
80105335:	53                   	push   %ebx
80105336:	50                   	push   %eax
80105337:	68 a8 6f 10 80       	push   $0x80106fa8
8010533c:	e8 a0 b2 ff ff       	call   801005e1 <cprintf>
    lapiceoi();
80105341:	e8 14 d1 ff ff       	call   8010245a <lapiceoi>
    break;
80105346:	83 c4 10             	add    $0x10,%esp
80105349:	e9 bf fe ff ff       	jmp    8010520d <trap+0x8c>
    if(myproc() == 0 || (tf->cs&3) == 0){
8010534e:	e8 f2 df ff ff       	call   80103345 <myproc>
80105353:	85 c0                	test   %eax,%eax
80105355:	74 60                	je     801053b7 <trap+0x236>
80105357:	f6 47 3c 03          	testb  $0x3,0x3c(%edi)
8010535b:	74 5a                	je     801053b7 <trap+0x236>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
8010535d:	0f 20 d0             	mov    %cr2,%eax
80105360:	89 45 d8             	mov    %eax,-0x28(%ebp)
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105363:	8b 77 38             	mov    0x38(%edi),%esi
80105366:	e8 bf df ff ff       	call   8010332a <cpuid>
8010536b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010536e:	8b 5f 34             	mov    0x34(%edi),%ebx
80105371:	8b 4f 30             	mov    0x30(%edi),%ecx
80105374:	89 4d e0             	mov    %ecx,-0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80105377:	e8 c9 df ff ff       	call   80103345 <myproc>
8010537c:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010537f:	e8 c1 df ff ff       	call   80103345 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105384:	ff 75 d8             	pushl  -0x28(%ebp)
80105387:	56                   	push   %esi
80105388:	ff 75 e4             	pushl  -0x1c(%ebp)
8010538b:	53                   	push   %ebx
8010538c:	ff 75 e0             	pushl  -0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
8010538f:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105392:	83 c2 6c             	add    $0x6c,%edx
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105395:	52                   	push   %edx
80105396:	ff 70 10             	pushl  0x10(%eax)
80105399:	68 00 70 10 80       	push   $0x80107000
8010539e:	e8 3e b2 ff ff       	call   801005e1 <cprintf>
    myproc()->killed = 1;
801053a3:	83 c4 20             	add    $0x20,%esp
801053a6:	e8 9a df ff ff       	call   80103345 <myproc>
801053ab:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
801053b2:	e9 56 fe ff ff       	jmp    8010520d <trap+0x8c>
801053b7:	0f 20 d6             	mov    %cr2,%esi
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
801053ba:	8b 5f 38             	mov    0x38(%edi),%ebx
801053bd:	e8 68 df ff ff       	call   8010332a <cpuid>
801053c2:	83 ec 0c             	sub    $0xc,%esp
801053c5:	56                   	push   %esi
801053c6:	53                   	push   %ebx
801053c7:	50                   	push   %eax
801053c8:	ff 77 30             	pushl  0x30(%edi)
801053cb:	68 cc 6f 10 80       	push   $0x80106fcc
801053d0:	e8 0c b2 ff ff       	call   801005e1 <cprintf>
      panic("trap");
801053d5:	83 c4 14             	add    $0x14,%esp
801053d8:	68 a2 6f 10 80       	push   $0x80106fa2
801053dd:	e8 62 af ff ff       	call   80100344 <panic>
    exit();
801053e2:	e8 03 e4 ff ff       	call   801037ea <exit>
801053e7:	e9 46 fe ff ff       	jmp    80105232 <trap+0xb1>
  if(myproc() && myproc()->state == RUNNING &&
801053ec:	83 7f 30 20          	cmpl   $0x20,0x30(%edi)
801053f0:	0f 85 54 fe ff ff    	jne    8010524a <trap+0xc9>
    yield();
801053f6:	e8 b6 e4 ff ff       	call   801038b1 <yield>
801053fb:	e9 4a fe ff ff       	jmp    8010524a <trap+0xc9>
    exit();
80105400:	e8 e5 e3 ff ff       	call   801037ea <exit>
80105405:	e9 65 fe ff ff       	jmp    8010526f <trap+0xee>

8010540a <uartgetc>:
  outb(COM1+0, c);
}

static int
uartgetc(void)
{
8010540a:	55                   	push   %ebp
8010540b:	89 e5                	mov    %esp,%ebp
  if(!uart)
8010540d:	83 3d c0 a5 10 80 00 	cmpl   $0x0,0x8010a5c0
80105414:	74 15                	je     8010542b <uartgetc+0x21>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80105416:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010541b:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
8010541c:	a8 01                	test   $0x1,%al
8010541e:	74 12                	je     80105432 <uartgetc+0x28>
80105420:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105425:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
80105426:	0f b6 c0             	movzbl %al,%eax
}
80105429:	5d                   	pop    %ebp
8010542a:	c3                   	ret    
    return -1;
8010542b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105430:	eb f7                	jmp    80105429 <uartgetc+0x1f>
    return -1;
80105432:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105437:	eb f0                	jmp    80105429 <uartgetc+0x1f>

80105439 <uartputc>:
  if(!uart)
80105439:	83 3d c0 a5 10 80 00 	cmpl   $0x0,0x8010a5c0
80105440:	74 4f                	je     80105491 <uartputc+0x58>
{
80105442:	55                   	push   %ebp
80105443:	89 e5                	mov    %esp,%ebp
80105445:	56                   	push   %esi
80105446:	53                   	push   %ebx
80105447:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010544c:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
8010544d:	a8 20                	test   $0x20,%al
8010544f:	75 30                	jne    80105481 <uartputc+0x48>
    microdelay(10);
80105451:	83 ec 0c             	sub    $0xc,%esp
80105454:	6a 0a                	push   $0xa
80105456:	e8 1e d0 ff ff       	call   80102479 <microdelay>
8010545b:	83 c4 10             	add    $0x10,%esp
8010545e:	bb 7f 00 00 00       	mov    $0x7f,%ebx
80105463:	be fd 03 00 00       	mov    $0x3fd,%esi
80105468:	89 f2                	mov    %esi,%edx
8010546a:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
8010546b:	a8 20                	test   $0x20,%al
8010546d:	75 12                	jne    80105481 <uartputc+0x48>
    microdelay(10);
8010546f:	83 ec 0c             	sub    $0xc,%esp
80105472:	6a 0a                	push   $0xa
80105474:	e8 00 d0 ff ff       	call   80102479 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80105479:	83 c4 10             	add    $0x10,%esp
8010547c:	83 eb 01             	sub    $0x1,%ebx
8010547f:	75 e7                	jne    80105468 <uartputc+0x2f>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80105481:	8b 45 08             	mov    0x8(%ebp),%eax
80105484:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105489:	ee                   	out    %al,(%dx)
}
8010548a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010548d:	5b                   	pop    %ebx
8010548e:	5e                   	pop    %esi
8010548f:	5d                   	pop    %ebp
80105490:	c3                   	ret    
80105491:	f3 c3                	repz ret 

80105493 <uartinit>:
{
80105493:	55                   	push   %ebp
80105494:	89 e5                	mov    %esp,%ebp
80105496:	56                   	push   %esi
80105497:	53                   	push   %ebx
80105498:	b9 00 00 00 00       	mov    $0x0,%ecx
8010549d:	ba fa 03 00 00       	mov    $0x3fa,%edx
801054a2:	89 c8                	mov    %ecx,%eax
801054a4:	ee                   	out    %al,(%dx)
801054a5:	be fb 03 00 00       	mov    $0x3fb,%esi
801054aa:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
801054af:	89 f2                	mov    %esi,%edx
801054b1:	ee                   	out    %al,(%dx)
801054b2:	b8 0c 00 00 00       	mov    $0xc,%eax
801054b7:	ba f8 03 00 00       	mov    $0x3f8,%edx
801054bc:	ee                   	out    %al,(%dx)
801054bd:	bb f9 03 00 00       	mov    $0x3f9,%ebx
801054c2:	89 c8                	mov    %ecx,%eax
801054c4:	89 da                	mov    %ebx,%edx
801054c6:	ee                   	out    %al,(%dx)
801054c7:	b8 03 00 00 00       	mov    $0x3,%eax
801054cc:	89 f2                	mov    %esi,%edx
801054ce:	ee                   	out    %al,(%dx)
801054cf:	ba fc 03 00 00       	mov    $0x3fc,%edx
801054d4:	89 c8                	mov    %ecx,%eax
801054d6:	ee                   	out    %al,(%dx)
801054d7:	b8 01 00 00 00       	mov    $0x1,%eax
801054dc:	89 da                	mov    %ebx,%edx
801054de:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801054df:	ba fd 03 00 00       	mov    $0x3fd,%edx
801054e4:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
801054e5:	3c ff                	cmp    $0xff,%al
801054e7:	74 48                	je     80105531 <uartinit+0x9e>
  uart = 1;
801054e9:	c7 05 c0 a5 10 80 01 	movl   $0x1,0x8010a5c0
801054f0:	00 00 00 
801054f3:	ba fa 03 00 00       	mov    $0x3fa,%edx
801054f8:	ec                   	in     (%dx),%al
801054f9:	ba f8 03 00 00       	mov    $0x3f8,%edx
801054fe:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
801054ff:	83 ec 08             	sub    $0x8,%esp
80105502:	6a 00                	push   $0x0
80105504:	6a 04                	push   $0x4
80105506:	e8 fb ca ff ff       	call   80102006 <ioapicenable>
8010550b:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
8010550e:	bb c4 70 10 80       	mov    $0x801070c4,%ebx
80105513:	b8 78 00 00 00       	mov    $0x78,%eax
    uartputc(*p);
80105518:	83 ec 0c             	sub    $0xc,%esp
8010551b:	0f be c0             	movsbl %al,%eax
8010551e:	50                   	push   %eax
8010551f:	e8 15 ff ff ff       	call   80105439 <uartputc>
  for(p="xv6...\n"; *p; p++)
80105524:	83 c3 01             	add    $0x1,%ebx
80105527:	0f b6 03             	movzbl (%ebx),%eax
8010552a:	83 c4 10             	add    $0x10,%esp
8010552d:	84 c0                	test   %al,%al
8010552f:	75 e7                	jne    80105518 <uartinit+0x85>
}
80105531:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105534:	5b                   	pop    %ebx
80105535:	5e                   	pop    %esi
80105536:	5d                   	pop    %ebp
80105537:	c3                   	ret    

80105538 <uartintr>:

void
uartintr(void)
{
80105538:	55                   	push   %ebp
80105539:	89 e5                	mov    %esp,%ebp
8010553b:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
8010553e:	68 0a 54 10 80       	push   $0x8010540a
80105543:	e8 f3 b1 ff ff       	call   8010073b <consoleintr>
}
80105548:	83 c4 10             	add    $0x10,%esp
8010554b:	c9                   	leave  
8010554c:	c3                   	ret    

8010554d <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
8010554d:	6a 00                	push   $0x0
  pushl $0
8010554f:	6a 00                	push   $0x0
  jmp alltraps
80105551:	e9 59 fb ff ff       	jmp    801050af <alltraps>

80105556 <vector1>:
.globl vector1
vector1:
  pushl $0
80105556:	6a 00                	push   $0x0
  pushl $1
80105558:	6a 01                	push   $0x1
  jmp alltraps
8010555a:	e9 50 fb ff ff       	jmp    801050af <alltraps>

8010555f <vector2>:
.globl vector2
vector2:
  pushl $0
8010555f:	6a 00                	push   $0x0
  pushl $2
80105561:	6a 02                	push   $0x2
  jmp alltraps
80105563:	e9 47 fb ff ff       	jmp    801050af <alltraps>

80105568 <vector3>:
.globl vector3
vector3:
  pushl $0
80105568:	6a 00                	push   $0x0
  pushl $3
8010556a:	6a 03                	push   $0x3
  jmp alltraps
8010556c:	e9 3e fb ff ff       	jmp    801050af <alltraps>

80105571 <vector4>:
.globl vector4
vector4:
  pushl $0
80105571:	6a 00                	push   $0x0
  pushl $4
80105573:	6a 04                	push   $0x4
  jmp alltraps
80105575:	e9 35 fb ff ff       	jmp    801050af <alltraps>

8010557a <vector5>:
.globl vector5
vector5:
  pushl $0
8010557a:	6a 00                	push   $0x0
  pushl $5
8010557c:	6a 05                	push   $0x5
  jmp alltraps
8010557e:	e9 2c fb ff ff       	jmp    801050af <alltraps>

80105583 <vector6>:
.globl vector6
vector6:
  pushl $0
80105583:	6a 00                	push   $0x0
  pushl $6
80105585:	6a 06                	push   $0x6
  jmp alltraps
80105587:	e9 23 fb ff ff       	jmp    801050af <alltraps>

8010558c <vector7>:
.globl vector7
vector7:
  pushl $0
8010558c:	6a 00                	push   $0x0
  pushl $7
8010558e:	6a 07                	push   $0x7
  jmp alltraps
80105590:	e9 1a fb ff ff       	jmp    801050af <alltraps>

80105595 <vector8>:
.globl vector8
vector8:
  pushl $8
80105595:	6a 08                	push   $0x8
  jmp alltraps
80105597:	e9 13 fb ff ff       	jmp    801050af <alltraps>

8010559c <vector9>:
.globl vector9
vector9:
  pushl $0
8010559c:	6a 00                	push   $0x0
  pushl $9
8010559e:	6a 09                	push   $0x9
  jmp alltraps
801055a0:	e9 0a fb ff ff       	jmp    801050af <alltraps>

801055a5 <vector10>:
.globl vector10
vector10:
  pushl $10
801055a5:	6a 0a                	push   $0xa
  jmp alltraps
801055a7:	e9 03 fb ff ff       	jmp    801050af <alltraps>

801055ac <vector11>:
.globl vector11
vector11:
  pushl $11
801055ac:	6a 0b                	push   $0xb
  jmp alltraps
801055ae:	e9 fc fa ff ff       	jmp    801050af <alltraps>

801055b3 <vector12>:
.globl vector12
vector12:
  pushl $12
801055b3:	6a 0c                	push   $0xc
  jmp alltraps
801055b5:	e9 f5 fa ff ff       	jmp    801050af <alltraps>

801055ba <vector13>:
.globl vector13
vector13:
  pushl $13
801055ba:	6a 0d                	push   $0xd
  jmp alltraps
801055bc:	e9 ee fa ff ff       	jmp    801050af <alltraps>

801055c1 <vector14>:
.globl vector14
vector14:
  pushl $14
801055c1:	6a 0e                	push   $0xe
  jmp alltraps
801055c3:	e9 e7 fa ff ff       	jmp    801050af <alltraps>

801055c8 <vector15>:
.globl vector15
vector15:
  pushl $0
801055c8:	6a 00                	push   $0x0
  pushl $15
801055ca:	6a 0f                	push   $0xf
  jmp alltraps
801055cc:	e9 de fa ff ff       	jmp    801050af <alltraps>

801055d1 <vector16>:
.globl vector16
vector16:
  pushl $0
801055d1:	6a 00                	push   $0x0
  pushl $16
801055d3:	6a 10                	push   $0x10
  jmp alltraps
801055d5:	e9 d5 fa ff ff       	jmp    801050af <alltraps>

801055da <vector17>:
.globl vector17
vector17:
  pushl $17
801055da:	6a 11                	push   $0x11
  jmp alltraps
801055dc:	e9 ce fa ff ff       	jmp    801050af <alltraps>

801055e1 <vector18>:
.globl vector18
vector18:
  pushl $0
801055e1:	6a 00                	push   $0x0
  pushl $18
801055e3:	6a 12                	push   $0x12
  jmp alltraps
801055e5:	e9 c5 fa ff ff       	jmp    801050af <alltraps>

801055ea <vector19>:
.globl vector19
vector19:
  pushl $0
801055ea:	6a 00                	push   $0x0
  pushl $19
801055ec:	6a 13                	push   $0x13
  jmp alltraps
801055ee:	e9 bc fa ff ff       	jmp    801050af <alltraps>

801055f3 <vector20>:
.globl vector20
vector20:
  pushl $0
801055f3:	6a 00                	push   $0x0
  pushl $20
801055f5:	6a 14                	push   $0x14
  jmp alltraps
801055f7:	e9 b3 fa ff ff       	jmp    801050af <alltraps>

801055fc <vector21>:
.globl vector21
vector21:
  pushl $0
801055fc:	6a 00                	push   $0x0
  pushl $21
801055fe:	6a 15                	push   $0x15
  jmp alltraps
80105600:	e9 aa fa ff ff       	jmp    801050af <alltraps>

80105605 <vector22>:
.globl vector22
vector22:
  pushl $0
80105605:	6a 00                	push   $0x0
  pushl $22
80105607:	6a 16                	push   $0x16
  jmp alltraps
80105609:	e9 a1 fa ff ff       	jmp    801050af <alltraps>

8010560e <vector23>:
.globl vector23
vector23:
  pushl $0
8010560e:	6a 00                	push   $0x0
  pushl $23
80105610:	6a 17                	push   $0x17
  jmp alltraps
80105612:	e9 98 fa ff ff       	jmp    801050af <alltraps>

80105617 <vector24>:
.globl vector24
vector24:
  pushl $0
80105617:	6a 00                	push   $0x0
  pushl $24
80105619:	6a 18                	push   $0x18
  jmp alltraps
8010561b:	e9 8f fa ff ff       	jmp    801050af <alltraps>

80105620 <vector25>:
.globl vector25
vector25:
  pushl $0
80105620:	6a 00                	push   $0x0
  pushl $25
80105622:	6a 19                	push   $0x19
  jmp alltraps
80105624:	e9 86 fa ff ff       	jmp    801050af <alltraps>

80105629 <vector26>:
.globl vector26
vector26:
  pushl $0
80105629:	6a 00                	push   $0x0
  pushl $26
8010562b:	6a 1a                	push   $0x1a
  jmp alltraps
8010562d:	e9 7d fa ff ff       	jmp    801050af <alltraps>

80105632 <vector27>:
.globl vector27
vector27:
  pushl $0
80105632:	6a 00                	push   $0x0
  pushl $27
80105634:	6a 1b                	push   $0x1b
  jmp alltraps
80105636:	e9 74 fa ff ff       	jmp    801050af <alltraps>

8010563b <vector28>:
.globl vector28
vector28:
  pushl $0
8010563b:	6a 00                	push   $0x0
  pushl $28
8010563d:	6a 1c                	push   $0x1c
  jmp alltraps
8010563f:	e9 6b fa ff ff       	jmp    801050af <alltraps>

80105644 <vector29>:
.globl vector29
vector29:
  pushl $0
80105644:	6a 00                	push   $0x0
  pushl $29
80105646:	6a 1d                	push   $0x1d
  jmp alltraps
80105648:	e9 62 fa ff ff       	jmp    801050af <alltraps>

8010564d <vector30>:
.globl vector30
vector30:
  pushl $0
8010564d:	6a 00                	push   $0x0
  pushl $30
8010564f:	6a 1e                	push   $0x1e
  jmp alltraps
80105651:	e9 59 fa ff ff       	jmp    801050af <alltraps>

80105656 <vector31>:
.globl vector31
vector31:
  pushl $0
80105656:	6a 00                	push   $0x0
  pushl $31
80105658:	6a 1f                	push   $0x1f
  jmp alltraps
8010565a:	e9 50 fa ff ff       	jmp    801050af <alltraps>

8010565f <vector32>:
.globl vector32
vector32:
  pushl $0
8010565f:	6a 00                	push   $0x0
  pushl $32
80105661:	6a 20                	push   $0x20
  jmp alltraps
80105663:	e9 47 fa ff ff       	jmp    801050af <alltraps>

80105668 <vector33>:
.globl vector33
vector33:
  pushl $0
80105668:	6a 00                	push   $0x0
  pushl $33
8010566a:	6a 21                	push   $0x21
  jmp alltraps
8010566c:	e9 3e fa ff ff       	jmp    801050af <alltraps>

80105671 <vector34>:
.globl vector34
vector34:
  pushl $0
80105671:	6a 00                	push   $0x0
  pushl $34
80105673:	6a 22                	push   $0x22
  jmp alltraps
80105675:	e9 35 fa ff ff       	jmp    801050af <alltraps>

8010567a <vector35>:
.globl vector35
vector35:
  pushl $0
8010567a:	6a 00                	push   $0x0
  pushl $35
8010567c:	6a 23                	push   $0x23
  jmp alltraps
8010567e:	e9 2c fa ff ff       	jmp    801050af <alltraps>

80105683 <vector36>:
.globl vector36
vector36:
  pushl $0
80105683:	6a 00                	push   $0x0
  pushl $36
80105685:	6a 24                	push   $0x24
  jmp alltraps
80105687:	e9 23 fa ff ff       	jmp    801050af <alltraps>

8010568c <vector37>:
.globl vector37
vector37:
  pushl $0
8010568c:	6a 00                	push   $0x0
  pushl $37
8010568e:	6a 25                	push   $0x25
  jmp alltraps
80105690:	e9 1a fa ff ff       	jmp    801050af <alltraps>

80105695 <vector38>:
.globl vector38
vector38:
  pushl $0
80105695:	6a 00                	push   $0x0
  pushl $38
80105697:	6a 26                	push   $0x26
  jmp alltraps
80105699:	e9 11 fa ff ff       	jmp    801050af <alltraps>

8010569e <vector39>:
.globl vector39
vector39:
  pushl $0
8010569e:	6a 00                	push   $0x0
  pushl $39
801056a0:	6a 27                	push   $0x27
  jmp alltraps
801056a2:	e9 08 fa ff ff       	jmp    801050af <alltraps>

801056a7 <vector40>:
.globl vector40
vector40:
  pushl $0
801056a7:	6a 00                	push   $0x0
  pushl $40
801056a9:	6a 28                	push   $0x28
  jmp alltraps
801056ab:	e9 ff f9 ff ff       	jmp    801050af <alltraps>

801056b0 <vector41>:
.globl vector41
vector41:
  pushl $0
801056b0:	6a 00                	push   $0x0
  pushl $41
801056b2:	6a 29                	push   $0x29
  jmp alltraps
801056b4:	e9 f6 f9 ff ff       	jmp    801050af <alltraps>

801056b9 <vector42>:
.globl vector42
vector42:
  pushl $0
801056b9:	6a 00                	push   $0x0
  pushl $42
801056bb:	6a 2a                	push   $0x2a
  jmp alltraps
801056bd:	e9 ed f9 ff ff       	jmp    801050af <alltraps>

801056c2 <vector43>:
.globl vector43
vector43:
  pushl $0
801056c2:	6a 00                	push   $0x0
  pushl $43
801056c4:	6a 2b                	push   $0x2b
  jmp alltraps
801056c6:	e9 e4 f9 ff ff       	jmp    801050af <alltraps>

801056cb <vector44>:
.globl vector44
vector44:
  pushl $0
801056cb:	6a 00                	push   $0x0
  pushl $44
801056cd:	6a 2c                	push   $0x2c
  jmp alltraps
801056cf:	e9 db f9 ff ff       	jmp    801050af <alltraps>

801056d4 <vector45>:
.globl vector45
vector45:
  pushl $0
801056d4:	6a 00                	push   $0x0
  pushl $45
801056d6:	6a 2d                	push   $0x2d
  jmp alltraps
801056d8:	e9 d2 f9 ff ff       	jmp    801050af <alltraps>

801056dd <vector46>:
.globl vector46
vector46:
  pushl $0
801056dd:	6a 00                	push   $0x0
  pushl $46
801056df:	6a 2e                	push   $0x2e
  jmp alltraps
801056e1:	e9 c9 f9 ff ff       	jmp    801050af <alltraps>

801056e6 <vector47>:
.globl vector47
vector47:
  pushl $0
801056e6:	6a 00                	push   $0x0
  pushl $47
801056e8:	6a 2f                	push   $0x2f
  jmp alltraps
801056ea:	e9 c0 f9 ff ff       	jmp    801050af <alltraps>

801056ef <vector48>:
.globl vector48
vector48:
  pushl $0
801056ef:	6a 00                	push   $0x0
  pushl $48
801056f1:	6a 30                	push   $0x30
  jmp alltraps
801056f3:	e9 b7 f9 ff ff       	jmp    801050af <alltraps>

801056f8 <vector49>:
.globl vector49
vector49:
  pushl $0
801056f8:	6a 00                	push   $0x0
  pushl $49
801056fa:	6a 31                	push   $0x31
  jmp alltraps
801056fc:	e9 ae f9 ff ff       	jmp    801050af <alltraps>

80105701 <vector50>:
.globl vector50
vector50:
  pushl $0
80105701:	6a 00                	push   $0x0
  pushl $50
80105703:	6a 32                	push   $0x32
  jmp alltraps
80105705:	e9 a5 f9 ff ff       	jmp    801050af <alltraps>

8010570a <vector51>:
.globl vector51
vector51:
  pushl $0
8010570a:	6a 00                	push   $0x0
  pushl $51
8010570c:	6a 33                	push   $0x33
  jmp alltraps
8010570e:	e9 9c f9 ff ff       	jmp    801050af <alltraps>

80105713 <vector52>:
.globl vector52
vector52:
  pushl $0
80105713:	6a 00                	push   $0x0
  pushl $52
80105715:	6a 34                	push   $0x34
  jmp alltraps
80105717:	e9 93 f9 ff ff       	jmp    801050af <alltraps>

8010571c <vector53>:
.globl vector53
vector53:
  pushl $0
8010571c:	6a 00                	push   $0x0
  pushl $53
8010571e:	6a 35                	push   $0x35
  jmp alltraps
80105720:	e9 8a f9 ff ff       	jmp    801050af <alltraps>

80105725 <vector54>:
.globl vector54
vector54:
  pushl $0
80105725:	6a 00                	push   $0x0
  pushl $54
80105727:	6a 36                	push   $0x36
  jmp alltraps
80105729:	e9 81 f9 ff ff       	jmp    801050af <alltraps>

8010572e <vector55>:
.globl vector55
vector55:
  pushl $0
8010572e:	6a 00                	push   $0x0
  pushl $55
80105730:	6a 37                	push   $0x37
  jmp alltraps
80105732:	e9 78 f9 ff ff       	jmp    801050af <alltraps>

80105737 <vector56>:
.globl vector56
vector56:
  pushl $0
80105737:	6a 00                	push   $0x0
  pushl $56
80105739:	6a 38                	push   $0x38
  jmp alltraps
8010573b:	e9 6f f9 ff ff       	jmp    801050af <alltraps>

80105740 <vector57>:
.globl vector57
vector57:
  pushl $0
80105740:	6a 00                	push   $0x0
  pushl $57
80105742:	6a 39                	push   $0x39
  jmp alltraps
80105744:	e9 66 f9 ff ff       	jmp    801050af <alltraps>

80105749 <vector58>:
.globl vector58
vector58:
  pushl $0
80105749:	6a 00                	push   $0x0
  pushl $58
8010574b:	6a 3a                	push   $0x3a
  jmp alltraps
8010574d:	e9 5d f9 ff ff       	jmp    801050af <alltraps>

80105752 <vector59>:
.globl vector59
vector59:
  pushl $0
80105752:	6a 00                	push   $0x0
  pushl $59
80105754:	6a 3b                	push   $0x3b
  jmp alltraps
80105756:	e9 54 f9 ff ff       	jmp    801050af <alltraps>

8010575b <vector60>:
.globl vector60
vector60:
  pushl $0
8010575b:	6a 00                	push   $0x0
  pushl $60
8010575d:	6a 3c                	push   $0x3c
  jmp alltraps
8010575f:	e9 4b f9 ff ff       	jmp    801050af <alltraps>

80105764 <vector61>:
.globl vector61
vector61:
  pushl $0
80105764:	6a 00                	push   $0x0
  pushl $61
80105766:	6a 3d                	push   $0x3d
  jmp alltraps
80105768:	e9 42 f9 ff ff       	jmp    801050af <alltraps>

8010576d <vector62>:
.globl vector62
vector62:
  pushl $0
8010576d:	6a 00                	push   $0x0
  pushl $62
8010576f:	6a 3e                	push   $0x3e
  jmp alltraps
80105771:	e9 39 f9 ff ff       	jmp    801050af <alltraps>

80105776 <vector63>:
.globl vector63
vector63:
  pushl $0
80105776:	6a 00                	push   $0x0
  pushl $63
80105778:	6a 3f                	push   $0x3f
  jmp alltraps
8010577a:	e9 30 f9 ff ff       	jmp    801050af <alltraps>

8010577f <vector64>:
.globl vector64
vector64:
  pushl $0
8010577f:	6a 00                	push   $0x0
  pushl $64
80105781:	6a 40                	push   $0x40
  jmp alltraps
80105783:	e9 27 f9 ff ff       	jmp    801050af <alltraps>

80105788 <vector65>:
.globl vector65
vector65:
  pushl $0
80105788:	6a 00                	push   $0x0
  pushl $65
8010578a:	6a 41                	push   $0x41
  jmp alltraps
8010578c:	e9 1e f9 ff ff       	jmp    801050af <alltraps>

80105791 <vector66>:
.globl vector66
vector66:
  pushl $0
80105791:	6a 00                	push   $0x0
  pushl $66
80105793:	6a 42                	push   $0x42
  jmp alltraps
80105795:	e9 15 f9 ff ff       	jmp    801050af <alltraps>

8010579a <vector67>:
.globl vector67
vector67:
  pushl $0
8010579a:	6a 00                	push   $0x0
  pushl $67
8010579c:	6a 43                	push   $0x43
  jmp alltraps
8010579e:	e9 0c f9 ff ff       	jmp    801050af <alltraps>

801057a3 <vector68>:
.globl vector68
vector68:
  pushl $0
801057a3:	6a 00                	push   $0x0
  pushl $68
801057a5:	6a 44                	push   $0x44
  jmp alltraps
801057a7:	e9 03 f9 ff ff       	jmp    801050af <alltraps>

801057ac <vector69>:
.globl vector69
vector69:
  pushl $0
801057ac:	6a 00                	push   $0x0
  pushl $69
801057ae:	6a 45                	push   $0x45
  jmp alltraps
801057b0:	e9 fa f8 ff ff       	jmp    801050af <alltraps>

801057b5 <vector70>:
.globl vector70
vector70:
  pushl $0
801057b5:	6a 00                	push   $0x0
  pushl $70
801057b7:	6a 46                	push   $0x46
  jmp alltraps
801057b9:	e9 f1 f8 ff ff       	jmp    801050af <alltraps>

801057be <vector71>:
.globl vector71
vector71:
  pushl $0
801057be:	6a 00                	push   $0x0
  pushl $71
801057c0:	6a 47                	push   $0x47
  jmp alltraps
801057c2:	e9 e8 f8 ff ff       	jmp    801050af <alltraps>

801057c7 <vector72>:
.globl vector72
vector72:
  pushl $0
801057c7:	6a 00                	push   $0x0
  pushl $72
801057c9:	6a 48                	push   $0x48
  jmp alltraps
801057cb:	e9 df f8 ff ff       	jmp    801050af <alltraps>

801057d0 <vector73>:
.globl vector73
vector73:
  pushl $0
801057d0:	6a 00                	push   $0x0
  pushl $73
801057d2:	6a 49                	push   $0x49
  jmp alltraps
801057d4:	e9 d6 f8 ff ff       	jmp    801050af <alltraps>

801057d9 <vector74>:
.globl vector74
vector74:
  pushl $0
801057d9:	6a 00                	push   $0x0
  pushl $74
801057db:	6a 4a                	push   $0x4a
  jmp alltraps
801057dd:	e9 cd f8 ff ff       	jmp    801050af <alltraps>

801057e2 <vector75>:
.globl vector75
vector75:
  pushl $0
801057e2:	6a 00                	push   $0x0
  pushl $75
801057e4:	6a 4b                	push   $0x4b
  jmp alltraps
801057e6:	e9 c4 f8 ff ff       	jmp    801050af <alltraps>

801057eb <vector76>:
.globl vector76
vector76:
  pushl $0
801057eb:	6a 00                	push   $0x0
  pushl $76
801057ed:	6a 4c                	push   $0x4c
  jmp alltraps
801057ef:	e9 bb f8 ff ff       	jmp    801050af <alltraps>

801057f4 <vector77>:
.globl vector77
vector77:
  pushl $0
801057f4:	6a 00                	push   $0x0
  pushl $77
801057f6:	6a 4d                	push   $0x4d
  jmp alltraps
801057f8:	e9 b2 f8 ff ff       	jmp    801050af <alltraps>

801057fd <vector78>:
.globl vector78
vector78:
  pushl $0
801057fd:	6a 00                	push   $0x0
  pushl $78
801057ff:	6a 4e                	push   $0x4e
  jmp alltraps
80105801:	e9 a9 f8 ff ff       	jmp    801050af <alltraps>

80105806 <vector79>:
.globl vector79
vector79:
  pushl $0
80105806:	6a 00                	push   $0x0
  pushl $79
80105808:	6a 4f                	push   $0x4f
  jmp alltraps
8010580a:	e9 a0 f8 ff ff       	jmp    801050af <alltraps>

8010580f <vector80>:
.globl vector80
vector80:
  pushl $0
8010580f:	6a 00                	push   $0x0
  pushl $80
80105811:	6a 50                	push   $0x50
  jmp alltraps
80105813:	e9 97 f8 ff ff       	jmp    801050af <alltraps>

80105818 <vector81>:
.globl vector81
vector81:
  pushl $0
80105818:	6a 00                	push   $0x0
  pushl $81
8010581a:	6a 51                	push   $0x51
  jmp alltraps
8010581c:	e9 8e f8 ff ff       	jmp    801050af <alltraps>

80105821 <vector82>:
.globl vector82
vector82:
  pushl $0
80105821:	6a 00                	push   $0x0
  pushl $82
80105823:	6a 52                	push   $0x52
  jmp alltraps
80105825:	e9 85 f8 ff ff       	jmp    801050af <alltraps>

8010582a <vector83>:
.globl vector83
vector83:
  pushl $0
8010582a:	6a 00                	push   $0x0
  pushl $83
8010582c:	6a 53                	push   $0x53
  jmp alltraps
8010582e:	e9 7c f8 ff ff       	jmp    801050af <alltraps>

80105833 <vector84>:
.globl vector84
vector84:
  pushl $0
80105833:	6a 00                	push   $0x0
  pushl $84
80105835:	6a 54                	push   $0x54
  jmp alltraps
80105837:	e9 73 f8 ff ff       	jmp    801050af <alltraps>

8010583c <vector85>:
.globl vector85
vector85:
  pushl $0
8010583c:	6a 00                	push   $0x0
  pushl $85
8010583e:	6a 55                	push   $0x55
  jmp alltraps
80105840:	e9 6a f8 ff ff       	jmp    801050af <alltraps>

80105845 <vector86>:
.globl vector86
vector86:
  pushl $0
80105845:	6a 00                	push   $0x0
  pushl $86
80105847:	6a 56                	push   $0x56
  jmp alltraps
80105849:	e9 61 f8 ff ff       	jmp    801050af <alltraps>

8010584e <vector87>:
.globl vector87
vector87:
  pushl $0
8010584e:	6a 00                	push   $0x0
  pushl $87
80105850:	6a 57                	push   $0x57
  jmp alltraps
80105852:	e9 58 f8 ff ff       	jmp    801050af <alltraps>

80105857 <vector88>:
.globl vector88
vector88:
  pushl $0
80105857:	6a 00                	push   $0x0
  pushl $88
80105859:	6a 58                	push   $0x58
  jmp alltraps
8010585b:	e9 4f f8 ff ff       	jmp    801050af <alltraps>

80105860 <vector89>:
.globl vector89
vector89:
  pushl $0
80105860:	6a 00                	push   $0x0
  pushl $89
80105862:	6a 59                	push   $0x59
  jmp alltraps
80105864:	e9 46 f8 ff ff       	jmp    801050af <alltraps>

80105869 <vector90>:
.globl vector90
vector90:
  pushl $0
80105869:	6a 00                	push   $0x0
  pushl $90
8010586b:	6a 5a                	push   $0x5a
  jmp alltraps
8010586d:	e9 3d f8 ff ff       	jmp    801050af <alltraps>

80105872 <vector91>:
.globl vector91
vector91:
  pushl $0
80105872:	6a 00                	push   $0x0
  pushl $91
80105874:	6a 5b                	push   $0x5b
  jmp alltraps
80105876:	e9 34 f8 ff ff       	jmp    801050af <alltraps>

8010587b <vector92>:
.globl vector92
vector92:
  pushl $0
8010587b:	6a 00                	push   $0x0
  pushl $92
8010587d:	6a 5c                	push   $0x5c
  jmp alltraps
8010587f:	e9 2b f8 ff ff       	jmp    801050af <alltraps>

80105884 <vector93>:
.globl vector93
vector93:
  pushl $0
80105884:	6a 00                	push   $0x0
  pushl $93
80105886:	6a 5d                	push   $0x5d
  jmp alltraps
80105888:	e9 22 f8 ff ff       	jmp    801050af <alltraps>

8010588d <vector94>:
.globl vector94
vector94:
  pushl $0
8010588d:	6a 00                	push   $0x0
  pushl $94
8010588f:	6a 5e                	push   $0x5e
  jmp alltraps
80105891:	e9 19 f8 ff ff       	jmp    801050af <alltraps>

80105896 <vector95>:
.globl vector95
vector95:
  pushl $0
80105896:	6a 00                	push   $0x0
  pushl $95
80105898:	6a 5f                	push   $0x5f
  jmp alltraps
8010589a:	e9 10 f8 ff ff       	jmp    801050af <alltraps>

8010589f <vector96>:
.globl vector96
vector96:
  pushl $0
8010589f:	6a 00                	push   $0x0
  pushl $96
801058a1:	6a 60                	push   $0x60
  jmp alltraps
801058a3:	e9 07 f8 ff ff       	jmp    801050af <alltraps>

801058a8 <vector97>:
.globl vector97
vector97:
  pushl $0
801058a8:	6a 00                	push   $0x0
  pushl $97
801058aa:	6a 61                	push   $0x61
  jmp alltraps
801058ac:	e9 fe f7 ff ff       	jmp    801050af <alltraps>

801058b1 <vector98>:
.globl vector98
vector98:
  pushl $0
801058b1:	6a 00                	push   $0x0
  pushl $98
801058b3:	6a 62                	push   $0x62
  jmp alltraps
801058b5:	e9 f5 f7 ff ff       	jmp    801050af <alltraps>

801058ba <vector99>:
.globl vector99
vector99:
  pushl $0
801058ba:	6a 00                	push   $0x0
  pushl $99
801058bc:	6a 63                	push   $0x63
  jmp alltraps
801058be:	e9 ec f7 ff ff       	jmp    801050af <alltraps>

801058c3 <vector100>:
.globl vector100
vector100:
  pushl $0
801058c3:	6a 00                	push   $0x0
  pushl $100
801058c5:	6a 64                	push   $0x64
  jmp alltraps
801058c7:	e9 e3 f7 ff ff       	jmp    801050af <alltraps>

801058cc <vector101>:
.globl vector101
vector101:
  pushl $0
801058cc:	6a 00                	push   $0x0
  pushl $101
801058ce:	6a 65                	push   $0x65
  jmp alltraps
801058d0:	e9 da f7 ff ff       	jmp    801050af <alltraps>

801058d5 <vector102>:
.globl vector102
vector102:
  pushl $0
801058d5:	6a 00                	push   $0x0
  pushl $102
801058d7:	6a 66                	push   $0x66
  jmp alltraps
801058d9:	e9 d1 f7 ff ff       	jmp    801050af <alltraps>

801058de <vector103>:
.globl vector103
vector103:
  pushl $0
801058de:	6a 00                	push   $0x0
  pushl $103
801058e0:	6a 67                	push   $0x67
  jmp alltraps
801058e2:	e9 c8 f7 ff ff       	jmp    801050af <alltraps>

801058e7 <vector104>:
.globl vector104
vector104:
  pushl $0
801058e7:	6a 00                	push   $0x0
  pushl $104
801058e9:	6a 68                	push   $0x68
  jmp alltraps
801058eb:	e9 bf f7 ff ff       	jmp    801050af <alltraps>

801058f0 <vector105>:
.globl vector105
vector105:
  pushl $0
801058f0:	6a 00                	push   $0x0
  pushl $105
801058f2:	6a 69                	push   $0x69
  jmp alltraps
801058f4:	e9 b6 f7 ff ff       	jmp    801050af <alltraps>

801058f9 <vector106>:
.globl vector106
vector106:
  pushl $0
801058f9:	6a 00                	push   $0x0
  pushl $106
801058fb:	6a 6a                	push   $0x6a
  jmp alltraps
801058fd:	e9 ad f7 ff ff       	jmp    801050af <alltraps>

80105902 <vector107>:
.globl vector107
vector107:
  pushl $0
80105902:	6a 00                	push   $0x0
  pushl $107
80105904:	6a 6b                	push   $0x6b
  jmp alltraps
80105906:	e9 a4 f7 ff ff       	jmp    801050af <alltraps>

8010590b <vector108>:
.globl vector108
vector108:
  pushl $0
8010590b:	6a 00                	push   $0x0
  pushl $108
8010590d:	6a 6c                	push   $0x6c
  jmp alltraps
8010590f:	e9 9b f7 ff ff       	jmp    801050af <alltraps>

80105914 <vector109>:
.globl vector109
vector109:
  pushl $0
80105914:	6a 00                	push   $0x0
  pushl $109
80105916:	6a 6d                	push   $0x6d
  jmp alltraps
80105918:	e9 92 f7 ff ff       	jmp    801050af <alltraps>

8010591d <vector110>:
.globl vector110
vector110:
  pushl $0
8010591d:	6a 00                	push   $0x0
  pushl $110
8010591f:	6a 6e                	push   $0x6e
  jmp alltraps
80105921:	e9 89 f7 ff ff       	jmp    801050af <alltraps>

80105926 <vector111>:
.globl vector111
vector111:
  pushl $0
80105926:	6a 00                	push   $0x0
  pushl $111
80105928:	6a 6f                	push   $0x6f
  jmp alltraps
8010592a:	e9 80 f7 ff ff       	jmp    801050af <alltraps>

8010592f <vector112>:
.globl vector112
vector112:
  pushl $0
8010592f:	6a 00                	push   $0x0
  pushl $112
80105931:	6a 70                	push   $0x70
  jmp alltraps
80105933:	e9 77 f7 ff ff       	jmp    801050af <alltraps>

80105938 <vector113>:
.globl vector113
vector113:
  pushl $0
80105938:	6a 00                	push   $0x0
  pushl $113
8010593a:	6a 71                	push   $0x71
  jmp alltraps
8010593c:	e9 6e f7 ff ff       	jmp    801050af <alltraps>

80105941 <vector114>:
.globl vector114
vector114:
  pushl $0
80105941:	6a 00                	push   $0x0
  pushl $114
80105943:	6a 72                	push   $0x72
  jmp alltraps
80105945:	e9 65 f7 ff ff       	jmp    801050af <alltraps>

8010594a <vector115>:
.globl vector115
vector115:
  pushl $0
8010594a:	6a 00                	push   $0x0
  pushl $115
8010594c:	6a 73                	push   $0x73
  jmp alltraps
8010594e:	e9 5c f7 ff ff       	jmp    801050af <alltraps>

80105953 <vector116>:
.globl vector116
vector116:
  pushl $0
80105953:	6a 00                	push   $0x0
  pushl $116
80105955:	6a 74                	push   $0x74
  jmp alltraps
80105957:	e9 53 f7 ff ff       	jmp    801050af <alltraps>

8010595c <vector117>:
.globl vector117
vector117:
  pushl $0
8010595c:	6a 00                	push   $0x0
  pushl $117
8010595e:	6a 75                	push   $0x75
  jmp alltraps
80105960:	e9 4a f7 ff ff       	jmp    801050af <alltraps>

80105965 <vector118>:
.globl vector118
vector118:
  pushl $0
80105965:	6a 00                	push   $0x0
  pushl $118
80105967:	6a 76                	push   $0x76
  jmp alltraps
80105969:	e9 41 f7 ff ff       	jmp    801050af <alltraps>

8010596e <vector119>:
.globl vector119
vector119:
  pushl $0
8010596e:	6a 00                	push   $0x0
  pushl $119
80105970:	6a 77                	push   $0x77
  jmp alltraps
80105972:	e9 38 f7 ff ff       	jmp    801050af <alltraps>

80105977 <vector120>:
.globl vector120
vector120:
  pushl $0
80105977:	6a 00                	push   $0x0
  pushl $120
80105979:	6a 78                	push   $0x78
  jmp alltraps
8010597b:	e9 2f f7 ff ff       	jmp    801050af <alltraps>

80105980 <vector121>:
.globl vector121
vector121:
  pushl $0
80105980:	6a 00                	push   $0x0
  pushl $121
80105982:	6a 79                	push   $0x79
  jmp alltraps
80105984:	e9 26 f7 ff ff       	jmp    801050af <alltraps>

80105989 <vector122>:
.globl vector122
vector122:
  pushl $0
80105989:	6a 00                	push   $0x0
  pushl $122
8010598b:	6a 7a                	push   $0x7a
  jmp alltraps
8010598d:	e9 1d f7 ff ff       	jmp    801050af <alltraps>

80105992 <vector123>:
.globl vector123
vector123:
  pushl $0
80105992:	6a 00                	push   $0x0
  pushl $123
80105994:	6a 7b                	push   $0x7b
  jmp alltraps
80105996:	e9 14 f7 ff ff       	jmp    801050af <alltraps>

8010599b <vector124>:
.globl vector124
vector124:
  pushl $0
8010599b:	6a 00                	push   $0x0
  pushl $124
8010599d:	6a 7c                	push   $0x7c
  jmp alltraps
8010599f:	e9 0b f7 ff ff       	jmp    801050af <alltraps>

801059a4 <vector125>:
.globl vector125
vector125:
  pushl $0
801059a4:	6a 00                	push   $0x0
  pushl $125
801059a6:	6a 7d                	push   $0x7d
  jmp alltraps
801059a8:	e9 02 f7 ff ff       	jmp    801050af <alltraps>

801059ad <vector126>:
.globl vector126
vector126:
  pushl $0
801059ad:	6a 00                	push   $0x0
  pushl $126
801059af:	6a 7e                	push   $0x7e
  jmp alltraps
801059b1:	e9 f9 f6 ff ff       	jmp    801050af <alltraps>

801059b6 <vector127>:
.globl vector127
vector127:
  pushl $0
801059b6:	6a 00                	push   $0x0
  pushl $127
801059b8:	6a 7f                	push   $0x7f
  jmp alltraps
801059ba:	e9 f0 f6 ff ff       	jmp    801050af <alltraps>

801059bf <vector128>:
.globl vector128
vector128:
  pushl $0
801059bf:	6a 00                	push   $0x0
  pushl $128
801059c1:	68 80 00 00 00       	push   $0x80
  jmp alltraps
801059c6:	e9 e4 f6 ff ff       	jmp    801050af <alltraps>

801059cb <vector129>:
.globl vector129
vector129:
  pushl $0
801059cb:	6a 00                	push   $0x0
  pushl $129
801059cd:	68 81 00 00 00       	push   $0x81
  jmp alltraps
801059d2:	e9 d8 f6 ff ff       	jmp    801050af <alltraps>

801059d7 <vector130>:
.globl vector130
vector130:
  pushl $0
801059d7:	6a 00                	push   $0x0
  pushl $130
801059d9:	68 82 00 00 00       	push   $0x82
  jmp alltraps
801059de:	e9 cc f6 ff ff       	jmp    801050af <alltraps>

801059e3 <vector131>:
.globl vector131
vector131:
  pushl $0
801059e3:	6a 00                	push   $0x0
  pushl $131
801059e5:	68 83 00 00 00       	push   $0x83
  jmp alltraps
801059ea:	e9 c0 f6 ff ff       	jmp    801050af <alltraps>

801059ef <vector132>:
.globl vector132
vector132:
  pushl $0
801059ef:	6a 00                	push   $0x0
  pushl $132
801059f1:	68 84 00 00 00       	push   $0x84
  jmp alltraps
801059f6:	e9 b4 f6 ff ff       	jmp    801050af <alltraps>

801059fb <vector133>:
.globl vector133
vector133:
  pushl $0
801059fb:	6a 00                	push   $0x0
  pushl $133
801059fd:	68 85 00 00 00       	push   $0x85
  jmp alltraps
80105a02:	e9 a8 f6 ff ff       	jmp    801050af <alltraps>

80105a07 <vector134>:
.globl vector134
vector134:
  pushl $0
80105a07:	6a 00                	push   $0x0
  pushl $134
80105a09:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80105a0e:	e9 9c f6 ff ff       	jmp    801050af <alltraps>

80105a13 <vector135>:
.globl vector135
vector135:
  pushl $0
80105a13:	6a 00                	push   $0x0
  pushl $135
80105a15:	68 87 00 00 00       	push   $0x87
  jmp alltraps
80105a1a:	e9 90 f6 ff ff       	jmp    801050af <alltraps>

80105a1f <vector136>:
.globl vector136
vector136:
  pushl $0
80105a1f:	6a 00                	push   $0x0
  pushl $136
80105a21:	68 88 00 00 00       	push   $0x88
  jmp alltraps
80105a26:	e9 84 f6 ff ff       	jmp    801050af <alltraps>

80105a2b <vector137>:
.globl vector137
vector137:
  pushl $0
80105a2b:	6a 00                	push   $0x0
  pushl $137
80105a2d:	68 89 00 00 00       	push   $0x89
  jmp alltraps
80105a32:	e9 78 f6 ff ff       	jmp    801050af <alltraps>

80105a37 <vector138>:
.globl vector138
vector138:
  pushl $0
80105a37:	6a 00                	push   $0x0
  pushl $138
80105a39:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
80105a3e:	e9 6c f6 ff ff       	jmp    801050af <alltraps>

80105a43 <vector139>:
.globl vector139
vector139:
  pushl $0
80105a43:	6a 00                	push   $0x0
  pushl $139
80105a45:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
80105a4a:	e9 60 f6 ff ff       	jmp    801050af <alltraps>

80105a4f <vector140>:
.globl vector140
vector140:
  pushl $0
80105a4f:	6a 00                	push   $0x0
  pushl $140
80105a51:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
80105a56:	e9 54 f6 ff ff       	jmp    801050af <alltraps>

80105a5b <vector141>:
.globl vector141
vector141:
  pushl $0
80105a5b:	6a 00                	push   $0x0
  pushl $141
80105a5d:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
80105a62:	e9 48 f6 ff ff       	jmp    801050af <alltraps>

80105a67 <vector142>:
.globl vector142
vector142:
  pushl $0
80105a67:	6a 00                	push   $0x0
  pushl $142
80105a69:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
80105a6e:	e9 3c f6 ff ff       	jmp    801050af <alltraps>

80105a73 <vector143>:
.globl vector143
vector143:
  pushl $0
80105a73:	6a 00                	push   $0x0
  pushl $143
80105a75:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80105a7a:	e9 30 f6 ff ff       	jmp    801050af <alltraps>

80105a7f <vector144>:
.globl vector144
vector144:
  pushl $0
80105a7f:	6a 00                	push   $0x0
  pushl $144
80105a81:	68 90 00 00 00       	push   $0x90
  jmp alltraps
80105a86:	e9 24 f6 ff ff       	jmp    801050af <alltraps>

80105a8b <vector145>:
.globl vector145
vector145:
  pushl $0
80105a8b:	6a 00                	push   $0x0
  pushl $145
80105a8d:	68 91 00 00 00       	push   $0x91
  jmp alltraps
80105a92:	e9 18 f6 ff ff       	jmp    801050af <alltraps>

80105a97 <vector146>:
.globl vector146
vector146:
  pushl $0
80105a97:	6a 00                	push   $0x0
  pushl $146
80105a99:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80105a9e:	e9 0c f6 ff ff       	jmp    801050af <alltraps>

80105aa3 <vector147>:
.globl vector147
vector147:
  pushl $0
80105aa3:	6a 00                	push   $0x0
  pushl $147
80105aa5:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80105aaa:	e9 00 f6 ff ff       	jmp    801050af <alltraps>

80105aaf <vector148>:
.globl vector148
vector148:
  pushl $0
80105aaf:	6a 00                	push   $0x0
  pushl $148
80105ab1:	68 94 00 00 00       	push   $0x94
  jmp alltraps
80105ab6:	e9 f4 f5 ff ff       	jmp    801050af <alltraps>

80105abb <vector149>:
.globl vector149
vector149:
  pushl $0
80105abb:	6a 00                	push   $0x0
  pushl $149
80105abd:	68 95 00 00 00       	push   $0x95
  jmp alltraps
80105ac2:	e9 e8 f5 ff ff       	jmp    801050af <alltraps>

80105ac7 <vector150>:
.globl vector150
vector150:
  pushl $0
80105ac7:	6a 00                	push   $0x0
  pushl $150
80105ac9:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80105ace:	e9 dc f5 ff ff       	jmp    801050af <alltraps>

80105ad3 <vector151>:
.globl vector151
vector151:
  pushl $0
80105ad3:	6a 00                	push   $0x0
  pushl $151
80105ad5:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80105ada:	e9 d0 f5 ff ff       	jmp    801050af <alltraps>

80105adf <vector152>:
.globl vector152
vector152:
  pushl $0
80105adf:	6a 00                	push   $0x0
  pushl $152
80105ae1:	68 98 00 00 00       	push   $0x98
  jmp alltraps
80105ae6:	e9 c4 f5 ff ff       	jmp    801050af <alltraps>

80105aeb <vector153>:
.globl vector153
vector153:
  pushl $0
80105aeb:	6a 00                	push   $0x0
  pushl $153
80105aed:	68 99 00 00 00       	push   $0x99
  jmp alltraps
80105af2:	e9 b8 f5 ff ff       	jmp    801050af <alltraps>

80105af7 <vector154>:
.globl vector154
vector154:
  pushl $0
80105af7:	6a 00                	push   $0x0
  pushl $154
80105af9:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80105afe:	e9 ac f5 ff ff       	jmp    801050af <alltraps>

80105b03 <vector155>:
.globl vector155
vector155:
  pushl $0
80105b03:	6a 00                	push   $0x0
  pushl $155
80105b05:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80105b0a:	e9 a0 f5 ff ff       	jmp    801050af <alltraps>

80105b0f <vector156>:
.globl vector156
vector156:
  pushl $0
80105b0f:	6a 00                	push   $0x0
  pushl $156
80105b11:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
80105b16:	e9 94 f5 ff ff       	jmp    801050af <alltraps>

80105b1b <vector157>:
.globl vector157
vector157:
  pushl $0
80105b1b:	6a 00                	push   $0x0
  pushl $157
80105b1d:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
80105b22:	e9 88 f5 ff ff       	jmp    801050af <alltraps>

80105b27 <vector158>:
.globl vector158
vector158:
  pushl $0
80105b27:	6a 00                	push   $0x0
  pushl $158
80105b29:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
80105b2e:	e9 7c f5 ff ff       	jmp    801050af <alltraps>

80105b33 <vector159>:
.globl vector159
vector159:
  pushl $0
80105b33:	6a 00                	push   $0x0
  pushl $159
80105b35:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
80105b3a:	e9 70 f5 ff ff       	jmp    801050af <alltraps>

80105b3f <vector160>:
.globl vector160
vector160:
  pushl $0
80105b3f:	6a 00                	push   $0x0
  pushl $160
80105b41:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
80105b46:	e9 64 f5 ff ff       	jmp    801050af <alltraps>

80105b4b <vector161>:
.globl vector161
vector161:
  pushl $0
80105b4b:	6a 00                	push   $0x0
  pushl $161
80105b4d:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
80105b52:	e9 58 f5 ff ff       	jmp    801050af <alltraps>

80105b57 <vector162>:
.globl vector162
vector162:
  pushl $0
80105b57:	6a 00                	push   $0x0
  pushl $162
80105b59:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
80105b5e:	e9 4c f5 ff ff       	jmp    801050af <alltraps>

80105b63 <vector163>:
.globl vector163
vector163:
  pushl $0
80105b63:	6a 00                	push   $0x0
  pushl $163
80105b65:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
80105b6a:	e9 40 f5 ff ff       	jmp    801050af <alltraps>

80105b6f <vector164>:
.globl vector164
vector164:
  pushl $0
80105b6f:	6a 00                	push   $0x0
  pushl $164
80105b71:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
80105b76:	e9 34 f5 ff ff       	jmp    801050af <alltraps>

80105b7b <vector165>:
.globl vector165
vector165:
  pushl $0
80105b7b:	6a 00                	push   $0x0
  pushl $165
80105b7d:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
80105b82:	e9 28 f5 ff ff       	jmp    801050af <alltraps>

80105b87 <vector166>:
.globl vector166
vector166:
  pushl $0
80105b87:	6a 00                	push   $0x0
  pushl $166
80105b89:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80105b8e:	e9 1c f5 ff ff       	jmp    801050af <alltraps>

80105b93 <vector167>:
.globl vector167
vector167:
  pushl $0
80105b93:	6a 00                	push   $0x0
  pushl $167
80105b95:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80105b9a:	e9 10 f5 ff ff       	jmp    801050af <alltraps>

80105b9f <vector168>:
.globl vector168
vector168:
  pushl $0
80105b9f:	6a 00                	push   $0x0
  pushl $168
80105ba1:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
80105ba6:	e9 04 f5 ff ff       	jmp    801050af <alltraps>

80105bab <vector169>:
.globl vector169
vector169:
  pushl $0
80105bab:	6a 00                	push   $0x0
  pushl $169
80105bad:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
80105bb2:	e9 f8 f4 ff ff       	jmp    801050af <alltraps>

80105bb7 <vector170>:
.globl vector170
vector170:
  pushl $0
80105bb7:	6a 00                	push   $0x0
  pushl $170
80105bb9:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80105bbe:	e9 ec f4 ff ff       	jmp    801050af <alltraps>

80105bc3 <vector171>:
.globl vector171
vector171:
  pushl $0
80105bc3:	6a 00                	push   $0x0
  pushl $171
80105bc5:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80105bca:	e9 e0 f4 ff ff       	jmp    801050af <alltraps>

80105bcf <vector172>:
.globl vector172
vector172:
  pushl $0
80105bcf:	6a 00                	push   $0x0
  pushl $172
80105bd1:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
80105bd6:	e9 d4 f4 ff ff       	jmp    801050af <alltraps>

80105bdb <vector173>:
.globl vector173
vector173:
  pushl $0
80105bdb:	6a 00                	push   $0x0
  pushl $173
80105bdd:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
80105be2:	e9 c8 f4 ff ff       	jmp    801050af <alltraps>

80105be7 <vector174>:
.globl vector174
vector174:
  pushl $0
80105be7:	6a 00                	push   $0x0
  pushl $174
80105be9:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80105bee:	e9 bc f4 ff ff       	jmp    801050af <alltraps>

80105bf3 <vector175>:
.globl vector175
vector175:
  pushl $0
80105bf3:	6a 00                	push   $0x0
  pushl $175
80105bf5:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80105bfa:	e9 b0 f4 ff ff       	jmp    801050af <alltraps>

80105bff <vector176>:
.globl vector176
vector176:
  pushl $0
80105bff:	6a 00                	push   $0x0
  pushl $176
80105c01:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
80105c06:	e9 a4 f4 ff ff       	jmp    801050af <alltraps>

80105c0b <vector177>:
.globl vector177
vector177:
  pushl $0
80105c0b:	6a 00                	push   $0x0
  pushl $177
80105c0d:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
80105c12:	e9 98 f4 ff ff       	jmp    801050af <alltraps>

80105c17 <vector178>:
.globl vector178
vector178:
  pushl $0
80105c17:	6a 00                	push   $0x0
  pushl $178
80105c19:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80105c1e:	e9 8c f4 ff ff       	jmp    801050af <alltraps>

80105c23 <vector179>:
.globl vector179
vector179:
  pushl $0
80105c23:	6a 00                	push   $0x0
  pushl $179
80105c25:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80105c2a:	e9 80 f4 ff ff       	jmp    801050af <alltraps>

80105c2f <vector180>:
.globl vector180
vector180:
  pushl $0
80105c2f:	6a 00                	push   $0x0
  pushl $180
80105c31:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
80105c36:	e9 74 f4 ff ff       	jmp    801050af <alltraps>

80105c3b <vector181>:
.globl vector181
vector181:
  pushl $0
80105c3b:	6a 00                	push   $0x0
  pushl $181
80105c3d:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
80105c42:	e9 68 f4 ff ff       	jmp    801050af <alltraps>

80105c47 <vector182>:
.globl vector182
vector182:
  pushl $0
80105c47:	6a 00                	push   $0x0
  pushl $182
80105c49:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
80105c4e:	e9 5c f4 ff ff       	jmp    801050af <alltraps>

80105c53 <vector183>:
.globl vector183
vector183:
  pushl $0
80105c53:	6a 00                	push   $0x0
  pushl $183
80105c55:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
80105c5a:	e9 50 f4 ff ff       	jmp    801050af <alltraps>

80105c5f <vector184>:
.globl vector184
vector184:
  pushl $0
80105c5f:	6a 00                	push   $0x0
  pushl $184
80105c61:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
80105c66:	e9 44 f4 ff ff       	jmp    801050af <alltraps>

80105c6b <vector185>:
.globl vector185
vector185:
  pushl $0
80105c6b:	6a 00                	push   $0x0
  pushl $185
80105c6d:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
80105c72:	e9 38 f4 ff ff       	jmp    801050af <alltraps>

80105c77 <vector186>:
.globl vector186
vector186:
  pushl $0
80105c77:	6a 00                	push   $0x0
  pushl $186
80105c79:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80105c7e:	e9 2c f4 ff ff       	jmp    801050af <alltraps>

80105c83 <vector187>:
.globl vector187
vector187:
  pushl $0
80105c83:	6a 00                	push   $0x0
  pushl $187
80105c85:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80105c8a:	e9 20 f4 ff ff       	jmp    801050af <alltraps>

80105c8f <vector188>:
.globl vector188
vector188:
  pushl $0
80105c8f:	6a 00                	push   $0x0
  pushl $188
80105c91:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
80105c96:	e9 14 f4 ff ff       	jmp    801050af <alltraps>

80105c9b <vector189>:
.globl vector189
vector189:
  pushl $0
80105c9b:	6a 00                	push   $0x0
  pushl $189
80105c9d:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
80105ca2:	e9 08 f4 ff ff       	jmp    801050af <alltraps>

80105ca7 <vector190>:
.globl vector190
vector190:
  pushl $0
80105ca7:	6a 00                	push   $0x0
  pushl $190
80105ca9:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80105cae:	e9 fc f3 ff ff       	jmp    801050af <alltraps>

80105cb3 <vector191>:
.globl vector191
vector191:
  pushl $0
80105cb3:	6a 00                	push   $0x0
  pushl $191
80105cb5:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80105cba:	e9 f0 f3 ff ff       	jmp    801050af <alltraps>

80105cbf <vector192>:
.globl vector192
vector192:
  pushl $0
80105cbf:	6a 00                	push   $0x0
  pushl $192
80105cc1:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
80105cc6:	e9 e4 f3 ff ff       	jmp    801050af <alltraps>

80105ccb <vector193>:
.globl vector193
vector193:
  pushl $0
80105ccb:	6a 00                	push   $0x0
  pushl $193
80105ccd:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
80105cd2:	e9 d8 f3 ff ff       	jmp    801050af <alltraps>

80105cd7 <vector194>:
.globl vector194
vector194:
  pushl $0
80105cd7:	6a 00                	push   $0x0
  pushl $194
80105cd9:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80105cde:	e9 cc f3 ff ff       	jmp    801050af <alltraps>

80105ce3 <vector195>:
.globl vector195
vector195:
  pushl $0
80105ce3:	6a 00                	push   $0x0
  pushl $195
80105ce5:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80105cea:	e9 c0 f3 ff ff       	jmp    801050af <alltraps>

80105cef <vector196>:
.globl vector196
vector196:
  pushl $0
80105cef:	6a 00                	push   $0x0
  pushl $196
80105cf1:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
80105cf6:	e9 b4 f3 ff ff       	jmp    801050af <alltraps>

80105cfb <vector197>:
.globl vector197
vector197:
  pushl $0
80105cfb:	6a 00                	push   $0x0
  pushl $197
80105cfd:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
80105d02:	e9 a8 f3 ff ff       	jmp    801050af <alltraps>

80105d07 <vector198>:
.globl vector198
vector198:
  pushl $0
80105d07:	6a 00                	push   $0x0
  pushl $198
80105d09:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80105d0e:	e9 9c f3 ff ff       	jmp    801050af <alltraps>

80105d13 <vector199>:
.globl vector199
vector199:
  pushl $0
80105d13:	6a 00                	push   $0x0
  pushl $199
80105d15:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80105d1a:	e9 90 f3 ff ff       	jmp    801050af <alltraps>

80105d1f <vector200>:
.globl vector200
vector200:
  pushl $0
80105d1f:	6a 00                	push   $0x0
  pushl $200
80105d21:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
80105d26:	e9 84 f3 ff ff       	jmp    801050af <alltraps>

80105d2b <vector201>:
.globl vector201
vector201:
  pushl $0
80105d2b:	6a 00                	push   $0x0
  pushl $201
80105d2d:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
80105d32:	e9 78 f3 ff ff       	jmp    801050af <alltraps>

80105d37 <vector202>:
.globl vector202
vector202:
  pushl $0
80105d37:	6a 00                	push   $0x0
  pushl $202
80105d39:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
80105d3e:	e9 6c f3 ff ff       	jmp    801050af <alltraps>

80105d43 <vector203>:
.globl vector203
vector203:
  pushl $0
80105d43:	6a 00                	push   $0x0
  pushl $203
80105d45:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
80105d4a:	e9 60 f3 ff ff       	jmp    801050af <alltraps>

80105d4f <vector204>:
.globl vector204
vector204:
  pushl $0
80105d4f:	6a 00                	push   $0x0
  pushl $204
80105d51:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
80105d56:	e9 54 f3 ff ff       	jmp    801050af <alltraps>

80105d5b <vector205>:
.globl vector205
vector205:
  pushl $0
80105d5b:	6a 00                	push   $0x0
  pushl $205
80105d5d:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
80105d62:	e9 48 f3 ff ff       	jmp    801050af <alltraps>

80105d67 <vector206>:
.globl vector206
vector206:
  pushl $0
80105d67:	6a 00                	push   $0x0
  pushl $206
80105d69:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
80105d6e:	e9 3c f3 ff ff       	jmp    801050af <alltraps>

80105d73 <vector207>:
.globl vector207
vector207:
  pushl $0
80105d73:	6a 00                	push   $0x0
  pushl $207
80105d75:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80105d7a:	e9 30 f3 ff ff       	jmp    801050af <alltraps>

80105d7f <vector208>:
.globl vector208
vector208:
  pushl $0
80105d7f:	6a 00                	push   $0x0
  pushl $208
80105d81:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
80105d86:	e9 24 f3 ff ff       	jmp    801050af <alltraps>

80105d8b <vector209>:
.globl vector209
vector209:
  pushl $0
80105d8b:	6a 00                	push   $0x0
  pushl $209
80105d8d:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
80105d92:	e9 18 f3 ff ff       	jmp    801050af <alltraps>

80105d97 <vector210>:
.globl vector210
vector210:
  pushl $0
80105d97:	6a 00                	push   $0x0
  pushl $210
80105d99:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80105d9e:	e9 0c f3 ff ff       	jmp    801050af <alltraps>

80105da3 <vector211>:
.globl vector211
vector211:
  pushl $0
80105da3:	6a 00                	push   $0x0
  pushl $211
80105da5:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80105daa:	e9 00 f3 ff ff       	jmp    801050af <alltraps>

80105daf <vector212>:
.globl vector212
vector212:
  pushl $0
80105daf:	6a 00                	push   $0x0
  pushl $212
80105db1:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
80105db6:	e9 f4 f2 ff ff       	jmp    801050af <alltraps>

80105dbb <vector213>:
.globl vector213
vector213:
  pushl $0
80105dbb:	6a 00                	push   $0x0
  pushl $213
80105dbd:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
80105dc2:	e9 e8 f2 ff ff       	jmp    801050af <alltraps>

80105dc7 <vector214>:
.globl vector214
vector214:
  pushl $0
80105dc7:	6a 00                	push   $0x0
  pushl $214
80105dc9:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80105dce:	e9 dc f2 ff ff       	jmp    801050af <alltraps>

80105dd3 <vector215>:
.globl vector215
vector215:
  pushl $0
80105dd3:	6a 00                	push   $0x0
  pushl $215
80105dd5:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80105dda:	e9 d0 f2 ff ff       	jmp    801050af <alltraps>

80105ddf <vector216>:
.globl vector216
vector216:
  pushl $0
80105ddf:	6a 00                	push   $0x0
  pushl $216
80105de1:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
80105de6:	e9 c4 f2 ff ff       	jmp    801050af <alltraps>

80105deb <vector217>:
.globl vector217
vector217:
  pushl $0
80105deb:	6a 00                	push   $0x0
  pushl $217
80105ded:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
80105df2:	e9 b8 f2 ff ff       	jmp    801050af <alltraps>

80105df7 <vector218>:
.globl vector218
vector218:
  pushl $0
80105df7:	6a 00                	push   $0x0
  pushl $218
80105df9:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80105dfe:	e9 ac f2 ff ff       	jmp    801050af <alltraps>

80105e03 <vector219>:
.globl vector219
vector219:
  pushl $0
80105e03:	6a 00                	push   $0x0
  pushl $219
80105e05:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80105e0a:	e9 a0 f2 ff ff       	jmp    801050af <alltraps>

80105e0f <vector220>:
.globl vector220
vector220:
  pushl $0
80105e0f:	6a 00                	push   $0x0
  pushl $220
80105e11:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
80105e16:	e9 94 f2 ff ff       	jmp    801050af <alltraps>

80105e1b <vector221>:
.globl vector221
vector221:
  pushl $0
80105e1b:	6a 00                	push   $0x0
  pushl $221
80105e1d:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
80105e22:	e9 88 f2 ff ff       	jmp    801050af <alltraps>

80105e27 <vector222>:
.globl vector222
vector222:
  pushl $0
80105e27:	6a 00                	push   $0x0
  pushl $222
80105e29:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80105e2e:	e9 7c f2 ff ff       	jmp    801050af <alltraps>

80105e33 <vector223>:
.globl vector223
vector223:
  pushl $0
80105e33:	6a 00                	push   $0x0
  pushl $223
80105e35:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
80105e3a:	e9 70 f2 ff ff       	jmp    801050af <alltraps>

80105e3f <vector224>:
.globl vector224
vector224:
  pushl $0
80105e3f:	6a 00                	push   $0x0
  pushl $224
80105e41:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
80105e46:	e9 64 f2 ff ff       	jmp    801050af <alltraps>

80105e4b <vector225>:
.globl vector225
vector225:
  pushl $0
80105e4b:	6a 00                	push   $0x0
  pushl $225
80105e4d:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
80105e52:	e9 58 f2 ff ff       	jmp    801050af <alltraps>

80105e57 <vector226>:
.globl vector226
vector226:
  pushl $0
80105e57:	6a 00                	push   $0x0
  pushl $226
80105e59:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
80105e5e:	e9 4c f2 ff ff       	jmp    801050af <alltraps>

80105e63 <vector227>:
.globl vector227
vector227:
  pushl $0
80105e63:	6a 00                	push   $0x0
  pushl $227
80105e65:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
80105e6a:	e9 40 f2 ff ff       	jmp    801050af <alltraps>

80105e6f <vector228>:
.globl vector228
vector228:
  pushl $0
80105e6f:	6a 00                	push   $0x0
  pushl $228
80105e71:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
80105e76:	e9 34 f2 ff ff       	jmp    801050af <alltraps>

80105e7b <vector229>:
.globl vector229
vector229:
  pushl $0
80105e7b:	6a 00                	push   $0x0
  pushl $229
80105e7d:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
80105e82:	e9 28 f2 ff ff       	jmp    801050af <alltraps>

80105e87 <vector230>:
.globl vector230
vector230:
  pushl $0
80105e87:	6a 00                	push   $0x0
  pushl $230
80105e89:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80105e8e:	e9 1c f2 ff ff       	jmp    801050af <alltraps>

80105e93 <vector231>:
.globl vector231
vector231:
  pushl $0
80105e93:	6a 00                	push   $0x0
  pushl $231
80105e95:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80105e9a:	e9 10 f2 ff ff       	jmp    801050af <alltraps>

80105e9f <vector232>:
.globl vector232
vector232:
  pushl $0
80105e9f:	6a 00                	push   $0x0
  pushl $232
80105ea1:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80105ea6:	e9 04 f2 ff ff       	jmp    801050af <alltraps>

80105eab <vector233>:
.globl vector233
vector233:
  pushl $0
80105eab:	6a 00                	push   $0x0
  pushl $233
80105ead:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80105eb2:	e9 f8 f1 ff ff       	jmp    801050af <alltraps>

80105eb7 <vector234>:
.globl vector234
vector234:
  pushl $0
80105eb7:	6a 00                	push   $0x0
  pushl $234
80105eb9:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80105ebe:	e9 ec f1 ff ff       	jmp    801050af <alltraps>

80105ec3 <vector235>:
.globl vector235
vector235:
  pushl $0
80105ec3:	6a 00                	push   $0x0
  pushl $235
80105ec5:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80105eca:	e9 e0 f1 ff ff       	jmp    801050af <alltraps>

80105ecf <vector236>:
.globl vector236
vector236:
  pushl $0
80105ecf:	6a 00                	push   $0x0
  pushl $236
80105ed1:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80105ed6:	e9 d4 f1 ff ff       	jmp    801050af <alltraps>

80105edb <vector237>:
.globl vector237
vector237:
  pushl $0
80105edb:	6a 00                	push   $0x0
  pushl $237
80105edd:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80105ee2:	e9 c8 f1 ff ff       	jmp    801050af <alltraps>

80105ee7 <vector238>:
.globl vector238
vector238:
  pushl $0
80105ee7:	6a 00                	push   $0x0
  pushl $238
80105ee9:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80105eee:	e9 bc f1 ff ff       	jmp    801050af <alltraps>

80105ef3 <vector239>:
.globl vector239
vector239:
  pushl $0
80105ef3:	6a 00                	push   $0x0
  pushl $239
80105ef5:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80105efa:	e9 b0 f1 ff ff       	jmp    801050af <alltraps>

80105eff <vector240>:
.globl vector240
vector240:
  pushl $0
80105eff:	6a 00                	push   $0x0
  pushl $240
80105f01:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80105f06:	e9 a4 f1 ff ff       	jmp    801050af <alltraps>

80105f0b <vector241>:
.globl vector241
vector241:
  pushl $0
80105f0b:	6a 00                	push   $0x0
  pushl $241
80105f0d:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80105f12:	e9 98 f1 ff ff       	jmp    801050af <alltraps>

80105f17 <vector242>:
.globl vector242
vector242:
  pushl $0
80105f17:	6a 00                	push   $0x0
  pushl $242
80105f19:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80105f1e:	e9 8c f1 ff ff       	jmp    801050af <alltraps>

80105f23 <vector243>:
.globl vector243
vector243:
  pushl $0
80105f23:	6a 00                	push   $0x0
  pushl $243
80105f25:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80105f2a:	e9 80 f1 ff ff       	jmp    801050af <alltraps>

80105f2f <vector244>:
.globl vector244
vector244:
  pushl $0
80105f2f:	6a 00                	push   $0x0
  pushl $244
80105f31:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80105f36:	e9 74 f1 ff ff       	jmp    801050af <alltraps>

80105f3b <vector245>:
.globl vector245
vector245:
  pushl $0
80105f3b:	6a 00                	push   $0x0
  pushl $245
80105f3d:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80105f42:	e9 68 f1 ff ff       	jmp    801050af <alltraps>

80105f47 <vector246>:
.globl vector246
vector246:
  pushl $0
80105f47:	6a 00                	push   $0x0
  pushl $246
80105f49:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80105f4e:	e9 5c f1 ff ff       	jmp    801050af <alltraps>

80105f53 <vector247>:
.globl vector247
vector247:
  pushl $0
80105f53:	6a 00                	push   $0x0
  pushl $247
80105f55:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80105f5a:	e9 50 f1 ff ff       	jmp    801050af <alltraps>

80105f5f <vector248>:
.globl vector248
vector248:
  pushl $0
80105f5f:	6a 00                	push   $0x0
  pushl $248
80105f61:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80105f66:	e9 44 f1 ff ff       	jmp    801050af <alltraps>

80105f6b <vector249>:
.globl vector249
vector249:
  pushl $0
80105f6b:	6a 00                	push   $0x0
  pushl $249
80105f6d:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80105f72:	e9 38 f1 ff ff       	jmp    801050af <alltraps>

80105f77 <vector250>:
.globl vector250
vector250:
  pushl $0
80105f77:	6a 00                	push   $0x0
  pushl $250
80105f79:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80105f7e:	e9 2c f1 ff ff       	jmp    801050af <alltraps>

80105f83 <vector251>:
.globl vector251
vector251:
  pushl $0
80105f83:	6a 00                	push   $0x0
  pushl $251
80105f85:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80105f8a:	e9 20 f1 ff ff       	jmp    801050af <alltraps>

80105f8f <vector252>:
.globl vector252
vector252:
  pushl $0
80105f8f:	6a 00                	push   $0x0
  pushl $252
80105f91:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80105f96:	e9 14 f1 ff ff       	jmp    801050af <alltraps>

80105f9b <vector253>:
.globl vector253
vector253:
  pushl $0
80105f9b:	6a 00                	push   $0x0
  pushl $253
80105f9d:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80105fa2:	e9 08 f1 ff ff       	jmp    801050af <alltraps>

80105fa7 <vector254>:
.globl vector254
vector254:
  pushl $0
80105fa7:	6a 00                	push   $0x0
  pushl $254
80105fa9:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80105fae:	e9 fc f0 ff ff       	jmp    801050af <alltraps>

80105fb3 <vector255>:
.globl vector255
vector255:
  pushl $0
80105fb3:	6a 00                	push   $0x0
  pushl $255
80105fb5:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80105fba:	e9 f0 f0 ff ff       	jmp    801050af <alltraps>

80105fbf <walkpgdir>:
// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
80105fbf:	55                   	push   %ebp
80105fc0:	89 e5                	mov    %esp,%ebp
80105fc2:	57                   	push   %edi
80105fc3:	56                   	push   %esi
80105fc4:	53                   	push   %ebx
80105fc5:	83 ec 0c             	sub    $0xc,%esp
80105fc8:	89 d6                	mov    %edx,%esi
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
80105fca:	c1 ea 16             	shr    $0x16,%edx
80105fcd:	8d 3c 90             	lea    (%eax,%edx,4),%edi
  if(*pde & PTE_P){
80105fd0:	8b 1f                	mov    (%edi),%ebx
80105fd2:	f6 c3 01             	test   $0x1,%bl
80105fd5:	74 21                	je     80105ff8 <walkpgdir+0x39>
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80105fd7:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80105fdd:	81 c3 00 00 00 80    	add    $0x80000000,%ebx
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
80105fe3:	c1 ee 0a             	shr    $0xa,%esi
80105fe6:	81 e6 fc 0f 00 00    	and    $0xffc,%esi
80105fec:	01 f3                	add    %esi,%ebx
}
80105fee:	89 d8                	mov    %ebx,%eax
80105ff0:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105ff3:	5b                   	pop    %ebx
80105ff4:	5e                   	pop    %esi
80105ff5:	5f                   	pop    %edi
80105ff6:	5d                   	pop    %ebp
80105ff7:	c3                   	ret    
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80105ff8:	85 c9                	test   %ecx,%ecx
80105ffa:	74 2b                	je     80106027 <walkpgdir+0x68>
80105ffc:	e8 5d c1 ff ff       	call   8010215e <kalloc>
80106001:	89 c3                	mov    %eax,%ebx
80106003:	85 c0                	test   %eax,%eax
80106005:	74 e7                	je     80105fee <walkpgdir+0x2f>
    memset(pgtab, 0, PGSIZE);
80106007:	83 ec 04             	sub    $0x4,%esp
8010600a:	68 00 10 00 00       	push   $0x1000
8010600f:	6a 00                	push   $0x0
80106011:	50                   	push   %eax
80106012:	e8 e9 df ff ff       	call   80104000 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106017:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
8010601d:	83 c8 07             	or     $0x7,%eax
80106020:	89 07                	mov    %eax,(%edi)
80106022:	83 c4 10             	add    $0x10,%esp
80106025:	eb bc                	jmp    80105fe3 <walkpgdir+0x24>
      return 0;
80106027:	bb 00 00 00 00       	mov    $0x0,%ebx
8010602c:	eb c0                	jmp    80105fee <walkpgdir+0x2f>

8010602e <mappages>:
// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
8010602e:	55                   	push   %ebp
8010602f:	89 e5                	mov    %esp,%ebp
80106031:	57                   	push   %edi
80106032:	56                   	push   %esi
80106033:	53                   	push   %ebx
80106034:	83 ec 1c             	sub    $0x1c,%esp
80106037:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  char *a, *last;
  pte_t *pte;

  a = (char*)PGROUNDDOWN((uint)va);
8010603a:	89 d0                	mov    %edx,%eax
8010603c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106041:	89 c3                	mov    %eax,%ebx
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106043:	8d 54 0a ff          	lea    -0x1(%edx,%ecx,1),%edx
80106047:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
8010604d:	89 55 e0             	mov    %edx,-0x20(%ebp)
80106050:	8b 7d 08             	mov    0x8(%ebp),%edi
80106053:	29 c7                	sub    %eax,%edi
  for(;;){
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
      return -1;
    if(*pte & PTE_P)
      panic("remap");
    *pte = pa | perm | PTE_P;
80106055:	8b 45 0c             	mov    0xc(%ebp),%eax
80106058:	83 c8 01             	or     $0x1,%eax
8010605b:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010605e:	8d 34 3b             	lea    (%ebx,%edi,1),%esi
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80106061:	b9 01 00 00 00       	mov    $0x1,%ecx
80106066:	89 da                	mov    %ebx,%edx
80106068:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010606b:	e8 4f ff ff ff       	call   80105fbf <walkpgdir>
80106070:	85 c0                	test   %eax,%eax
80106072:	74 24                	je     80106098 <mappages+0x6a>
    if(*pte & PTE_P)
80106074:	f6 00 01             	testb  $0x1,(%eax)
80106077:	75 12                	jne    8010608b <mappages+0x5d>
    *pte = pa | perm | PTE_P;
80106079:	0b 75 dc             	or     -0x24(%ebp),%esi
8010607c:	89 30                	mov    %esi,(%eax)
    if(a == last)
8010607e:	3b 5d e0             	cmp    -0x20(%ebp),%ebx
80106081:	74 22                	je     801060a5 <mappages+0x77>
      break;
    a += PGSIZE;
80106083:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80106089:	eb d3                	jmp    8010605e <mappages+0x30>
      panic("remap");
8010608b:	83 ec 0c             	sub    $0xc,%esp
8010608e:	68 cc 70 10 80       	push   $0x801070cc
80106093:	e8 ac a2 ff ff       	call   80100344 <panic>
      return -1;
80106098:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    pa += PGSIZE;
  }
  return 0;
}
8010609d:	8d 65 f4             	lea    -0xc(%ebp),%esp
801060a0:	5b                   	pop    %ebx
801060a1:	5e                   	pop    %esi
801060a2:	5f                   	pop    %edi
801060a3:	5d                   	pop    %ebp
801060a4:	c3                   	ret    
  return 0;
801060a5:	b8 00 00 00 00       	mov    $0x0,%eax
801060aa:	eb f1                	jmp    8010609d <mappages+0x6f>

801060ac <seginit>:
{
801060ac:	55                   	push   %ebp
801060ad:	89 e5                	mov    %esp,%ebp
801060af:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
801060b2:	e8 73 d2 ff ff       	call   8010332a <cpuid>
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
801060b7:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
801060bd:	66 c7 80 18 28 11 80 	movw   $0xffff,-0x7feed7e8(%eax)
801060c4:	ff ff 
801060c6:	66 c7 80 1a 28 11 80 	movw   $0x0,-0x7feed7e6(%eax)
801060cd:	00 00 
801060cf:	c6 80 1c 28 11 80 00 	movb   $0x0,-0x7feed7e4(%eax)
801060d6:	c6 80 1d 28 11 80 9a 	movb   $0x9a,-0x7feed7e3(%eax)
801060dd:	c6 80 1e 28 11 80 cf 	movb   $0xcf,-0x7feed7e2(%eax)
801060e4:	c6 80 1f 28 11 80 00 	movb   $0x0,-0x7feed7e1(%eax)
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
801060eb:	66 c7 80 20 28 11 80 	movw   $0xffff,-0x7feed7e0(%eax)
801060f2:	ff ff 
801060f4:	66 c7 80 22 28 11 80 	movw   $0x0,-0x7feed7de(%eax)
801060fb:	00 00 
801060fd:	c6 80 24 28 11 80 00 	movb   $0x0,-0x7feed7dc(%eax)
80106104:	c6 80 25 28 11 80 92 	movb   $0x92,-0x7feed7db(%eax)
8010610b:	c6 80 26 28 11 80 cf 	movb   $0xcf,-0x7feed7da(%eax)
80106112:	c6 80 27 28 11 80 00 	movb   $0x0,-0x7feed7d9(%eax)
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80106119:	66 c7 80 28 28 11 80 	movw   $0xffff,-0x7feed7d8(%eax)
80106120:	ff ff 
80106122:	66 c7 80 2a 28 11 80 	movw   $0x0,-0x7feed7d6(%eax)
80106129:	00 00 
8010612b:	c6 80 2c 28 11 80 00 	movb   $0x0,-0x7feed7d4(%eax)
80106132:	c6 80 2d 28 11 80 fa 	movb   $0xfa,-0x7feed7d3(%eax)
80106139:	c6 80 2e 28 11 80 cf 	movb   $0xcf,-0x7feed7d2(%eax)
80106140:	c6 80 2f 28 11 80 00 	movb   $0x0,-0x7feed7d1(%eax)
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80106147:	66 c7 80 30 28 11 80 	movw   $0xffff,-0x7feed7d0(%eax)
8010614e:	ff ff 
80106150:	66 c7 80 32 28 11 80 	movw   $0x0,-0x7feed7ce(%eax)
80106157:	00 00 
80106159:	c6 80 34 28 11 80 00 	movb   $0x0,-0x7feed7cc(%eax)
80106160:	c6 80 35 28 11 80 f2 	movb   $0xf2,-0x7feed7cb(%eax)
80106167:	c6 80 36 28 11 80 cf 	movb   $0xcf,-0x7feed7ca(%eax)
8010616e:	c6 80 37 28 11 80 00 	movb   $0x0,-0x7feed7c9(%eax)
  lgdt(c->gdt, sizeof(c->gdt));
80106175:	05 10 28 11 80       	add    $0x80112810,%eax
  pd[0] = size-1;
8010617a:	66 c7 45 f2 2f 00    	movw   $0x2f,-0xe(%ebp)
  pd[1] = (uint)p;
80106180:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80106184:	c1 e8 10             	shr    $0x10,%eax
80106187:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
8010618b:	8d 45 f2             	lea    -0xe(%ebp),%eax
8010618e:	0f 01 10             	lgdtl  (%eax)
}
80106191:	c9                   	leave  
80106192:	c3                   	ret    

80106193 <switchkvm>:

// Switch h/w page table register to the kernel-only page table,
// for when no process is running.
void
switchkvm(void)
{
80106193:	55                   	push   %ebp
80106194:	89 e5                	mov    %esp,%ebp
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80106196:	a1 c4 57 11 80       	mov    0x801157c4,%eax
8010619b:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
801061a0:	0f 22 d8             	mov    %eax,%cr3
}
801061a3:	5d                   	pop    %ebp
801061a4:	c3                   	ret    

801061a5 <switchuvm>:

// Switch TSS and h/w page table to correspond to process p.
void
switchuvm(struct proc *p)
{
801061a5:	55                   	push   %ebp
801061a6:	89 e5                	mov    %esp,%ebp
801061a8:	57                   	push   %edi
801061a9:	56                   	push   %esi
801061aa:	53                   	push   %ebx
801061ab:	83 ec 1c             	sub    $0x1c,%esp
801061ae:	8b 75 08             	mov    0x8(%ebp),%esi
  if(p == 0)
801061b1:	85 f6                	test   %esi,%esi
801061b3:	0f 84 c3 00 00 00    	je     8010627c <switchuvm+0xd7>
    panic("switchuvm: no process");
  if(p->kstack == 0)
801061b9:	83 7e 08 00          	cmpl   $0x0,0x8(%esi)
801061bd:	0f 84 c6 00 00 00    	je     80106289 <switchuvm+0xe4>
    panic("switchuvm: no kstack");
  if(p->pgdir == 0)
801061c3:	83 7e 04 00          	cmpl   $0x0,0x4(%esi)
801061c7:	0f 84 c9 00 00 00    	je     80106296 <switchuvm+0xf1>
    panic("switchuvm: no pgdir");

  pushcli();
801061cd:	e8 af dc ff ff       	call   80103e81 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
801061d2:	e8 dc d0 ff ff       	call   801032b3 <mycpu>
801061d7:	89 c3                	mov    %eax,%ebx
801061d9:	e8 d5 d0 ff ff       	call   801032b3 <mycpu>
801061de:	89 c7                	mov    %eax,%edi
801061e0:	e8 ce d0 ff ff       	call   801032b3 <mycpu>
801061e5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801061e8:	e8 c6 d0 ff ff       	call   801032b3 <mycpu>
801061ed:	66 c7 83 98 00 00 00 	movw   $0x67,0x98(%ebx)
801061f4:	67 00 
801061f6:	83 c7 08             	add    $0x8,%edi
801061f9:	66 89 bb 9a 00 00 00 	mov    %di,0x9a(%ebx)
80106200:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80106203:	83 c2 08             	add    $0x8,%edx
80106206:	c1 ea 10             	shr    $0x10,%edx
80106209:	88 93 9c 00 00 00    	mov    %dl,0x9c(%ebx)
8010620f:	c6 83 9d 00 00 00 99 	movb   $0x99,0x9d(%ebx)
80106216:	c6 83 9e 00 00 00 40 	movb   $0x40,0x9e(%ebx)
8010621d:	83 c0 08             	add    $0x8,%eax
80106220:	c1 e8 18             	shr    $0x18,%eax
80106223:	88 83 9f 00 00 00    	mov    %al,0x9f(%ebx)
                                sizeof(mycpu()->ts)-1, 0);
  mycpu()->gdt[SEG_TSS].s = 0;
80106229:	e8 85 d0 ff ff       	call   801032b3 <mycpu>
8010622e:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80106235:	e8 79 d0 ff ff       	call   801032b3 <mycpu>
8010623a:	66 c7 40 10 10 00    	movw   $0x10,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80106240:	8b 5e 08             	mov    0x8(%esi),%ebx
80106243:	e8 6b d0 ff ff       	call   801032b3 <mycpu>
80106248:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010624e:	89 58 0c             	mov    %ebx,0xc(%eax)
  // setting IOPL=0 in eflags *and* iomb beyond the tss segment limit
  // forbids I/O instructions (e.g., inb and outb) from user space
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106251:	e8 5d d0 ff ff       	call   801032b3 <mycpu>
80106256:	66 c7 40 6e ff ff    	movw   $0xffff,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
8010625c:	b8 28 00 00 00       	mov    $0x28,%eax
80106261:	0f 00 d8             	ltr    %ax
  ltr(SEG_TSS << 3);
  lcr3(V2P(p->pgdir));  // switch to process's address space
80106264:	8b 46 04             	mov    0x4(%esi),%eax
80106267:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
8010626c:	0f 22 d8             	mov    %eax,%cr3
  popcli();
8010626f:	e8 4a dc ff ff       	call   80103ebe <popcli>
}
80106274:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106277:	5b                   	pop    %ebx
80106278:	5e                   	pop    %esi
80106279:	5f                   	pop    %edi
8010627a:	5d                   	pop    %ebp
8010627b:	c3                   	ret    
    panic("switchuvm: no process");
8010627c:	83 ec 0c             	sub    $0xc,%esp
8010627f:	68 d2 70 10 80       	push   $0x801070d2
80106284:	e8 bb a0 ff ff       	call   80100344 <panic>
    panic("switchuvm: no kstack");
80106289:	83 ec 0c             	sub    $0xc,%esp
8010628c:	68 e8 70 10 80       	push   $0x801070e8
80106291:	e8 ae a0 ff ff       	call   80100344 <panic>
    panic("switchuvm: no pgdir");
80106296:	83 ec 0c             	sub    $0xc,%esp
80106299:	68 fd 70 10 80       	push   $0x801070fd
8010629e:	e8 a1 a0 ff ff       	call   80100344 <panic>

801062a3 <inituvm>:

// Load the initcode into address 0 of pgdir.
// sz must be less than a page.
void
inituvm(pde_t *pgdir, char *init, uint sz)
{
801062a3:	55                   	push   %ebp
801062a4:	89 e5                	mov    %esp,%ebp
801062a6:	56                   	push   %esi
801062a7:	53                   	push   %ebx
801062a8:	8b 75 10             	mov    0x10(%ebp),%esi
  char *mem;

  if(sz >= PGSIZE)
801062ab:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
801062b1:	77 4c                	ja     801062ff <inituvm+0x5c>
    panic("inituvm: more than a page");
  mem = kalloc();
801062b3:	e8 a6 be ff ff       	call   8010215e <kalloc>
801062b8:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
801062ba:	83 ec 04             	sub    $0x4,%esp
801062bd:	68 00 10 00 00       	push   $0x1000
801062c2:	6a 00                	push   $0x0
801062c4:	50                   	push   %eax
801062c5:	e8 36 dd ff ff       	call   80104000 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
801062ca:	83 c4 08             	add    $0x8,%esp
801062cd:	6a 06                	push   $0x6
801062cf:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801062d5:	50                   	push   %eax
801062d6:	b9 00 10 00 00       	mov    $0x1000,%ecx
801062db:	ba 00 00 00 00       	mov    $0x0,%edx
801062e0:	8b 45 08             	mov    0x8(%ebp),%eax
801062e3:	e8 46 fd ff ff       	call   8010602e <mappages>
  memmove(mem, init, sz);
801062e8:	83 c4 0c             	add    $0xc,%esp
801062eb:	56                   	push   %esi
801062ec:	ff 75 0c             	pushl  0xc(%ebp)
801062ef:	53                   	push   %ebx
801062f0:	e8 a0 dd ff ff       	call   80104095 <memmove>
}
801062f5:	83 c4 10             	add    $0x10,%esp
801062f8:	8d 65 f8             	lea    -0x8(%ebp),%esp
801062fb:	5b                   	pop    %ebx
801062fc:	5e                   	pop    %esi
801062fd:	5d                   	pop    %ebp
801062fe:	c3                   	ret    
    panic("inituvm: more than a page");
801062ff:	83 ec 0c             	sub    $0xc,%esp
80106302:	68 11 71 10 80       	push   $0x80107111
80106307:	e8 38 a0 ff ff       	call   80100344 <panic>

8010630c <loaduvm>:

// Load a program segment into pgdir.  addr must be page-aligned
// and the pages from addr to addr+sz must already be mapped.
int
loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz)
{
8010630c:	55                   	push   %ebp
8010630d:	89 e5                	mov    %esp,%ebp
8010630f:	57                   	push   %edi
80106310:	56                   	push   %esi
80106311:	53                   	push   %ebx
80106312:	83 ec 1c             	sub    $0x1c,%esp
80106315:	8b 45 0c             	mov    0xc(%ebp),%eax
  uint i, pa, n;
  pte_t *pte;

  if((uint) addr % PGSIZE != 0)
80106318:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010631b:	a9 ff 0f 00 00       	test   $0xfff,%eax
80106320:	75 71                	jne    80106393 <loaduvm+0x87>
    panic("loaduvm: addr must be page aligned");
  for(i = 0; i < sz; i += PGSIZE){
80106322:	8b 75 18             	mov    0x18(%ebp),%esi
80106325:	bb 00 00 00 00       	mov    $0x0,%ebx
    else
      n = PGSIZE;
    if(readi(ip, P2V(pa), offset+i, n) != n)
      return -1;
  }
  return 0;
8010632a:	b8 00 00 00 00       	mov    $0x0,%eax
  for(i = 0; i < sz; i += PGSIZE){
8010632f:	85 f6                	test   %esi,%esi
80106331:	74 7f                	je     801063b2 <loaduvm+0xa6>
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
80106333:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106336:	8d 14 18             	lea    (%eax,%ebx,1),%edx
80106339:	b9 00 00 00 00       	mov    $0x0,%ecx
8010633e:	8b 45 08             	mov    0x8(%ebp),%eax
80106341:	e8 79 fc ff ff       	call   80105fbf <walkpgdir>
80106346:	85 c0                	test   %eax,%eax
80106348:	74 56                	je     801063a0 <loaduvm+0x94>
    pa = PTE_ADDR(*pte);
8010634a:	8b 00                	mov    (%eax),%eax
8010634c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      n = sz - i;
80106351:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
80106357:	bf 00 10 00 00       	mov    $0x1000,%edi
8010635c:	0f 46 fe             	cmovbe %esi,%edi
    if(readi(ip, P2V(pa), offset+i, n) != n)
8010635f:	57                   	push   %edi
80106360:	89 da                	mov    %ebx,%edx
80106362:	03 55 14             	add    0x14(%ebp),%edx
80106365:	52                   	push   %edx
80106366:	05 00 00 00 80       	add    $0x80000000,%eax
8010636b:	50                   	push   %eax
8010636c:	ff 75 10             	pushl  0x10(%ebp)
8010636f:	e8 06 b4 ff ff       	call   8010177a <readi>
80106374:	83 c4 10             	add    $0x10,%esp
80106377:	39 f8                	cmp    %edi,%eax
80106379:	75 32                	jne    801063ad <loaduvm+0xa1>
  for(i = 0; i < sz; i += PGSIZE){
8010637b:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106381:	81 ee 00 10 00 00    	sub    $0x1000,%esi
80106387:	39 5d 18             	cmp    %ebx,0x18(%ebp)
8010638a:	77 a7                	ja     80106333 <loaduvm+0x27>
  return 0;
8010638c:	b8 00 00 00 00       	mov    $0x0,%eax
80106391:	eb 1f                	jmp    801063b2 <loaduvm+0xa6>
    panic("loaduvm: addr must be page aligned");
80106393:	83 ec 0c             	sub    $0xc,%esp
80106396:	68 cc 71 10 80       	push   $0x801071cc
8010639b:	e8 a4 9f ff ff       	call   80100344 <panic>
      panic("loaduvm: address should exist");
801063a0:	83 ec 0c             	sub    $0xc,%esp
801063a3:	68 2b 71 10 80       	push   $0x8010712b
801063a8:	e8 97 9f ff ff       	call   80100344 <panic>
      return -1;
801063ad:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801063b2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801063b5:	5b                   	pop    %ebx
801063b6:	5e                   	pop    %esi
801063b7:	5f                   	pop    %edi
801063b8:	5d                   	pop    %ebp
801063b9:	c3                   	ret    

801063ba <deallocuvm>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
801063ba:	55                   	push   %ebp
801063bb:	89 e5                	mov    %esp,%ebp
801063bd:	57                   	push   %edi
801063be:	56                   	push   %esi
801063bf:	53                   	push   %ebx
801063c0:	83 ec 0c             	sub    $0xc,%esp
801063c3:	8b 7d 0c             	mov    0xc(%ebp),%edi
  pte_t *pte;
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;
801063c6:	89 f8                	mov    %edi,%eax
  if(newsz >= oldsz)
801063c8:	39 7d 10             	cmp    %edi,0x10(%ebp)
801063cb:	73 16                	jae    801063e3 <deallocuvm+0x29>

  a = PGROUNDUP(newsz);
801063cd:	8b 45 10             	mov    0x10(%ebp),%eax
801063d0:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801063d6:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; a  < oldsz; a += PGSIZE){
801063dc:	39 df                	cmp    %ebx,%edi
801063de:	77 21                	ja     80106401 <deallocuvm+0x47>
      char *v = P2V(pa);
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
801063e0:	8b 45 10             	mov    0x10(%ebp),%eax
}
801063e3:	8d 65 f4             	lea    -0xc(%ebp),%esp
801063e6:	5b                   	pop    %ebx
801063e7:	5e                   	pop    %esi
801063e8:	5f                   	pop    %edi
801063e9:	5d                   	pop    %ebp
801063ea:	c3                   	ret    
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
801063eb:	81 e3 00 00 c0 ff    	and    $0xffc00000,%ebx
801063f1:	81 c3 00 f0 3f 00    	add    $0x3ff000,%ebx
  for(; a  < oldsz; a += PGSIZE){
801063f7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801063fd:	39 df                	cmp    %ebx,%edi
801063ff:	76 df                	jbe    801063e0 <deallocuvm+0x26>
    pte = walkpgdir(pgdir, (char*)a, 0);
80106401:	b9 00 00 00 00       	mov    $0x0,%ecx
80106406:	89 da                	mov    %ebx,%edx
80106408:	8b 45 08             	mov    0x8(%ebp),%eax
8010640b:	e8 af fb ff ff       	call   80105fbf <walkpgdir>
80106410:	89 c6                	mov    %eax,%esi
    if(!pte)
80106412:	85 c0                	test   %eax,%eax
80106414:	74 d5                	je     801063eb <deallocuvm+0x31>
    else if((*pte & PTE_P) != 0){
80106416:	8b 00                	mov    (%eax),%eax
80106418:	a8 01                	test   $0x1,%al
8010641a:	74 db                	je     801063f7 <deallocuvm+0x3d>
      if(pa == 0)
8010641c:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106421:	74 19                	je     8010643c <deallocuvm+0x82>
      kfree(v);
80106423:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
80106426:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
8010642b:	50                   	push   %eax
8010642c:	e8 08 bc ff ff       	call   80102039 <kfree>
      *pte = 0;
80106431:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80106437:	83 c4 10             	add    $0x10,%esp
8010643a:	eb bb                	jmp    801063f7 <deallocuvm+0x3d>
        panic("kfree");
8010643c:	83 ec 0c             	sub    $0xc,%esp
8010643f:	68 66 6a 10 80       	push   $0x80106a66
80106444:	e8 fb 9e ff ff       	call   80100344 <panic>

80106449 <allocuvm>:
{
80106449:	55                   	push   %ebp
8010644a:	89 e5                	mov    %esp,%ebp
8010644c:	57                   	push   %edi
8010644d:	56                   	push   %esi
8010644e:	53                   	push   %ebx
8010644f:	83 ec 1c             	sub    $0x1c,%esp
80106452:	8b 7d 10             	mov    0x10(%ebp),%edi
  if(newsz >= KERNBASE)
80106455:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106458:	85 ff                	test   %edi,%edi
8010645a:	0f 88 c5 00 00 00    	js     80106525 <allocuvm+0xdc>
  if(newsz < oldsz)
80106460:	3b 7d 0c             	cmp    0xc(%ebp),%edi
80106463:	72 60                	jb     801064c5 <allocuvm+0x7c>
  a = PGROUNDUP(oldsz);
80106465:	8b 45 0c             	mov    0xc(%ebp),%eax
80106468:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
8010646e:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; a < newsz; a += PGSIZE){
80106474:	39 df                	cmp    %ebx,%edi
80106476:	0f 86 b0 00 00 00    	jbe    8010652c <allocuvm+0xe3>
    mem = kalloc();
8010647c:	e8 dd bc ff ff       	call   8010215e <kalloc>
80106481:	89 c6                	mov    %eax,%esi
    if(mem == 0){
80106483:	85 c0                	test   %eax,%eax
80106485:	74 46                	je     801064cd <allocuvm+0x84>
    memset(mem, 0, PGSIZE);
80106487:	83 ec 04             	sub    $0x4,%esp
8010648a:	68 00 10 00 00       	push   $0x1000
8010648f:	6a 00                	push   $0x0
80106491:	50                   	push   %eax
80106492:	e8 69 db ff ff       	call   80104000 <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
80106497:	83 c4 08             	add    $0x8,%esp
8010649a:	6a 06                	push   $0x6
8010649c:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
801064a2:	50                   	push   %eax
801064a3:	b9 00 10 00 00       	mov    $0x1000,%ecx
801064a8:	89 da                	mov    %ebx,%edx
801064aa:	8b 45 08             	mov    0x8(%ebp),%eax
801064ad:	e8 7c fb ff ff       	call   8010602e <mappages>
801064b2:	83 c4 10             	add    $0x10,%esp
801064b5:	85 c0                	test   %eax,%eax
801064b7:	78 3c                	js     801064f5 <allocuvm+0xac>
  for(; a < newsz; a += PGSIZE){
801064b9:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801064bf:	39 df                	cmp    %ebx,%edi
801064c1:	77 b9                	ja     8010647c <allocuvm+0x33>
801064c3:	eb 67                	jmp    8010652c <allocuvm+0xe3>
    return oldsz;
801064c5:	8b 45 0c             	mov    0xc(%ebp),%eax
801064c8:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801064cb:	eb 5f                	jmp    8010652c <allocuvm+0xe3>
      cprintf("allocuvm out of memory\n");
801064cd:	83 ec 0c             	sub    $0xc,%esp
801064d0:	68 49 71 10 80       	push   $0x80107149
801064d5:	e8 07 a1 ff ff       	call   801005e1 <cprintf>
      deallocuvm(pgdir, newsz, oldsz);
801064da:	83 c4 0c             	add    $0xc,%esp
801064dd:	ff 75 0c             	pushl  0xc(%ebp)
801064e0:	57                   	push   %edi
801064e1:	ff 75 08             	pushl  0x8(%ebp)
801064e4:	e8 d1 fe ff ff       	call   801063ba <deallocuvm>
      return 0;
801064e9:	83 c4 10             	add    $0x10,%esp
801064ec:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
801064f3:	eb 37                	jmp    8010652c <allocuvm+0xe3>
      cprintf("allocuvm out of memory (2)\n");
801064f5:	83 ec 0c             	sub    $0xc,%esp
801064f8:	68 61 71 10 80       	push   $0x80107161
801064fd:	e8 df a0 ff ff       	call   801005e1 <cprintf>
      deallocuvm(pgdir, newsz, oldsz);
80106502:	83 c4 0c             	add    $0xc,%esp
80106505:	ff 75 0c             	pushl  0xc(%ebp)
80106508:	57                   	push   %edi
80106509:	ff 75 08             	pushl  0x8(%ebp)
8010650c:	e8 a9 fe ff ff       	call   801063ba <deallocuvm>
      kfree(mem);
80106511:	89 34 24             	mov    %esi,(%esp)
80106514:	e8 20 bb ff ff       	call   80102039 <kfree>
      return 0;
80106519:	83 c4 10             	add    $0x10,%esp
8010651c:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80106523:	eb 07                	jmp    8010652c <allocuvm+0xe3>
    return 0;
80106525:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
}
8010652c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010652f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106532:	5b                   	pop    %ebx
80106533:	5e                   	pop    %esi
80106534:	5f                   	pop    %edi
80106535:	5d                   	pop    %ebp
80106536:	c3                   	ret    

80106537 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
80106537:	55                   	push   %ebp
80106538:	89 e5                	mov    %esp,%ebp
8010653a:	57                   	push   %edi
8010653b:	56                   	push   %esi
8010653c:	53                   	push   %ebx
8010653d:	83 ec 0c             	sub    $0xc,%esp
80106540:	8b 7d 08             	mov    0x8(%ebp),%edi
  uint i;

  if(pgdir == 0)
80106543:	85 ff                	test   %edi,%edi
80106545:	74 1d                	je     80106564 <freevm+0x2d>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
80106547:	83 ec 04             	sub    $0x4,%esp
8010654a:	6a 00                	push   $0x0
8010654c:	68 00 00 00 80       	push   $0x80000000
80106551:	57                   	push   %edi
80106552:	e8 63 fe ff ff       	call   801063ba <deallocuvm>
80106557:	89 fb                	mov    %edi,%ebx
80106559:	8d b7 00 10 00 00    	lea    0x1000(%edi),%esi
8010655f:	83 c4 10             	add    $0x10,%esp
80106562:	eb 14                	jmp    80106578 <freevm+0x41>
    panic("freevm: no pgdir");
80106564:	83 ec 0c             	sub    $0xc,%esp
80106567:	68 7d 71 10 80       	push   $0x8010717d
8010656c:	e8 d3 9d ff ff       	call   80100344 <panic>
80106571:	83 c3 04             	add    $0x4,%ebx
  for(i = 0; i < NPDENTRIES; i++){
80106574:	39 f3                	cmp    %esi,%ebx
80106576:	74 1e                	je     80106596 <freevm+0x5f>
    if(pgdir[i] & PTE_P){
80106578:	8b 03                	mov    (%ebx),%eax
8010657a:	a8 01                	test   $0x1,%al
8010657c:	74 f3                	je     80106571 <freevm+0x3a>
      char * v = P2V(PTE_ADDR(pgdir[i]));
      kfree(v);
8010657e:	83 ec 0c             	sub    $0xc,%esp
      char * v = P2V(PTE_ADDR(pgdir[i]));
80106581:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106586:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
8010658b:	50                   	push   %eax
8010658c:	e8 a8 ba ff ff       	call   80102039 <kfree>
80106591:	83 c4 10             	add    $0x10,%esp
80106594:	eb db                	jmp    80106571 <freevm+0x3a>
    }
  }
  kfree((char*)pgdir);
80106596:	83 ec 0c             	sub    $0xc,%esp
80106599:	57                   	push   %edi
8010659a:	e8 9a ba ff ff       	call   80102039 <kfree>
}
8010659f:	83 c4 10             	add    $0x10,%esp
801065a2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801065a5:	5b                   	pop    %ebx
801065a6:	5e                   	pop    %esi
801065a7:	5f                   	pop    %edi
801065a8:	5d                   	pop    %ebp
801065a9:	c3                   	ret    

801065aa <setupkvm>:
{
801065aa:	55                   	push   %ebp
801065ab:	89 e5                	mov    %esp,%ebp
801065ad:	56                   	push   %esi
801065ae:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
801065af:	e8 aa bb ff ff       	call   8010215e <kalloc>
801065b4:	89 c6                	mov    %eax,%esi
801065b6:	85 c0                	test   %eax,%eax
801065b8:	74 42                	je     801065fc <setupkvm+0x52>
  memset(pgdir, 0, PGSIZE);
801065ba:	83 ec 04             	sub    $0x4,%esp
801065bd:	68 00 10 00 00       	push   $0x1000
801065c2:	6a 00                	push   $0x0
801065c4:	50                   	push   %eax
801065c5:	e8 36 da ff ff       	call   80104000 <memset>
801065ca:	83 c4 10             	add    $0x10,%esp
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801065cd:	bb 20 a4 10 80       	mov    $0x8010a420,%ebx
                (uint)k->phys_start, k->perm) < 0) {
801065d2:	8b 43 04             	mov    0x4(%ebx),%eax
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
801065d5:	8b 4b 08             	mov    0x8(%ebx),%ecx
801065d8:	29 c1                	sub    %eax,%ecx
801065da:	83 ec 08             	sub    $0x8,%esp
801065dd:	ff 73 0c             	pushl  0xc(%ebx)
801065e0:	50                   	push   %eax
801065e1:	8b 13                	mov    (%ebx),%edx
801065e3:	89 f0                	mov    %esi,%eax
801065e5:	e8 44 fa ff ff       	call   8010602e <mappages>
801065ea:	83 c4 10             	add    $0x10,%esp
801065ed:	85 c0                	test   %eax,%eax
801065ef:	78 14                	js     80106605 <setupkvm+0x5b>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801065f1:	83 c3 10             	add    $0x10,%ebx
801065f4:	81 fb 60 a4 10 80    	cmp    $0x8010a460,%ebx
801065fa:	75 d6                	jne    801065d2 <setupkvm+0x28>
}
801065fc:	89 f0                	mov    %esi,%eax
801065fe:	8d 65 f8             	lea    -0x8(%ebp),%esp
80106601:	5b                   	pop    %ebx
80106602:	5e                   	pop    %esi
80106603:	5d                   	pop    %ebp
80106604:	c3                   	ret    
      freevm(pgdir);
80106605:	83 ec 0c             	sub    $0xc,%esp
80106608:	56                   	push   %esi
80106609:	e8 29 ff ff ff       	call   80106537 <freevm>
      return 0;
8010660e:	83 c4 10             	add    $0x10,%esp
80106611:	be 00 00 00 00       	mov    $0x0,%esi
80106616:	eb e4                	jmp    801065fc <setupkvm+0x52>

80106618 <kvmalloc>:
{
80106618:	55                   	push   %ebp
80106619:	89 e5                	mov    %esp,%ebp
8010661b:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
8010661e:	e8 87 ff ff ff       	call   801065aa <setupkvm>
80106623:	a3 c4 57 11 80       	mov    %eax,0x801157c4
  switchkvm();
80106628:	e8 66 fb ff ff       	call   80106193 <switchkvm>
}
8010662d:	c9                   	leave  
8010662e:	c3                   	ret    

8010662f <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
8010662f:	55                   	push   %ebp
80106630:	89 e5                	mov    %esp,%ebp
80106632:	83 ec 08             	sub    $0x8,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
80106635:	b9 00 00 00 00       	mov    $0x0,%ecx
8010663a:	8b 55 0c             	mov    0xc(%ebp),%edx
8010663d:	8b 45 08             	mov    0x8(%ebp),%eax
80106640:	e8 7a f9 ff ff       	call   80105fbf <walkpgdir>
  if(pte == 0)
80106645:	85 c0                	test   %eax,%eax
80106647:	74 05                	je     8010664e <clearpteu+0x1f>
    panic("clearpteu");
  *pte &= ~PTE_U;
80106649:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
8010664c:	c9                   	leave  
8010664d:	c3                   	ret    
    panic("clearpteu");
8010664e:	83 ec 0c             	sub    $0xc,%esp
80106651:	68 8e 71 10 80       	push   $0x8010718e
80106656:	e8 e9 9c ff ff       	call   80100344 <panic>

8010665b <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
8010665b:	55                   	push   %ebp
8010665c:	89 e5                	mov    %esp,%ebp
8010665e:	57                   	push   %edi
8010665f:	56                   	push   %esi
80106660:	53                   	push   %ebx
80106661:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
80106664:	e8 41 ff ff ff       	call   801065aa <setupkvm>
80106669:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010666c:	85 c0                	test   %eax,%eax
8010666e:	0f 84 c7 00 00 00    	je     8010673b <copyuvm+0xe0>
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
80106674:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80106678:	0f 84 bd 00 00 00    	je     8010673b <copyuvm+0xe0>
8010667e:	bf 00 00 00 00       	mov    $0x0,%edi
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
80106683:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106686:	b9 00 00 00 00       	mov    $0x0,%ecx
8010668b:	89 fa                	mov    %edi,%edx
8010668d:	8b 45 08             	mov    0x8(%ebp),%eax
80106690:	e8 2a f9 ff ff       	call   80105fbf <walkpgdir>
80106695:	85 c0                	test   %eax,%eax
80106697:	74 67                	je     80106700 <copyuvm+0xa5>
      panic("copyuvm: pte should exist");
    if(!(*pte & PTE_P))
80106699:	8b 00                	mov    (%eax),%eax
8010669b:	a8 01                	test   $0x1,%al
8010669d:	74 6e                	je     8010670d <copyuvm+0xb2>
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
8010669f:	89 c6                	mov    %eax,%esi
801066a1:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
    flags = PTE_FLAGS(*pte);
801066a7:	25 ff 0f 00 00       	and    $0xfff,%eax
801066ac:	89 45 e0             	mov    %eax,-0x20(%ebp)
    if((mem = kalloc()) == 0)
801066af:	e8 aa ba ff ff       	call   8010215e <kalloc>
801066b4:	89 c3                	mov    %eax,%ebx
801066b6:	85 c0                	test   %eax,%eax
801066b8:	74 6c                	je     80106726 <copyuvm+0xcb>
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
801066ba:	83 ec 04             	sub    $0x4,%esp
801066bd:	68 00 10 00 00       	push   $0x1000
801066c2:	81 c6 00 00 00 80    	add    $0x80000000,%esi
801066c8:	56                   	push   %esi
801066c9:	50                   	push   %eax
801066ca:	e8 c6 d9 ff ff       	call   80104095 <memmove>
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
801066cf:	83 c4 08             	add    $0x8,%esp
801066d2:	ff 75 e0             	pushl  -0x20(%ebp)
801066d5:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801066db:	50                   	push   %eax
801066dc:	b9 00 10 00 00       	mov    $0x1000,%ecx
801066e1:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801066e4:	8b 45 dc             	mov    -0x24(%ebp),%eax
801066e7:	e8 42 f9 ff ff       	call   8010602e <mappages>
801066ec:	83 c4 10             	add    $0x10,%esp
801066ef:	85 c0                	test   %eax,%eax
801066f1:	78 27                	js     8010671a <copyuvm+0xbf>
  for(i = 0; i < sz; i += PGSIZE){
801066f3:	81 c7 00 10 00 00    	add    $0x1000,%edi
801066f9:	39 7d 0c             	cmp    %edi,0xc(%ebp)
801066fc:	77 85                	ja     80106683 <copyuvm+0x28>
801066fe:	eb 3b                	jmp    8010673b <copyuvm+0xe0>
      panic("copyuvm: pte should exist");
80106700:	83 ec 0c             	sub    $0xc,%esp
80106703:	68 98 71 10 80       	push   $0x80107198
80106708:	e8 37 9c ff ff       	call   80100344 <panic>
      panic("copyuvm: page not present");
8010670d:	83 ec 0c             	sub    $0xc,%esp
80106710:	68 b2 71 10 80       	push   $0x801071b2
80106715:	e8 2a 9c ff ff       	call   80100344 <panic>
      kfree(mem);
8010671a:	83 ec 0c             	sub    $0xc,%esp
8010671d:	53                   	push   %ebx
8010671e:	e8 16 b9 ff ff       	call   80102039 <kfree>
      goto bad;
80106723:	83 c4 10             	add    $0x10,%esp
    }
  }
  return d;

bad:
  freevm(d);
80106726:	83 ec 0c             	sub    $0xc,%esp
80106729:	ff 75 dc             	pushl  -0x24(%ebp)
8010672c:	e8 06 fe ff ff       	call   80106537 <freevm>
  return 0;
80106731:	83 c4 10             	add    $0x10,%esp
80106734:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
}
8010673b:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010673e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106741:	5b                   	pop    %ebx
80106742:	5e                   	pop    %esi
80106743:	5f                   	pop    %edi
80106744:	5d                   	pop    %ebp
80106745:	c3                   	ret    

80106746 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
80106746:	55                   	push   %ebp
80106747:	89 e5                	mov    %esp,%ebp
80106749:	83 ec 08             	sub    $0x8,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
8010674c:	b9 00 00 00 00       	mov    $0x0,%ecx
80106751:	8b 55 0c             	mov    0xc(%ebp),%edx
80106754:	8b 45 08             	mov    0x8(%ebp),%eax
80106757:	e8 63 f8 ff ff       	call   80105fbf <walkpgdir>
  if((*pte & PTE_P) == 0)
8010675c:	8b 00                	mov    (%eax),%eax
    return 0;
  if((*pte & PTE_U) == 0)
8010675e:	89 c2                	mov    %eax,%edx
80106760:	83 e2 05             	and    $0x5,%edx
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
80106763:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106768:	05 00 00 00 80       	add    $0x80000000,%eax
8010676d:	83 fa 05             	cmp    $0x5,%edx
80106770:	ba 00 00 00 00       	mov    $0x0,%edx
80106775:	0f 45 c2             	cmovne %edx,%eax
}
80106778:	c9                   	leave  
80106779:	c3                   	ret    

8010677a <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
8010677a:	55                   	push   %ebp
8010677b:	89 e5                	mov    %esp,%ebp
8010677d:	57                   	push   %edi
8010677e:	56                   	push   %esi
8010677f:	53                   	push   %ebx
80106780:	83 ec 0c             	sub    $0xc,%esp
80106783:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
80106786:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
8010678a:	74 55                	je     801067e1 <copyout+0x67>
    va0 = (uint)PGROUNDDOWN(va);
8010678c:	89 df                	mov    %ebx,%edi
8010678e:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
    pa0 = uva2ka(pgdir, (char*)va0);
80106794:	83 ec 08             	sub    $0x8,%esp
80106797:	57                   	push   %edi
80106798:	ff 75 08             	pushl  0x8(%ebp)
8010679b:	e8 a6 ff ff ff       	call   80106746 <uva2ka>
    if(pa0 == 0)
801067a0:	83 c4 10             	add    $0x10,%esp
801067a3:	85 c0                	test   %eax,%eax
801067a5:	74 41                	je     801067e8 <copyout+0x6e>
      return -1;
    n = PGSIZE - (va - va0);
801067a7:	89 fe                	mov    %edi,%esi
801067a9:	29 de                	sub    %ebx,%esi
801067ab:	81 c6 00 10 00 00    	add    $0x1000,%esi
801067b1:	3b 75 14             	cmp    0x14(%ebp),%esi
801067b4:	0f 47 75 14          	cmova  0x14(%ebp),%esi
    if(n > len)
      n = len;
    memmove(pa0 + (va - va0), buf, n);
801067b8:	83 ec 04             	sub    $0x4,%esp
801067bb:	56                   	push   %esi
801067bc:	ff 75 10             	pushl  0x10(%ebp)
801067bf:	29 fb                	sub    %edi,%ebx
801067c1:	01 d8                	add    %ebx,%eax
801067c3:	50                   	push   %eax
801067c4:	e8 cc d8 ff ff       	call   80104095 <memmove>
    len -= n;
    buf += n;
801067c9:	01 75 10             	add    %esi,0x10(%ebp)
    va = va0 + PGSIZE;
801067cc:	8d 9f 00 10 00 00    	lea    0x1000(%edi),%ebx
  while(len > 0){
801067d2:	83 c4 10             	add    $0x10,%esp
801067d5:	29 75 14             	sub    %esi,0x14(%ebp)
801067d8:	75 b2                	jne    8010678c <copyout+0x12>
  }
  return 0;
801067da:	b8 00 00 00 00       	mov    $0x0,%eax
801067df:	eb 0c                	jmp    801067ed <copyout+0x73>
801067e1:	b8 00 00 00 00       	mov    $0x0,%eax
801067e6:	eb 05                	jmp    801067ed <copyout+0x73>
      return -1;
801067e8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801067ed:	8d 65 f4             	lea    -0xc(%ebp),%esp
801067f0:	5b                   	pop    %ebx
801067f1:	5e                   	pop    %esi
801067f2:	5f                   	pop    %edi
801067f3:	5d                   	pop    %ebp
801067f4:	c3                   	ret    
