
user/_test_aging:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#define INNER_LOOP 1000000
#define OUTER_LOOP 100
#define PI 3.14

int main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	56                   	push   %esi
   e:	53                   	push   %ebx
   f:	51                   	push   %ecx
  10:	83 ec 1c             	sub    $0x1c,%esp
    int pid = getpid();
  13:	e8 34 03 00 00       	call   34c <getpid>
    float dummy = 0;
    int i, j;

    printf(1, "=== AGING TEST START ===\n");
  18:	83 ec 08             	sub    $0x8,%esp
  1b:	68 18 07 00 00       	push   $0x718
  20:	6a 01                	push   $0x1
  22:	e8 d7 03 00 00       	call   3fe <printf>

    pid = fork_rt(20);  // RT 프로세스 [P1]
  27:	c7 04 24 14 00 00 00 	movl   $0x14,(%esp)
  2e:	e8 39 03 00 00       	call   36c <fork_rt>
  33:	89 c6                	mov    %eax,%esi
    if (pid == 0)
  35:	83 c4 10             	add    $0x10,%esp
    {
        // RT 프로세스 [P1] - 100틱 넘으면 강등됨
        for (i = 0; i < OUTER_LOOP; i++)
  38:	89 c3                	mov    %eax,%ebx
    float dummy = 0;
  3a:	d9 ee                	fldz   
  3c:	d9 5d e0             	fstps  -0x20(%ebp)
    if (pid == 0)
  3f:	85 c0                	test   %eax,%eax
  41:	74 2f                	je     72 <main+0x72>
                dummy += PI * j;
            printf(1, "P1 (rt), i = %d, dummy = %x\n", i, dummy);
        }
        exit();
    }
    int rr_pid1 = fork();  // [P2] RR
  43:	e8 7c 02 00 00       	call   2c4 <fork>
  48:	89 c3                	mov    %eax,%ebx
    if (rr_pid1 == 0)
  4a:	85 c0                	test   %eax,%eax
  4c:	75 6c                	jne    ba <main+0xba>
    {
        for (i = 0; i < 20; i++)
        {
            printf(1, "P2 (rr), i = %d, dummy = %x\n", i, dummy);
  4e:	83 ec 0c             	sub    $0xc,%esp
  51:	6a 00                	push   $0x0
  53:	6a 00                	push   $0x0
  55:	53                   	push   %ebx
  56:	68 4f 07 00 00       	push   $0x74f
  5b:	6a 01                	push   $0x1
  5d:	e8 9c 03 00 00       	call   3fe <printf>
        for (i = 0; i < 20; i++)
  62:	83 c3 01             	add    $0x1,%ebx
  65:	83 c4 20             	add    $0x20,%esp
  68:	83 fb 14             	cmp    $0x14,%ebx
  6b:	75 e1                	jne    4e <main+0x4e>
        }
        exit();
  6d:	e8 5a 02 00 00       	call   2cc <exit>
            for (j = 0; j < INNER_LOOP; j++)
  72:	89 f0                	mov    %esi,%eax
                dummy += PI * j;
  74:	dd 05 a0 07 00 00    	fldl   0x7a0
  7a:	89 45 dc             	mov    %eax,-0x24(%ebp)
  7d:	db 45 dc             	fildl  -0x24(%ebp)
  80:	d8 c9                	fmul   %st(1),%st
  82:	d8 45 e0             	fadds  -0x20(%ebp)
  85:	d9 5d e0             	fstps  -0x20(%ebp)
            for (j = 0; j < INNER_LOOP; j++)
  88:	83 c0 01             	add    $0x1,%eax
  8b:	3d 40 42 0f 00       	cmp    $0xf4240,%eax
  90:	75 e8                	jne    7a <main+0x7a>
  92:	dd d8                	fstp   %st(0)
            printf(1, "P1 (rt), i = %d, dummy = %x\n", i, dummy);
  94:	83 ec 14             	sub    $0x14,%esp
  97:	d9 45 e0             	flds   -0x20(%ebp)
  9a:	dd 1c 24             	fstpl  (%esp)
  9d:	53                   	push   %ebx
  9e:	68 32 07 00 00       	push   $0x732
  a3:	6a 01                	push   $0x1
  a5:	e8 54 03 00 00       	call   3fe <printf>
        for (i = 0; i < OUTER_LOOP; i++)
  aa:	83 c3 01             	add    $0x1,%ebx
  ad:	83 c4 20             	add    $0x20,%esp
  b0:	83 fb 64             	cmp    $0x64,%ebx
  b3:	75 bd                	jne    72 <main+0x72>
        exit();
  b5:	e8 12 02 00 00       	call   2cc <exit>
    }

    int rr_pid2 = fork();  // [P3] RR
  ba:	e8 05 02 00 00       	call   2c4 <fork>
  bf:	89 c3                	mov    %eax,%ebx
    if (rr_pid2 == 0)
  c1:	85 c0                	test   %eax,%eax
  c3:	75 24                	jne    e9 <main+0xe9>
    {
        for (i = 0; i < 20; i++)
        {
            printf(1, "P3 (rr), i = %d, dummy = %x\n", i, dummy);
  c5:	83 ec 0c             	sub    $0xc,%esp
  c8:	6a 00                	push   $0x0
  ca:	6a 00                	push   $0x0
  cc:	53                   	push   %ebx
  cd:	68 6c 07 00 00       	push   $0x76c
  d2:	6a 01                	push   $0x1
  d4:	e8 25 03 00 00       	call   3fe <printf>
        for (i = 0; i < 20; i++)
  d9:	83 c3 01             	add    $0x1,%ebx
  dc:	83 c4 20             	add    $0x20,%esp
  df:	83 fb 14             	cmp    $0x14,%ebx
  e2:	75 e1                	jne    c5 <main+0xc5>
        }
        exit();
  e4:	e8 e3 01 00 00       	call   2cc <exit>
    }
    wait();
  e9:	e8 e6 01 00 00       	call   2d4 <wait>
    wait();
  ee:	e8 e1 01 00 00       	call   2d4 <wait>
    wait();
  f3:	e8 dc 01 00 00       	call   2d4 <wait>
    printf(1, "=== TEST DONE ===\n");
  f8:	83 ec 08             	sub    $0x8,%esp
  fb:	68 89 07 00 00       	push   $0x789
 100:	6a 01                	push   $0x1
 102:	e8 f7 02 00 00       	call   3fe <printf>
    exit();
 107:	e8 c0 01 00 00       	call   2cc <exit>

0000010c <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 10c:	55                   	push   %ebp
 10d:	89 e5                	mov    %esp,%ebp
 10f:	53                   	push   %ebx
 110:	8b 45 08             	mov    0x8(%ebp),%eax
 113:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 116:	89 c2                	mov    %eax,%edx
 118:	83 c1 01             	add    $0x1,%ecx
 11b:	83 c2 01             	add    $0x1,%edx
 11e:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 122:	88 5a ff             	mov    %bl,-0x1(%edx)
 125:	84 db                	test   %bl,%bl
 127:	75 ef                	jne    118 <strcpy+0xc>
    ;
  return os;
}
 129:	5b                   	pop    %ebx
 12a:	5d                   	pop    %ebp
 12b:	c3                   	ret    

0000012c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 12c:	55                   	push   %ebp
 12d:	89 e5                	mov    %esp,%ebp
 12f:	8b 4d 08             	mov    0x8(%ebp),%ecx
 132:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 135:	0f b6 01             	movzbl (%ecx),%eax
 138:	84 c0                	test   %al,%al
 13a:	74 15                	je     151 <strcmp+0x25>
 13c:	3a 02                	cmp    (%edx),%al
 13e:	75 11                	jne    151 <strcmp+0x25>
    p++, q++;
 140:	83 c1 01             	add    $0x1,%ecx
 143:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 146:	0f b6 01             	movzbl (%ecx),%eax
 149:	84 c0                	test   %al,%al
 14b:	74 04                	je     151 <strcmp+0x25>
 14d:	3a 02                	cmp    (%edx),%al
 14f:	74 ef                	je     140 <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
 151:	0f b6 c0             	movzbl %al,%eax
 154:	0f b6 12             	movzbl (%edx),%edx
 157:	29 d0                	sub    %edx,%eax
}
 159:	5d                   	pop    %ebp
 15a:	c3                   	ret    

0000015b <strlen>:

uint
strlen(const char *s)
{
 15b:	55                   	push   %ebp
 15c:	89 e5                	mov    %esp,%ebp
 15e:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 161:	80 39 00             	cmpb   $0x0,(%ecx)
 164:	74 12                	je     178 <strlen+0x1d>
 166:	ba 00 00 00 00       	mov    $0x0,%edx
 16b:	83 c2 01             	add    $0x1,%edx
 16e:	89 d0                	mov    %edx,%eax
 170:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 174:	75 f5                	jne    16b <strlen+0x10>
    ;
  return n;
}
 176:	5d                   	pop    %ebp
 177:	c3                   	ret    
  for(n = 0; s[n]; n++)
 178:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 17d:	eb f7                	jmp    176 <strlen+0x1b>

0000017f <memset>:

void*
memset(void *dst, int c, uint n)
{
 17f:	55                   	push   %ebp
 180:	89 e5                	mov    %esp,%ebp
 182:	57                   	push   %edi
 183:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 186:	89 d7                	mov    %edx,%edi
 188:	8b 4d 10             	mov    0x10(%ebp),%ecx
 18b:	8b 45 0c             	mov    0xc(%ebp),%eax
 18e:	fc                   	cld    
 18f:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 191:	89 d0                	mov    %edx,%eax
 193:	5f                   	pop    %edi
 194:	5d                   	pop    %ebp
 195:	c3                   	ret    

00000196 <strchr>:

char*
strchr(const char *s, char c)
{
 196:	55                   	push   %ebp
 197:	89 e5                	mov    %esp,%ebp
 199:	53                   	push   %ebx
 19a:	8b 45 08             	mov    0x8(%ebp),%eax
 19d:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 1a0:	0f b6 10             	movzbl (%eax),%edx
 1a3:	84 d2                	test   %dl,%dl
 1a5:	74 1e                	je     1c5 <strchr+0x2f>
 1a7:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 1a9:	38 d3                	cmp    %dl,%bl
 1ab:	74 15                	je     1c2 <strchr+0x2c>
  for(; *s; s++)
 1ad:	83 c0 01             	add    $0x1,%eax
 1b0:	0f b6 10             	movzbl (%eax),%edx
 1b3:	84 d2                	test   %dl,%dl
 1b5:	74 06                	je     1bd <strchr+0x27>
    if(*s == c)
 1b7:	38 ca                	cmp    %cl,%dl
 1b9:	75 f2                	jne    1ad <strchr+0x17>
 1bb:	eb 05                	jmp    1c2 <strchr+0x2c>
      return (char*)s;
  return 0;
 1bd:	b8 00 00 00 00       	mov    $0x0,%eax
}
 1c2:	5b                   	pop    %ebx
 1c3:	5d                   	pop    %ebp
 1c4:	c3                   	ret    
  return 0;
 1c5:	b8 00 00 00 00       	mov    $0x0,%eax
 1ca:	eb f6                	jmp    1c2 <strchr+0x2c>

000001cc <gets>:

char*
gets(char *buf, int max)
{
 1cc:	55                   	push   %ebp
 1cd:	89 e5                	mov    %esp,%ebp
 1cf:	57                   	push   %edi
 1d0:	56                   	push   %esi
 1d1:	53                   	push   %ebx
 1d2:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1d5:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 1da:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 1dd:	8d 5e 01             	lea    0x1(%esi),%ebx
 1e0:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1e3:	7d 2b                	jge    210 <gets+0x44>
    cc = read(0, &c, 1);
 1e5:	83 ec 04             	sub    $0x4,%esp
 1e8:	6a 01                	push   $0x1
 1ea:	57                   	push   %edi
 1eb:	6a 00                	push   $0x0
 1ed:	e8 f2 00 00 00       	call   2e4 <read>
    if(cc < 1)
 1f2:	83 c4 10             	add    $0x10,%esp
 1f5:	85 c0                	test   %eax,%eax
 1f7:	7e 17                	jle    210 <gets+0x44>
      break;
    buf[i++] = c;
 1f9:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 1fd:	8b 55 08             	mov    0x8(%ebp),%edx
 200:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 204:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 206:	3c 0a                	cmp    $0xa,%al
 208:	74 04                	je     20e <gets+0x42>
 20a:	3c 0d                	cmp    $0xd,%al
 20c:	75 cf                	jne    1dd <gets+0x11>
  for(i=0; i+1 < max; ){
 20e:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 210:	8b 45 08             	mov    0x8(%ebp),%eax
 213:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 217:	8d 65 f4             	lea    -0xc(%ebp),%esp
 21a:	5b                   	pop    %ebx
 21b:	5e                   	pop    %esi
 21c:	5f                   	pop    %edi
 21d:	5d                   	pop    %ebp
 21e:	c3                   	ret    

0000021f <stat>:

int
stat(const char *n, struct stat *st)
{
 21f:	55                   	push   %ebp
 220:	89 e5                	mov    %esp,%ebp
 222:	56                   	push   %esi
 223:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 224:	83 ec 08             	sub    $0x8,%esp
 227:	6a 00                	push   $0x0
 229:	ff 75 08             	pushl  0x8(%ebp)
 22c:	e8 db 00 00 00       	call   30c <open>
  if(fd < 0)
 231:	83 c4 10             	add    $0x10,%esp
 234:	85 c0                	test   %eax,%eax
 236:	78 24                	js     25c <stat+0x3d>
 238:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 23a:	83 ec 08             	sub    $0x8,%esp
 23d:	ff 75 0c             	pushl  0xc(%ebp)
 240:	50                   	push   %eax
 241:	e8 de 00 00 00       	call   324 <fstat>
 246:	89 c6                	mov    %eax,%esi
  close(fd);
 248:	89 1c 24             	mov    %ebx,(%esp)
 24b:	e8 a4 00 00 00       	call   2f4 <close>
  return r;
 250:	83 c4 10             	add    $0x10,%esp
}
 253:	89 f0                	mov    %esi,%eax
 255:	8d 65 f8             	lea    -0x8(%ebp),%esp
 258:	5b                   	pop    %ebx
 259:	5e                   	pop    %esi
 25a:	5d                   	pop    %ebp
 25b:	c3                   	ret    
    return -1;
 25c:	be ff ff ff ff       	mov    $0xffffffff,%esi
 261:	eb f0                	jmp    253 <stat+0x34>

00000263 <atoi>:

int
atoi(const char *s)
{
 263:	55                   	push   %ebp
 264:	89 e5                	mov    %esp,%ebp
 266:	53                   	push   %ebx
 267:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 26a:	0f b6 11             	movzbl (%ecx),%edx
 26d:	8d 42 d0             	lea    -0x30(%edx),%eax
 270:	3c 09                	cmp    $0x9,%al
 272:	77 20                	ja     294 <atoi+0x31>
  n = 0;
 274:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 279:	83 c1 01             	add    $0x1,%ecx
 27c:	8d 04 80             	lea    (%eax,%eax,4),%eax
 27f:	0f be d2             	movsbl %dl,%edx
 282:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 286:	0f b6 11             	movzbl (%ecx),%edx
 289:	8d 5a d0             	lea    -0x30(%edx),%ebx
 28c:	80 fb 09             	cmp    $0x9,%bl
 28f:	76 e8                	jbe    279 <atoi+0x16>
  return n;
}
 291:	5b                   	pop    %ebx
 292:	5d                   	pop    %ebp
 293:	c3                   	ret    
  n = 0;
 294:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 299:	eb f6                	jmp    291 <atoi+0x2e>

0000029b <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 29b:	55                   	push   %ebp
 29c:	89 e5                	mov    %esp,%ebp
 29e:	56                   	push   %esi
 29f:	53                   	push   %ebx
 2a0:	8b 45 08             	mov    0x8(%ebp),%eax
 2a3:	8b 75 0c             	mov    0xc(%ebp),%esi
 2a6:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 2a9:	85 db                	test   %ebx,%ebx
 2ab:	7e 13                	jle    2c0 <memmove+0x25>
 2ad:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 2b2:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 2b6:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 2b9:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 2bc:	39 d3                	cmp    %edx,%ebx
 2be:	75 f2                	jne    2b2 <memmove+0x17>
  return vdst;
}
 2c0:	5b                   	pop    %ebx
 2c1:	5e                   	pop    %esi
 2c2:	5d                   	pop    %ebp
 2c3:	c3                   	ret    

000002c4 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2c4:	b8 01 00 00 00       	mov    $0x1,%eax
 2c9:	cd 40                	int    $0x40
 2cb:	c3                   	ret    

000002cc <exit>:
SYSCALL(exit)
 2cc:	b8 02 00 00 00       	mov    $0x2,%eax
 2d1:	cd 40                	int    $0x40
 2d3:	c3                   	ret    

000002d4 <wait>:
SYSCALL(wait)
 2d4:	b8 03 00 00 00       	mov    $0x3,%eax
 2d9:	cd 40                	int    $0x40
 2db:	c3                   	ret    

000002dc <pipe>:
SYSCALL(pipe)
 2dc:	b8 04 00 00 00       	mov    $0x4,%eax
 2e1:	cd 40                	int    $0x40
 2e3:	c3                   	ret    

000002e4 <read>:
SYSCALL(read)
 2e4:	b8 05 00 00 00       	mov    $0x5,%eax
 2e9:	cd 40                	int    $0x40
 2eb:	c3                   	ret    

000002ec <write>:
SYSCALL(write)
 2ec:	b8 10 00 00 00       	mov    $0x10,%eax
 2f1:	cd 40                	int    $0x40
 2f3:	c3                   	ret    

000002f4 <close>:
SYSCALL(close)
 2f4:	b8 15 00 00 00       	mov    $0x15,%eax
 2f9:	cd 40                	int    $0x40
 2fb:	c3                   	ret    

000002fc <kill>:
SYSCALL(kill)
 2fc:	b8 06 00 00 00       	mov    $0x6,%eax
 301:	cd 40                	int    $0x40
 303:	c3                   	ret    

00000304 <exec>:
SYSCALL(exec)
 304:	b8 07 00 00 00       	mov    $0x7,%eax
 309:	cd 40                	int    $0x40
 30b:	c3                   	ret    

0000030c <open>:
SYSCALL(open)
 30c:	b8 0f 00 00 00       	mov    $0xf,%eax
 311:	cd 40                	int    $0x40
 313:	c3                   	ret    

00000314 <mknod>:
SYSCALL(mknod)
 314:	b8 11 00 00 00       	mov    $0x11,%eax
 319:	cd 40                	int    $0x40
 31b:	c3                   	ret    

0000031c <unlink>:
SYSCALL(unlink)
 31c:	b8 12 00 00 00       	mov    $0x12,%eax
 321:	cd 40                	int    $0x40
 323:	c3                   	ret    

00000324 <fstat>:
SYSCALL(fstat)
 324:	b8 08 00 00 00       	mov    $0x8,%eax
 329:	cd 40                	int    $0x40
 32b:	c3                   	ret    

0000032c <link>:
SYSCALL(link)
 32c:	b8 13 00 00 00       	mov    $0x13,%eax
 331:	cd 40                	int    $0x40
 333:	c3                   	ret    

00000334 <mkdir>:
SYSCALL(mkdir)
 334:	b8 14 00 00 00       	mov    $0x14,%eax
 339:	cd 40                	int    $0x40
 33b:	c3                   	ret    

0000033c <chdir>:
SYSCALL(chdir)
 33c:	b8 09 00 00 00       	mov    $0x9,%eax
 341:	cd 40                	int    $0x40
 343:	c3                   	ret    

00000344 <dup>:
SYSCALL(dup)
 344:	b8 0a 00 00 00       	mov    $0xa,%eax
 349:	cd 40                	int    $0x40
 34b:	c3                   	ret    

0000034c <getpid>:
SYSCALL(getpid)
 34c:	b8 0b 00 00 00       	mov    $0xb,%eax
 351:	cd 40                	int    $0x40
 353:	c3                   	ret    

00000354 <sbrk>:
SYSCALL(sbrk)
 354:	b8 0c 00 00 00       	mov    $0xc,%eax
 359:	cd 40                	int    $0x40
 35b:	c3                   	ret    

0000035c <sleep>:
SYSCALL(sleep)
 35c:	b8 0d 00 00 00       	mov    $0xd,%eax
 361:	cd 40                	int    $0x40
 363:	c3                   	ret    

00000364 <uptime>:
SYSCALL(uptime)
 364:	b8 0e 00 00 00       	mov    $0xe,%eax
 369:	cd 40                	int    $0x40
 36b:	c3                   	ret    

0000036c <fork_rt>:
SYSCALL(fork_rt)
 36c:	b8 16 00 00 00       	mov    $0x16,%eax
 371:	cd 40                	int    $0x40
 373:	c3                   	ret    

00000374 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 374:	55                   	push   %ebp
 375:	89 e5                	mov    %esp,%ebp
 377:	57                   	push   %edi
 378:	56                   	push   %esi
 379:	53                   	push   %ebx
 37a:	83 ec 3c             	sub    $0x3c,%esp
 37d:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 37f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 383:	74 14                	je     399 <printint+0x25>
 385:	85 d2                	test   %edx,%edx
 387:	79 10                	jns    399 <printint+0x25>
    neg = 1;
    x = -xx;
 389:	f7 da                	neg    %edx
    neg = 1;
 38b:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 392:	bf 00 00 00 00       	mov    $0x0,%edi
 397:	eb 0b                	jmp    3a4 <printint+0x30>
  neg = 0;
 399:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 3a0:	eb f0                	jmp    392 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 3a2:	89 df                	mov    %ebx,%edi
 3a4:	8d 5f 01             	lea    0x1(%edi),%ebx
 3a7:	89 d0                	mov    %edx,%eax
 3a9:	ba 00 00 00 00       	mov    $0x0,%edx
 3ae:	f7 f1                	div    %ecx
 3b0:	0f b6 92 b0 07 00 00 	movzbl 0x7b0(%edx),%edx
 3b7:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 3bb:	89 c2                	mov    %eax,%edx
 3bd:	85 c0                	test   %eax,%eax
 3bf:	75 e1                	jne    3a2 <printint+0x2e>
  if(neg)
 3c1:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 3c5:	74 08                	je     3cf <printint+0x5b>
    buf[i++] = '-';
 3c7:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 3cc:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 3cf:	83 eb 01             	sub    $0x1,%ebx
 3d2:	78 22                	js     3f6 <printint+0x82>
  write(fd, &c, 1);
 3d4:	8d 7d d7             	lea    -0x29(%ebp),%edi
 3d7:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 3dc:	88 45 d7             	mov    %al,-0x29(%ebp)
 3df:	83 ec 04             	sub    $0x4,%esp
 3e2:	6a 01                	push   $0x1
 3e4:	57                   	push   %edi
 3e5:	56                   	push   %esi
 3e6:	e8 01 ff ff ff       	call   2ec <write>
  while(--i >= 0)
 3eb:	83 eb 01             	sub    $0x1,%ebx
 3ee:	83 c4 10             	add    $0x10,%esp
 3f1:	83 fb ff             	cmp    $0xffffffff,%ebx
 3f4:	75 e1                	jne    3d7 <printint+0x63>
    putc(fd, buf[i]);
}
 3f6:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3f9:	5b                   	pop    %ebx
 3fa:	5e                   	pop    %esi
 3fb:	5f                   	pop    %edi
 3fc:	5d                   	pop    %ebp
 3fd:	c3                   	ret    

000003fe <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 3fe:	55                   	push   %ebp
 3ff:	89 e5                	mov    %esp,%ebp
 401:	57                   	push   %edi
 402:	56                   	push   %esi
 403:	53                   	push   %ebx
 404:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 407:	8b 75 0c             	mov    0xc(%ebp),%esi
 40a:	0f b6 1e             	movzbl (%esi),%ebx
 40d:	84 db                	test   %bl,%bl
 40f:	0f 84 b1 01 00 00    	je     5c6 <printf+0x1c8>
 415:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 418:	8d 45 10             	lea    0x10(%ebp),%eax
 41b:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 41e:	bf 00 00 00 00       	mov    $0x0,%edi
 423:	eb 2d                	jmp    452 <printf+0x54>
 425:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 428:	83 ec 04             	sub    $0x4,%esp
 42b:	6a 01                	push   $0x1
 42d:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 430:	50                   	push   %eax
 431:	ff 75 08             	pushl  0x8(%ebp)
 434:	e8 b3 fe ff ff       	call   2ec <write>
 439:	83 c4 10             	add    $0x10,%esp
 43c:	eb 05                	jmp    443 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 43e:	83 ff 25             	cmp    $0x25,%edi
 441:	74 22                	je     465 <printf+0x67>
 443:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 446:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 44a:	84 db                	test   %bl,%bl
 44c:	0f 84 74 01 00 00    	je     5c6 <printf+0x1c8>
    c = fmt[i] & 0xff;
 452:	0f be d3             	movsbl %bl,%edx
 455:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 458:	85 ff                	test   %edi,%edi
 45a:	75 e2                	jne    43e <printf+0x40>
      if(c == '%'){
 45c:	83 f8 25             	cmp    $0x25,%eax
 45f:	75 c4                	jne    425 <printf+0x27>
        state = '%';
 461:	89 c7                	mov    %eax,%edi
 463:	eb de                	jmp    443 <printf+0x45>
      if(c == 'd'){
 465:	83 f8 64             	cmp    $0x64,%eax
 468:	74 59                	je     4c3 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 46a:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 470:	83 fa 70             	cmp    $0x70,%edx
 473:	74 7a                	je     4ef <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 475:	83 f8 73             	cmp    $0x73,%eax
 478:	0f 84 9d 00 00 00    	je     51b <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 47e:	83 f8 63             	cmp    $0x63,%eax
 481:	0f 84 f2 00 00 00    	je     579 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 487:	83 f8 25             	cmp    $0x25,%eax
 48a:	0f 84 15 01 00 00    	je     5a5 <printf+0x1a7>
 490:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 494:	83 ec 04             	sub    $0x4,%esp
 497:	6a 01                	push   $0x1
 499:	8d 45 e7             	lea    -0x19(%ebp),%eax
 49c:	50                   	push   %eax
 49d:	ff 75 08             	pushl  0x8(%ebp)
 4a0:	e8 47 fe ff ff       	call   2ec <write>
 4a5:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 4a8:	83 c4 0c             	add    $0xc,%esp
 4ab:	6a 01                	push   $0x1
 4ad:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 4b0:	50                   	push   %eax
 4b1:	ff 75 08             	pushl  0x8(%ebp)
 4b4:	e8 33 fe ff ff       	call   2ec <write>
 4b9:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 4bc:	bf 00 00 00 00       	mov    $0x0,%edi
 4c1:	eb 80                	jmp    443 <printf+0x45>
        printint(fd, *ap, 10, 1);
 4c3:	83 ec 0c             	sub    $0xc,%esp
 4c6:	6a 01                	push   $0x1
 4c8:	b9 0a 00 00 00       	mov    $0xa,%ecx
 4cd:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4d0:	8b 17                	mov    (%edi),%edx
 4d2:	8b 45 08             	mov    0x8(%ebp),%eax
 4d5:	e8 9a fe ff ff       	call   374 <printint>
        ap++;
 4da:	89 f8                	mov    %edi,%eax
 4dc:	83 c0 04             	add    $0x4,%eax
 4df:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4e2:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4e5:	bf 00 00 00 00       	mov    $0x0,%edi
 4ea:	e9 54 ff ff ff       	jmp    443 <printf+0x45>
        printint(fd, *ap, 16, 0);
 4ef:	83 ec 0c             	sub    $0xc,%esp
 4f2:	6a 00                	push   $0x0
 4f4:	b9 10 00 00 00       	mov    $0x10,%ecx
 4f9:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4fc:	8b 17                	mov    (%edi),%edx
 4fe:	8b 45 08             	mov    0x8(%ebp),%eax
 501:	e8 6e fe ff ff       	call   374 <printint>
        ap++;
 506:	89 f8                	mov    %edi,%eax
 508:	83 c0 04             	add    $0x4,%eax
 50b:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 50e:	83 c4 10             	add    $0x10,%esp
      state = 0;
 511:	bf 00 00 00 00       	mov    $0x0,%edi
 516:	e9 28 ff ff ff       	jmp    443 <printf+0x45>
        s = (char*)*ap;
 51b:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 51e:	8b 01                	mov    (%ecx),%eax
        ap++;
 520:	83 c1 04             	add    $0x4,%ecx
 523:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 526:	85 c0                	test   %eax,%eax
 528:	74 13                	je     53d <printf+0x13f>
        s = (char*)*ap;
 52a:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 52c:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 52f:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 534:	84 c0                	test   %al,%al
 536:	75 0f                	jne    547 <printf+0x149>
 538:	e9 06 ff ff ff       	jmp    443 <printf+0x45>
          s = "(null)";
 53d:	bb a8 07 00 00       	mov    $0x7a8,%ebx
        while(*s != 0){
 542:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 547:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 54a:	89 75 d0             	mov    %esi,-0x30(%ebp)
 54d:	8b 75 08             	mov    0x8(%ebp),%esi
 550:	88 45 e3             	mov    %al,-0x1d(%ebp)
 553:	83 ec 04             	sub    $0x4,%esp
 556:	6a 01                	push   $0x1
 558:	57                   	push   %edi
 559:	56                   	push   %esi
 55a:	e8 8d fd ff ff       	call   2ec <write>
          s++;
 55f:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 562:	0f b6 03             	movzbl (%ebx),%eax
 565:	83 c4 10             	add    $0x10,%esp
 568:	84 c0                	test   %al,%al
 56a:	75 e4                	jne    550 <printf+0x152>
 56c:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 56f:	bf 00 00 00 00       	mov    $0x0,%edi
 574:	e9 ca fe ff ff       	jmp    443 <printf+0x45>
        putc(fd, *ap);
 579:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 57c:	8b 07                	mov    (%edi),%eax
 57e:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 581:	83 ec 04             	sub    $0x4,%esp
 584:	6a 01                	push   $0x1
 586:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 589:	50                   	push   %eax
 58a:	ff 75 08             	pushl  0x8(%ebp)
 58d:	e8 5a fd ff ff       	call   2ec <write>
        ap++;
 592:	83 c7 04             	add    $0x4,%edi
 595:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 598:	83 c4 10             	add    $0x10,%esp
      state = 0;
 59b:	bf 00 00 00 00       	mov    $0x0,%edi
 5a0:	e9 9e fe ff ff       	jmp    443 <printf+0x45>
 5a5:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 5a8:	83 ec 04             	sub    $0x4,%esp
 5ab:	6a 01                	push   $0x1
 5ad:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 5b0:	50                   	push   %eax
 5b1:	ff 75 08             	pushl  0x8(%ebp)
 5b4:	e8 33 fd ff ff       	call   2ec <write>
 5b9:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5bc:	bf 00 00 00 00       	mov    $0x0,%edi
 5c1:	e9 7d fe ff ff       	jmp    443 <printf+0x45>
    }
  }
}
 5c6:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5c9:	5b                   	pop    %ebx
 5ca:	5e                   	pop    %esi
 5cb:	5f                   	pop    %edi
 5cc:	5d                   	pop    %ebp
 5cd:	c3                   	ret    

000005ce <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5ce:	55                   	push   %ebp
 5cf:	89 e5                	mov    %esp,%ebp
 5d1:	57                   	push   %edi
 5d2:	56                   	push   %esi
 5d3:	53                   	push   %ebx
 5d4:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 5d7:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5da:	a1 20 0a 00 00       	mov    0xa20,%eax
 5df:	eb 0c                	jmp    5ed <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 5e1:	8b 10                	mov    (%eax),%edx
 5e3:	39 c2                	cmp    %eax,%edx
 5e5:	77 04                	ja     5eb <free+0x1d>
 5e7:	39 ca                	cmp    %ecx,%edx
 5e9:	77 10                	ja     5fb <free+0x2d>
{
 5eb:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5ed:	39 c8                	cmp    %ecx,%eax
 5ef:	73 f0                	jae    5e1 <free+0x13>
 5f1:	8b 10                	mov    (%eax),%edx
 5f3:	39 ca                	cmp    %ecx,%edx
 5f5:	77 04                	ja     5fb <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 5f7:	39 c2                	cmp    %eax,%edx
 5f9:	77 f0                	ja     5eb <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 5fb:	8b 73 fc             	mov    -0x4(%ebx),%esi
 5fe:	8b 10                	mov    (%eax),%edx
 600:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 603:	39 fa                	cmp    %edi,%edx
 605:	74 19                	je     620 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 607:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 60a:	8b 50 04             	mov    0x4(%eax),%edx
 60d:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 610:	39 f1                	cmp    %esi,%ecx
 612:	74 1b                	je     62f <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 614:	89 08                	mov    %ecx,(%eax)
  freep = p;
 616:	a3 20 0a 00 00       	mov    %eax,0xa20
}
 61b:	5b                   	pop    %ebx
 61c:	5e                   	pop    %esi
 61d:	5f                   	pop    %edi
 61e:	5d                   	pop    %ebp
 61f:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 620:	03 72 04             	add    0x4(%edx),%esi
 623:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 626:	8b 10                	mov    (%eax),%edx
 628:	8b 12                	mov    (%edx),%edx
 62a:	89 53 f8             	mov    %edx,-0x8(%ebx)
 62d:	eb db                	jmp    60a <free+0x3c>
    p->s.size += bp->s.size;
 62f:	03 53 fc             	add    -0x4(%ebx),%edx
 632:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 635:	8b 53 f8             	mov    -0x8(%ebx),%edx
 638:	89 10                	mov    %edx,(%eax)
 63a:	eb da                	jmp    616 <free+0x48>

0000063c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 63c:	55                   	push   %ebp
 63d:	89 e5                	mov    %esp,%ebp
 63f:	57                   	push   %edi
 640:	56                   	push   %esi
 641:	53                   	push   %ebx
 642:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 645:	8b 45 08             	mov    0x8(%ebp),%eax
 648:	8d 58 07             	lea    0x7(%eax),%ebx
 64b:	c1 eb 03             	shr    $0x3,%ebx
 64e:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 651:	8b 15 20 0a 00 00    	mov    0xa20,%edx
 657:	85 d2                	test   %edx,%edx
 659:	74 20                	je     67b <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 65b:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 65d:	8b 48 04             	mov    0x4(%eax),%ecx
 660:	39 cb                	cmp    %ecx,%ebx
 662:	76 3c                	jbe    6a0 <malloc+0x64>
 664:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 66a:	be 00 10 00 00       	mov    $0x1000,%esi
 66f:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 672:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 679:	eb 70                	jmp    6eb <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 67b:	c7 05 20 0a 00 00 24 	movl   $0xa24,0xa20
 682:	0a 00 00 
 685:	c7 05 24 0a 00 00 24 	movl   $0xa24,0xa24
 68c:	0a 00 00 
    base.s.size = 0;
 68f:	c7 05 28 0a 00 00 00 	movl   $0x0,0xa28
 696:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 699:	ba 24 0a 00 00       	mov    $0xa24,%edx
 69e:	eb bb                	jmp    65b <malloc+0x1f>
      if(p->s.size == nunits)
 6a0:	39 cb                	cmp    %ecx,%ebx
 6a2:	74 1c                	je     6c0 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 6a4:	29 d9                	sub    %ebx,%ecx
 6a6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 6a9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 6ac:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 6af:	89 15 20 0a 00 00    	mov    %edx,0xa20
      return (void*)(p + 1);
 6b5:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 6b8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6bb:	5b                   	pop    %ebx
 6bc:	5e                   	pop    %esi
 6bd:	5f                   	pop    %edi
 6be:	5d                   	pop    %ebp
 6bf:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 6c0:	8b 08                	mov    (%eax),%ecx
 6c2:	89 0a                	mov    %ecx,(%edx)
 6c4:	eb e9                	jmp    6af <malloc+0x73>
  hp->s.size = nu;
 6c6:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 6c9:	83 ec 0c             	sub    $0xc,%esp
 6cc:	83 c0 08             	add    $0x8,%eax
 6cf:	50                   	push   %eax
 6d0:	e8 f9 fe ff ff       	call   5ce <free>
  return freep;
 6d5:	8b 15 20 0a 00 00    	mov    0xa20,%edx
      if((p = morecore(nunits)) == 0)
 6db:	83 c4 10             	add    $0x10,%esp
 6de:	85 d2                	test   %edx,%edx
 6e0:	74 2b                	je     70d <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 6e2:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 6e4:	8b 48 04             	mov    0x4(%eax),%ecx
 6e7:	39 d9                	cmp    %ebx,%ecx
 6e9:	73 b5                	jae    6a0 <malloc+0x64>
 6eb:	89 c2                	mov    %eax,%edx
    if(p == freep)
 6ed:	39 05 20 0a 00 00    	cmp    %eax,0xa20
 6f3:	75 ed                	jne    6e2 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 6f5:	83 ec 0c             	sub    $0xc,%esp
 6f8:	57                   	push   %edi
 6f9:	e8 56 fc ff ff       	call   354 <sbrk>
  if(p == (char*)-1)
 6fe:	83 c4 10             	add    $0x10,%esp
 701:	83 f8 ff             	cmp    $0xffffffff,%eax
 704:	75 c0                	jne    6c6 <malloc+0x8a>
        return 0;
 706:	b8 00 00 00 00       	mov    $0x0,%eax
 70b:	eb ab                	jmp    6b8 <malloc+0x7c>
 70d:	b8 00 00 00 00       	mov    $0x0,%eax
 712:	eb a4                	jmp    6b8 <malloc+0x7c>
