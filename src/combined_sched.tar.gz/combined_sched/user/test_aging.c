#include "types.h"
#include "stat.h"
#include "user.h"

#define INNER_LOOP 1000000
#define OUTER_LOOP 100
#define PI 3.14

int main(int argc, char **argv)
{
    int pid = getpid();
    float dummy = 0;
    int i, j;

    printf(1, "=== AGING TEST START ===\n");

    pid = fork_rt(20);  // RT 프로세스 [P1]
    if (pid == 0)
    {
        // RT 프로세스 [P1] - 100틱 넘으면 강등됨
        for (i = 0; i < OUTER_LOOP; i++)
        {
            for (j = 0; j < INNER_LOOP; j++)
                dummy += PI * j;
            printf(1, "P1 (rt), i = %d, dummy = %x\n", i, dummy);
        }
        exit();
    }
    int rr_pid1 = fork();  // [P2] RR
    if (rr_pid1 == 0)
    {
        for (i = 0; i < 20; i++)
        {
            printf(1, "P2 (rr), i = %d, dummy = %x\n", i, dummy);
        }
        exit();
    }

    int rr_pid2 = fork();  // [P3] RR
    if (rr_pid2 == 0)
    {
        for (i = 0; i < 20; i++)
        {
            printf(1, "P3 (rr), i = %d, dummy = %x\n", i, dummy);
        }
        exit();
    }
    wait();
    wait();
    wait();
    printf(1, "=== TEST DONE ===\n");
    exit();
}

