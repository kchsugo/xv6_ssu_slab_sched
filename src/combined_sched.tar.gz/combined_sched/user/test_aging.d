user/test_aging.o: user/test_aging.c /usr/include/stdc-predef.h types.h \
 stat.h user.h
