
user/_test_mix:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#define INNER_LOOP 5000000
#define OUTER_LOOP 20
#define PI 3.14

int main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
	int pid = getpid();
  14:	e8 71 06 00 00       	call   68a <getpid>
    float dummy = 0;
    int i,j;
	printf(1, "=== TEST START ===\n");
  19:	83 ec 08             	sub    $0x8,%esp
  1c:	68 58 0a 00 00       	push   $0xa58
  21:	6a 01                	push   $0x1
  23:	e8 14 07 00 00       	call   73c <printf>
    pid = fork();
  28:	e8 d5 05 00 00       	call   602 <fork>
    if (pid == 0) /* [P2] child, its sched type must be ROUNDROBIN */
  2d:	83 c4 10             	add    $0x10,%esp
  30:	85 c0                	test   %eax,%eax
  32:	74 6c                	je     a0 <main+0xa0>
			wait();
        }
    }
    else /* [P1] parent, its sched type must be ROUNDROBIN*/
    {
        for (i=0; i<6; i++)
  34:	bb 00 00 00 00       	mov    $0x0,%ebx
    float dummy = 0;
  39:	d9 ee                	fldz   
  3b:	d9 5d e0             	fstps  -0x20(%ebp)
        {
            for (j=0; j<INNER_LOOP; j++)
  3e:	b8 00 00 00 00       	mov    $0x0,%eax
				dummy += PI*j;
  43:	dd 05 80 0b 00 00    	fldl   0xb80
  49:	89 45 dc             	mov    %eax,-0x24(%ebp)
  4c:	db 45 dc             	fildl  -0x24(%ebp)
  4f:	d8 c9                	fmul   %st(1),%st
  51:	d8 45 e0             	fadds  -0x20(%ebp)
  54:	d9 5d e0             	fstps  -0x20(%ebp)
            for (j=0; j<INNER_LOOP; j++)
  57:	83 c0 01             	add    $0x1,%eax
  5a:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
  5f:	75 e8                	jne    49 <main+0x49>
  61:	dd d8                	fstp   %st(0)
            printf(1, "P1 (RR), i = %d, dummy = %x\n", i, dummy);
  63:	83 ec 14             	sub    $0x14,%esp
  66:	d9 45 e0             	flds   -0x20(%ebp)
  69:	dd 1c 24             	fstpl  (%esp)
  6c:	53                   	push   %ebx
  6d:	68 49 0b 00 00       	push   $0xb49
  72:	6a 01                	push   $0x1
  74:	e8 c3 06 00 00       	call   73c <printf>
        for (i=0; i<6; i++)
  79:	83 c3 01             	add    $0x1,%ebx
  7c:	83 c4 20             	add    $0x20,%esp
  7f:	83 fb 06             	cmp    $0x6,%ebx
  82:	75 ba                	jne    3e <main+0x3e>
        }
		wait();
  84:	e8 89 05 00 00       	call   612 <wait>
		printf(1, "=== TEST DONE ===\n");
  89:	83 ec 08             	sub    $0x8,%esp
  8c:	68 66 0b 00 00       	push   $0xb66
  91:	6a 01                	push   $0x1
  93:	e8 a4 06 00 00       	call   73c <printf>
  98:	83 c4 10             	add    $0x10,%esp
    }
	exit();
  9b:	e8 6a 05 00 00       	call   60a <exit>
  a0:	89 c6                	mov    %eax,%esi
		for (i=0; i<3; i++)
  a2:	89 c3                	mov    %eax,%ebx
    float dummy = 0;
  a4:	d9 ee                	fldz   
  a6:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  a9:	89 f0                	mov    %esi,%eax
				dummy += PI*j;
  ab:	dd 05 80 0b 00 00    	fldl   0xb80
  b1:	89 45 dc             	mov    %eax,-0x24(%ebp)
  b4:	db 45 dc             	fildl  -0x24(%ebp)
  b7:	d8 c9                	fmul   %st(1),%st
  b9:	d8 45 e0             	fadds  -0x20(%ebp)
  bc:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  bf:	83 c0 01             	add    $0x1,%eax
  c2:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
  c7:	75 e8                	jne    b1 <main+0xb1>
  c9:	dd d8                	fstp   %st(0)
            printf(1, "P2 (RR), i = %d, dummy = %x\n", i, dummy);
  cb:	83 ec 14             	sub    $0x14,%esp
  ce:	d9 45 e0             	flds   -0x20(%ebp)
  d1:	dd 1c 24             	fstpl  (%esp)
  d4:	53                   	push   %ebx
  d5:	68 6c 0a 00 00       	push   $0xa6c
  da:	6a 01                	push   $0x1
  dc:	e8 5b 06 00 00       	call   73c <printf>
		for (i=0; i<3; i++)
  e1:	83 c3 01             	add    $0x1,%ebx
  e4:	83 c4 20             	add    $0x20,%esp
  e7:	83 fb 03             	cmp    $0x3,%ebx
  ea:	75 bd                	jne    a9 <main+0xa9>
        pid = fork();
  ec:	e8 11 05 00 00       	call   602 <fork>
  f1:	89 c7                	mov    %eax,%edi
        if (pid == 0) /* [P3] child-of-child, its sched type must be ROUNDROBIN */
  f3:	85 c0                	test   %eax,%eax
  f5:	74 4d                	je     144 <main+0x144>
				for (j=0; j<INNER_LOOP; j++)
  f7:	89 f0                	mov    %esi,%eax
					dummy += PI*j;
  f9:	dd 05 80 0b 00 00    	fldl   0xb80
  ff:	89 45 dc             	mov    %eax,-0x24(%ebp)
 102:	db 45 dc             	fildl  -0x24(%ebp)
 105:	d8 c9                	fmul   %st(1),%st
 107:	d8 45 e0             	fadds  -0x20(%ebp)
 10a:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
 10d:	83 c0 01             	add    $0x1,%eax
 110:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 115:	75 e8                	jne    ff <main+0xff>
 117:	dd d8                	fstp   %st(0)
				printf(1, "P2 (RR), i = %d, dummy = %x\n", i, dummy);
 119:	83 ec 14             	sub    $0x14,%esp
 11c:	d9 45 e0             	flds   -0x20(%ebp)
 11f:	dd 1c 24             	fstpl  (%esp)
 122:	53                   	push   %ebx
 123:	68 6c 0a 00 00       	push   $0xa6c
 128:	6a 01                	push   $0x1
 12a:	e8 0d 06 00 00       	call   73c <printf>
			for (i=3; i<6; i++)
 12f:	83 c3 01             	add    $0x1,%ebx
 132:	83 c4 20             	add    $0x20,%esp
 135:	83 fb 06             	cmp    $0x6,%ebx
 138:	75 bd                	jne    f7 <main+0xf7>
			wait();
 13a:	e8 d3 04 00 00       	call   612 <wait>
 13f:	e9 57 ff ff ff       	jmp    9b <main+0x9b>
			for (i=0; i<3; i++)
 144:	89 c3                	mov    %eax,%ebx
			dummy = 0;
 146:	d9 ee                	fldz   
 148:	d9 5d e0             	fstps  -0x20(%ebp)
                for (j=0; j<INNER_LOOP; j++)
 14b:	89 f8                	mov    %edi,%eax
                    dummy += PI*j;
 14d:	dd 05 80 0b 00 00    	fldl   0xb80
 153:	89 45 dc             	mov    %eax,-0x24(%ebp)
 156:	db 45 dc             	fildl  -0x24(%ebp)
 159:	d8 c9                	fmul   %st(1),%st
 15b:	d8 45 e0             	fadds  -0x20(%ebp)
 15e:	d9 5d e0             	fstps  -0x20(%ebp)
                for (j=0; j<INNER_LOOP; j++)
 161:	83 c0 01             	add    $0x1,%eax
 164:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 169:	75 e8                	jne    153 <main+0x153>
 16b:	dd d8                	fstp   %st(0)
				printf(1, "P3 (RR), i = %d, dummy = %x\n", i, dummy);
 16d:	83 ec 14             	sub    $0x14,%esp
 170:	d9 45 e0             	flds   -0x20(%ebp)
 173:	dd 1c 24             	fstpl  (%esp)
 176:	53                   	push   %ebx
 177:	68 89 0a 00 00       	push   $0xa89
 17c:	6a 01                	push   $0x1
 17e:	e8 b9 05 00 00       	call   73c <printf>
			for (i=0; i<3; i++)
 183:	83 c3 01             	add    $0x1,%ebx
 186:	83 c4 20             	add    $0x20,%esp
 189:	83 fb 03             	cmp    $0x3,%ebx
 18c:	75 bd                	jne    14b <main+0x14b>
			pid = fork_rt(20);
 18e:	83 ec 0c             	sub    $0xc,%esp
 191:	6a 14                	push   $0x14
 193:	e8 12 05 00 00       	call   6aa <fork_rt>
 198:	89 c6                	mov    %eax,%esi
			if (pid == 0) /* [PA], its priority must be 20, sched type must be PRIORITY */
 19a:	83 c4 10             	add    $0x10,%esp
 19d:	85 c0                	test   %eax,%eax
 19f:	74 4d                	je     1ee <main+0x1ee>
                    for (j=0; j<INNER_LOOP; j++)
 1a1:	89 f8                	mov    %edi,%eax
						dummy += PI*j;
 1a3:	dd 05 80 0b 00 00    	fldl   0xb80
 1a9:	89 45 dc             	mov    %eax,-0x24(%ebp)
 1ac:	db 45 dc             	fildl  -0x24(%ebp)
 1af:	d8 c9                	fmul   %st(1),%st
 1b1:	d8 45 e0             	fadds  -0x20(%ebp)
 1b4:	d9 5d e0             	fstps  -0x20(%ebp)
                    for (j=0; j<INNER_LOOP; j++)
 1b7:	83 c0 01             	add    $0x1,%eax
 1ba:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 1bf:	75 e8                	jne    1a9 <main+0x1a9>
 1c1:	dd d8                	fstp   %st(0)
                    printf(1, "P3 (RR), i = %d, dummy = %x\n", i, dummy);
 1c3:	83 ec 14             	sub    $0x14,%esp
 1c6:	d9 45 e0             	flds   -0x20(%ebp)
 1c9:	dd 1c 24             	fstpl  (%esp)
 1cc:	53                   	push   %ebx
 1cd:	68 89 0a 00 00       	push   $0xa89
 1d2:	6a 01                	push   $0x1
 1d4:	e8 63 05 00 00       	call   73c <printf>
				for (i=3; i<6; i++)
 1d9:	83 c3 01             	add    $0x1,%ebx
 1dc:	83 c4 20             	add    $0x20,%esp
 1df:	83 fb 06             	cmp    $0x6,%ebx
 1e2:	75 bd                	jne    1a1 <main+0x1a1>
				wait();
 1e4:	e8 29 04 00 00       	call   612 <wait>
 1e9:	e9 ad fe ff ff       	jmp    9b <main+0x9b>
				printf(1, "=== RT SCHED START ===\n");
 1ee:	83 ec 08             	sub    $0x8,%esp
 1f1:	68 a6 0a 00 00       	push   $0xaa6
 1f6:	6a 01                	push   $0x1
 1f8:	e8 3f 05 00 00       	call   73c <printf>
 1fd:	83 c4 10             	add    $0x10,%esp
                for (i=0; i<3; i++)
 200:	89 f3                	mov    %esi,%ebx
				dummy = 0;
 202:	d9 ee                	fldz   
 204:	d9 5d e0             	fstps  -0x20(%ebp)
                    for (j=0; j<INNER_LOOP; j++)
 207:	89 f0                	mov    %esi,%eax
                        dummy += PI*j;
 209:	dd 05 80 0b 00 00    	fldl   0xb80
 20f:	89 45 dc             	mov    %eax,-0x24(%ebp)
 212:	db 45 dc             	fildl  -0x24(%ebp)
 215:	d8 c9                	fmul   %st(1),%st
 217:	d8 45 e0             	fadds  -0x20(%ebp)
 21a:	d9 5d e0             	fstps  -0x20(%ebp)
                    for (j=0; j<INNER_LOOP; j++)
 21d:	83 c0 01             	add    $0x1,%eax
 220:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 225:	75 e8                	jne    20f <main+0x20f>
 227:	dd d8                	fstp   %st(0)
                    printf(1, "PA (RT), i = %d, dummy = %x\n", i, dummy);
 229:	83 ec 14             	sub    $0x14,%esp
 22c:	d9 45 e0             	flds   -0x20(%ebp)
 22f:	dd 1c 24             	fstpl  (%esp)
 232:	53                   	push   %ebx
 233:	68 be 0a 00 00       	push   $0xabe
 238:	6a 01                	push   $0x1
 23a:	e8 fd 04 00 00       	call   73c <printf>
                for (i=0; i<3; i++)
 23f:	83 c3 01             	add    $0x1,%ebx
 242:	83 c4 20             	add    $0x20,%esp
 245:	83 fb 03             	cmp    $0x3,%ebx
 248:	75 bd                	jne    207 <main+0x207>
                pid = fork_rt(10);
 24a:	83 ec 0c             	sub    $0xc,%esp
 24d:	6a 0a                	push   $0xa
 24f:	e8 56 04 00 00       	call   6aa <fork_rt>
 254:	89 c3                	mov    %eax,%ebx
                if(pid == 0) /* [PB], its priority must be 10, sched type must be PRIORITY */
 256:	83 c4 10             	add    $0x10,%esp
 259:	85 c0                	test   %eax,%eax
 25b:	74 61                	je     2be <main+0x2be>
                    for (i=0; i<3; i++)
 25d:	89 f3                	mov    %esi,%ebx
                        for (j=0; j<INNER_LOOP; j++)
 25f:	89 f0                	mov    %esi,%eax
                            dummy += PI*j;
 261:	dd 05 80 0b 00 00    	fldl   0xb80
 267:	89 45 dc             	mov    %eax,-0x24(%ebp)
 26a:	db 45 dc             	fildl  -0x24(%ebp)
 26d:	d8 c9                	fmul   %st(1),%st
 26f:	d8 45 e0             	fadds  -0x20(%ebp)
 272:	d9 5d e0             	fstps  -0x20(%ebp)
                        for (j=0; j<INNER_LOOP; j++)
 275:	83 c0 01             	add    $0x1,%eax
 278:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 27d:	75 e8                	jne    267 <main+0x267>
 27f:	dd d8                	fstp   %st(0)
                        printf(1, "PA (RT), i = %d, dummy = %x\n", i, dummy);
 281:	83 ec 14             	sub    $0x14,%esp
 284:	d9 45 e0             	flds   -0x20(%ebp)
 287:	dd 1c 24             	fstpl  (%esp)
 28a:	53                   	push   %ebx
 28b:	68 be 0a 00 00       	push   $0xabe
 290:	6a 01                	push   $0x1
 292:	e8 a5 04 00 00       	call   73c <printf>
                    for (i=0; i<3; i++)
 297:	83 c3 01             	add    $0x1,%ebx
 29a:	83 c4 20             	add    $0x20,%esp
 29d:	83 fb 03             	cmp    $0x3,%ebx
 2a0:	75 bd                	jne    25f <main+0x25f>
					printf(1, "=== RT SCHED DONE ===\n");
 2a2:	83 ec 08             	sub    $0x8,%esp
 2a5:	68 32 0b 00 00       	push   $0xb32
 2aa:	6a 01                	push   $0x1
 2ac:	e8 8b 04 00 00       	call   73c <printf>
                    wait();
 2b1:	e8 5c 03 00 00       	call   612 <wait>
 2b6:	83 c4 10             	add    $0x10,%esp
 2b9:	e9 dd fd ff ff       	jmp    9b <main+0x9b>
                    for (i=0; i<3; i++)
 2be:	89 c6                	mov    %eax,%esi
                        for (j=0; j<INNER_LOOP; j++)
 2c0:	89 d8                	mov    %ebx,%eax
							dummy += PI*j;
 2c2:	dd 05 80 0b 00 00    	fldl   0xb80
 2c8:	89 45 dc             	mov    %eax,-0x24(%ebp)
 2cb:	db 45 dc             	fildl  -0x24(%ebp)
 2ce:	d8 c9                	fmul   %st(1),%st
 2d0:	d8 45 e0             	fadds  -0x20(%ebp)
 2d3:	d9 5d e0             	fstps  -0x20(%ebp)
                        for (j=0; j<INNER_LOOP; j++)
 2d6:	83 c0 01             	add    $0x1,%eax
 2d9:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 2de:	75 e8                	jne    2c8 <main+0x2c8>
 2e0:	dd d8                	fstp   %st(0)
                        printf(1, "PB (RT), i = %d, dummy = %x\n", i, dummy);
 2e2:	83 ec 14             	sub    $0x14,%esp
 2e5:	d9 45 e0             	flds   -0x20(%ebp)
 2e8:	dd 1c 24             	fstpl  (%esp)
 2eb:	56                   	push   %esi
 2ec:	68 db 0a 00 00       	push   $0xadb
 2f1:	6a 01                	push   $0x1
 2f3:	e8 44 04 00 00       	call   73c <printf>
                    for (i=0; i<3; i++)
 2f8:	83 c6 01             	add    $0x1,%esi
 2fb:	83 c4 20             	add    $0x20,%esp
 2fe:	83 fe 03             	cmp    $0x3,%esi
 301:	75 bd                	jne    2c0 <main+0x2c0>
					pid = fork_rt(11);
 303:	83 ec 0c             	sub    $0xc,%esp
 306:	6a 0b                	push   $0xb
 308:	e8 9d 03 00 00       	call   6aa <fork_rt>
 30d:	89 c7                	mov    %eax,%edi
					if(pid == 0) /* [PC], its priority must be 11, sched type must be PRIORITY*/
 30f:	83 c4 10             	add    $0x10,%esp
 312:	85 c0                	test   %eax,%eax
 314:	74 4d                	je     363 <main+0x363>
                            for (j=0; j<INNER_LOOP; j++)
 316:	89 d8                	mov    %ebx,%eax
                                dummy += PI*j;
 318:	dd 05 80 0b 00 00    	fldl   0xb80
 31e:	89 45 dc             	mov    %eax,-0x24(%ebp)
 321:	db 45 dc             	fildl  -0x24(%ebp)
 324:	d8 c9                	fmul   %st(1),%st
 326:	d8 45 e0             	fadds  -0x20(%ebp)
 329:	d9 5d e0             	fstps  -0x20(%ebp)
                            for (j=0; j<INNER_LOOP; j++)
 32c:	83 c0 01             	add    $0x1,%eax
 32f:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 334:	75 e8                	jne    31e <main+0x31e>
 336:	dd d8                	fstp   %st(0)
                            printf(1, "PB (RT), i = %d, dummy = %x\n", i, dummy);
 338:	83 ec 14             	sub    $0x14,%esp
 33b:	d9 45 e0             	flds   -0x20(%ebp)
 33e:	dd 1c 24             	fstpl  (%esp)
 341:	56                   	push   %esi
 342:	68 db 0a 00 00       	push   $0xadb
 347:	6a 01                	push   $0x1
 349:	e8 ee 03 00 00       	call   73c <printf>
						for (i=3; i<6; i++)
 34e:	83 c6 01             	add    $0x1,%esi
 351:	83 c4 20             	add    $0x20,%esp
 354:	83 fe 06             	cmp    $0x6,%esi
 357:	75 bd                	jne    316 <main+0x316>
						wait();
 359:	e8 b4 02 00 00       	call   612 <wait>
 35e:	e9 38 fd ff ff       	jmp    9b <main+0x9b>
						for (i=0; i<3; i++)
 363:	89 c6                	mov    %eax,%esi
							for (j=0; j<INNER_LOOP; j++)
 365:	89 f8                	mov    %edi,%eax
								dummy += PI*j;
 367:	dd 05 80 0b 00 00    	fldl   0xb80
 36d:	89 45 dc             	mov    %eax,-0x24(%ebp)
 370:	db 45 dc             	fildl  -0x24(%ebp)
 373:	d8 c9                	fmul   %st(1),%st
 375:	d8 45 e0             	fadds  -0x20(%ebp)
 378:	d9 5d e0             	fstps  -0x20(%ebp)
							for (j=0; j<INNER_LOOP; j++)
 37b:	83 c0 01             	add    $0x1,%eax
 37e:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 383:	75 e8                	jne    36d <main+0x36d>
 385:	dd d8                	fstp   %st(0)
							printf(1, "PC (RT), i = %d, dummy = %x\n", i, dummy);
 387:	83 ec 14             	sub    $0x14,%esp
 38a:	d9 45 e0             	flds   -0x20(%ebp)
 38d:	dd 1c 24             	fstpl  (%esp)
 390:	56                   	push   %esi
 391:	68 f8 0a 00 00       	push   $0xaf8
 396:	6a 01                	push   $0x1
 398:	e8 9f 03 00 00       	call   73c <printf>
						for (i=0; i<3; i++)
 39d:	83 c6 01             	add    $0x1,%esi
 3a0:	83 c4 20             	add    $0x20,%esp
 3a3:	83 fe 03             	cmp    $0x3,%esi
 3a6:	75 bd                	jne    365 <main+0x365>
						pid = fork();
 3a8:	e8 55 02 00 00       	call   602 <fork>
 3ad:	89 c3                	mov    %eax,%ebx
						if(pid == 0) /* [P4], its sched type must be ROUNDROBIN */
 3af:	85 c0                	test   %eax,%eax
 3b1:	74 4d                	je     400 <main+0x400>
								for (j=0; j<INNER_LOOP; j++)
 3b3:	89 f8                	mov    %edi,%eax
									dummy += PI*j;
 3b5:	dd 05 80 0b 00 00    	fldl   0xb80
 3bb:	89 45 dc             	mov    %eax,-0x24(%ebp)
 3be:	db 45 dc             	fildl  -0x24(%ebp)
 3c1:	d8 c9                	fmul   %st(1),%st
 3c3:	d8 45 e0             	fadds  -0x20(%ebp)
 3c6:	d9 5d e0             	fstps  -0x20(%ebp)
								for (j=0; j<INNER_LOOP; j++)
 3c9:	83 c0 01             	add    $0x1,%eax
 3cc:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 3d1:	75 e8                	jne    3bb <main+0x3bb>
 3d3:	dd d8                	fstp   %st(0)
								printf(1, "PC (RT), i = %d, dummy = %x\n", i, dummy);
 3d5:	83 ec 14             	sub    $0x14,%esp
 3d8:	d9 45 e0             	flds   -0x20(%ebp)
 3db:	dd 1c 24             	fstpl  (%esp)
 3de:	56                   	push   %esi
 3df:	68 f8 0a 00 00       	push   $0xaf8
 3e4:	6a 01                	push   $0x1
 3e6:	e8 51 03 00 00       	call   73c <printf>
							for (i=3; i<6; i++)
 3eb:	83 c6 01             	add    $0x1,%esi
 3ee:	83 c4 20             	add    $0x20,%esp
 3f1:	83 fe 06             	cmp    $0x6,%esi
 3f4:	75 bd                	jne    3b3 <main+0x3b3>
							wait();
 3f6:	e8 17 02 00 00       	call   612 <wait>
 3fb:	e9 9b fc ff ff       	jmp    9b <main+0x9b>
							for (i=0; i<6; i++)
 400:	89 c6                	mov    %eax,%esi
                                for (j=0; j<INNER_LOOP; j++)
 402:	89 d8                	mov    %ebx,%eax
                                    dummy += PI*j;
 404:	dd 05 80 0b 00 00    	fldl   0xb80
 40a:	89 45 dc             	mov    %eax,-0x24(%ebp)
 40d:	db 45 dc             	fildl  -0x24(%ebp)
 410:	d8 c9                	fmul   %st(1),%st
 412:	d8 45 e0             	fadds  -0x20(%ebp)
 415:	d9 5d e0             	fstps  -0x20(%ebp)
                                for (j=0; j<INNER_LOOP; j++)
 418:	83 c0 01             	add    $0x1,%eax
 41b:	3d 40 4b 4c 00       	cmp    $0x4c4b40,%eax
 420:	75 e8                	jne    40a <main+0x40a>
 422:	dd d8                	fstp   %st(0)
                                printf(1, "P4 (RR), i = %d, dummy = %x\n", i, dummy);
 424:	83 ec 14             	sub    $0x14,%esp
 427:	d9 45 e0             	flds   -0x20(%ebp)
 42a:	dd 1c 24             	fstpl  (%esp)
 42d:	56                   	push   %esi
 42e:	68 15 0b 00 00       	push   $0xb15
 433:	6a 01                	push   $0x1
 435:	e8 02 03 00 00       	call   73c <printf>
							for (i=0; i<6; i++)
 43a:	83 c6 01             	add    $0x1,%esi
 43d:	83 c4 20             	add    $0x20,%esp
 440:	83 fe 06             	cmp    $0x6,%esi
 443:	75 bd                	jne    402 <main+0x402>
 445:	e9 51 fc ff ff       	jmp    9b <main+0x9b>

0000044a <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 44a:	55                   	push   %ebp
 44b:	89 e5                	mov    %esp,%ebp
 44d:	53                   	push   %ebx
 44e:	8b 45 08             	mov    0x8(%ebp),%eax
 451:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 454:	89 c2                	mov    %eax,%edx
 456:	83 c1 01             	add    $0x1,%ecx
 459:	83 c2 01             	add    $0x1,%edx
 45c:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 460:	88 5a ff             	mov    %bl,-0x1(%edx)
 463:	84 db                	test   %bl,%bl
 465:	75 ef                	jne    456 <strcpy+0xc>
    ;
  return os;
}
 467:	5b                   	pop    %ebx
 468:	5d                   	pop    %ebp
 469:	c3                   	ret    

0000046a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 46a:	55                   	push   %ebp
 46b:	89 e5                	mov    %esp,%ebp
 46d:	8b 4d 08             	mov    0x8(%ebp),%ecx
 470:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 473:	0f b6 01             	movzbl (%ecx),%eax
 476:	84 c0                	test   %al,%al
 478:	74 15                	je     48f <strcmp+0x25>
 47a:	3a 02                	cmp    (%edx),%al
 47c:	75 11                	jne    48f <strcmp+0x25>
    p++, q++;
 47e:	83 c1 01             	add    $0x1,%ecx
 481:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 484:	0f b6 01             	movzbl (%ecx),%eax
 487:	84 c0                	test   %al,%al
 489:	74 04                	je     48f <strcmp+0x25>
 48b:	3a 02                	cmp    (%edx),%al
 48d:	74 ef                	je     47e <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
 48f:	0f b6 c0             	movzbl %al,%eax
 492:	0f b6 12             	movzbl (%edx),%edx
 495:	29 d0                	sub    %edx,%eax
}
 497:	5d                   	pop    %ebp
 498:	c3                   	ret    

00000499 <strlen>:

uint
strlen(const char *s)
{
 499:	55                   	push   %ebp
 49a:	89 e5                	mov    %esp,%ebp
 49c:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 49f:	80 39 00             	cmpb   $0x0,(%ecx)
 4a2:	74 12                	je     4b6 <strlen+0x1d>
 4a4:	ba 00 00 00 00       	mov    $0x0,%edx
 4a9:	83 c2 01             	add    $0x1,%edx
 4ac:	89 d0                	mov    %edx,%eax
 4ae:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 4b2:	75 f5                	jne    4a9 <strlen+0x10>
    ;
  return n;
}
 4b4:	5d                   	pop    %ebp
 4b5:	c3                   	ret    
  for(n = 0; s[n]; n++)
 4b6:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 4bb:	eb f7                	jmp    4b4 <strlen+0x1b>

000004bd <memset>:

void*
memset(void *dst, int c, uint n)
{
 4bd:	55                   	push   %ebp
 4be:	89 e5                	mov    %esp,%ebp
 4c0:	57                   	push   %edi
 4c1:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 4c4:	89 d7                	mov    %edx,%edi
 4c6:	8b 4d 10             	mov    0x10(%ebp),%ecx
 4c9:	8b 45 0c             	mov    0xc(%ebp),%eax
 4cc:	fc                   	cld    
 4cd:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 4cf:	89 d0                	mov    %edx,%eax
 4d1:	5f                   	pop    %edi
 4d2:	5d                   	pop    %ebp
 4d3:	c3                   	ret    

000004d4 <strchr>:

char*
strchr(const char *s, char c)
{
 4d4:	55                   	push   %ebp
 4d5:	89 e5                	mov    %esp,%ebp
 4d7:	53                   	push   %ebx
 4d8:	8b 45 08             	mov    0x8(%ebp),%eax
 4db:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 4de:	0f b6 10             	movzbl (%eax),%edx
 4e1:	84 d2                	test   %dl,%dl
 4e3:	74 1e                	je     503 <strchr+0x2f>
 4e5:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 4e7:	38 d3                	cmp    %dl,%bl
 4e9:	74 15                	je     500 <strchr+0x2c>
  for(; *s; s++)
 4eb:	83 c0 01             	add    $0x1,%eax
 4ee:	0f b6 10             	movzbl (%eax),%edx
 4f1:	84 d2                	test   %dl,%dl
 4f3:	74 06                	je     4fb <strchr+0x27>
    if(*s == c)
 4f5:	38 ca                	cmp    %cl,%dl
 4f7:	75 f2                	jne    4eb <strchr+0x17>
 4f9:	eb 05                	jmp    500 <strchr+0x2c>
      return (char*)s;
  return 0;
 4fb:	b8 00 00 00 00       	mov    $0x0,%eax
}
 500:	5b                   	pop    %ebx
 501:	5d                   	pop    %ebp
 502:	c3                   	ret    
  return 0;
 503:	b8 00 00 00 00       	mov    $0x0,%eax
 508:	eb f6                	jmp    500 <strchr+0x2c>

0000050a <gets>:

char*
gets(char *buf, int max)
{
 50a:	55                   	push   %ebp
 50b:	89 e5                	mov    %esp,%ebp
 50d:	57                   	push   %edi
 50e:	56                   	push   %esi
 50f:	53                   	push   %ebx
 510:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 513:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 518:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 51b:	8d 5e 01             	lea    0x1(%esi),%ebx
 51e:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 521:	7d 2b                	jge    54e <gets+0x44>
    cc = read(0, &c, 1);
 523:	83 ec 04             	sub    $0x4,%esp
 526:	6a 01                	push   $0x1
 528:	57                   	push   %edi
 529:	6a 00                	push   $0x0
 52b:	e8 f2 00 00 00       	call   622 <read>
    if(cc < 1)
 530:	83 c4 10             	add    $0x10,%esp
 533:	85 c0                	test   %eax,%eax
 535:	7e 17                	jle    54e <gets+0x44>
      break;
    buf[i++] = c;
 537:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 53b:	8b 55 08             	mov    0x8(%ebp),%edx
 53e:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 542:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 544:	3c 0a                	cmp    $0xa,%al
 546:	74 04                	je     54c <gets+0x42>
 548:	3c 0d                	cmp    $0xd,%al
 54a:	75 cf                	jne    51b <gets+0x11>
  for(i=0; i+1 < max; ){
 54c:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 54e:	8b 45 08             	mov    0x8(%ebp),%eax
 551:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 555:	8d 65 f4             	lea    -0xc(%ebp),%esp
 558:	5b                   	pop    %ebx
 559:	5e                   	pop    %esi
 55a:	5f                   	pop    %edi
 55b:	5d                   	pop    %ebp
 55c:	c3                   	ret    

0000055d <stat>:

int
stat(const char *n, struct stat *st)
{
 55d:	55                   	push   %ebp
 55e:	89 e5                	mov    %esp,%ebp
 560:	56                   	push   %esi
 561:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 562:	83 ec 08             	sub    $0x8,%esp
 565:	6a 00                	push   $0x0
 567:	ff 75 08             	pushl  0x8(%ebp)
 56a:	e8 db 00 00 00       	call   64a <open>
  if(fd < 0)
 56f:	83 c4 10             	add    $0x10,%esp
 572:	85 c0                	test   %eax,%eax
 574:	78 24                	js     59a <stat+0x3d>
 576:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 578:	83 ec 08             	sub    $0x8,%esp
 57b:	ff 75 0c             	pushl  0xc(%ebp)
 57e:	50                   	push   %eax
 57f:	e8 de 00 00 00       	call   662 <fstat>
 584:	89 c6                	mov    %eax,%esi
  close(fd);
 586:	89 1c 24             	mov    %ebx,(%esp)
 589:	e8 a4 00 00 00       	call   632 <close>
  return r;
 58e:	83 c4 10             	add    $0x10,%esp
}
 591:	89 f0                	mov    %esi,%eax
 593:	8d 65 f8             	lea    -0x8(%ebp),%esp
 596:	5b                   	pop    %ebx
 597:	5e                   	pop    %esi
 598:	5d                   	pop    %ebp
 599:	c3                   	ret    
    return -1;
 59a:	be ff ff ff ff       	mov    $0xffffffff,%esi
 59f:	eb f0                	jmp    591 <stat+0x34>

000005a1 <atoi>:

int
atoi(const char *s)
{
 5a1:	55                   	push   %ebp
 5a2:	89 e5                	mov    %esp,%ebp
 5a4:	53                   	push   %ebx
 5a5:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 5a8:	0f b6 11             	movzbl (%ecx),%edx
 5ab:	8d 42 d0             	lea    -0x30(%edx),%eax
 5ae:	3c 09                	cmp    $0x9,%al
 5b0:	77 20                	ja     5d2 <atoi+0x31>
  n = 0;
 5b2:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 5b7:	83 c1 01             	add    $0x1,%ecx
 5ba:	8d 04 80             	lea    (%eax,%eax,4),%eax
 5bd:	0f be d2             	movsbl %dl,%edx
 5c0:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 5c4:	0f b6 11             	movzbl (%ecx),%edx
 5c7:	8d 5a d0             	lea    -0x30(%edx),%ebx
 5ca:	80 fb 09             	cmp    $0x9,%bl
 5cd:	76 e8                	jbe    5b7 <atoi+0x16>
  return n;
}
 5cf:	5b                   	pop    %ebx
 5d0:	5d                   	pop    %ebp
 5d1:	c3                   	ret    
  n = 0;
 5d2:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 5d7:	eb f6                	jmp    5cf <atoi+0x2e>

000005d9 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 5d9:	55                   	push   %ebp
 5da:	89 e5                	mov    %esp,%ebp
 5dc:	56                   	push   %esi
 5dd:	53                   	push   %ebx
 5de:	8b 45 08             	mov    0x8(%ebp),%eax
 5e1:	8b 75 0c             	mov    0xc(%ebp),%esi
 5e4:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 5e7:	85 db                	test   %ebx,%ebx
 5e9:	7e 13                	jle    5fe <memmove+0x25>
 5eb:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 5f0:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 5f4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 5f7:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 5fa:	39 d3                	cmp    %edx,%ebx
 5fc:	75 f2                	jne    5f0 <memmove+0x17>
  return vdst;
}
 5fe:	5b                   	pop    %ebx
 5ff:	5e                   	pop    %esi
 600:	5d                   	pop    %ebp
 601:	c3                   	ret    

00000602 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 602:	b8 01 00 00 00       	mov    $0x1,%eax
 607:	cd 40                	int    $0x40
 609:	c3                   	ret    

0000060a <exit>:
SYSCALL(exit)
 60a:	b8 02 00 00 00       	mov    $0x2,%eax
 60f:	cd 40                	int    $0x40
 611:	c3                   	ret    

00000612 <wait>:
SYSCALL(wait)
 612:	b8 03 00 00 00       	mov    $0x3,%eax
 617:	cd 40                	int    $0x40
 619:	c3                   	ret    

0000061a <pipe>:
SYSCALL(pipe)
 61a:	b8 04 00 00 00       	mov    $0x4,%eax
 61f:	cd 40                	int    $0x40
 621:	c3                   	ret    

00000622 <read>:
SYSCALL(read)
 622:	b8 05 00 00 00       	mov    $0x5,%eax
 627:	cd 40                	int    $0x40
 629:	c3                   	ret    

0000062a <write>:
SYSCALL(write)
 62a:	b8 10 00 00 00       	mov    $0x10,%eax
 62f:	cd 40                	int    $0x40
 631:	c3                   	ret    

00000632 <close>:
SYSCALL(close)
 632:	b8 15 00 00 00       	mov    $0x15,%eax
 637:	cd 40                	int    $0x40
 639:	c3                   	ret    

0000063a <kill>:
SYSCALL(kill)
 63a:	b8 06 00 00 00       	mov    $0x6,%eax
 63f:	cd 40                	int    $0x40
 641:	c3                   	ret    

00000642 <exec>:
SYSCALL(exec)
 642:	b8 07 00 00 00       	mov    $0x7,%eax
 647:	cd 40                	int    $0x40
 649:	c3                   	ret    

0000064a <open>:
SYSCALL(open)
 64a:	b8 0f 00 00 00       	mov    $0xf,%eax
 64f:	cd 40                	int    $0x40
 651:	c3                   	ret    

00000652 <mknod>:
SYSCALL(mknod)
 652:	b8 11 00 00 00       	mov    $0x11,%eax
 657:	cd 40                	int    $0x40
 659:	c3                   	ret    

0000065a <unlink>:
SYSCALL(unlink)
 65a:	b8 12 00 00 00       	mov    $0x12,%eax
 65f:	cd 40                	int    $0x40
 661:	c3                   	ret    

00000662 <fstat>:
SYSCALL(fstat)
 662:	b8 08 00 00 00       	mov    $0x8,%eax
 667:	cd 40                	int    $0x40
 669:	c3                   	ret    

0000066a <link>:
SYSCALL(link)
 66a:	b8 13 00 00 00       	mov    $0x13,%eax
 66f:	cd 40                	int    $0x40
 671:	c3                   	ret    

00000672 <mkdir>:
SYSCALL(mkdir)
 672:	b8 14 00 00 00       	mov    $0x14,%eax
 677:	cd 40                	int    $0x40
 679:	c3                   	ret    

0000067a <chdir>:
SYSCALL(chdir)
 67a:	b8 09 00 00 00       	mov    $0x9,%eax
 67f:	cd 40                	int    $0x40
 681:	c3                   	ret    

00000682 <dup>:
SYSCALL(dup)
 682:	b8 0a 00 00 00       	mov    $0xa,%eax
 687:	cd 40                	int    $0x40
 689:	c3                   	ret    

0000068a <getpid>:
SYSCALL(getpid)
 68a:	b8 0b 00 00 00       	mov    $0xb,%eax
 68f:	cd 40                	int    $0x40
 691:	c3                   	ret    

00000692 <sbrk>:
SYSCALL(sbrk)
 692:	b8 0c 00 00 00       	mov    $0xc,%eax
 697:	cd 40                	int    $0x40
 699:	c3                   	ret    

0000069a <sleep>:
SYSCALL(sleep)
 69a:	b8 0d 00 00 00       	mov    $0xd,%eax
 69f:	cd 40                	int    $0x40
 6a1:	c3                   	ret    

000006a2 <uptime>:
SYSCALL(uptime)
 6a2:	b8 0e 00 00 00       	mov    $0xe,%eax
 6a7:	cd 40                	int    $0x40
 6a9:	c3                   	ret    

000006aa <fork_rt>:
SYSCALL(fork_rt)
 6aa:	b8 16 00 00 00       	mov    $0x16,%eax
 6af:	cd 40                	int    $0x40
 6b1:	c3                   	ret    

000006b2 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 6b2:	55                   	push   %ebp
 6b3:	89 e5                	mov    %esp,%ebp
 6b5:	57                   	push   %edi
 6b6:	56                   	push   %esi
 6b7:	53                   	push   %ebx
 6b8:	83 ec 3c             	sub    $0x3c,%esp
 6bb:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 6bd:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 6c1:	74 14                	je     6d7 <printint+0x25>
 6c3:	85 d2                	test   %edx,%edx
 6c5:	79 10                	jns    6d7 <printint+0x25>
    neg = 1;
    x = -xx;
 6c7:	f7 da                	neg    %edx
    neg = 1;
 6c9:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 6d0:	bf 00 00 00 00       	mov    $0x0,%edi
 6d5:	eb 0b                	jmp    6e2 <printint+0x30>
  neg = 0;
 6d7:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 6de:	eb f0                	jmp    6d0 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 6e0:	89 df                	mov    %ebx,%edi
 6e2:	8d 5f 01             	lea    0x1(%edi),%ebx
 6e5:	89 d0                	mov    %edx,%eax
 6e7:	ba 00 00 00 00       	mov    $0x0,%edx
 6ec:	f7 f1                	div    %ecx
 6ee:	0f b6 92 90 0b 00 00 	movzbl 0xb90(%edx),%edx
 6f5:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 6f9:	89 c2                	mov    %eax,%edx
 6fb:	85 c0                	test   %eax,%eax
 6fd:	75 e1                	jne    6e0 <printint+0x2e>
  if(neg)
 6ff:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 703:	74 08                	je     70d <printint+0x5b>
    buf[i++] = '-';
 705:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 70a:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 70d:	83 eb 01             	sub    $0x1,%ebx
 710:	78 22                	js     734 <printint+0x82>
  write(fd, &c, 1);
 712:	8d 7d d7             	lea    -0x29(%ebp),%edi
 715:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 71a:	88 45 d7             	mov    %al,-0x29(%ebp)
 71d:	83 ec 04             	sub    $0x4,%esp
 720:	6a 01                	push   $0x1
 722:	57                   	push   %edi
 723:	56                   	push   %esi
 724:	e8 01 ff ff ff       	call   62a <write>
  while(--i >= 0)
 729:	83 eb 01             	sub    $0x1,%ebx
 72c:	83 c4 10             	add    $0x10,%esp
 72f:	83 fb ff             	cmp    $0xffffffff,%ebx
 732:	75 e1                	jne    715 <printint+0x63>
    putc(fd, buf[i]);
}
 734:	8d 65 f4             	lea    -0xc(%ebp),%esp
 737:	5b                   	pop    %ebx
 738:	5e                   	pop    %esi
 739:	5f                   	pop    %edi
 73a:	5d                   	pop    %ebp
 73b:	c3                   	ret    

0000073c <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 73c:	55                   	push   %ebp
 73d:	89 e5                	mov    %esp,%ebp
 73f:	57                   	push   %edi
 740:	56                   	push   %esi
 741:	53                   	push   %ebx
 742:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 745:	8b 75 0c             	mov    0xc(%ebp),%esi
 748:	0f b6 1e             	movzbl (%esi),%ebx
 74b:	84 db                	test   %bl,%bl
 74d:	0f 84 b1 01 00 00    	je     904 <printf+0x1c8>
 753:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 756:	8d 45 10             	lea    0x10(%ebp),%eax
 759:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 75c:	bf 00 00 00 00       	mov    $0x0,%edi
 761:	eb 2d                	jmp    790 <printf+0x54>
 763:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 766:	83 ec 04             	sub    $0x4,%esp
 769:	6a 01                	push   $0x1
 76b:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 76e:	50                   	push   %eax
 76f:	ff 75 08             	pushl  0x8(%ebp)
 772:	e8 b3 fe ff ff       	call   62a <write>
 777:	83 c4 10             	add    $0x10,%esp
 77a:	eb 05                	jmp    781 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 77c:	83 ff 25             	cmp    $0x25,%edi
 77f:	74 22                	je     7a3 <printf+0x67>
 781:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 784:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 788:	84 db                	test   %bl,%bl
 78a:	0f 84 74 01 00 00    	je     904 <printf+0x1c8>
    c = fmt[i] & 0xff;
 790:	0f be d3             	movsbl %bl,%edx
 793:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 796:	85 ff                	test   %edi,%edi
 798:	75 e2                	jne    77c <printf+0x40>
      if(c == '%'){
 79a:	83 f8 25             	cmp    $0x25,%eax
 79d:	75 c4                	jne    763 <printf+0x27>
        state = '%';
 79f:	89 c7                	mov    %eax,%edi
 7a1:	eb de                	jmp    781 <printf+0x45>
      if(c == 'd'){
 7a3:	83 f8 64             	cmp    $0x64,%eax
 7a6:	74 59                	je     801 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 7a8:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 7ae:	83 fa 70             	cmp    $0x70,%edx
 7b1:	74 7a                	je     82d <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 7b3:	83 f8 73             	cmp    $0x73,%eax
 7b6:	0f 84 9d 00 00 00    	je     859 <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 7bc:	83 f8 63             	cmp    $0x63,%eax
 7bf:	0f 84 f2 00 00 00    	je     8b7 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 7c5:	83 f8 25             	cmp    $0x25,%eax
 7c8:	0f 84 15 01 00 00    	je     8e3 <printf+0x1a7>
 7ce:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 7d2:	83 ec 04             	sub    $0x4,%esp
 7d5:	6a 01                	push   $0x1
 7d7:	8d 45 e7             	lea    -0x19(%ebp),%eax
 7da:	50                   	push   %eax
 7db:	ff 75 08             	pushl  0x8(%ebp)
 7de:	e8 47 fe ff ff       	call   62a <write>
 7e3:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 7e6:	83 c4 0c             	add    $0xc,%esp
 7e9:	6a 01                	push   $0x1
 7eb:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 7ee:	50                   	push   %eax
 7ef:	ff 75 08             	pushl  0x8(%ebp)
 7f2:	e8 33 fe ff ff       	call   62a <write>
 7f7:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 7fa:	bf 00 00 00 00       	mov    $0x0,%edi
 7ff:	eb 80                	jmp    781 <printf+0x45>
        printint(fd, *ap, 10, 1);
 801:	83 ec 0c             	sub    $0xc,%esp
 804:	6a 01                	push   $0x1
 806:	b9 0a 00 00 00       	mov    $0xa,%ecx
 80b:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 80e:	8b 17                	mov    (%edi),%edx
 810:	8b 45 08             	mov    0x8(%ebp),%eax
 813:	e8 9a fe ff ff       	call   6b2 <printint>
        ap++;
 818:	89 f8                	mov    %edi,%eax
 81a:	83 c0 04             	add    $0x4,%eax
 81d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 820:	83 c4 10             	add    $0x10,%esp
      state = 0;
 823:	bf 00 00 00 00       	mov    $0x0,%edi
 828:	e9 54 ff ff ff       	jmp    781 <printf+0x45>
        printint(fd, *ap, 16, 0);
 82d:	83 ec 0c             	sub    $0xc,%esp
 830:	6a 00                	push   $0x0
 832:	b9 10 00 00 00       	mov    $0x10,%ecx
 837:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 83a:	8b 17                	mov    (%edi),%edx
 83c:	8b 45 08             	mov    0x8(%ebp),%eax
 83f:	e8 6e fe ff ff       	call   6b2 <printint>
        ap++;
 844:	89 f8                	mov    %edi,%eax
 846:	83 c0 04             	add    $0x4,%eax
 849:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 84c:	83 c4 10             	add    $0x10,%esp
      state = 0;
 84f:	bf 00 00 00 00       	mov    $0x0,%edi
 854:	e9 28 ff ff ff       	jmp    781 <printf+0x45>
        s = (char*)*ap;
 859:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 85c:	8b 01                	mov    (%ecx),%eax
        ap++;
 85e:	83 c1 04             	add    $0x4,%ecx
 861:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 864:	85 c0                	test   %eax,%eax
 866:	74 13                	je     87b <printf+0x13f>
        s = (char*)*ap;
 868:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 86a:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 86d:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 872:	84 c0                	test   %al,%al
 874:	75 0f                	jne    885 <printf+0x149>
 876:	e9 06 ff ff ff       	jmp    781 <printf+0x45>
          s = "(null)";
 87b:	bb 88 0b 00 00       	mov    $0xb88,%ebx
        while(*s != 0){
 880:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 885:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 888:	89 75 d0             	mov    %esi,-0x30(%ebp)
 88b:	8b 75 08             	mov    0x8(%ebp),%esi
 88e:	88 45 e3             	mov    %al,-0x1d(%ebp)
 891:	83 ec 04             	sub    $0x4,%esp
 894:	6a 01                	push   $0x1
 896:	57                   	push   %edi
 897:	56                   	push   %esi
 898:	e8 8d fd ff ff       	call   62a <write>
          s++;
 89d:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 8a0:	0f b6 03             	movzbl (%ebx),%eax
 8a3:	83 c4 10             	add    $0x10,%esp
 8a6:	84 c0                	test   %al,%al
 8a8:	75 e4                	jne    88e <printf+0x152>
 8aa:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 8ad:	bf 00 00 00 00       	mov    $0x0,%edi
 8b2:	e9 ca fe ff ff       	jmp    781 <printf+0x45>
        putc(fd, *ap);
 8b7:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 8ba:	8b 07                	mov    (%edi),%eax
 8bc:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 8bf:	83 ec 04             	sub    $0x4,%esp
 8c2:	6a 01                	push   $0x1
 8c4:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 8c7:	50                   	push   %eax
 8c8:	ff 75 08             	pushl  0x8(%ebp)
 8cb:	e8 5a fd ff ff       	call   62a <write>
        ap++;
 8d0:	83 c7 04             	add    $0x4,%edi
 8d3:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 8d6:	83 c4 10             	add    $0x10,%esp
      state = 0;
 8d9:	bf 00 00 00 00       	mov    $0x0,%edi
 8de:	e9 9e fe ff ff       	jmp    781 <printf+0x45>
 8e3:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 8e6:	83 ec 04             	sub    $0x4,%esp
 8e9:	6a 01                	push   $0x1
 8eb:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 8ee:	50                   	push   %eax
 8ef:	ff 75 08             	pushl  0x8(%ebp)
 8f2:	e8 33 fd ff ff       	call   62a <write>
 8f7:	83 c4 10             	add    $0x10,%esp
      state = 0;
 8fa:	bf 00 00 00 00       	mov    $0x0,%edi
 8ff:	e9 7d fe ff ff       	jmp    781 <printf+0x45>
    }
  }
}
 904:	8d 65 f4             	lea    -0xc(%ebp),%esp
 907:	5b                   	pop    %ebx
 908:	5e                   	pop    %esi
 909:	5f                   	pop    %edi
 90a:	5d                   	pop    %ebp
 90b:	c3                   	ret    

0000090c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 90c:	55                   	push   %ebp
 90d:	89 e5                	mov    %esp,%ebp
 90f:	57                   	push   %edi
 910:	56                   	push   %esi
 911:	53                   	push   %ebx
 912:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 915:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 918:	a1 04 0e 00 00       	mov    0xe04,%eax
 91d:	eb 0c                	jmp    92b <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 91f:	8b 10                	mov    (%eax),%edx
 921:	39 c2                	cmp    %eax,%edx
 923:	77 04                	ja     929 <free+0x1d>
 925:	39 ca                	cmp    %ecx,%edx
 927:	77 10                	ja     939 <free+0x2d>
{
 929:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 92b:	39 c8                	cmp    %ecx,%eax
 92d:	73 f0                	jae    91f <free+0x13>
 92f:	8b 10                	mov    (%eax),%edx
 931:	39 ca                	cmp    %ecx,%edx
 933:	77 04                	ja     939 <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 935:	39 c2                	cmp    %eax,%edx
 937:	77 f0                	ja     929 <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 939:	8b 73 fc             	mov    -0x4(%ebx),%esi
 93c:	8b 10                	mov    (%eax),%edx
 93e:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 941:	39 fa                	cmp    %edi,%edx
 943:	74 19                	je     95e <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 945:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 948:	8b 50 04             	mov    0x4(%eax),%edx
 94b:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 94e:	39 f1                	cmp    %esi,%ecx
 950:	74 1b                	je     96d <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 952:	89 08                	mov    %ecx,(%eax)
  freep = p;
 954:	a3 04 0e 00 00       	mov    %eax,0xe04
}
 959:	5b                   	pop    %ebx
 95a:	5e                   	pop    %esi
 95b:	5f                   	pop    %edi
 95c:	5d                   	pop    %ebp
 95d:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 95e:	03 72 04             	add    0x4(%edx),%esi
 961:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 964:	8b 10                	mov    (%eax),%edx
 966:	8b 12                	mov    (%edx),%edx
 968:	89 53 f8             	mov    %edx,-0x8(%ebx)
 96b:	eb db                	jmp    948 <free+0x3c>
    p->s.size += bp->s.size;
 96d:	03 53 fc             	add    -0x4(%ebx),%edx
 970:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 973:	8b 53 f8             	mov    -0x8(%ebx),%edx
 976:	89 10                	mov    %edx,(%eax)
 978:	eb da                	jmp    954 <free+0x48>

0000097a <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 97a:	55                   	push   %ebp
 97b:	89 e5                	mov    %esp,%ebp
 97d:	57                   	push   %edi
 97e:	56                   	push   %esi
 97f:	53                   	push   %ebx
 980:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 983:	8b 45 08             	mov    0x8(%ebp),%eax
 986:	8d 58 07             	lea    0x7(%eax),%ebx
 989:	c1 eb 03             	shr    $0x3,%ebx
 98c:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 98f:	8b 15 04 0e 00 00    	mov    0xe04,%edx
 995:	85 d2                	test   %edx,%edx
 997:	74 20                	je     9b9 <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 999:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 99b:	8b 48 04             	mov    0x4(%eax),%ecx
 99e:	39 cb                	cmp    %ecx,%ebx
 9a0:	76 3c                	jbe    9de <malloc+0x64>
 9a2:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 9a8:	be 00 10 00 00       	mov    $0x1000,%esi
 9ad:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 9b0:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 9b7:	eb 70                	jmp    a29 <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 9b9:	c7 05 04 0e 00 00 08 	movl   $0xe08,0xe04
 9c0:	0e 00 00 
 9c3:	c7 05 08 0e 00 00 08 	movl   $0xe08,0xe08
 9ca:	0e 00 00 
    base.s.size = 0;
 9cd:	c7 05 0c 0e 00 00 00 	movl   $0x0,0xe0c
 9d4:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 9d7:	ba 08 0e 00 00       	mov    $0xe08,%edx
 9dc:	eb bb                	jmp    999 <malloc+0x1f>
      if(p->s.size == nunits)
 9de:	39 cb                	cmp    %ecx,%ebx
 9e0:	74 1c                	je     9fe <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 9e2:	29 d9                	sub    %ebx,%ecx
 9e4:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 9e7:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 9ea:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 9ed:	89 15 04 0e 00 00    	mov    %edx,0xe04
      return (void*)(p + 1);
 9f3:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 9f6:	8d 65 f4             	lea    -0xc(%ebp),%esp
 9f9:	5b                   	pop    %ebx
 9fa:	5e                   	pop    %esi
 9fb:	5f                   	pop    %edi
 9fc:	5d                   	pop    %ebp
 9fd:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 9fe:	8b 08                	mov    (%eax),%ecx
 a00:	89 0a                	mov    %ecx,(%edx)
 a02:	eb e9                	jmp    9ed <malloc+0x73>
  hp->s.size = nu;
 a04:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 a07:	83 ec 0c             	sub    $0xc,%esp
 a0a:	83 c0 08             	add    $0x8,%eax
 a0d:	50                   	push   %eax
 a0e:	e8 f9 fe ff ff       	call   90c <free>
  return freep;
 a13:	8b 15 04 0e 00 00    	mov    0xe04,%edx
      if((p = morecore(nunits)) == 0)
 a19:	83 c4 10             	add    $0x10,%esp
 a1c:	85 d2                	test   %edx,%edx
 a1e:	74 2b                	je     a4b <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a20:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 a22:	8b 48 04             	mov    0x4(%eax),%ecx
 a25:	39 d9                	cmp    %ebx,%ecx
 a27:	73 b5                	jae    9de <malloc+0x64>
 a29:	89 c2                	mov    %eax,%edx
    if(p == freep)
 a2b:	39 05 04 0e 00 00    	cmp    %eax,0xe04
 a31:	75 ed                	jne    a20 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 a33:	83 ec 0c             	sub    $0xc,%esp
 a36:	57                   	push   %edi
 a37:	e8 56 fc ff ff       	call   692 <sbrk>
  if(p == (char*)-1)
 a3c:	83 c4 10             	add    $0x10,%esp
 a3f:	83 f8 ff             	cmp    $0xffffffff,%eax
 a42:	75 c0                	jne    a04 <malloc+0x8a>
        return 0;
 a44:	b8 00 00 00 00       	mov    $0x0,%eax
 a49:	eb ab                	jmp    9f6 <malloc+0x7c>
 a4b:	b8 00 00 00 00       	mov    $0x0,%eax
 a50:	eb a4                	jmp    9f6 <malloc+0x7c>
