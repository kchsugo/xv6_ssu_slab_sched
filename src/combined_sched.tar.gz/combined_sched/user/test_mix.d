user/test_mix.o: user/test_mix.c /usr/include/stdc-predef.h types.h \
 stat.h user.h
