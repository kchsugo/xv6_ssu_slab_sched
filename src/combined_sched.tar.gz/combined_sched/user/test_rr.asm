
user/_test_rr:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#define INNER_LOOP 10000
#define OUTER_LOOP 20
#define PI 3.14 

int main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	56                   	push   %esi
   e:	53                   	push   %ebx
   f:	51                   	push   %ecx
  10:	83 ec 1c             	sub    $0x1c,%esp
	int pid = getpid();
  13:	e8 74 03 00 00       	call   38c <getpid>
	float dummy = 0;
	int i,j;
	printf(1, "=== TEST START ===\n");
  18:	83 ec 08             	sub    $0x8,%esp
  1b:	68 58 07 00 00       	push   $0x758
  20:	6a 01                	push   $0x1
  22:	e8 17 04 00 00       	call   43e <printf>
	pid = fork();
  27:	e8 d8 02 00 00       	call   304 <fork>
	if (pid == 0)	/* [P2] Child, its sched type must be ROUNDROBIN */
  2c:	83 c4 10             	add    $0x10,%esp
			wait();
		}
	} 
	else	/* [P1] Parent, its sched type must be ROUNDROBIN */
	{
		for (i=0; i<OUTER_LOOP; i++)
  2f:	bb 00 00 00 00       	mov    $0x0,%ebx
	float dummy = 0;
  34:	d9 ee                	fldz   
  36:	d9 5d e0             	fstps  -0x20(%ebp)
	if (pid == 0)	/* [P2] Child, its sched type must be ROUNDROBIN */
  39:	85 c0                	test   %eax,%eax
  3b:	74 62                	je     9f <main+0x9f>
		{
			for (j=0; j<INNER_LOOP; j++)
  3d:	b8 00 00 00 00       	mov    $0x0,%eax
				dummy += PI*j;
  42:	dd 05 d8 07 00 00    	fldl   0x7d8
  48:	89 45 dc             	mov    %eax,-0x24(%ebp)
  4b:	db 45 dc             	fildl  -0x24(%ebp)
  4e:	d8 c9                	fmul   %st(1),%st
  50:	d8 45 e0             	fadds  -0x20(%ebp)
  53:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  56:	83 c0 01             	add    $0x1,%eax
  59:	3d 10 27 00 00       	cmp    $0x2710,%eax
  5e:	75 e8                	jne    48 <main+0x48>
  60:	dd d8                	fstp   %st(0)
			printf(1, "P1 (RR), i = %d, dummy = %x\n", i, dummy);
  62:	83 ec 14             	sub    $0x14,%esp
  65:	d9 45 e0             	flds   -0x20(%ebp)
  68:	dd 1c 24             	fstpl  (%esp)
  6b:	53                   	push   %ebx
  6c:	68 a6 07 00 00       	push   $0x7a6
  71:	6a 01                	push   $0x1
  73:	e8 c6 03 00 00       	call   43e <printf>
		for (i=0; i<OUTER_LOOP; i++)
  78:	83 c3 01             	add    $0x1,%ebx
  7b:	83 c4 20             	add    $0x20,%esp
  7e:	83 fb 14             	cmp    $0x14,%ebx
  81:	75 ba                	jne    3d <main+0x3d>
		}
		wait();
  83:	e8 8c 02 00 00       	call   314 <wait>
		printf(1, "=== TEST DONE ===\n");
  88:	83 ec 08             	sub    $0x8,%esp
  8b:	68 c3 07 00 00       	push   $0x7c3
  90:	6a 01                	push   $0x1
  92:	e8 a7 03 00 00       	call   43e <printf>
  97:	83 c4 10             	add    $0x10,%esp
	}
	exit();
  9a:	e8 6d 02 00 00       	call   30c <exit>
  9f:	89 c6                	mov    %eax,%esi
		pid = fork();
  a1:	e8 5e 02 00 00       	call   304 <fork>
  a6:	89 c3                	mov    %eax,%ebx
		if (pid == 0) /* [P3] child-of-child, its sched type must be ROUNDROBIN */
  a8:	85 c0                	test   %eax,%eax
  aa:	74 51                	je     fd <main+0xfd>
			for (i=0; i<OUTER_LOOP; i++)
  ac:	89 f3                	mov    %esi,%ebx
	float dummy = 0;
  ae:	d9 ee                	fldz   
  b0:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
  b3:	89 f0                	mov    %esi,%eax
					dummy += PI*j;
  b5:	dd 05 d8 07 00 00    	fldl   0x7d8
  bb:	89 45 dc             	mov    %eax,-0x24(%ebp)
  be:	db 45 dc             	fildl  -0x24(%ebp)
  c1:	d8 c9                	fmul   %st(1),%st
  c3:	d8 45 e0             	fadds  -0x20(%ebp)
  c6:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
  c9:	83 c0 01             	add    $0x1,%eax
  cc:	3d 10 27 00 00       	cmp    $0x2710,%eax
  d1:	75 e8                	jne    bb <main+0xbb>
  d3:	dd d8                	fstp   %st(0)
				printf(1, "P2 (RR), i = %d, dummy = %x\n", i, dummy);
  d5:	83 ec 14             	sub    $0x14,%esp
  d8:	d9 45 e0             	flds   -0x20(%ebp)
  db:	dd 1c 24             	fstpl  (%esp)
  de:	53                   	push   %ebx
  df:	68 89 07 00 00       	push   $0x789
  e4:	6a 01                	push   $0x1
  e6:	e8 53 03 00 00       	call   43e <printf>
			for (i=0; i<OUTER_LOOP; i++)
  eb:	83 c3 01             	add    $0x1,%ebx
  ee:	83 c4 20             	add    $0x20,%esp
  f1:	83 fb 14             	cmp    $0x14,%ebx
  f4:	75 bd                	jne    b3 <main+0xb3>
			wait();
  f6:	e8 19 02 00 00       	call   314 <wait>
  fb:	eb 9d                	jmp    9a <main+0x9a>
			for (i=0; i<OUTER_LOOP; i++)
  fd:	89 c6                	mov    %eax,%esi
	float dummy = 0;
  ff:	d9 ee                	fldz   
 101:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
 104:	89 d8                	mov    %ebx,%eax
					dummy += PI*j;
 106:	dd 05 d8 07 00 00    	fldl   0x7d8
 10c:	89 45 dc             	mov    %eax,-0x24(%ebp)
 10f:	db 45 dc             	fildl  -0x24(%ebp)
 112:	d8 c9                	fmul   %st(1),%st
 114:	d8 45 e0             	fadds  -0x20(%ebp)
 117:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
 11a:	83 c0 01             	add    $0x1,%eax
 11d:	3d 10 27 00 00       	cmp    $0x2710,%eax
 122:	75 e8                	jne    10c <main+0x10c>
 124:	dd d8                	fstp   %st(0)
				printf(1, "P3 (RR), i = %d, dummy = %x\n", i, dummy);
 126:	83 ec 14             	sub    $0x14,%esp
 129:	d9 45 e0             	flds   -0x20(%ebp)
 12c:	dd 1c 24             	fstpl  (%esp)
 12f:	56                   	push   %esi
 130:	68 6c 07 00 00       	push   $0x76c
 135:	6a 01                	push   $0x1
 137:	e8 02 03 00 00       	call   43e <printf>
			for (i=0; i<OUTER_LOOP; i++)
 13c:	83 c6 01             	add    $0x1,%esi
 13f:	83 c4 20             	add    $0x20,%esp
 142:	83 fe 14             	cmp    $0x14,%esi
 145:	75 bd                	jne    104 <main+0x104>
 147:	e9 4e ff ff ff       	jmp    9a <main+0x9a>

0000014c <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 14c:	55                   	push   %ebp
 14d:	89 e5                	mov    %esp,%ebp
 14f:	53                   	push   %ebx
 150:	8b 45 08             	mov    0x8(%ebp),%eax
 153:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 156:	89 c2                	mov    %eax,%edx
 158:	83 c1 01             	add    $0x1,%ecx
 15b:	83 c2 01             	add    $0x1,%edx
 15e:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 162:	88 5a ff             	mov    %bl,-0x1(%edx)
 165:	84 db                	test   %bl,%bl
 167:	75 ef                	jne    158 <strcpy+0xc>
    ;
  return os;
}
 169:	5b                   	pop    %ebx
 16a:	5d                   	pop    %ebp
 16b:	c3                   	ret    

0000016c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 16c:	55                   	push   %ebp
 16d:	89 e5                	mov    %esp,%ebp
 16f:	8b 4d 08             	mov    0x8(%ebp),%ecx
 172:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 175:	0f b6 01             	movzbl (%ecx),%eax
 178:	84 c0                	test   %al,%al
 17a:	74 15                	je     191 <strcmp+0x25>
 17c:	3a 02                	cmp    (%edx),%al
 17e:	75 11                	jne    191 <strcmp+0x25>
    p++, q++;
 180:	83 c1 01             	add    $0x1,%ecx
 183:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 186:	0f b6 01             	movzbl (%ecx),%eax
 189:	84 c0                	test   %al,%al
 18b:	74 04                	je     191 <strcmp+0x25>
 18d:	3a 02                	cmp    (%edx),%al
 18f:	74 ef                	je     180 <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
 191:	0f b6 c0             	movzbl %al,%eax
 194:	0f b6 12             	movzbl (%edx),%edx
 197:	29 d0                	sub    %edx,%eax
}
 199:	5d                   	pop    %ebp
 19a:	c3                   	ret    

0000019b <strlen>:

uint
strlen(const char *s)
{
 19b:	55                   	push   %ebp
 19c:	89 e5                	mov    %esp,%ebp
 19e:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 1a1:	80 39 00             	cmpb   $0x0,(%ecx)
 1a4:	74 12                	je     1b8 <strlen+0x1d>
 1a6:	ba 00 00 00 00       	mov    $0x0,%edx
 1ab:	83 c2 01             	add    $0x1,%edx
 1ae:	89 d0                	mov    %edx,%eax
 1b0:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 1b4:	75 f5                	jne    1ab <strlen+0x10>
    ;
  return n;
}
 1b6:	5d                   	pop    %ebp
 1b7:	c3                   	ret    
  for(n = 0; s[n]; n++)
 1b8:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 1bd:	eb f7                	jmp    1b6 <strlen+0x1b>

000001bf <memset>:

void*
memset(void *dst, int c, uint n)
{
 1bf:	55                   	push   %ebp
 1c0:	89 e5                	mov    %esp,%ebp
 1c2:	57                   	push   %edi
 1c3:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 1c6:	89 d7                	mov    %edx,%edi
 1c8:	8b 4d 10             	mov    0x10(%ebp),%ecx
 1cb:	8b 45 0c             	mov    0xc(%ebp),%eax
 1ce:	fc                   	cld    
 1cf:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 1d1:	89 d0                	mov    %edx,%eax
 1d3:	5f                   	pop    %edi
 1d4:	5d                   	pop    %ebp
 1d5:	c3                   	ret    

000001d6 <strchr>:

char*
strchr(const char *s, char c)
{
 1d6:	55                   	push   %ebp
 1d7:	89 e5                	mov    %esp,%ebp
 1d9:	53                   	push   %ebx
 1da:	8b 45 08             	mov    0x8(%ebp),%eax
 1dd:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 1e0:	0f b6 10             	movzbl (%eax),%edx
 1e3:	84 d2                	test   %dl,%dl
 1e5:	74 1e                	je     205 <strchr+0x2f>
 1e7:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 1e9:	38 d3                	cmp    %dl,%bl
 1eb:	74 15                	je     202 <strchr+0x2c>
  for(; *s; s++)
 1ed:	83 c0 01             	add    $0x1,%eax
 1f0:	0f b6 10             	movzbl (%eax),%edx
 1f3:	84 d2                	test   %dl,%dl
 1f5:	74 06                	je     1fd <strchr+0x27>
    if(*s == c)
 1f7:	38 ca                	cmp    %cl,%dl
 1f9:	75 f2                	jne    1ed <strchr+0x17>
 1fb:	eb 05                	jmp    202 <strchr+0x2c>
      return (char*)s;
  return 0;
 1fd:	b8 00 00 00 00       	mov    $0x0,%eax
}
 202:	5b                   	pop    %ebx
 203:	5d                   	pop    %ebp
 204:	c3                   	ret    
  return 0;
 205:	b8 00 00 00 00       	mov    $0x0,%eax
 20a:	eb f6                	jmp    202 <strchr+0x2c>

0000020c <gets>:

char*
gets(char *buf, int max)
{
 20c:	55                   	push   %ebp
 20d:	89 e5                	mov    %esp,%ebp
 20f:	57                   	push   %edi
 210:	56                   	push   %esi
 211:	53                   	push   %ebx
 212:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 215:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 21a:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 21d:	8d 5e 01             	lea    0x1(%esi),%ebx
 220:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 223:	7d 2b                	jge    250 <gets+0x44>
    cc = read(0, &c, 1);
 225:	83 ec 04             	sub    $0x4,%esp
 228:	6a 01                	push   $0x1
 22a:	57                   	push   %edi
 22b:	6a 00                	push   $0x0
 22d:	e8 f2 00 00 00       	call   324 <read>
    if(cc < 1)
 232:	83 c4 10             	add    $0x10,%esp
 235:	85 c0                	test   %eax,%eax
 237:	7e 17                	jle    250 <gets+0x44>
      break;
    buf[i++] = c;
 239:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 23d:	8b 55 08             	mov    0x8(%ebp),%edx
 240:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 244:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 246:	3c 0a                	cmp    $0xa,%al
 248:	74 04                	je     24e <gets+0x42>
 24a:	3c 0d                	cmp    $0xd,%al
 24c:	75 cf                	jne    21d <gets+0x11>
  for(i=0; i+1 < max; ){
 24e:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 250:	8b 45 08             	mov    0x8(%ebp),%eax
 253:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 257:	8d 65 f4             	lea    -0xc(%ebp),%esp
 25a:	5b                   	pop    %ebx
 25b:	5e                   	pop    %esi
 25c:	5f                   	pop    %edi
 25d:	5d                   	pop    %ebp
 25e:	c3                   	ret    

0000025f <stat>:

int
stat(const char *n, struct stat *st)
{
 25f:	55                   	push   %ebp
 260:	89 e5                	mov    %esp,%ebp
 262:	56                   	push   %esi
 263:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 264:	83 ec 08             	sub    $0x8,%esp
 267:	6a 00                	push   $0x0
 269:	ff 75 08             	pushl  0x8(%ebp)
 26c:	e8 db 00 00 00       	call   34c <open>
  if(fd < 0)
 271:	83 c4 10             	add    $0x10,%esp
 274:	85 c0                	test   %eax,%eax
 276:	78 24                	js     29c <stat+0x3d>
 278:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 27a:	83 ec 08             	sub    $0x8,%esp
 27d:	ff 75 0c             	pushl  0xc(%ebp)
 280:	50                   	push   %eax
 281:	e8 de 00 00 00       	call   364 <fstat>
 286:	89 c6                	mov    %eax,%esi
  close(fd);
 288:	89 1c 24             	mov    %ebx,(%esp)
 28b:	e8 a4 00 00 00       	call   334 <close>
  return r;
 290:	83 c4 10             	add    $0x10,%esp
}
 293:	89 f0                	mov    %esi,%eax
 295:	8d 65 f8             	lea    -0x8(%ebp),%esp
 298:	5b                   	pop    %ebx
 299:	5e                   	pop    %esi
 29a:	5d                   	pop    %ebp
 29b:	c3                   	ret    
    return -1;
 29c:	be ff ff ff ff       	mov    $0xffffffff,%esi
 2a1:	eb f0                	jmp    293 <stat+0x34>

000002a3 <atoi>:

int
atoi(const char *s)
{
 2a3:	55                   	push   %ebp
 2a4:	89 e5                	mov    %esp,%ebp
 2a6:	53                   	push   %ebx
 2a7:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2aa:	0f b6 11             	movzbl (%ecx),%edx
 2ad:	8d 42 d0             	lea    -0x30(%edx),%eax
 2b0:	3c 09                	cmp    $0x9,%al
 2b2:	77 20                	ja     2d4 <atoi+0x31>
  n = 0;
 2b4:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 2b9:	83 c1 01             	add    $0x1,%ecx
 2bc:	8d 04 80             	lea    (%eax,%eax,4),%eax
 2bf:	0f be d2             	movsbl %dl,%edx
 2c2:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 2c6:	0f b6 11             	movzbl (%ecx),%edx
 2c9:	8d 5a d0             	lea    -0x30(%edx),%ebx
 2cc:	80 fb 09             	cmp    $0x9,%bl
 2cf:	76 e8                	jbe    2b9 <atoi+0x16>
  return n;
}
 2d1:	5b                   	pop    %ebx
 2d2:	5d                   	pop    %ebp
 2d3:	c3                   	ret    
  n = 0;
 2d4:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 2d9:	eb f6                	jmp    2d1 <atoi+0x2e>

000002db <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2db:	55                   	push   %ebp
 2dc:	89 e5                	mov    %esp,%ebp
 2de:	56                   	push   %esi
 2df:	53                   	push   %ebx
 2e0:	8b 45 08             	mov    0x8(%ebp),%eax
 2e3:	8b 75 0c             	mov    0xc(%ebp),%esi
 2e6:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 2e9:	85 db                	test   %ebx,%ebx
 2eb:	7e 13                	jle    300 <memmove+0x25>
 2ed:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 2f2:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 2f6:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 2f9:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 2fc:	39 d3                	cmp    %edx,%ebx
 2fe:	75 f2                	jne    2f2 <memmove+0x17>
  return vdst;
}
 300:	5b                   	pop    %ebx
 301:	5e                   	pop    %esi
 302:	5d                   	pop    %ebp
 303:	c3                   	ret    

00000304 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 304:	b8 01 00 00 00       	mov    $0x1,%eax
 309:	cd 40                	int    $0x40
 30b:	c3                   	ret    

0000030c <exit>:
SYSCALL(exit)
 30c:	b8 02 00 00 00       	mov    $0x2,%eax
 311:	cd 40                	int    $0x40
 313:	c3                   	ret    

00000314 <wait>:
SYSCALL(wait)
 314:	b8 03 00 00 00       	mov    $0x3,%eax
 319:	cd 40                	int    $0x40
 31b:	c3                   	ret    

0000031c <pipe>:
SYSCALL(pipe)
 31c:	b8 04 00 00 00       	mov    $0x4,%eax
 321:	cd 40                	int    $0x40
 323:	c3                   	ret    

00000324 <read>:
SYSCALL(read)
 324:	b8 05 00 00 00       	mov    $0x5,%eax
 329:	cd 40                	int    $0x40
 32b:	c3                   	ret    

0000032c <write>:
SYSCALL(write)
 32c:	b8 10 00 00 00       	mov    $0x10,%eax
 331:	cd 40                	int    $0x40
 333:	c3                   	ret    

00000334 <close>:
SYSCALL(close)
 334:	b8 15 00 00 00       	mov    $0x15,%eax
 339:	cd 40                	int    $0x40
 33b:	c3                   	ret    

0000033c <kill>:
SYSCALL(kill)
 33c:	b8 06 00 00 00       	mov    $0x6,%eax
 341:	cd 40                	int    $0x40
 343:	c3                   	ret    

00000344 <exec>:
SYSCALL(exec)
 344:	b8 07 00 00 00       	mov    $0x7,%eax
 349:	cd 40                	int    $0x40
 34b:	c3                   	ret    

0000034c <open>:
SYSCALL(open)
 34c:	b8 0f 00 00 00       	mov    $0xf,%eax
 351:	cd 40                	int    $0x40
 353:	c3                   	ret    

00000354 <mknod>:
SYSCALL(mknod)
 354:	b8 11 00 00 00       	mov    $0x11,%eax
 359:	cd 40                	int    $0x40
 35b:	c3                   	ret    

0000035c <unlink>:
SYSCALL(unlink)
 35c:	b8 12 00 00 00       	mov    $0x12,%eax
 361:	cd 40                	int    $0x40
 363:	c3                   	ret    

00000364 <fstat>:
SYSCALL(fstat)
 364:	b8 08 00 00 00       	mov    $0x8,%eax
 369:	cd 40                	int    $0x40
 36b:	c3                   	ret    

0000036c <link>:
SYSCALL(link)
 36c:	b8 13 00 00 00       	mov    $0x13,%eax
 371:	cd 40                	int    $0x40
 373:	c3                   	ret    

00000374 <mkdir>:
SYSCALL(mkdir)
 374:	b8 14 00 00 00       	mov    $0x14,%eax
 379:	cd 40                	int    $0x40
 37b:	c3                   	ret    

0000037c <chdir>:
SYSCALL(chdir)
 37c:	b8 09 00 00 00       	mov    $0x9,%eax
 381:	cd 40                	int    $0x40
 383:	c3                   	ret    

00000384 <dup>:
SYSCALL(dup)
 384:	b8 0a 00 00 00       	mov    $0xa,%eax
 389:	cd 40                	int    $0x40
 38b:	c3                   	ret    

0000038c <getpid>:
SYSCALL(getpid)
 38c:	b8 0b 00 00 00       	mov    $0xb,%eax
 391:	cd 40                	int    $0x40
 393:	c3                   	ret    

00000394 <sbrk>:
SYSCALL(sbrk)
 394:	b8 0c 00 00 00       	mov    $0xc,%eax
 399:	cd 40                	int    $0x40
 39b:	c3                   	ret    

0000039c <sleep>:
SYSCALL(sleep)
 39c:	b8 0d 00 00 00       	mov    $0xd,%eax
 3a1:	cd 40                	int    $0x40
 3a3:	c3                   	ret    

000003a4 <uptime>:
SYSCALL(uptime)
 3a4:	b8 0e 00 00 00       	mov    $0xe,%eax
 3a9:	cd 40                	int    $0x40
 3ab:	c3                   	ret    

000003ac <fork_rt>:
SYSCALL(fork_rt)
 3ac:	b8 16 00 00 00       	mov    $0x16,%eax
 3b1:	cd 40                	int    $0x40
 3b3:	c3                   	ret    

000003b4 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 3b4:	55                   	push   %ebp
 3b5:	89 e5                	mov    %esp,%ebp
 3b7:	57                   	push   %edi
 3b8:	56                   	push   %esi
 3b9:	53                   	push   %ebx
 3ba:	83 ec 3c             	sub    $0x3c,%esp
 3bd:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3bf:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 3c3:	74 14                	je     3d9 <printint+0x25>
 3c5:	85 d2                	test   %edx,%edx
 3c7:	79 10                	jns    3d9 <printint+0x25>
    neg = 1;
    x = -xx;
 3c9:	f7 da                	neg    %edx
    neg = 1;
 3cb:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 3d2:	bf 00 00 00 00       	mov    $0x0,%edi
 3d7:	eb 0b                	jmp    3e4 <printint+0x30>
  neg = 0;
 3d9:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 3e0:	eb f0                	jmp    3d2 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 3e2:	89 df                	mov    %ebx,%edi
 3e4:	8d 5f 01             	lea    0x1(%edi),%ebx
 3e7:	89 d0                	mov    %edx,%eax
 3e9:	ba 00 00 00 00       	mov    $0x0,%edx
 3ee:	f7 f1                	div    %ecx
 3f0:	0f b6 92 e8 07 00 00 	movzbl 0x7e8(%edx),%edx
 3f7:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 3fb:	89 c2                	mov    %eax,%edx
 3fd:	85 c0                	test   %eax,%eax
 3ff:	75 e1                	jne    3e2 <printint+0x2e>
  if(neg)
 401:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 405:	74 08                	je     40f <printint+0x5b>
    buf[i++] = '-';
 407:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 40c:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 40f:	83 eb 01             	sub    $0x1,%ebx
 412:	78 22                	js     436 <printint+0x82>
  write(fd, &c, 1);
 414:	8d 7d d7             	lea    -0x29(%ebp),%edi
 417:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 41c:	88 45 d7             	mov    %al,-0x29(%ebp)
 41f:	83 ec 04             	sub    $0x4,%esp
 422:	6a 01                	push   $0x1
 424:	57                   	push   %edi
 425:	56                   	push   %esi
 426:	e8 01 ff ff ff       	call   32c <write>
  while(--i >= 0)
 42b:	83 eb 01             	sub    $0x1,%ebx
 42e:	83 c4 10             	add    $0x10,%esp
 431:	83 fb ff             	cmp    $0xffffffff,%ebx
 434:	75 e1                	jne    417 <printint+0x63>
    putc(fd, buf[i]);
}
 436:	8d 65 f4             	lea    -0xc(%ebp),%esp
 439:	5b                   	pop    %ebx
 43a:	5e                   	pop    %esi
 43b:	5f                   	pop    %edi
 43c:	5d                   	pop    %ebp
 43d:	c3                   	ret    

0000043e <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 43e:	55                   	push   %ebp
 43f:	89 e5                	mov    %esp,%ebp
 441:	57                   	push   %edi
 442:	56                   	push   %esi
 443:	53                   	push   %ebx
 444:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 447:	8b 75 0c             	mov    0xc(%ebp),%esi
 44a:	0f b6 1e             	movzbl (%esi),%ebx
 44d:	84 db                	test   %bl,%bl
 44f:	0f 84 b1 01 00 00    	je     606 <printf+0x1c8>
 455:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 458:	8d 45 10             	lea    0x10(%ebp),%eax
 45b:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 45e:	bf 00 00 00 00       	mov    $0x0,%edi
 463:	eb 2d                	jmp    492 <printf+0x54>
 465:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 468:	83 ec 04             	sub    $0x4,%esp
 46b:	6a 01                	push   $0x1
 46d:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 470:	50                   	push   %eax
 471:	ff 75 08             	pushl  0x8(%ebp)
 474:	e8 b3 fe ff ff       	call   32c <write>
 479:	83 c4 10             	add    $0x10,%esp
 47c:	eb 05                	jmp    483 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 47e:	83 ff 25             	cmp    $0x25,%edi
 481:	74 22                	je     4a5 <printf+0x67>
 483:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 486:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 48a:	84 db                	test   %bl,%bl
 48c:	0f 84 74 01 00 00    	je     606 <printf+0x1c8>
    c = fmt[i] & 0xff;
 492:	0f be d3             	movsbl %bl,%edx
 495:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 498:	85 ff                	test   %edi,%edi
 49a:	75 e2                	jne    47e <printf+0x40>
      if(c == '%'){
 49c:	83 f8 25             	cmp    $0x25,%eax
 49f:	75 c4                	jne    465 <printf+0x27>
        state = '%';
 4a1:	89 c7                	mov    %eax,%edi
 4a3:	eb de                	jmp    483 <printf+0x45>
      if(c == 'd'){
 4a5:	83 f8 64             	cmp    $0x64,%eax
 4a8:	74 59                	je     503 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 4aa:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 4b0:	83 fa 70             	cmp    $0x70,%edx
 4b3:	74 7a                	je     52f <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 4b5:	83 f8 73             	cmp    $0x73,%eax
 4b8:	0f 84 9d 00 00 00    	je     55b <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 4be:	83 f8 63             	cmp    $0x63,%eax
 4c1:	0f 84 f2 00 00 00    	je     5b9 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 4c7:	83 f8 25             	cmp    $0x25,%eax
 4ca:	0f 84 15 01 00 00    	je     5e5 <printf+0x1a7>
 4d0:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 4d4:	83 ec 04             	sub    $0x4,%esp
 4d7:	6a 01                	push   $0x1
 4d9:	8d 45 e7             	lea    -0x19(%ebp),%eax
 4dc:	50                   	push   %eax
 4dd:	ff 75 08             	pushl  0x8(%ebp)
 4e0:	e8 47 fe ff ff       	call   32c <write>
 4e5:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 4e8:	83 c4 0c             	add    $0xc,%esp
 4eb:	6a 01                	push   $0x1
 4ed:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 4f0:	50                   	push   %eax
 4f1:	ff 75 08             	pushl  0x8(%ebp)
 4f4:	e8 33 fe ff ff       	call   32c <write>
 4f9:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 4fc:	bf 00 00 00 00       	mov    $0x0,%edi
 501:	eb 80                	jmp    483 <printf+0x45>
        printint(fd, *ap, 10, 1);
 503:	83 ec 0c             	sub    $0xc,%esp
 506:	6a 01                	push   $0x1
 508:	b9 0a 00 00 00       	mov    $0xa,%ecx
 50d:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 510:	8b 17                	mov    (%edi),%edx
 512:	8b 45 08             	mov    0x8(%ebp),%eax
 515:	e8 9a fe ff ff       	call   3b4 <printint>
        ap++;
 51a:	89 f8                	mov    %edi,%eax
 51c:	83 c0 04             	add    $0x4,%eax
 51f:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 522:	83 c4 10             	add    $0x10,%esp
      state = 0;
 525:	bf 00 00 00 00       	mov    $0x0,%edi
 52a:	e9 54 ff ff ff       	jmp    483 <printf+0x45>
        printint(fd, *ap, 16, 0);
 52f:	83 ec 0c             	sub    $0xc,%esp
 532:	6a 00                	push   $0x0
 534:	b9 10 00 00 00       	mov    $0x10,%ecx
 539:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 53c:	8b 17                	mov    (%edi),%edx
 53e:	8b 45 08             	mov    0x8(%ebp),%eax
 541:	e8 6e fe ff ff       	call   3b4 <printint>
        ap++;
 546:	89 f8                	mov    %edi,%eax
 548:	83 c0 04             	add    $0x4,%eax
 54b:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 54e:	83 c4 10             	add    $0x10,%esp
      state = 0;
 551:	bf 00 00 00 00       	mov    $0x0,%edi
 556:	e9 28 ff ff ff       	jmp    483 <printf+0x45>
        s = (char*)*ap;
 55b:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 55e:	8b 01                	mov    (%ecx),%eax
        ap++;
 560:	83 c1 04             	add    $0x4,%ecx
 563:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 566:	85 c0                	test   %eax,%eax
 568:	74 13                	je     57d <printf+0x13f>
        s = (char*)*ap;
 56a:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 56c:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 56f:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 574:	84 c0                	test   %al,%al
 576:	75 0f                	jne    587 <printf+0x149>
 578:	e9 06 ff ff ff       	jmp    483 <printf+0x45>
          s = "(null)";
 57d:	bb e0 07 00 00       	mov    $0x7e0,%ebx
        while(*s != 0){
 582:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 587:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 58a:	89 75 d0             	mov    %esi,-0x30(%ebp)
 58d:	8b 75 08             	mov    0x8(%ebp),%esi
 590:	88 45 e3             	mov    %al,-0x1d(%ebp)
 593:	83 ec 04             	sub    $0x4,%esp
 596:	6a 01                	push   $0x1
 598:	57                   	push   %edi
 599:	56                   	push   %esi
 59a:	e8 8d fd ff ff       	call   32c <write>
          s++;
 59f:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 5a2:	0f b6 03             	movzbl (%ebx),%eax
 5a5:	83 c4 10             	add    $0x10,%esp
 5a8:	84 c0                	test   %al,%al
 5aa:	75 e4                	jne    590 <printf+0x152>
 5ac:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 5af:	bf 00 00 00 00       	mov    $0x0,%edi
 5b4:	e9 ca fe ff ff       	jmp    483 <printf+0x45>
        putc(fd, *ap);
 5b9:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 5bc:	8b 07                	mov    (%edi),%eax
 5be:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 5c1:	83 ec 04             	sub    $0x4,%esp
 5c4:	6a 01                	push   $0x1
 5c6:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 5c9:	50                   	push   %eax
 5ca:	ff 75 08             	pushl  0x8(%ebp)
 5cd:	e8 5a fd ff ff       	call   32c <write>
        ap++;
 5d2:	83 c7 04             	add    $0x4,%edi
 5d5:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 5d8:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5db:	bf 00 00 00 00       	mov    $0x0,%edi
 5e0:	e9 9e fe ff ff       	jmp    483 <printf+0x45>
 5e5:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 5e8:	83 ec 04             	sub    $0x4,%esp
 5eb:	6a 01                	push   $0x1
 5ed:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 5f0:	50                   	push   %eax
 5f1:	ff 75 08             	pushl  0x8(%ebp)
 5f4:	e8 33 fd ff ff       	call   32c <write>
 5f9:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5fc:	bf 00 00 00 00       	mov    $0x0,%edi
 601:	e9 7d fe ff ff       	jmp    483 <printf+0x45>
    }
  }
}
 606:	8d 65 f4             	lea    -0xc(%ebp),%esp
 609:	5b                   	pop    %ebx
 60a:	5e                   	pop    %esi
 60b:	5f                   	pop    %edi
 60c:	5d                   	pop    %ebp
 60d:	c3                   	ret    

0000060e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 60e:	55                   	push   %ebp
 60f:	89 e5                	mov    %esp,%ebp
 611:	57                   	push   %edi
 612:	56                   	push   %esi
 613:	53                   	push   %ebx
 614:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 617:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 61a:	a1 58 0a 00 00       	mov    0xa58,%eax
 61f:	eb 0c                	jmp    62d <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 621:	8b 10                	mov    (%eax),%edx
 623:	39 c2                	cmp    %eax,%edx
 625:	77 04                	ja     62b <free+0x1d>
 627:	39 ca                	cmp    %ecx,%edx
 629:	77 10                	ja     63b <free+0x2d>
{
 62b:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 62d:	39 c8                	cmp    %ecx,%eax
 62f:	73 f0                	jae    621 <free+0x13>
 631:	8b 10                	mov    (%eax),%edx
 633:	39 ca                	cmp    %ecx,%edx
 635:	77 04                	ja     63b <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 637:	39 c2                	cmp    %eax,%edx
 639:	77 f0                	ja     62b <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 63b:	8b 73 fc             	mov    -0x4(%ebx),%esi
 63e:	8b 10                	mov    (%eax),%edx
 640:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 643:	39 fa                	cmp    %edi,%edx
 645:	74 19                	je     660 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 647:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 64a:	8b 50 04             	mov    0x4(%eax),%edx
 64d:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 650:	39 f1                	cmp    %esi,%ecx
 652:	74 1b                	je     66f <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 654:	89 08                	mov    %ecx,(%eax)
  freep = p;
 656:	a3 58 0a 00 00       	mov    %eax,0xa58
}
 65b:	5b                   	pop    %ebx
 65c:	5e                   	pop    %esi
 65d:	5f                   	pop    %edi
 65e:	5d                   	pop    %ebp
 65f:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 660:	03 72 04             	add    0x4(%edx),%esi
 663:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 666:	8b 10                	mov    (%eax),%edx
 668:	8b 12                	mov    (%edx),%edx
 66a:	89 53 f8             	mov    %edx,-0x8(%ebx)
 66d:	eb db                	jmp    64a <free+0x3c>
    p->s.size += bp->s.size;
 66f:	03 53 fc             	add    -0x4(%ebx),%edx
 672:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 675:	8b 53 f8             	mov    -0x8(%ebx),%edx
 678:	89 10                	mov    %edx,(%eax)
 67a:	eb da                	jmp    656 <free+0x48>

0000067c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 67c:	55                   	push   %ebp
 67d:	89 e5                	mov    %esp,%ebp
 67f:	57                   	push   %edi
 680:	56                   	push   %esi
 681:	53                   	push   %ebx
 682:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 685:	8b 45 08             	mov    0x8(%ebp),%eax
 688:	8d 58 07             	lea    0x7(%eax),%ebx
 68b:	c1 eb 03             	shr    $0x3,%ebx
 68e:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 691:	8b 15 58 0a 00 00    	mov    0xa58,%edx
 697:	85 d2                	test   %edx,%edx
 699:	74 20                	je     6bb <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 69b:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 69d:	8b 48 04             	mov    0x4(%eax),%ecx
 6a0:	39 cb                	cmp    %ecx,%ebx
 6a2:	76 3c                	jbe    6e0 <malloc+0x64>
 6a4:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 6aa:	be 00 10 00 00       	mov    $0x1000,%esi
 6af:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 6b2:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 6b9:	eb 70                	jmp    72b <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 6bb:	c7 05 58 0a 00 00 5c 	movl   $0xa5c,0xa58
 6c2:	0a 00 00 
 6c5:	c7 05 5c 0a 00 00 5c 	movl   $0xa5c,0xa5c
 6cc:	0a 00 00 
    base.s.size = 0;
 6cf:	c7 05 60 0a 00 00 00 	movl   $0x0,0xa60
 6d6:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 6d9:	ba 5c 0a 00 00       	mov    $0xa5c,%edx
 6de:	eb bb                	jmp    69b <malloc+0x1f>
      if(p->s.size == nunits)
 6e0:	39 cb                	cmp    %ecx,%ebx
 6e2:	74 1c                	je     700 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 6e4:	29 d9                	sub    %ebx,%ecx
 6e6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 6e9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 6ec:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 6ef:	89 15 58 0a 00 00    	mov    %edx,0xa58
      return (void*)(p + 1);
 6f5:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 6f8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6fb:	5b                   	pop    %ebx
 6fc:	5e                   	pop    %esi
 6fd:	5f                   	pop    %edi
 6fe:	5d                   	pop    %ebp
 6ff:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 700:	8b 08                	mov    (%eax),%ecx
 702:	89 0a                	mov    %ecx,(%edx)
 704:	eb e9                	jmp    6ef <malloc+0x73>
  hp->s.size = nu;
 706:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 709:	83 ec 0c             	sub    $0xc,%esp
 70c:	83 c0 08             	add    $0x8,%eax
 70f:	50                   	push   %eax
 710:	e8 f9 fe ff ff       	call   60e <free>
  return freep;
 715:	8b 15 58 0a 00 00    	mov    0xa58,%edx
      if((p = morecore(nunits)) == 0)
 71b:	83 c4 10             	add    $0x10,%esp
 71e:	85 d2                	test   %edx,%edx
 720:	74 2b                	je     74d <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 722:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 724:	8b 48 04             	mov    0x4(%eax),%ecx
 727:	39 d9                	cmp    %ebx,%ecx
 729:	73 b5                	jae    6e0 <malloc+0x64>
 72b:	89 c2                	mov    %eax,%edx
    if(p == freep)
 72d:	39 05 58 0a 00 00    	cmp    %eax,0xa58
 733:	75 ed                	jne    722 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 735:	83 ec 0c             	sub    $0xc,%esp
 738:	57                   	push   %edi
 739:	e8 56 fc ff ff       	call   394 <sbrk>
  if(p == (char*)-1)
 73e:	83 c4 10             	add    $0x10,%esp
 741:	83 f8 ff             	cmp    $0xffffffff,%eax
 744:	75 c0                	jne    706 <malloc+0x8a>
        return 0;
 746:	b8 00 00 00 00       	mov    $0x0,%eax
 74b:	eb ab                	jmp    6f8 <malloc+0x7c>
 74d:	b8 00 00 00 00       	mov    $0x0,%eax
 752:	eb a4                	jmp    6f8 <malloc+0x7c>
