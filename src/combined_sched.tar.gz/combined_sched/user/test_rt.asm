
user/_test_rt:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#define INNER_LOOP 1000
#define OUTER_LOOP 20
#define PI 3.14 

int main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	56                   	push   %esi
   e:	53                   	push   %ebx
   f:	51                   	push   %ecx
  10:	83 ec 1c             	sub    $0x1c,%esp
	int pid = getpid();
  13:	e8 c6 03 00 00       	call   3de <getpid>
	float dummy = 0;
	int i,j;
	printf(1, "=== TEST START ===\n");
  18:	83 ec 08             	sub    $0x8,%esp
  1b:	68 a8 07 00 00       	push   $0x7a8
  20:	6a 01                	push   $0x1
  22:	e8 69 04 00 00       	call   490 <printf>
	pid = fork_rt(10);
  27:	c7 04 24 0a 00 00 00 	movl   $0xa,(%esp)
  2e:	e8 cb 03 00 00       	call   3fe <fork_rt>
	if (pid == 0)	/* [PA] Child, its priority must be 10, sched type must be PRIORITY */
  33:	83 c4 10             	add    $0x10,%esp
  36:	85 c0                	test   %eax,%eax
  38:	74 6c                	je     a6 <main+0xa6>
			wait();
		}
	} 
	else	/* [P1] Parent, its sched type must be ROUNDROBIN. but, its priority must be 20 */
	{
		for (i=0; i<OUTER_LOOP; i++)
  3a:	bb 00 00 00 00       	mov    $0x0,%ebx
	float dummy = 0;
  3f:	d9 ee                	fldz   
  41:	d9 5d e0             	fstps  -0x20(%ebp)
		{
			for (j=0; j<INNER_LOOP; j++)
  44:	b8 00 00 00 00       	mov    $0x0,%eax
				dummy += PI*j;
  49:	dd 05 28 08 00 00    	fldl   0x828
  4f:	89 45 dc             	mov    %eax,-0x24(%ebp)
  52:	db 45 dc             	fildl  -0x24(%ebp)
  55:	d8 c9                	fmul   %st(1),%st
  57:	d8 45 e0             	fadds  -0x20(%ebp)
  5a:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  5d:	83 c0 01             	add    $0x1,%eax
  60:	3d e8 03 00 00       	cmp    $0x3e8,%eax
  65:	75 e8                	jne    4f <main+0x4f>
  67:	dd d8                	fstp   %st(0)
			printf(1, "P1 (RR), i = %d, dummy = %x\n", i, dummy);
  69:	83 ec 14             	sub    $0x14,%esp
  6c:	d9 45 e0             	flds   -0x20(%ebp)
  6f:	dd 1c 24             	fstpl  (%esp)
  72:	53                   	push   %ebx
  73:	68 f6 07 00 00       	push   $0x7f6
  78:	6a 01                	push   $0x1
  7a:	e8 11 04 00 00       	call   490 <printf>
		for (i=0; i<OUTER_LOOP; i++)
  7f:	83 c3 01             	add    $0x1,%ebx
  82:	83 c4 20             	add    $0x20,%esp
  85:	83 fb 14             	cmp    $0x14,%ebx
  88:	75 ba                	jne    44 <main+0x44>
		}
		wait();
  8a:	e8 d7 02 00 00       	call   366 <wait>
		printf(1, "=== TEST DONE ===\n");
  8f:	83 ec 08             	sub    $0x8,%esp
  92:	68 13 08 00 00       	push   $0x813
  97:	6a 01                	push   $0x1
  99:	e8 f2 03 00 00       	call   490 <printf>
  9e:	83 c4 10             	add    $0x10,%esp
	}
	exit();
  a1:	e8 b8 02 00 00       	call   35e <exit>
  a6:	89 c3                	mov    %eax,%ebx
		for (i=0; i<OUTER_LOOP/2; i++)
  a8:	89 c6                	mov    %eax,%esi
	float dummy = 0;
  aa:	d9 ee                	fldz   
  ac:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  af:	89 d8                	mov    %ebx,%eax
				dummy += PI*j;
  b1:	dd 05 28 08 00 00    	fldl   0x828
  b7:	89 45 dc             	mov    %eax,-0x24(%ebp)
  ba:	db 45 dc             	fildl  -0x24(%ebp)
  bd:	d8 c9                	fmul   %st(1),%st
  bf:	d8 45 e0             	fadds  -0x20(%ebp)
  c2:	d9 5d e0             	fstps  -0x20(%ebp)
			for (j=0; j<INNER_LOOP; j++)
  c5:	83 c0 01             	add    $0x1,%eax
  c8:	3d e8 03 00 00       	cmp    $0x3e8,%eax
  cd:	75 e8                	jne    b7 <main+0xb7>
  cf:	dd d8                	fstp   %st(0)
			printf(1, "PA (RT), i = %d, dummy = %x\n", i, dummy);
  d1:	83 ec 14             	sub    $0x14,%esp
  d4:	d9 45 e0             	flds   -0x20(%ebp)
  d7:	dd 1c 24             	fstpl  (%esp)
  da:	56                   	push   %esi
  db:	68 bc 07 00 00       	push   $0x7bc
  e0:	6a 01                	push   $0x1
  e2:	e8 a9 03 00 00       	call   490 <printf>
		for (i=0; i<OUTER_LOOP/2; i++)
  e7:	83 c6 01             	add    $0x1,%esi
  ea:	83 c4 20             	add    $0x20,%esp
  ed:	83 fe 0a             	cmp    $0xa,%esi
  f0:	75 bd                	jne    af <main+0xaf>
		pid = fork_rt(11);
  f2:	83 ec 0c             	sub    $0xc,%esp
  f5:	6a 0b                	push   $0xb
  f7:	e8 02 03 00 00       	call   3fe <fork_rt>
  fc:	89 c6                	mov    %eax,%esi
		if (pid == 0) /* [PB] child-of-child, its priority must be 11, sched type must be PRIORITY */
  fe:	83 c4 10             	add    $0x10,%esp
 101:	85 c0                	test   %eax,%eax
 103:	74 4f                	je     154 <main+0x154>
			for (i=0; i<OUTER_LOOP/2; i++)
 105:	89 de                	mov    %ebx,%esi
				for (j=0; j<INNER_LOOP; j++)
 107:	89 d8                	mov    %ebx,%eax
					dummy += PI*j;
 109:	dd 05 28 08 00 00    	fldl   0x828
 10f:	89 45 dc             	mov    %eax,-0x24(%ebp)
 112:	db 45 dc             	fildl  -0x24(%ebp)
 115:	d8 c9                	fmul   %st(1),%st
 117:	d8 45 e0             	fadds  -0x20(%ebp)
 11a:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
 11d:	83 c0 01             	add    $0x1,%eax
 120:	3d e8 03 00 00       	cmp    $0x3e8,%eax
 125:	75 e8                	jne    10f <main+0x10f>
 127:	dd d8                	fstp   %st(0)
				printf(1, "PA (RT), i = %d, dummy = %x\n", i, dummy);
 129:	83 ec 14             	sub    $0x14,%esp
 12c:	d9 45 e0             	flds   -0x20(%ebp)
 12f:	dd 1c 24             	fstpl  (%esp)
 132:	56                   	push   %esi
 133:	68 bc 07 00 00       	push   $0x7bc
 138:	6a 01                	push   $0x1
 13a:	e8 51 03 00 00       	call   490 <printf>
			for (i=0; i<OUTER_LOOP/2; i++)
 13f:	83 c6 01             	add    $0x1,%esi
 142:	83 c4 20             	add    $0x20,%esp
 145:	83 fe 0a             	cmp    $0xa,%esi
 148:	75 bd                	jne    107 <main+0x107>
			wait();
 14a:	e8 17 02 00 00       	call   366 <wait>
 14f:	e9 4d ff ff ff       	jmp    a1 <main+0xa1>
			for (i=0; i<OUTER_LOOP/2; i++)
 154:	89 c3                	mov    %eax,%ebx
				for (j=0; j<INNER_LOOP; j++)
 156:	89 f0                	mov    %esi,%eax
					dummy += PI*j;
 158:	dd 05 28 08 00 00    	fldl   0x828
 15e:	89 45 dc             	mov    %eax,-0x24(%ebp)
 161:	db 45 dc             	fildl  -0x24(%ebp)
 164:	d8 c9                	fmul   %st(1),%st
 166:	d8 45 e0             	fadds  -0x20(%ebp)
 169:	d9 5d e0             	fstps  -0x20(%ebp)
				for (j=0; j<INNER_LOOP; j++)
 16c:	83 c0 01             	add    $0x1,%eax
 16f:	3d e8 03 00 00       	cmp    $0x3e8,%eax
 174:	75 e8                	jne    15e <main+0x15e>
 176:	dd d8                	fstp   %st(0)
				printf(1, "PB (RT), i = %d, dummy = %x\n", i, dummy);
 178:	83 ec 14             	sub    $0x14,%esp
 17b:	d9 45 e0             	flds   -0x20(%ebp)
 17e:	dd 1c 24             	fstpl  (%esp)
 181:	53                   	push   %ebx
 182:	68 d9 07 00 00       	push   $0x7d9
 187:	6a 01                	push   $0x1
 189:	e8 02 03 00 00       	call   490 <printf>
			for (i=0; i<OUTER_LOOP/2; i++)
 18e:	83 c3 01             	add    $0x1,%ebx
 191:	83 c4 20             	add    $0x20,%esp
 194:	83 fb 0a             	cmp    $0xa,%ebx
 197:	75 bd                	jne    156 <main+0x156>
 199:	e9 03 ff ff ff       	jmp    a1 <main+0xa1>

0000019e <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 19e:	55                   	push   %ebp
 19f:	89 e5                	mov    %esp,%ebp
 1a1:	53                   	push   %ebx
 1a2:	8b 45 08             	mov    0x8(%ebp),%eax
 1a5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1a8:	89 c2                	mov    %eax,%edx
 1aa:	83 c1 01             	add    $0x1,%ecx
 1ad:	83 c2 01             	add    $0x1,%edx
 1b0:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 1b4:	88 5a ff             	mov    %bl,-0x1(%edx)
 1b7:	84 db                	test   %bl,%bl
 1b9:	75 ef                	jne    1aa <strcpy+0xc>
    ;
  return os;
}
 1bb:	5b                   	pop    %ebx
 1bc:	5d                   	pop    %ebp
 1bd:	c3                   	ret    

000001be <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1be:	55                   	push   %ebp
 1bf:	89 e5                	mov    %esp,%ebp
 1c1:	8b 4d 08             	mov    0x8(%ebp),%ecx
 1c4:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 1c7:	0f b6 01             	movzbl (%ecx),%eax
 1ca:	84 c0                	test   %al,%al
 1cc:	74 15                	je     1e3 <strcmp+0x25>
 1ce:	3a 02                	cmp    (%edx),%al
 1d0:	75 11                	jne    1e3 <strcmp+0x25>
    p++, q++;
 1d2:	83 c1 01             	add    $0x1,%ecx
 1d5:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 1d8:	0f b6 01             	movzbl (%ecx),%eax
 1db:	84 c0                	test   %al,%al
 1dd:	74 04                	je     1e3 <strcmp+0x25>
 1df:	3a 02                	cmp    (%edx),%al
 1e1:	74 ef                	je     1d2 <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
 1e3:	0f b6 c0             	movzbl %al,%eax
 1e6:	0f b6 12             	movzbl (%edx),%edx
 1e9:	29 d0                	sub    %edx,%eax
}
 1eb:	5d                   	pop    %ebp
 1ec:	c3                   	ret    

000001ed <strlen>:

uint
strlen(const char *s)
{
 1ed:	55                   	push   %ebp
 1ee:	89 e5                	mov    %esp,%ebp
 1f0:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 1f3:	80 39 00             	cmpb   $0x0,(%ecx)
 1f6:	74 12                	je     20a <strlen+0x1d>
 1f8:	ba 00 00 00 00       	mov    $0x0,%edx
 1fd:	83 c2 01             	add    $0x1,%edx
 200:	89 d0                	mov    %edx,%eax
 202:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 206:	75 f5                	jne    1fd <strlen+0x10>
    ;
  return n;
}
 208:	5d                   	pop    %ebp
 209:	c3                   	ret    
  for(n = 0; s[n]; n++)
 20a:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 20f:	eb f7                	jmp    208 <strlen+0x1b>

00000211 <memset>:

void*
memset(void *dst, int c, uint n)
{
 211:	55                   	push   %ebp
 212:	89 e5                	mov    %esp,%ebp
 214:	57                   	push   %edi
 215:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 218:	89 d7                	mov    %edx,%edi
 21a:	8b 4d 10             	mov    0x10(%ebp),%ecx
 21d:	8b 45 0c             	mov    0xc(%ebp),%eax
 220:	fc                   	cld    
 221:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 223:	89 d0                	mov    %edx,%eax
 225:	5f                   	pop    %edi
 226:	5d                   	pop    %ebp
 227:	c3                   	ret    

00000228 <strchr>:

char*
strchr(const char *s, char c)
{
 228:	55                   	push   %ebp
 229:	89 e5                	mov    %esp,%ebp
 22b:	53                   	push   %ebx
 22c:	8b 45 08             	mov    0x8(%ebp),%eax
 22f:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 232:	0f b6 10             	movzbl (%eax),%edx
 235:	84 d2                	test   %dl,%dl
 237:	74 1e                	je     257 <strchr+0x2f>
 239:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 23b:	38 d3                	cmp    %dl,%bl
 23d:	74 15                	je     254 <strchr+0x2c>
  for(; *s; s++)
 23f:	83 c0 01             	add    $0x1,%eax
 242:	0f b6 10             	movzbl (%eax),%edx
 245:	84 d2                	test   %dl,%dl
 247:	74 06                	je     24f <strchr+0x27>
    if(*s == c)
 249:	38 ca                	cmp    %cl,%dl
 24b:	75 f2                	jne    23f <strchr+0x17>
 24d:	eb 05                	jmp    254 <strchr+0x2c>
      return (char*)s;
  return 0;
 24f:	b8 00 00 00 00       	mov    $0x0,%eax
}
 254:	5b                   	pop    %ebx
 255:	5d                   	pop    %ebp
 256:	c3                   	ret    
  return 0;
 257:	b8 00 00 00 00       	mov    $0x0,%eax
 25c:	eb f6                	jmp    254 <strchr+0x2c>

0000025e <gets>:

char*
gets(char *buf, int max)
{
 25e:	55                   	push   %ebp
 25f:	89 e5                	mov    %esp,%ebp
 261:	57                   	push   %edi
 262:	56                   	push   %esi
 263:	53                   	push   %ebx
 264:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 267:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 26c:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 26f:	8d 5e 01             	lea    0x1(%esi),%ebx
 272:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 275:	7d 2b                	jge    2a2 <gets+0x44>
    cc = read(0, &c, 1);
 277:	83 ec 04             	sub    $0x4,%esp
 27a:	6a 01                	push   $0x1
 27c:	57                   	push   %edi
 27d:	6a 00                	push   $0x0
 27f:	e8 f2 00 00 00       	call   376 <read>
    if(cc < 1)
 284:	83 c4 10             	add    $0x10,%esp
 287:	85 c0                	test   %eax,%eax
 289:	7e 17                	jle    2a2 <gets+0x44>
      break;
    buf[i++] = c;
 28b:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 28f:	8b 55 08             	mov    0x8(%ebp),%edx
 292:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 296:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 298:	3c 0a                	cmp    $0xa,%al
 29a:	74 04                	je     2a0 <gets+0x42>
 29c:	3c 0d                	cmp    $0xd,%al
 29e:	75 cf                	jne    26f <gets+0x11>
  for(i=0; i+1 < max; ){
 2a0:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 2a2:	8b 45 08             	mov    0x8(%ebp),%eax
 2a5:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 2a9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2ac:	5b                   	pop    %ebx
 2ad:	5e                   	pop    %esi
 2ae:	5f                   	pop    %edi
 2af:	5d                   	pop    %ebp
 2b0:	c3                   	ret    

000002b1 <stat>:

int
stat(const char *n, struct stat *st)
{
 2b1:	55                   	push   %ebp
 2b2:	89 e5                	mov    %esp,%ebp
 2b4:	56                   	push   %esi
 2b5:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2b6:	83 ec 08             	sub    $0x8,%esp
 2b9:	6a 00                	push   $0x0
 2bb:	ff 75 08             	pushl  0x8(%ebp)
 2be:	e8 db 00 00 00       	call   39e <open>
  if(fd < 0)
 2c3:	83 c4 10             	add    $0x10,%esp
 2c6:	85 c0                	test   %eax,%eax
 2c8:	78 24                	js     2ee <stat+0x3d>
 2ca:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 2cc:	83 ec 08             	sub    $0x8,%esp
 2cf:	ff 75 0c             	pushl  0xc(%ebp)
 2d2:	50                   	push   %eax
 2d3:	e8 de 00 00 00       	call   3b6 <fstat>
 2d8:	89 c6                	mov    %eax,%esi
  close(fd);
 2da:	89 1c 24             	mov    %ebx,(%esp)
 2dd:	e8 a4 00 00 00       	call   386 <close>
  return r;
 2e2:	83 c4 10             	add    $0x10,%esp
}
 2e5:	89 f0                	mov    %esi,%eax
 2e7:	8d 65 f8             	lea    -0x8(%ebp),%esp
 2ea:	5b                   	pop    %ebx
 2eb:	5e                   	pop    %esi
 2ec:	5d                   	pop    %ebp
 2ed:	c3                   	ret    
    return -1;
 2ee:	be ff ff ff ff       	mov    $0xffffffff,%esi
 2f3:	eb f0                	jmp    2e5 <stat+0x34>

000002f5 <atoi>:

int
atoi(const char *s)
{
 2f5:	55                   	push   %ebp
 2f6:	89 e5                	mov    %esp,%ebp
 2f8:	53                   	push   %ebx
 2f9:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2fc:	0f b6 11             	movzbl (%ecx),%edx
 2ff:	8d 42 d0             	lea    -0x30(%edx),%eax
 302:	3c 09                	cmp    $0x9,%al
 304:	77 20                	ja     326 <atoi+0x31>
  n = 0;
 306:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 30b:	83 c1 01             	add    $0x1,%ecx
 30e:	8d 04 80             	lea    (%eax,%eax,4),%eax
 311:	0f be d2             	movsbl %dl,%edx
 314:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 318:	0f b6 11             	movzbl (%ecx),%edx
 31b:	8d 5a d0             	lea    -0x30(%edx),%ebx
 31e:	80 fb 09             	cmp    $0x9,%bl
 321:	76 e8                	jbe    30b <atoi+0x16>
  return n;
}
 323:	5b                   	pop    %ebx
 324:	5d                   	pop    %ebp
 325:	c3                   	ret    
  n = 0;
 326:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 32b:	eb f6                	jmp    323 <atoi+0x2e>

0000032d <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 32d:	55                   	push   %ebp
 32e:	89 e5                	mov    %esp,%ebp
 330:	56                   	push   %esi
 331:	53                   	push   %ebx
 332:	8b 45 08             	mov    0x8(%ebp),%eax
 335:	8b 75 0c             	mov    0xc(%ebp),%esi
 338:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 33b:	85 db                	test   %ebx,%ebx
 33d:	7e 13                	jle    352 <memmove+0x25>
 33f:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 344:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 348:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 34b:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 34e:	39 d3                	cmp    %edx,%ebx
 350:	75 f2                	jne    344 <memmove+0x17>
  return vdst;
}
 352:	5b                   	pop    %ebx
 353:	5e                   	pop    %esi
 354:	5d                   	pop    %ebp
 355:	c3                   	ret    

00000356 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 356:	b8 01 00 00 00       	mov    $0x1,%eax
 35b:	cd 40                	int    $0x40
 35d:	c3                   	ret    

0000035e <exit>:
SYSCALL(exit)
 35e:	b8 02 00 00 00       	mov    $0x2,%eax
 363:	cd 40                	int    $0x40
 365:	c3                   	ret    

00000366 <wait>:
SYSCALL(wait)
 366:	b8 03 00 00 00       	mov    $0x3,%eax
 36b:	cd 40                	int    $0x40
 36d:	c3                   	ret    

0000036e <pipe>:
SYSCALL(pipe)
 36e:	b8 04 00 00 00       	mov    $0x4,%eax
 373:	cd 40                	int    $0x40
 375:	c3                   	ret    

00000376 <read>:
SYSCALL(read)
 376:	b8 05 00 00 00       	mov    $0x5,%eax
 37b:	cd 40                	int    $0x40
 37d:	c3                   	ret    

0000037e <write>:
SYSCALL(write)
 37e:	b8 10 00 00 00       	mov    $0x10,%eax
 383:	cd 40                	int    $0x40
 385:	c3                   	ret    

00000386 <close>:
SYSCALL(close)
 386:	b8 15 00 00 00       	mov    $0x15,%eax
 38b:	cd 40                	int    $0x40
 38d:	c3                   	ret    

0000038e <kill>:
SYSCALL(kill)
 38e:	b8 06 00 00 00       	mov    $0x6,%eax
 393:	cd 40                	int    $0x40
 395:	c3                   	ret    

00000396 <exec>:
SYSCALL(exec)
 396:	b8 07 00 00 00       	mov    $0x7,%eax
 39b:	cd 40                	int    $0x40
 39d:	c3                   	ret    

0000039e <open>:
SYSCALL(open)
 39e:	b8 0f 00 00 00       	mov    $0xf,%eax
 3a3:	cd 40                	int    $0x40
 3a5:	c3                   	ret    

000003a6 <mknod>:
SYSCALL(mknod)
 3a6:	b8 11 00 00 00       	mov    $0x11,%eax
 3ab:	cd 40                	int    $0x40
 3ad:	c3                   	ret    

000003ae <unlink>:
SYSCALL(unlink)
 3ae:	b8 12 00 00 00       	mov    $0x12,%eax
 3b3:	cd 40                	int    $0x40
 3b5:	c3                   	ret    

000003b6 <fstat>:
SYSCALL(fstat)
 3b6:	b8 08 00 00 00       	mov    $0x8,%eax
 3bb:	cd 40                	int    $0x40
 3bd:	c3                   	ret    

000003be <link>:
SYSCALL(link)
 3be:	b8 13 00 00 00       	mov    $0x13,%eax
 3c3:	cd 40                	int    $0x40
 3c5:	c3                   	ret    

000003c6 <mkdir>:
SYSCALL(mkdir)
 3c6:	b8 14 00 00 00       	mov    $0x14,%eax
 3cb:	cd 40                	int    $0x40
 3cd:	c3                   	ret    

000003ce <chdir>:
SYSCALL(chdir)
 3ce:	b8 09 00 00 00       	mov    $0x9,%eax
 3d3:	cd 40                	int    $0x40
 3d5:	c3                   	ret    

000003d6 <dup>:
SYSCALL(dup)
 3d6:	b8 0a 00 00 00       	mov    $0xa,%eax
 3db:	cd 40                	int    $0x40
 3dd:	c3                   	ret    

000003de <getpid>:
SYSCALL(getpid)
 3de:	b8 0b 00 00 00       	mov    $0xb,%eax
 3e3:	cd 40                	int    $0x40
 3e5:	c3                   	ret    

000003e6 <sbrk>:
SYSCALL(sbrk)
 3e6:	b8 0c 00 00 00       	mov    $0xc,%eax
 3eb:	cd 40                	int    $0x40
 3ed:	c3                   	ret    

000003ee <sleep>:
SYSCALL(sleep)
 3ee:	b8 0d 00 00 00       	mov    $0xd,%eax
 3f3:	cd 40                	int    $0x40
 3f5:	c3                   	ret    

000003f6 <uptime>:
SYSCALL(uptime)
 3f6:	b8 0e 00 00 00       	mov    $0xe,%eax
 3fb:	cd 40                	int    $0x40
 3fd:	c3                   	ret    

000003fe <fork_rt>:
SYSCALL(fork_rt)
 3fe:	b8 16 00 00 00       	mov    $0x16,%eax
 403:	cd 40                	int    $0x40
 405:	c3                   	ret    

00000406 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 406:	55                   	push   %ebp
 407:	89 e5                	mov    %esp,%ebp
 409:	57                   	push   %edi
 40a:	56                   	push   %esi
 40b:	53                   	push   %ebx
 40c:	83 ec 3c             	sub    $0x3c,%esp
 40f:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 411:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 415:	74 14                	je     42b <printint+0x25>
 417:	85 d2                	test   %edx,%edx
 419:	79 10                	jns    42b <printint+0x25>
    neg = 1;
    x = -xx;
 41b:	f7 da                	neg    %edx
    neg = 1;
 41d:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 424:	bf 00 00 00 00       	mov    $0x0,%edi
 429:	eb 0b                	jmp    436 <printint+0x30>
  neg = 0;
 42b:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 432:	eb f0                	jmp    424 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 434:	89 df                	mov    %ebx,%edi
 436:	8d 5f 01             	lea    0x1(%edi),%ebx
 439:	89 d0                	mov    %edx,%eax
 43b:	ba 00 00 00 00       	mov    $0x0,%edx
 440:	f7 f1                	div    %ecx
 442:	0f b6 92 38 08 00 00 	movzbl 0x838(%edx),%edx
 449:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 44d:	89 c2                	mov    %eax,%edx
 44f:	85 c0                	test   %eax,%eax
 451:	75 e1                	jne    434 <printint+0x2e>
  if(neg)
 453:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 457:	74 08                	je     461 <printint+0x5b>
    buf[i++] = '-';
 459:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 45e:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 461:	83 eb 01             	sub    $0x1,%ebx
 464:	78 22                	js     488 <printint+0x82>
  write(fd, &c, 1);
 466:	8d 7d d7             	lea    -0x29(%ebp),%edi
 469:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 46e:	88 45 d7             	mov    %al,-0x29(%ebp)
 471:	83 ec 04             	sub    $0x4,%esp
 474:	6a 01                	push   $0x1
 476:	57                   	push   %edi
 477:	56                   	push   %esi
 478:	e8 01 ff ff ff       	call   37e <write>
  while(--i >= 0)
 47d:	83 eb 01             	sub    $0x1,%ebx
 480:	83 c4 10             	add    $0x10,%esp
 483:	83 fb ff             	cmp    $0xffffffff,%ebx
 486:	75 e1                	jne    469 <printint+0x63>
    putc(fd, buf[i]);
}
 488:	8d 65 f4             	lea    -0xc(%ebp),%esp
 48b:	5b                   	pop    %ebx
 48c:	5e                   	pop    %esi
 48d:	5f                   	pop    %edi
 48e:	5d                   	pop    %ebp
 48f:	c3                   	ret    

00000490 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 490:	55                   	push   %ebp
 491:	89 e5                	mov    %esp,%ebp
 493:	57                   	push   %edi
 494:	56                   	push   %esi
 495:	53                   	push   %ebx
 496:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 499:	8b 75 0c             	mov    0xc(%ebp),%esi
 49c:	0f b6 1e             	movzbl (%esi),%ebx
 49f:	84 db                	test   %bl,%bl
 4a1:	0f 84 b1 01 00 00    	je     658 <printf+0x1c8>
 4a7:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 4aa:	8d 45 10             	lea    0x10(%ebp),%eax
 4ad:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 4b0:	bf 00 00 00 00       	mov    $0x0,%edi
 4b5:	eb 2d                	jmp    4e4 <printf+0x54>
 4b7:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 4ba:	83 ec 04             	sub    $0x4,%esp
 4bd:	6a 01                	push   $0x1
 4bf:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 4c2:	50                   	push   %eax
 4c3:	ff 75 08             	pushl  0x8(%ebp)
 4c6:	e8 b3 fe ff ff       	call   37e <write>
 4cb:	83 c4 10             	add    $0x10,%esp
 4ce:	eb 05                	jmp    4d5 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 4d0:	83 ff 25             	cmp    $0x25,%edi
 4d3:	74 22                	je     4f7 <printf+0x67>
 4d5:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 4d8:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 4dc:	84 db                	test   %bl,%bl
 4de:	0f 84 74 01 00 00    	je     658 <printf+0x1c8>
    c = fmt[i] & 0xff;
 4e4:	0f be d3             	movsbl %bl,%edx
 4e7:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 4ea:	85 ff                	test   %edi,%edi
 4ec:	75 e2                	jne    4d0 <printf+0x40>
      if(c == '%'){
 4ee:	83 f8 25             	cmp    $0x25,%eax
 4f1:	75 c4                	jne    4b7 <printf+0x27>
        state = '%';
 4f3:	89 c7                	mov    %eax,%edi
 4f5:	eb de                	jmp    4d5 <printf+0x45>
      if(c == 'd'){
 4f7:	83 f8 64             	cmp    $0x64,%eax
 4fa:	74 59                	je     555 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 4fc:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 502:	83 fa 70             	cmp    $0x70,%edx
 505:	74 7a                	je     581 <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 507:	83 f8 73             	cmp    $0x73,%eax
 50a:	0f 84 9d 00 00 00    	je     5ad <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 510:	83 f8 63             	cmp    $0x63,%eax
 513:	0f 84 f2 00 00 00    	je     60b <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 519:	83 f8 25             	cmp    $0x25,%eax
 51c:	0f 84 15 01 00 00    	je     637 <printf+0x1a7>
 522:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 526:	83 ec 04             	sub    $0x4,%esp
 529:	6a 01                	push   $0x1
 52b:	8d 45 e7             	lea    -0x19(%ebp),%eax
 52e:	50                   	push   %eax
 52f:	ff 75 08             	pushl  0x8(%ebp)
 532:	e8 47 fe ff ff       	call   37e <write>
 537:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 53a:	83 c4 0c             	add    $0xc,%esp
 53d:	6a 01                	push   $0x1
 53f:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 542:	50                   	push   %eax
 543:	ff 75 08             	pushl  0x8(%ebp)
 546:	e8 33 fe ff ff       	call   37e <write>
 54b:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 54e:	bf 00 00 00 00       	mov    $0x0,%edi
 553:	eb 80                	jmp    4d5 <printf+0x45>
        printint(fd, *ap, 10, 1);
 555:	83 ec 0c             	sub    $0xc,%esp
 558:	6a 01                	push   $0x1
 55a:	b9 0a 00 00 00       	mov    $0xa,%ecx
 55f:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 562:	8b 17                	mov    (%edi),%edx
 564:	8b 45 08             	mov    0x8(%ebp),%eax
 567:	e8 9a fe ff ff       	call   406 <printint>
        ap++;
 56c:	89 f8                	mov    %edi,%eax
 56e:	83 c0 04             	add    $0x4,%eax
 571:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 574:	83 c4 10             	add    $0x10,%esp
      state = 0;
 577:	bf 00 00 00 00       	mov    $0x0,%edi
 57c:	e9 54 ff ff ff       	jmp    4d5 <printf+0x45>
        printint(fd, *ap, 16, 0);
 581:	83 ec 0c             	sub    $0xc,%esp
 584:	6a 00                	push   $0x0
 586:	b9 10 00 00 00       	mov    $0x10,%ecx
 58b:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 58e:	8b 17                	mov    (%edi),%edx
 590:	8b 45 08             	mov    0x8(%ebp),%eax
 593:	e8 6e fe ff ff       	call   406 <printint>
        ap++;
 598:	89 f8                	mov    %edi,%eax
 59a:	83 c0 04             	add    $0x4,%eax
 59d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 5a0:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5a3:	bf 00 00 00 00       	mov    $0x0,%edi
 5a8:	e9 28 ff ff ff       	jmp    4d5 <printf+0x45>
        s = (char*)*ap;
 5ad:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 5b0:	8b 01                	mov    (%ecx),%eax
        ap++;
 5b2:	83 c1 04             	add    $0x4,%ecx
 5b5:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 5b8:	85 c0                	test   %eax,%eax
 5ba:	74 13                	je     5cf <printf+0x13f>
        s = (char*)*ap;
 5bc:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 5be:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 5c1:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 5c6:	84 c0                	test   %al,%al
 5c8:	75 0f                	jne    5d9 <printf+0x149>
 5ca:	e9 06 ff ff ff       	jmp    4d5 <printf+0x45>
          s = "(null)";
 5cf:	bb 30 08 00 00       	mov    $0x830,%ebx
        while(*s != 0){
 5d4:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 5d9:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 5dc:	89 75 d0             	mov    %esi,-0x30(%ebp)
 5df:	8b 75 08             	mov    0x8(%ebp),%esi
 5e2:	88 45 e3             	mov    %al,-0x1d(%ebp)
 5e5:	83 ec 04             	sub    $0x4,%esp
 5e8:	6a 01                	push   $0x1
 5ea:	57                   	push   %edi
 5eb:	56                   	push   %esi
 5ec:	e8 8d fd ff ff       	call   37e <write>
          s++;
 5f1:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 5f4:	0f b6 03             	movzbl (%ebx),%eax
 5f7:	83 c4 10             	add    $0x10,%esp
 5fa:	84 c0                	test   %al,%al
 5fc:	75 e4                	jne    5e2 <printf+0x152>
 5fe:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 601:	bf 00 00 00 00       	mov    $0x0,%edi
 606:	e9 ca fe ff ff       	jmp    4d5 <printf+0x45>
        putc(fd, *ap);
 60b:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 60e:	8b 07                	mov    (%edi),%eax
 610:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 613:	83 ec 04             	sub    $0x4,%esp
 616:	6a 01                	push   $0x1
 618:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 61b:	50                   	push   %eax
 61c:	ff 75 08             	pushl  0x8(%ebp)
 61f:	e8 5a fd ff ff       	call   37e <write>
        ap++;
 624:	83 c7 04             	add    $0x4,%edi
 627:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 62a:	83 c4 10             	add    $0x10,%esp
      state = 0;
 62d:	bf 00 00 00 00       	mov    $0x0,%edi
 632:	e9 9e fe ff ff       	jmp    4d5 <printf+0x45>
 637:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 63a:	83 ec 04             	sub    $0x4,%esp
 63d:	6a 01                	push   $0x1
 63f:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 642:	50                   	push   %eax
 643:	ff 75 08             	pushl  0x8(%ebp)
 646:	e8 33 fd ff ff       	call   37e <write>
 64b:	83 c4 10             	add    $0x10,%esp
      state = 0;
 64e:	bf 00 00 00 00       	mov    $0x0,%edi
 653:	e9 7d fe ff ff       	jmp    4d5 <printf+0x45>
    }
  }
}
 658:	8d 65 f4             	lea    -0xc(%ebp),%esp
 65b:	5b                   	pop    %ebx
 65c:	5e                   	pop    %esi
 65d:	5f                   	pop    %edi
 65e:	5d                   	pop    %ebp
 65f:	c3                   	ret    

00000660 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 660:	55                   	push   %ebp
 661:	89 e5                	mov    %esp,%ebp
 663:	57                   	push   %edi
 664:	56                   	push   %esi
 665:	53                   	push   %ebx
 666:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 669:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 66c:	a1 a8 0a 00 00       	mov    0xaa8,%eax
 671:	eb 0c                	jmp    67f <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 673:	8b 10                	mov    (%eax),%edx
 675:	39 c2                	cmp    %eax,%edx
 677:	77 04                	ja     67d <free+0x1d>
 679:	39 ca                	cmp    %ecx,%edx
 67b:	77 10                	ja     68d <free+0x2d>
{
 67d:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 67f:	39 c8                	cmp    %ecx,%eax
 681:	73 f0                	jae    673 <free+0x13>
 683:	8b 10                	mov    (%eax),%edx
 685:	39 ca                	cmp    %ecx,%edx
 687:	77 04                	ja     68d <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 689:	39 c2                	cmp    %eax,%edx
 68b:	77 f0                	ja     67d <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 68d:	8b 73 fc             	mov    -0x4(%ebx),%esi
 690:	8b 10                	mov    (%eax),%edx
 692:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 695:	39 fa                	cmp    %edi,%edx
 697:	74 19                	je     6b2 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 699:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 69c:	8b 50 04             	mov    0x4(%eax),%edx
 69f:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 6a2:	39 f1                	cmp    %esi,%ecx
 6a4:	74 1b                	je     6c1 <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 6a6:	89 08                	mov    %ecx,(%eax)
  freep = p;
 6a8:	a3 a8 0a 00 00       	mov    %eax,0xaa8
}
 6ad:	5b                   	pop    %ebx
 6ae:	5e                   	pop    %esi
 6af:	5f                   	pop    %edi
 6b0:	5d                   	pop    %ebp
 6b1:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 6b2:	03 72 04             	add    0x4(%edx),%esi
 6b5:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 6b8:	8b 10                	mov    (%eax),%edx
 6ba:	8b 12                	mov    (%edx),%edx
 6bc:	89 53 f8             	mov    %edx,-0x8(%ebx)
 6bf:	eb db                	jmp    69c <free+0x3c>
    p->s.size += bp->s.size;
 6c1:	03 53 fc             	add    -0x4(%ebx),%edx
 6c4:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 6c7:	8b 53 f8             	mov    -0x8(%ebx),%edx
 6ca:	89 10                	mov    %edx,(%eax)
 6cc:	eb da                	jmp    6a8 <free+0x48>

000006ce <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 6ce:	55                   	push   %ebp
 6cf:	89 e5                	mov    %esp,%ebp
 6d1:	57                   	push   %edi
 6d2:	56                   	push   %esi
 6d3:	53                   	push   %ebx
 6d4:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 6d7:	8b 45 08             	mov    0x8(%ebp),%eax
 6da:	8d 58 07             	lea    0x7(%eax),%ebx
 6dd:	c1 eb 03             	shr    $0x3,%ebx
 6e0:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 6e3:	8b 15 a8 0a 00 00    	mov    0xaa8,%edx
 6e9:	85 d2                	test   %edx,%edx
 6eb:	74 20                	je     70d <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 6ed:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 6ef:	8b 48 04             	mov    0x4(%eax),%ecx
 6f2:	39 cb                	cmp    %ecx,%ebx
 6f4:	76 3c                	jbe    732 <malloc+0x64>
 6f6:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 6fc:	be 00 10 00 00       	mov    $0x1000,%esi
 701:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 704:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 70b:	eb 70                	jmp    77d <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 70d:	c7 05 a8 0a 00 00 ac 	movl   $0xaac,0xaa8
 714:	0a 00 00 
 717:	c7 05 ac 0a 00 00 ac 	movl   $0xaac,0xaac
 71e:	0a 00 00 
    base.s.size = 0;
 721:	c7 05 b0 0a 00 00 00 	movl   $0x0,0xab0
 728:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 72b:	ba ac 0a 00 00       	mov    $0xaac,%edx
 730:	eb bb                	jmp    6ed <malloc+0x1f>
      if(p->s.size == nunits)
 732:	39 cb                	cmp    %ecx,%ebx
 734:	74 1c                	je     752 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 736:	29 d9                	sub    %ebx,%ecx
 738:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 73b:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 73e:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 741:	89 15 a8 0a 00 00    	mov    %edx,0xaa8
      return (void*)(p + 1);
 747:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 74a:	8d 65 f4             	lea    -0xc(%ebp),%esp
 74d:	5b                   	pop    %ebx
 74e:	5e                   	pop    %esi
 74f:	5f                   	pop    %edi
 750:	5d                   	pop    %ebp
 751:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 752:	8b 08                	mov    (%eax),%ecx
 754:	89 0a                	mov    %ecx,(%edx)
 756:	eb e9                	jmp    741 <malloc+0x73>
  hp->s.size = nu;
 758:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 75b:	83 ec 0c             	sub    $0xc,%esp
 75e:	83 c0 08             	add    $0x8,%eax
 761:	50                   	push   %eax
 762:	e8 f9 fe ff ff       	call   660 <free>
  return freep;
 767:	8b 15 a8 0a 00 00    	mov    0xaa8,%edx
      if((p = morecore(nunits)) == 0)
 76d:	83 c4 10             	add    $0x10,%esp
 770:	85 d2                	test   %edx,%edx
 772:	74 2b                	je     79f <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 774:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 776:	8b 48 04             	mov    0x4(%eax),%ecx
 779:	39 d9                	cmp    %ebx,%ecx
 77b:	73 b5                	jae    732 <malloc+0x64>
 77d:	89 c2                	mov    %eax,%edx
    if(p == freep)
 77f:	39 05 a8 0a 00 00    	cmp    %eax,0xaa8
 785:	75 ed                	jne    774 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 787:	83 ec 0c             	sub    $0xc,%esp
 78a:	57                   	push   %edi
 78b:	e8 56 fc ff ff       	call   3e6 <sbrk>
  if(p == (char*)-1)
 790:	83 c4 10             	add    $0x10,%esp
 793:	83 f8 ff             	cmp    $0xffffffff,%eax
 796:	75 c0                	jne    758 <malloc+0x8a>
        return 0;
 798:	b8 00 00 00 00       	mov    $0x0,%eax
 79d:	eb ab                	jmp    74a <malloc+0x7c>
 79f:	b8 00 00 00 00       	mov    $0x0,%eax
 7a4:	eb a4                	jmp    74a <malloc+0x7c>
