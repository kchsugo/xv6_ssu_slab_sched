user/test_rt.o: user/test_rt.c /usr/include/stdc-predef.h types.h stat.h \
 user.h
