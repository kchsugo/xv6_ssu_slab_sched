
kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc c0 45 1d 80       	mov    $0x801d45c0,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 8b 2a 10 80       	mov    $0x80102a8b,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax

80100034 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100034:	55                   	push   %ebp
80100035:	89 e5                	mov    %esp,%ebp
80100037:	53                   	push   %ebx
80100038:	83 ec 0c             	sub    $0xc,%esp
  struct buf *b;

  initlock(&bcache.lock, "bcache");
8010003b:	68 00 80 10 80       	push   $0x80108000
80100040:	68 c0 45 1d 80       	push   $0x801d45c0
80100045:	e8 3a 3c 00 00       	call   80103c84 <initlock>

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
8010004a:	c7 05 0c 8d 1d 80 bc 	movl   $0x801d8cbc,0x801d8d0c
80100051:	8c 1d 80 
  bcache.head.next = &bcache.head;
80100054:	c7 05 10 8d 1d 80 bc 	movl   $0x801d8cbc,0x801d8d10
8010005b:	8c 1d 80 
8010005e:	83 c4 10             	add    $0x10,%esp
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100061:	bb f4 45 1d 80       	mov    $0x801d45f4,%ebx
    b->next = bcache.head.next;
80100066:	a1 10 8d 1d 80       	mov    0x801d8d10,%eax
8010006b:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
8010006e:	c7 43 50 bc 8c 1d 80 	movl   $0x801d8cbc,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100075:	83 ec 08             	sub    $0x8,%esp
80100078:	68 07 80 10 80       	push   $0x80108007
8010007d:	8d 43 0c             	lea    0xc(%ebx),%eax
80100080:	50                   	push   %eax
80100081:	e8 f4 3a 00 00       	call   80103b7a <initsleeplock>
    bcache.head.next->prev = b;
80100086:	a1 10 8d 1d 80       	mov    0x801d8d10,%eax
8010008b:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
8010008e:	89 1d 10 8d 1d 80    	mov    %ebx,0x801d8d10
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100094:	81 c3 5c 02 00 00    	add    $0x25c,%ebx
8010009a:	83 c4 10             	add    $0x10,%esp
8010009d:	81 fb bc 8c 1d 80    	cmp    $0x801d8cbc,%ebx
801000a3:	72 c1                	jb     80100066 <binit+0x32>
  }
}
801000a5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000a8:	c9                   	leave  
801000a9:	c3                   	ret    

801000aa <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000aa:	55                   	push   %ebp
801000ab:	89 e5                	mov    %esp,%ebp
801000ad:	57                   	push   %edi
801000ae:	56                   	push   %esi
801000af:	53                   	push   %ebx
801000b0:	83 ec 18             	sub    $0x18,%esp
801000b3:	8b 75 08             	mov    0x8(%ebp),%esi
801000b6:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000b9:	68 c0 45 1d 80       	push   $0x801d45c0
801000be:	e8 09 3d 00 00       	call   80103dcc <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000c3:	8b 1d 10 8d 1d 80    	mov    0x801d8d10,%ebx
801000c9:	83 c4 10             	add    $0x10,%esp
801000cc:	81 fb bc 8c 1d 80    	cmp    $0x801d8cbc,%ebx
801000d2:	75 26                	jne    801000fa <bread+0x50>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
801000d4:	8b 1d 0c 8d 1d 80    	mov    0x801d8d0c,%ebx
801000da:	81 fb bc 8c 1d 80    	cmp    $0x801d8cbc,%ebx
801000e0:	75 4e                	jne    80100130 <bread+0x86>
  panic("bget: no buffers");
801000e2:	83 ec 0c             	sub    $0xc,%esp
801000e5:	68 0e 80 10 80       	push   $0x8010800e
801000ea:	e8 55 02 00 00       	call   80100344 <panic>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000ef:	8b 5b 54             	mov    0x54(%ebx),%ebx
801000f2:	81 fb bc 8c 1d 80    	cmp    $0x801d8cbc,%ebx
801000f8:	74 da                	je     801000d4 <bread+0x2a>
    if(b->dev == dev && b->blockno == blockno){
801000fa:	3b 73 04             	cmp    0x4(%ebx),%esi
801000fd:	75 f0                	jne    801000ef <bread+0x45>
801000ff:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100102:	75 eb                	jne    801000ef <bread+0x45>
      b->refcnt++;
80100104:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100108:	83 ec 0c             	sub    $0xc,%esp
8010010b:	68 c0 45 1d 80       	push   $0x801d45c0
80100110:	e8 1e 3d 00 00       	call   80103e33 <release>
      acquiresleep(&b->lock);
80100115:	8d 43 0c             	lea    0xc(%ebx),%eax
80100118:	89 04 24             	mov    %eax,(%esp)
8010011b:	e8 8d 3a 00 00       	call   80103bad <acquiresleep>
80100120:	83 c4 10             	add    $0x10,%esp
80100123:	eb 44                	jmp    80100169 <bread+0xbf>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100125:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100128:	81 fb bc 8c 1d 80    	cmp    $0x801d8cbc,%ebx
8010012e:	74 b2                	je     801000e2 <bread+0x38>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
80100130:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
80100134:	75 ef                	jne    80100125 <bread+0x7b>
80100136:	f6 03 04             	testb  $0x4,(%ebx)
80100139:	75 ea                	jne    80100125 <bread+0x7b>
      b->dev = dev;
8010013b:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010013e:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
80100141:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100147:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010014e:	83 ec 0c             	sub    $0xc,%esp
80100151:	68 c0 45 1d 80       	push   $0x801d45c0
80100156:	e8 d8 3c 00 00       	call   80103e33 <release>
      acquiresleep(&b->lock);
8010015b:	8d 43 0c             	lea    0xc(%ebx),%eax
8010015e:	89 04 24             	mov    %eax,(%esp)
80100161:	e8 47 3a 00 00       	call   80103bad <acquiresleep>
80100166:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100169:	f6 03 02             	testb  $0x2,(%ebx)
8010016c:	74 0a                	je     80100178 <bread+0xce>
    iderw(b);
  }
  return b;
}
8010016e:	89 d8                	mov    %ebx,%eax
80100170:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100173:	5b                   	pop    %ebx
80100174:	5e                   	pop    %esi
80100175:	5f                   	pop    %edi
80100176:	5d                   	pop    %ebp
80100177:	c3                   	ret    
    iderw(b);
80100178:	83 ec 0c             	sub    $0xc,%esp
8010017b:	53                   	push   %ebx
8010017c:	e8 0e 1d 00 00       	call   80101e8f <iderw>
80100181:	83 c4 10             	add    $0x10,%esp
  return b;
80100184:	eb e8                	jmp    8010016e <bread+0xc4>

80100186 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
80100186:	55                   	push   %ebp
80100187:	89 e5                	mov    %esp,%ebp
80100189:	53                   	push   %ebx
8010018a:	83 ec 10             	sub    $0x10,%esp
8010018d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
80100190:	8d 43 0c             	lea    0xc(%ebx),%eax
80100193:	50                   	push   %eax
80100194:	e8 a1 3a 00 00       	call   80103c3a <holdingsleep>
80100199:	83 c4 10             	add    $0x10,%esp
8010019c:	85 c0                	test   %eax,%eax
8010019e:	74 14                	je     801001b4 <bwrite+0x2e>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001a0:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001a3:	83 ec 0c             	sub    $0xc,%esp
801001a6:	53                   	push   %ebx
801001a7:	e8 e3 1c 00 00       	call   80101e8f <iderw>
}
801001ac:	83 c4 10             	add    $0x10,%esp
801001af:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001b2:	c9                   	leave  
801001b3:	c3                   	ret    
    panic("bwrite");
801001b4:	83 ec 0c             	sub    $0xc,%esp
801001b7:	68 1f 80 10 80       	push   $0x8010801f
801001bc:	e8 83 01 00 00       	call   80100344 <panic>

801001c1 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
801001c1:	55                   	push   %ebp
801001c2:	89 e5                	mov    %esp,%ebp
801001c4:	56                   	push   %esi
801001c5:	53                   	push   %ebx
801001c6:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001c9:	8d 73 0c             	lea    0xc(%ebx),%esi
801001cc:	83 ec 0c             	sub    $0xc,%esp
801001cf:	56                   	push   %esi
801001d0:	e8 65 3a 00 00       	call   80103c3a <holdingsleep>
801001d5:	83 c4 10             	add    $0x10,%esp
801001d8:	85 c0                	test   %eax,%eax
801001da:	74 6b                	je     80100247 <brelse+0x86>
    panic("brelse");

  releasesleep(&b->lock);
801001dc:	83 ec 0c             	sub    $0xc,%esp
801001df:	56                   	push   %esi
801001e0:	e8 1a 3a 00 00       	call   80103bff <releasesleep>

  acquire(&bcache.lock);
801001e5:	c7 04 24 c0 45 1d 80 	movl   $0x801d45c0,(%esp)
801001ec:	e8 db 3b 00 00       	call   80103dcc <acquire>
  b->refcnt--;
801001f1:	8b 43 4c             	mov    0x4c(%ebx),%eax
801001f4:	83 e8 01             	sub    $0x1,%eax
801001f7:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
801001fa:	83 c4 10             	add    $0x10,%esp
801001fd:	85 c0                	test   %eax,%eax
801001ff:	75 2f                	jne    80100230 <brelse+0x6f>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100201:	8b 43 54             	mov    0x54(%ebx),%eax
80100204:	8b 53 50             	mov    0x50(%ebx),%edx
80100207:	89 50 50             	mov    %edx,0x50(%eax)
    b->prev->next = b->next;
8010020a:	8b 43 50             	mov    0x50(%ebx),%eax
8010020d:	8b 53 54             	mov    0x54(%ebx),%edx
80100210:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
80100213:	a1 10 8d 1d 80       	mov    0x801d8d10,%eax
80100218:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
8010021b:	c7 43 50 bc 8c 1d 80 	movl   $0x801d8cbc,0x50(%ebx)
    bcache.head.next->prev = b;
80100222:	a1 10 8d 1d 80       	mov    0x801d8d10,%eax
80100227:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
8010022a:	89 1d 10 8d 1d 80    	mov    %ebx,0x801d8d10
  }
  
  release(&bcache.lock);
80100230:	83 ec 0c             	sub    $0xc,%esp
80100233:	68 c0 45 1d 80       	push   $0x801d45c0
80100238:	e8 f6 3b 00 00       	call   80103e33 <release>
}
8010023d:	83 c4 10             	add    $0x10,%esp
80100240:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100243:	5b                   	pop    %ebx
80100244:	5e                   	pop    %esi
80100245:	5d                   	pop    %ebp
80100246:	c3                   	ret    
    panic("brelse");
80100247:	83 ec 0c             	sub    $0xc,%esp
8010024a:	68 26 80 10 80       	push   $0x80108026
8010024f:	e8 f0 00 00 00       	call   80100344 <panic>

80100254 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
80100254:	55                   	push   %ebp
80100255:	89 e5                	mov    %esp,%ebp
80100257:	57                   	push   %edi
80100258:	56                   	push   %esi
80100259:	53                   	push   %ebx
8010025a:	83 ec 28             	sub    $0x28,%esp
8010025d:	8b 7d 0c             	mov    0xc(%ebp),%edi
80100260:	8b 75 10             	mov    0x10(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
80100263:	ff 75 08             	pushl  0x8(%ebp)
80100266:	e8 3d 13 00 00       	call   801015a8 <iunlock>
  target = n;
8010026b:	89 75 e4             	mov    %esi,-0x1c(%ebp)
  acquire(&cons.lock);
8010026e:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
80100275:	e8 52 3b 00 00       	call   80103dcc <acquire>
  while(n > 0){
8010027a:	83 c4 10             	add    $0x10,%esp
    while(input.r == input.w){
8010027d:	bb 20 8f 1d 80       	mov    $0x801d8f20,%ebx
  while(n > 0){
80100282:	85 f6                	test   %esi,%esi
80100284:	7e 68                	jle    801002ee <consoleread+0x9a>
    while(input.r == input.w){
80100286:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
8010028c:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
80100292:	75 2e                	jne    801002c2 <consoleread+0x6e>
      if(myproc()->killed){
80100294:	e8 b4 30 00 00       	call   8010334d <myproc>
80100299:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010029d:	75 71                	jne    80100310 <consoleread+0xbc>
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
8010029f:	83 ec 08             	sub    $0x8,%esp
801002a2:	68 20 b5 10 80       	push   $0x8010b520
801002a7:	68 a0 8f 1d 80       	push   $0x801d8fa0
801002ac:	e8 48 35 00 00       	call   801037f9 <sleep>
    while(input.r == input.w){
801002b1:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
801002b7:	83 c4 10             	add    $0x10,%esp
801002ba:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
801002c0:	74 d2                	je     80100294 <consoleread+0x40>
    }
    c = input.buf[input.r++ % INPUT_BUF];
801002c2:	8d 50 01             	lea    0x1(%eax),%edx
801002c5:	89 93 80 00 00 00    	mov    %edx,0x80(%ebx)
801002cb:	89 c2                	mov    %eax,%edx
801002cd:	83 e2 7f             	and    $0x7f,%edx
801002d0:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
801002d4:	0f be d1             	movsbl %cl,%edx
    if(c == C('D')){  // EOF
801002d7:	83 fa 04             	cmp    $0x4,%edx
801002da:	74 5c                	je     80100338 <consoleread+0xe4>
        // caller gets a 0-byte result.
        input.r--;
      }
      break;
    }
    *dst++ = c;
801002dc:	83 c7 01             	add    $0x1,%edi
801002df:	88 4f ff             	mov    %cl,-0x1(%edi)
    --n;
801002e2:	83 ee 01             	sub    $0x1,%esi
    if(c == '\n')
801002e5:	83 fa 0a             	cmp    $0xa,%edx
801002e8:	74 04                	je     801002ee <consoleread+0x9a>
  while(n > 0){
801002ea:	85 f6                	test   %esi,%esi
801002ec:	75 98                	jne    80100286 <consoleread+0x32>
      break;
  }
  release(&cons.lock);
801002ee:	83 ec 0c             	sub    $0xc,%esp
801002f1:	68 20 b5 10 80       	push   $0x8010b520
801002f6:	e8 38 3b 00 00       	call   80103e33 <release>
  ilock(ip);
801002fb:	83 c4 04             	add    $0x4,%esp
801002fe:	ff 75 08             	pushl  0x8(%ebp)
80100301:	e8 e0 11 00 00       	call   801014e6 <ilock>

  return target - n;
80100306:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80100309:	29 f0                	sub    %esi,%eax
8010030b:	83 c4 10             	add    $0x10,%esp
8010030e:	eb 20                	jmp    80100330 <consoleread+0xdc>
        release(&cons.lock);
80100310:	83 ec 0c             	sub    $0xc,%esp
80100313:	68 20 b5 10 80       	push   $0x8010b520
80100318:	e8 16 3b 00 00       	call   80103e33 <release>
        ilock(ip);
8010031d:	83 c4 04             	add    $0x4,%esp
80100320:	ff 75 08             	pushl  0x8(%ebp)
80100323:	e8 be 11 00 00       	call   801014e6 <ilock>
        return -1;
80100328:	83 c4 10             	add    $0x10,%esp
8010032b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80100330:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100333:	5b                   	pop    %ebx
80100334:	5e                   	pop    %esi
80100335:	5f                   	pop    %edi
80100336:	5d                   	pop    %ebp
80100337:	c3                   	ret    
      if(n < target){
80100338:	3b 75 e4             	cmp    -0x1c(%ebp),%esi
8010033b:	73 b1                	jae    801002ee <consoleread+0x9a>
        input.r--;
8010033d:	a3 a0 8f 1d 80       	mov    %eax,0x801d8fa0
80100342:	eb aa                	jmp    801002ee <consoleread+0x9a>

80100344 <panic>:
{
80100344:	55                   	push   %ebp
80100345:	89 e5                	mov    %esp,%ebp
80100347:	56                   	push   %esi
80100348:	53                   	push   %ebx
80100349:	83 ec 30             	sub    $0x30,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
8010034c:	fa                   	cli    
  cons.locking = 0;
8010034d:	c7 05 54 b5 10 80 00 	movl   $0x0,0x8010b554
80100354:	00 00 00 
  cprintf("lapicid %d: panic: ", lapicid());
80100357:	e8 e4 20 00 00       	call   80102440 <lapicid>
8010035c:	83 ec 08             	sub    $0x8,%esp
8010035f:	50                   	push   %eax
80100360:	68 2d 80 10 80       	push   $0x8010802d
80100365:	e8 77 02 00 00       	call   801005e1 <cprintf>
  cprintf(s);
8010036a:	83 c4 04             	add    $0x4,%esp
8010036d:	ff 75 08             	pushl  0x8(%ebp)
80100370:	e8 6c 02 00 00       	call   801005e1 <cprintf>
  cprintf("\n");
80100375:	c7 04 24 9f 89 10 80 	movl   $0x8010899f,(%esp)
8010037c:	e8 60 02 00 00       	call   801005e1 <cprintf>
  getcallerpcs(&s, pcs);
80100381:	83 c4 08             	add    $0x8,%esp
80100384:	8d 5d d0             	lea    -0x30(%ebp),%ebx
80100387:	53                   	push   %ebx
80100388:	8d 45 08             	lea    0x8(%ebp),%eax
8010038b:	50                   	push   %eax
8010038c:	e8 0e 39 00 00       	call   80103c9f <getcallerpcs>
80100391:	8d 75 f8             	lea    -0x8(%ebp),%esi
80100394:	83 c4 10             	add    $0x10,%esp
    cprintf(" %p", pcs[i]);
80100397:	83 ec 08             	sub    $0x8,%esp
8010039a:	ff 33                	pushl  (%ebx)
8010039c:	68 0c 86 10 80       	push   $0x8010860c
801003a1:	e8 3b 02 00 00       	call   801005e1 <cprintf>
801003a6:	83 c3 04             	add    $0x4,%ebx
  for(i=0; i<10; i++)
801003a9:	83 c4 10             	add    $0x10,%esp
801003ac:	39 f3                	cmp    %esi,%ebx
801003ae:	75 e7                	jne    80100397 <panic+0x53>
  panicked = 1; // freeze other CPU
801003b0:	c7 05 58 b5 10 80 01 	movl   $0x1,0x8010b558
801003b7:	00 00 00 
801003ba:	eb fe                	jmp    801003ba <panic+0x76>

801003bc <consputc>:
  if(panicked){
801003bc:	83 3d 58 b5 10 80 00 	cmpl   $0x0,0x8010b558
801003c3:	74 03                	je     801003c8 <consputc+0xc>
801003c5:	fa                   	cli    
801003c6:	eb fe                	jmp    801003c6 <consputc+0xa>
{
801003c8:	55                   	push   %ebp
801003c9:	89 e5                	mov    %esp,%ebp
801003cb:	57                   	push   %edi
801003cc:	56                   	push   %esi
801003cd:	53                   	push   %ebx
801003ce:	83 ec 0c             	sub    $0xc,%esp
801003d1:	89 c6                	mov    %eax,%esi
  if(c == BACKSPACE){
801003d3:	3d 00 01 00 00       	cmp    $0x100,%eax
801003d8:	74 5f                	je     80100439 <consputc+0x7d>
    uartputc(c);
801003da:	83 ec 0c             	sub    $0xc,%esp
801003dd:	50                   	push   %eax
801003de:	e8 3d 4e 00 00       	call   80105220 <uartputc>
801003e3:	83 c4 10             	add    $0x10,%esp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801003e6:	bb d4 03 00 00       	mov    $0x3d4,%ebx
801003eb:	b8 0e 00 00 00       	mov    $0xe,%eax
801003f0:	89 da                	mov    %ebx,%edx
801003f2:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801003f3:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
801003f8:	89 ca                	mov    %ecx,%edx
801003fa:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
801003fb:	0f b6 c0             	movzbl %al,%eax
801003fe:	c1 e0 08             	shl    $0x8,%eax
80100401:	89 c7                	mov    %eax,%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100403:	b8 0f 00 00 00       	mov    $0xf,%eax
80100408:	89 da                	mov    %ebx,%edx
8010040a:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010040b:	89 ca                	mov    %ecx,%edx
8010040d:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
8010040e:	0f b6 d8             	movzbl %al,%ebx
80100411:	09 fb                	or     %edi,%ebx
  if(c == '\n')
80100413:	83 fe 0a             	cmp    $0xa,%esi
80100416:	74 48                	je     80100460 <consputc+0xa4>
  else if(c == BACKSPACE){
80100418:	81 fe 00 01 00 00    	cmp    $0x100,%esi
8010041e:	0f 84 93 00 00 00    	je     801004b7 <consputc+0xfb>
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
80100424:	89 f0                	mov    %esi,%eax
80100426:	0f b6 c0             	movzbl %al,%eax
80100429:	80 cc 07             	or     $0x7,%ah
8010042c:	66 89 84 1b 00 80 0b 	mov    %ax,-0x7ff48000(%ebx,%ebx,1)
80100433:	80 
80100434:	8d 5b 01             	lea    0x1(%ebx),%ebx
80100437:	eb 35                	jmp    8010046e <consputc+0xb2>
    uartputc('\b'); uartputc(' '); uartputc('\b');
80100439:	83 ec 0c             	sub    $0xc,%esp
8010043c:	6a 08                	push   $0x8
8010043e:	e8 dd 4d 00 00       	call   80105220 <uartputc>
80100443:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
8010044a:	e8 d1 4d 00 00       	call   80105220 <uartputc>
8010044f:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
80100456:	e8 c5 4d 00 00       	call   80105220 <uartputc>
8010045b:	83 c4 10             	add    $0x10,%esp
8010045e:	eb 86                	jmp    801003e6 <consputc+0x2a>
    pos += 80 - pos%80;
80100460:	b9 50 00 00 00       	mov    $0x50,%ecx
80100465:	89 d8                	mov    %ebx,%eax
80100467:	99                   	cltd   
80100468:	f7 f9                	idiv   %ecx
8010046a:	29 d1                	sub    %edx,%ecx
8010046c:	01 cb                	add    %ecx,%ebx
  if(pos < 0 || pos > 25*80)
8010046e:	81 fb d0 07 00 00    	cmp    $0x7d0,%ebx
80100474:	77 4a                	ja     801004c0 <consputc+0x104>
  if((pos/80) >= 24){  // Scroll up.
80100476:	81 fb 7f 07 00 00    	cmp    $0x77f,%ebx
8010047c:	7f 4f                	jg     801004cd <consputc+0x111>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010047e:	be d4 03 00 00       	mov    $0x3d4,%esi
80100483:	b8 0e 00 00 00       	mov    $0xe,%eax
80100488:	89 f2                	mov    %esi,%edx
8010048a:	ee                   	out    %al,(%dx)
  outb(CRTPORT+1, pos>>8);
8010048b:	89 d8                	mov    %ebx,%eax
8010048d:	c1 f8 08             	sar    $0x8,%eax
80100490:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
80100495:	89 ca                	mov    %ecx,%edx
80100497:	ee                   	out    %al,(%dx)
80100498:	b8 0f 00 00 00       	mov    $0xf,%eax
8010049d:	89 f2                	mov    %esi,%edx
8010049f:	ee                   	out    %al,(%dx)
801004a0:	89 d8                	mov    %ebx,%eax
801004a2:	89 ca                	mov    %ecx,%edx
801004a4:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004a5:	66 c7 84 1b 00 80 0b 	movw   $0x720,-0x7ff48000(%ebx,%ebx,1)
801004ac:	80 20 07 
}
801004af:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004b2:	5b                   	pop    %ebx
801004b3:	5e                   	pop    %esi
801004b4:	5f                   	pop    %edi
801004b5:	5d                   	pop    %ebp
801004b6:	c3                   	ret    
    if(pos > 0) --pos;
801004b7:	85 db                	test   %ebx,%ebx
801004b9:	7e b3                	jle    8010046e <consputc+0xb2>
801004bb:	83 eb 01             	sub    $0x1,%ebx
801004be:	eb ae                	jmp    8010046e <consputc+0xb2>
    panic("pos under/overflow");
801004c0:	83 ec 0c             	sub    $0xc,%esp
801004c3:	68 41 80 10 80       	push   $0x80108041
801004c8:	e8 77 fe ff ff       	call   80100344 <panic>
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
801004cd:	83 ec 04             	sub    $0x4,%esp
801004d0:	68 60 0e 00 00       	push   $0xe60
801004d5:	68 a0 80 0b 80       	push   $0x800b80a0
801004da:	68 00 80 0b 80       	push   $0x800b8000
801004df:	e8 2b 3a 00 00       	call   80103f0f <memmove>
    pos -= 80;
801004e4:	83 eb 50             	sub    $0x50,%ebx
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
801004e7:	83 c4 0c             	add    $0xc,%esp
801004ea:	b8 80 07 00 00       	mov    $0x780,%eax
801004ef:	29 d8                	sub    %ebx,%eax
801004f1:	01 c0                	add    %eax,%eax
801004f3:	50                   	push   %eax
801004f4:	6a 00                	push   $0x0
801004f6:	8d 04 1b             	lea    (%ebx,%ebx,1),%eax
801004f9:	2d 00 80 f4 7f       	sub    $0x7ff48000,%eax
801004fe:	50                   	push   %eax
801004ff:	e8 76 39 00 00       	call   80103e7a <memset>
80100504:	83 c4 10             	add    $0x10,%esp
80100507:	e9 72 ff ff ff       	jmp    8010047e <consputc+0xc2>

8010050c <printint>:
{
8010050c:	55                   	push   %ebp
8010050d:	89 e5                	mov    %esp,%ebp
8010050f:	57                   	push   %edi
80100510:	56                   	push   %esi
80100511:	53                   	push   %ebx
80100512:	83 ec 1c             	sub    $0x1c,%esp
80100515:	89 d6                	mov    %edx,%esi
  if(sign && (sign = xx < 0))
80100517:	85 c9                	test   %ecx,%ecx
80100519:	74 04                	je     8010051f <printint+0x13>
8010051b:	85 c0                	test   %eax,%eax
8010051d:	78 0e                	js     8010052d <printint+0x21>
    x = xx;
8010051f:	89 c2                	mov    %eax,%edx
80100521:	bf 00 00 00 00       	mov    $0x0,%edi
  i = 0;
80100526:	b9 00 00 00 00       	mov    $0x0,%ecx
8010052b:	eb 0d                	jmp    8010053a <printint+0x2e>
    x = -xx;
8010052d:	f7 d8                	neg    %eax
8010052f:	89 c2                	mov    %eax,%edx
  if(sign && (sign = xx < 0))
80100531:	bf 01 00 00 00       	mov    $0x1,%edi
    x = -xx;
80100536:	eb ee                	jmp    80100526 <printint+0x1a>
    buf[i++] = digits[x % base];
80100538:	89 d9                	mov    %ebx,%ecx
8010053a:	8d 59 01             	lea    0x1(%ecx),%ebx
8010053d:	89 d0                	mov    %edx,%eax
8010053f:	ba 00 00 00 00       	mov    $0x0,%edx
80100544:	f7 f6                	div    %esi
80100546:	0f b6 92 6c 80 10 80 	movzbl -0x7fef7f94(%edx),%edx
8010054d:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
80100551:	89 c2                	mov    %eax,%edx
80100553:	85 c0                	test   %eax,%eax
80100555:	75 e1                	jne    80100538 <printint+0x2c>
  if(sign)
80100557:	85 ff                	test   %edi,%edi
80100559:	74 08                	je     80100563 <printint+0x57>
    buf[i++] = '-';
8010055b:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
80100560:	8d 59 02             	lea    0x2(%ecx),%ebx
  while(--i >= 0)
80100563:	83 eb 01             	sub    $0x1,%ebx
80100566:	78 12                	js     8010057a <printint+0x6e>
    consputc(buf[i]);
80100568:	0f be 44 2b d8       	movsbl -0x28(%ebx,%ebp,1),%eax
8010056d:	e8 4a fe ff ff       	call   801003bc <consputc>
  while(--i >= 0)
80100572:	83 eb 01             	sub    $0x1,%ebx
80100575:	83 fb ff             	cmp    $0xffffffff,%ebx
80100578:	75 ee                	jne    80100568 <printint+0x5c>
}
8010057a:	83 c4 1c             	add    $0x1c,%esp
8010057d:	5b                   	pop    %ebx
8010057e:	5e                   	pop    %esi
8010057f:	5f                   	pop    %edi
80100580:	5d                   	pop    %ebp
80100581:	c3                   	ret    

80100582 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
80100582:	55                   	push   %ebp
80100583:	89 e5                	mov    %esp,%ebp
80100585:	57                   	push   %edi
80100586:	56                   	push   %esi
80100587:	53                   	push   %ebx
80100588:	83 ec 18             	sub    $0x18,%esp
8010058b:	8b 75 0c             	mov    0xc(%ebp),%esi
8010058e:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  iunlock(ip);
80100591:	ff 75 08             	pushl  0x8(%ebp)
80100594:	e8 0f 10 00 00       	call   801015a8 <iunlock>
  acquire(&cons.lock);
80100599:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
801005a0:	e8 27 38 00 00       	call   80103dcc <acquire>
  for(i = 0; i < n; i++)
801005a5:	83 c4 10             	add    $0x10,%esp
801005a8:	85 ff                	test   %edi,%edi
801005aa:	7e 13                	jle    801005bf <consolewrite+0x3d>
801005ac:	89 f3                	mov    %esi,%ebx
801005ae:	01 fe                	add    %edi,%esi
    consputc(buf[i] & 0xff);
801005b0:	0f b6 03             	movzbl (%ebx),%eax
801005b3:	e8 04 fe ff ff       	call   801003bc <consputc>
801005b8:	83 c3 01             	add    $0x1,%ebx
  for(i = 0; i < n; i++)
801005bb:	39 f3                	cmp    %esi,%ebx
801005bd:	75 f1                	jne    801005b0 <consolewrite+0x2e>
  release(&cons.lock);
801005bf:	83 ec 0c             	sub    $0xc,%esp
801005c2:	68 20 b5 10 80       	push   $0x8010b520
801005c7:	e8 67 38 00 00       	call   80103e33 <release>
  ilock(ip);
801005cc:	83 c4 04             	add    $0x4,%esp
801005cf:	ff 75 08             	pushl  0x8(%ebp)
801005d2:	e8 0f 0f 00 00       	call   801014e6 <ilock>

  return n;
}
801005d7:	89 f8                	mov    %edi,%eax
801005d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801005dc:	5b                   	pop    %ebx
801005dd:	5e                   	pop    %esi
801005de:	5f                   	pop    %edi
801005df:	5d                   	pop    %ebp
801005e0:	c3                   	ret    

801005e1 <cprintf>:
{
801005e1:	55                   	push   %ebp
801005e2:	89 e5                	mov    %esp,%ebp
801005e4:	57                   	push   %edi
801005e5:	56                   	push   %esi
801005e6:	53                   	push   %ebx
801005e7:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking;
801005ea:	a1 54 b5 10 80       	mov    0x8010b554,%eax
801005ef:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if(locking)
801005f2:	85 c0                	test   %eax,%eax
801005f4:	75 2b                	jne    80100621 <cprintf+0x40>
  if (fmt == 0)
801005f6:	8b 7d 08             	mov    0x8(%ebp),%edi
801005f9:	85 ff                	test   %edi,%edi
801005fb:	74 36                	je     80100633 <cprintf+0x52>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801005fd:	0f b6 07             	movzbl (%edi),%eax
  argp = (uint*)(void*)(&fmt + 1);
80100600:	8d 4d 0c             	lea    0xc(%ebp),%ecx
80100603:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100606:	bb 00 00 00 00       	mov    $0x0,%ebx
8010060b:	85 c0                	test   %eax,%eax
8010060d:	75 41                	jne    80100650 <cprintf+0x6f>
  if(locking)
8010060f:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80100613:	0f 85 0d 01 00 00    	jne    80100726 <cprintf+0x145>
}
80100619:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010061c:	5b                   	pop    %ebx
8010061d:	5e                   	pop    %esi
8010061e:	5f                   	pop    %edi
8010061f:	5d                   	pop    %ebp
80100620:	c3                   	ret    
    acquire(&cons.lock);
80100621:	83 ec 0c             	sub    $0xc,%esp
80100624:	68 20 b5 10 80       	push   $0x8010b520
80100629:	e8 9e 37 00 00       	call   80103dcc <acquire>
8010062e:	83 c4 10             	add    $0x10,%esp
80100631:	eb c3                	jmp    801005f6 <cprintf+0x15>
    panic("null fmt");
80100633:	83 ec 0c             	sub    $0xc,%esp
80100636:	68 5b 80 10 80       	push   $0x8010805b
8010063b:	e8 04 fd ff ff       	call   80100344 <panic>
      consputc(c);
80100640:	e8 77 fd ff ff       	call   801003bc <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100645:	83 c3 01             	add    $0x1,%ebx
80100648:	0f b6 04 1f          	movzbl (%edi,%ebx,1),%eax
8010064c:	85 c0                	test   %eax,%eax
8010064e:	74 bf                	je     8010060f <cprintf+0x2e>
    if(c != '%'){
80100650:	83 f8 25             	cmp    $0x25,%eax
80100653:	75 eb                	jne    80100640 <cprintf+0x5f>
    c = fmt[++i] & 0xff;
80100655:	83 c3 01             	add    $0x1,%ebx
80100658:	0f b6 34 1f          	movzbl (%edi,%ebx,1),%esi
    if(c == 0)
8010065c:	85 f6                	test   %esi,%esi
8010065e:	74 af                	je     8010060f <cprintf+0x2e>
    switch(c){
80100660:	83 fe 70             	cmp    $0x70,%esi
80100663:	74 4c                	je     801006b1 <cprintf+0xd0>
80100665:	83 fe 70             	cmp    $0x70,%esi
80100668:	7f 2a                	jg     80100694 <cprintf+0xb3>
8010066a:	83 fe 25             	cmp    $0x25,%esi
8010066d:	0f 84 a4 00 00 00    	je     80100717 <cprintf+0x136>
80100673:	83 fe 64             	cmp    $0x64,%esi
80100676:	75 26                	jne    8010069e <cprintf+0xbd>
      printint(*argp++, 10, 1);
80100678:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010067b:	8d 70 04             	lea    0x4(%eax),%esi
8010067e:	b9 01 00 00 00       	mov    $0x1,%ecx
80100683:	ba 0a 00 00 00       	mov    $0xa,%edx
80100688:	8b 00                	mov    (%eax),%eax
8010068a:	e8 7d fe ff ff       	call   8010050c <printint>
8010068f:	89 75 e4             	mov    %esi,-0x1c(%ebp)
      break;
80100692:	eb b1                	jmp    80100645 <cprintf+0x64>
    switch(c){
80100694:	83 fe 73             	cmp    $0x73,%esi
80100697:	74 37                	je     801006d0 <cprintf+0xef>
80100699:	83 fe 78             	cmp    $0x78,%esi
8010069c:	74 13                	je     801006b1 <cprintf+0xd0>
      consputc('%');
8010069e:	b8 25 00 00 00       	mov    $0x25,%eax
801006a3:	e8 14 fd ff ff       	call   801003bc <consputc>
      consputc(c);
801006a8:	89 f0                	mov    %esi,%eax
801006aa:	e8 0d fd ff ff       	call   801003bc <consputc>
      break;
801006af:	eb 94                	jmp    80100645 <cprintf+0x64>
      printint(*argp++, 16, 0);
801006b1:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801006b4:	8d 70 04             	lea    0x4(%eax),%esi
801006b7:	b9 00 00 00 00       	mov    $0x0,%ecx
801006bc:	ba 10 00 00 00       	mov    $0x10,%edx
801006c1:	8b 00                	mov    (%eax),%eax
801006c3:	e8 44 fe ff ff       	call   8010050c <printint>
801006c8:	89 75 e4             	mov    %esi,-0x1c(%ebp)
      break;
801006cb:	e9 75 ff ff ff       	jmp    80100645 <cprintf+0x64>
      if((s = (char*)*argp++) == 0)
801006d0:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801006d3:	8d 50 04             	lea    0x4(%eax),%edx
801006d6:	89 55 dc             	mov    %edx,-0x24(%ebp)
801006d9:	8b 00                	mov    (%eax),%eax
801006db:	85 c0                	test   %eax,%eax
801006dd:	74 11                	je     801006f0 <cprintf+0x10f>
801006df:	89 c6                	mov    %eax,%esi
      for(; *s; s++)
801006e1:	0f b6 00             	movzbl (%eax),%eax
      if((s = (char*)*argp++) == 0)
801006e4:	89 55 e4             	mov    %edx,-0x1c(%ebp)
      for(; *s; s++)
801006e7:	84 c0                	test   %al,%al
801006e9:	75 0f                	jne    801006fa <cprintf+0x119>
801006eb:	e9 55 ff ff ff       	jmp    80100645 <cprintf+0x64>
        s = "(null)";
801006f0:	be 54 80 10 80       	mov    $0x80108054,%esi
      for(; *s; s++)
801006f5:	b8 28 00 00 00       	mov    $0x28,%eax
        consputc(*s);
801006fa:	0f be c0             	movsbl %al,%eax
801006fd:	e8 ba fc ff ff       	call   801003bc <consputc>
      for(; *s; s++)
80100702:	83 c6 01             	add    $0x1,%esi
80100705:	0f b6 06             	movzbl (%esi),%eax
80100708:	84 c0                	test   %al,%al
8010070a:	75 ee                	jne    801006fa <cprintf+0x119>
      if((s = (char*)*argp++) == 0)
8010070c:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010070f:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80100712:	e9 2e ff ff ff       	jmp    80100645 <cprintf+0x64>
      consputc('%');
80100717:	b8 25 00 00 00       	mov    $0x25,%eax
8010071c:	e8 9b fc ff ff       	call   801003bc <consputc>
      break;
80100721:	e9 1f ff ff ff       	jmp    80100645 <cprintf+0x64>
    release(&cons.lock);
80100726:	83 ec 0c             	sub    $0xc,%esp
80100729:	68 20 b5 10 80       	push   $0x8010b520
8010072e:	e8 00 37 00 00       	call   80103e33 <release>
80100733:	83 c4 10             	add    $0x10,%esp
}
80100736:	e9 de fe ff ff       	jmp    80100619 <cprintf+0x38>

8010073b <consoleintr>:
{
8010073b:	55                   	push   %ebp
8010073c:	89 e5                	mov    %esp,%ebp
8010073e:	57                   	push   %edi
8010073f:	56                   	push   %esi
80100740:	53                   	push   %ebx
80100741:	83 ec 28             	sub    $0x28,%esp
80100744:	8b 7d 08             	mov    0x8(%ebp),%edi
  acquire(&cons.lock);
80100747:	68 20 b5 10 80       	push   $0x8010b520
8010074c:	e8 7b 36 00 00       	call   80103dcc <acquire>
  while((c = getc()) >= 0){
80100751:	83 c4 10             	add    $0x10,%esp
  int c, doprocdump = 0;
80100754:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
      if(c != 0 && input.e-input.r < INPUT_BUF){
8010075b:	bb 20 8f 1d 80       	mov    $0x801d8f20,%ebx
  while((c = getc()) >= 0){
80100760:	e9 c2 00 00 00       	jmp    80100827 <consoleintr+0xec>
    switch(c){
80100765:	83 fe 08             	cmp    $0x8,%esi
80100768:	0f 84 dd 00 00 00    	je     8010084b <consoleintr+0x110>
      if(c != 0 && input.e-input.r < INPUT_BUF){
8010076e:	85 f6                	test   %esi,%esi
80100770:	0f 84 b1 00 00 00    	je     80100827 <consoleintr+0xec>
80100776:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
8010077c:	89 c2                	mov    %eax,%edx
8010077e:	2b 93 80 00 00 00    	sub    0x80(%ebx),%edx
80100784:	83 fa 7f             	cmp    $0x7f,%edx
80100787:	0f 87 9a 00 00 00    	ja     80100827 <consoleintr+0xec>
        c = (c == '\r') ? '\n' : c;
8010078d:	83 fe 0d             	cmp    $0xd,%esi
80100790:	0f 84 fd 00 00 00    	je     80100893 <consoleintr+0x158>
        input.buf[input.e++ % INPUT_BUF] = c;
80100796:	8d 50 01             	lea    0x1(%eax),%edx
80100799:	89 93 88 00 00 00    	mov    %edx,0x88(%ebx)
8010079f:	83 e0 7f             	and    $0x7f,%eax
801007a2:	89 f1                	mov    %esi,%ecx
801007a4:	88 0c 03             	mov    %cl,(%ebx,%eax,1)
        consputc(c);
801007a7:	89 f0                	mov    %esi,%eax
801007a9:	e8 0e fc ff ff       	call   801003bc <consputc>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
801007ae:	83 fe 0a             	cmp    $0xa,%esi
801007b1:	0f 84 f6 00 00 00    	je     801008ad <consoleintr+0x172>
801007b7:	83 fe 04             	cmp    $0x4,%esi
801007ba:	0f 84 ed 00 00 00    	je     801008ad <consoleintr+0x172>
801007c0:	8b 83 80 00 00 00    	mov    0x80(%ebx),%eax
801007c6:	83 e8 80             	sub    $0xffffff80,%eax
801007c9:	39 83 88 00 00 00    	cmp    %eax,0x88(%ebx)
801007cf:	75 56                	jne    80100827 <consoleintr+0xec>
801007d1:	e9 d7 00 00 00       	jmp    801008ad <consoleintr+0x172>
      while(input.e != input.w &&
801007d6:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
801007dc:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
801007e2:	74 43                	je     80100827 <consoleintr+0xec>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
801007e4:	83 e8 01             	sub    $0x1,%eax
801007e7:	89 c2                	mov    %eax,%edx
801007e9:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
801007ec:	80 3c 13 0a          	cmpb   $0xa,(%ebx,%edx,1)
801007f0:	74 35                	je     80100827 <consoleintr+0xec>
        input.e--;
801007f2:	89 83 88 00 00 00    	mov    %eax,0x88(%ebx)
        consputc(BACKSPACE);
801007f8:	b8 00 01 00 00       	mov    $0x100,%eax
801007fd:	e8 ba fb ff ff       	call   801003bc <consputc>
      while(input.e != input.w &&
80100802:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
80100808:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
8010080e:	74 17                	je     80100827 <consoleintr+0xec>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
80100810:	83 e8 01             	sub    $0x1,%eax
80100813:	89 c2                	mov    %eax,%edx
80100815:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
80100818:	80 3c 13 0a          	cmpb   $0xa,(%ebx,%edx,1)
8010081c:	75 d4                	jne    801007f2 <consoleintr+0xb7>
8010081e:	eb 07                	jmp    80100827 <consoleintr+0xec>
      doprocdump = 1;
80100820:	c7 45 e4 01 00 00 00 	movl   $0x1,-0x1c(%ebp)
  while((c = getc()) >= 0){
80100827:	ff d7                	call   *%edi
80100829:	89 c6                	mov    %eax,%esi
8010082b:	85 c0                	test   %eax,%eax
8010082d:	78 3f                	js     8010086e <consoleintr+0x133>
    switch(c){
8010082f:	83 fe 10             	cmp    $0x10,%esi
80100832:	74 ec                	je     80100820 <consoleintr+0xe5>
80100834:	83 fe 10             	cmp    $0x10,%esi
80100837:	0f 8e 28 ff ff ff    	jle    80100765 <consoleintr+0x2a>
8010083d:	83 fe 15             	cmp    $0x15,%esi
80100840:	74 94                	je     801007d6 <consoleintr+0x9b>
80100842:	83 fe 7f             	cmp    $0x7f,%esi
80100845:	0f 85 23 ff ff ff    	jne    8010076e <consoleintr+0x33>
      if(input.e != input.w){
8010084b:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
80100851:	3b 83 84 00 00 00    	cmp    0x84(%ebx),%eax
80100857:	74 ce                	je     80100827 <consoleintr+0xec>
        input.e--;
80100859:	83 e8 01             	sub    $0x1,%eax
8010085c:	89 83 88 00 00 00    	mov    %eax,0x88(%ebx)
        consputc(BACKSPACE);
80100862:	b8 00 01 00 00       	mov    $0x100,%eax
80100867:	e8 50 fb ff ff       	call   801003bc <consputc>
8010086c:	eb b9                	jmp    80100827 <consoleintr+0xec>
  release(&cons.lock);
8010086e:	83 ec 0c             	sub    $0xc,%esp
80100871:	68 20 b5 10 80       	push   $0x8010b520
80100876:	e8 b8 35 00 00       	call   80103e33 <release>
  if(doprocdump) {
8010087b:	83 c4 10             	add    $0x10,%esp
8010087e:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
80100882:	75 08                	jne    8010088c <consoleintr+0x151>
}
80100884:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100887:	5b                   	pop    %ebx
80100888:	5e                   	pop    %esi
80100889:	5f                   	pop    %edi
8010088a:	5d                   	pop    %ebp
8010088b:	c3                   	ret    
    procdump();  // now call procdump() wo. cons.lock held
8010088c:	e8 92 31 00 00       	call   80103a23 <procdump>
}
80100891:	eb f1                	jmp    80100884 <consoleintr+0x149>
        input.buf[input.e++ % INPUT_BUF] = c;
80100893:	8d 50 01             	lea    0x1(%eax),%edx
80100896:	89 93 88 00 00 00    	mov    %edx,0x88(%ebx)
8010089c:	83 e0 7f             	and    $0x7f,%eax
8010089f:	c6 04 03 0a          	movb   $0xa,(%ebx,%eax,1)
        consputc(c);
801008a3:	b8 0a 00 00 00       	mov    $0xa,%eax
801008a8:	e8 0f fb ff ff       	call   801003bc <consputc>
          input.w = input.e;
801008ad:	8b 83 88 00 00 00    	mov    0x88(%ebx),%eax
801008b3:	89 83 84 00 00 00    	mov    %eax,0x84(%ebx)
          wakeup(&input.r);
801008b9:	83 ec 0c             	sub    $0xc,%esp
801008bc:	68 a0 8f 1d 80       	push   $0x801d8fa0
801008c1:	e8 b3 30 00 00       	call   80103979 <wakeup>
801008c6:	83 c4 10             	add    $0x10,%esp
801008c9:	e9 59 ff ff ff       	jmp    80100827 <consoleintr+0xec>

801008ce <consoleinit>:

void
consoleinit(void)
{
801008ce:	55                   	push   %ebp
801008cf:	89 e5                	mov    %esp,%ebp
801008d1:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
801008d4:	68 64 80 10 80       	push   $0x80108064
801008d9:	68 20 b5 10 80       	push   $0x8010b520
801008de:	e8 a1 33 00 00       	call   80103c84 <initlock>

  devsw[CONSOLE].write = consolewrite;
801008e3:	c7 05 6c 99 1d 80 82 	movl   $0x80100582,0x801d996c
801008ea:	05 10 80 
  devsw[CONSOLE].read = consoleread;
801008ed:	c7 05 68 99 1d 80 54 	movl   $0x80100254,0x801d9968
801008f4:	02 10 80 
  cons.locking = 1;
801008f7:	c7 05 54 b5 10 80 01 	movl   $0x1,0x8010b554
801008fe:	00 00 00 

  ioapicenable(IRQ_KBD, 0);
80100901:	83 c4 08             	add    $0x8,%esp
80100904:	6a 00                	push   $0x0
80100906:	6a 01                	push   $0x1
80100908:	e8 f9 16 00 00       	call   80102006 <ioapicenable>
}
8010090d:	83 c4 10             	add    $0x10,%esp
80100910:	c9                   	leave  
80100911:	c3                   	ret    

80100912 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100912:	55                   	push   %ebp
80100913:	89 e5                	mov    %esp,%ebp
80100915:	57                   	push   %edi
80100916:	56                   	push   %esi
80100917:	53                   	push   %ebx
80100918:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
8010091e:	e8 2a 2a 00 00       	call   8010334d <myproc>
80100923:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)

  begin_op();
80100929:	e8 7f 1e 00 00       	call   801027ad <begin_op>

  if((ip = namei(path)) == 0){
8010092e:	83 ec 0c             	sub    $0xc,%esp
80100931:	ff 75 08             	pushl  0x8(%ebp)
80100934:	e8 4a 13 00 00       	call   80101c83 <namei>
80100939:	83 c4 10             	add    $0x10,%esp
8010093c:	85 c0                	test   %eax,%eax
8010093e:	74 42                	je     80100982 <exec+0x70>
80100940:	89 c3                	mov    %eax,%ebx
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100942:	83 ec 0c             	sub    $0xc,%esp
80100945:	50                   	push   %eax
80100946:	e8 9b 0b 00 00       	call   801014e6 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
8010094b:	6a 34                	push   $0x34
8010094d:	6a 00                	push   $0x0
8010094f:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100955:	50                   	push   %eax
80100956:	53                   	push   %ebx
80100957:	e8 1e 0e 00 00       	call   8010177a <readi>
8010095c:	83 c4 20             	add    $0x20,%esp
8010095f:	83 f8 34             	cmp    $0x34,%eax
80100962:	74 3a                	je     8010099e <exec+0x8c>

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
80100964:	83 ec 0c             	sub    $0xc,%esp
80100967:	53                   	push   %ebx
80100968:	e8 c2 0d 00 00       	call   8010172f <iunlockput>
    end_op();
8010096d:	e8 b6 1e 00 00       	call   80102828 <end_op>
80100972:	83 c4 10             	add    $0x10,%esp
  }
  return -1;
80100975:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010097a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010097d:	5b                   	pop    %ebx
8010097e:	5e                   	pop    %esi
8010097f:	5f                   	pop    %edi
80100980:	5d                   	pop    %ebp
80100981:	c3                   	ret    
    end_op();
80100982:	e8 a1 1e 00 00       	call   80102828 <end_op>
    cprintf("exec: fail\n");
80100987:	83 ec 0c             	sub    $0xc,%esp
8010098a:	68 7d 80 10 80       	push   $0x8010807d
8010098f:	e8 4d fc ff ff       	call   801005e1 <cprintf>
    return -1;
80100994:	83 c4 10             	add    $0x10,%esp
80100997:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010099c:	eb dc                	jmp    8010097a <exec+0x68>
  if(elf.magic != ELF_MAGIC)
8010099e:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
801009a5:	45 4c 46 
801009a8:	75 ba                	jne    80100964 <exec+0x52>
  if((pgdir = setupkvm()) == 0)
801009aa:	e8 e2 59 00 00       	call   80106391 <setupkvm>
801009af:	89 c7                	mov    %eax,%edi
801009b1:	85 c0                	test   %eax,%eax
801009b3:	74 af                	je     80100964 <exec+0x52>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801009b5:	8b 85 40 ff ff ff    	mov    -0xc0(%ebp),%eax
801009bb:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
801009c1:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
801009c8:	00 
801009c9:	0f 84 bf 00 00 00    	je     80100a8e <exec+0x17c>
  sz = 0;
801009cf:	c7 85 ec fe ff ff 00 	movl   $0x0,-0x114(%ebp)
801009d6:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
801009d9:	be 00 00 00 00       	mov    $0x0,%esi
801009de:	eb 12                	jmp    801009f2 <exec+0xe0>
801009e0:	83 c6 01             	add    $0x1,%esi
801009e3:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
801009ea:	39 f0                	cmp    %esi,%eax
801009ec:	0f 8e a6 00 00 00    	jle    80100a98 <exec+0x186>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
801009f2:	6a 20                	push   $0x20
801009f4:	89 f0                	mov    %esi,%eax
801009f6:	c1 e0 05             	shl    $0x5,%eax
801009f9:	03 85 f0 fe ff ff    	add    -0x110(%ebp),%eax
801009ff:	50                   	push   %eax
80100a00:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100a06:	50                   	push   %eax
80100a07:	53                   	push   %ebx
80100a08:	e8 6d 0d 00 00       	call   8010177a <readi>
80100a0d:	83 c4 10             	add    $0x10,%esp
80100a10:	83 f8 20             	cmp    $0x20,%eax
80100a13:	0f 85 c2 00 00 00    	jne    80100adb <exec+0x1c9>
    if(ph.type != ELF_PROG_LOAD)
80100a19:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100a20:	75 be                	jne    801009e0 <exec+0xce>
    if(ph.memsz < ph.filesz)
80100a22:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100a28:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100a2e:	0f 82 a7 00 00 00    	jb     80100adb <exec+0x1c9>
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100a34:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100a3a:	0f 82 9b 00 00 00    	jb     80100adb <exec+0x1c9>
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100a40:	83 ec 04             	sub    $0x4,%esp
80100a43:	50                   	push   %eax
80100a44:	ff b5 ec fe ff ff    	pushl  -0x114(%ebp)
80100a4a:	57                   	push   %edi
80100a4b:	e8 e0 57 00 00       	call   80106230 <allocuvm>
80100a50:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)
80100a56:	83 c4 10             	add    $0x10,%esp
80100a59:	85 c0                	test   %eax,%eax
80100a5b:	74 7e                	je     80100adb <exec+0x1c9>
    if(ph.vaddr % PGSIZE != 0)
80100a5d:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100a63:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100a68:	75 71                	jne    80100adb <exec+0x1c9>
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100a6a:	83 ec 0c             	sub    $0xc,%esp
80100a6d:	ff b5 14 ff ff ff    	pushl  -0xec(%ebp)
80100a73:	ff b5 08 ff ff ff    	pushl  -0xf8(%ebp)
80100a79:	53                   	push   %ebx
80100a7a:	50                   	push   %eax
80100a7b:	57                   	push   %edi
80100a7c:	e8 72 56 00 00       	call   801060f3 <loaduvm>
80100a81:	83 c4 20             	add    $0x20,%esp
80100a84:	85 c0                	test   %eax,%eax
80100a86:	0f 89 54 ff ff ff    	jns    801009e0 <exec+0xce>
 bad:
80100a8c:	eb 4d                	jmp    80100adb <exec+0x1c9>
  sz = 0;
80100a8e:	c7 85 ec fe ff ff 00 	movl   $0x0,-0x114(%ebp)
80100a95:	00 00 00 
  iunlockput(ip);
80100a98:	83 ec 0c             	sub    $0xc,%esp
80100a9b:	53                   	push   %ebx
80100a9c:	e8 8e 0c 00 00       	call   8010172f <iunlockput>
  end_op();
80100aa1:	e8 82 1d 00 00       	call   80102828 <end_op>
  sz = PGROUNDUP(sz);
80100aa6:	8b 85 ec fe ff ff    	mov    -0x114(%ebp),%eax
80100aac:	05 ff 0f 00 00       	add    $0xfff,%eax
80100ab1:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80100ab6:	89 c2                	mov    %eax,%edx
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ab8:	83 c4 0c             	add    $0xc,%esp
80100abb:	8d 80 00 20 00 00    	lea    0x2000(%eax),%eax
80100ac1:	50                   	push   %eax
80100ac2:	52                   	push   %edx
80100ac3:	57                   	push   %edi
80100ac4:	e8 67 57 00 00       	call   80106230 <allocuvm>
80100ac9:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100acf:	83 c4 10             	add    $0x10,%esp
  ip = 0;
80100ad2:	bb 00 00 00 00       	mov    $0x0,%ebx
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100ad7:	85 c0                	test   %eax,%eax
80100ad9:	75 1e                	jne    80100af9 <exec+0x1e7>
    freevm(pgdir);
80100adb:	83 ec 0c             	sub    $0xc,%esp
80100ade:	57                   	push   %edi
80100adf:	e8 3a 58 00 00       	call   8010631e <freevm>
  if(ip){
80100ae4:	83 c4 10             	add    $0x10,%esp
80100ae7:	85 db                	test   %ebx,%ebx
80100ae9:	0f 85 75 fe ff ff    	jne    80100964 <exec+0x52>
  return -1;
80100aef:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100af4:	e9 81 fe ff ff       	jmp    8010097a <exec+0x68>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100af9:	83 ec 08             	sub    $0x8,%esp
80100afc:	89 c3                	mov    %eax,%ebx
80100afe:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
80100b04:	50                   	push   %eax
80100b05:	57                   	push   %edi
80100b06:	e8 0b 59 00 00       	call   80106416 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100b0b:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b0e:	8b 00                	mov    (%eax),%eax
80100b10:	83 c4 10             	add    $0x10,%esp
80100b13:	be 00 00 00 00       	mov    $0x0,%esi
80100b18:	85 c0                	test   %eax,%eax
80100b1a:	74 5f                	je     80100b7b <exec+0x269>
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100b1c:	83 ec 0c             	sub    $0xc,%esp
80100b1f:	50                   	push   %eax
80100b20:	e8 18 35 00 00       	call   8010403d <strlen>
80100b25:	f7 d0                	not    %eax
80100b27:	01 d8                	add    %ebx,%eax
80100b29:	83 e0 fc             	and    $0xfffffffc,%eax
80100b2c:	89 c3                	mov    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100b2e:	83 c4 04             	add    $0x4,%esp
80100b31:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b34:	ff 34 b0             	pushl  (%eax,%esi,4)
80100b37:	e8 01 35 00 00       	call   8010403d <strlen>
80100b3c:	83 c0 01             	add    $0x1,%eax
80100b3f:	50                   	push   %eax
80100b40:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b43:	ff 34 b0             	pushl  (%eax,%esi,4)
80100b46:	53                   	push   %ebx
80100b47:	57                   	push   %edi
80100b48:	e8 14 5a 00 00       	call   80106561 <copyout>
80100b4d:	83 c4 20             	add    $0x20,%esp
80100b50:	85 c0                	test   %eax,%eax
80100b52:	0f 88 f4 00 00 00    	js     80100c4c <exec+0x33a>
    ustack[3+argc] = sp;
80100b58:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
  for(argc = 0; argv[argc]; argc++) {
80100b5f:	83 c6 01             	add    $0x1,%esi
80100b62:	8b 45 0c             	mov    0xc(%ebp),%eax
80100b65:	8b 04 b0             	mov    (%eax,%esi,4),%eax
80100b68:	85 c0                	test   %eax,%eax
80100b6a:	74 15                	je     80100b81 <exec+0x26f>
    if(argc >= MAXARG)
80100b6c:	83 fe 20             	cmp    $0x20,%esi
80100b6f:	75 ab                	jne    80100b1c <exec+0x20a>
  ip = 0;
80100b71:	bb 00 00 00 00       	mov    $0x0,%ebx
80100b76:	e9 60 ff ff ff       	jmp    80100adb <exec+0x1c9>
  sp = sz;
80100b7b:	8b 9d f0 fe ff ff    	mov    -0x110(%ebp),%ebx
  ustack[3+argc] = 0;
80100b81:	c7 84 b5 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%esi,4)
80100b88:	00 00 00 00 
  ustack[0] = 0xffffffff;  // fake return PC
80100b8c:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100b93:	ff ff ff 
  ustack[1] = argc;
80100b96:	89 b5 5c ff ff ff    	mov    %esi,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100b9c:	8d 04 b5 04 00 00 00 	lea    0x4(,%esi,4),%eax
80100ba3:	89 da                	mov    %ebx,%edx
80100ba5:	29 c2                	sub    %eax,%edx
80100ba7:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%ebp)
  sp -= (3+argc+1) * 4;
80100bad:	83 c0 0c             	add    $0xc,%eax
80100bb0:	89 de                	mov    %ebx,%esi
80100bb2:	29 c6                	sub    %eax,%esi
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100bb4:	50                   	push   %eax
80100bb5:	8d 85 58 ff ff ff    	lea    -0xa8(%ebp),%eax
80100bbb:	50                   	push   %eax
80100bbc:	56                   	push   %esi
80100bbd:	57                   	push   %edi
80100bbe:	e8 9e 59 00 00       	call   80106561 <copyout>
80100bc3:	83 c4 10             	add    $0x10,%esp
80100bc6:	85 c0                	test   %eax,%eax
80100bc8:	0f 88 88 00 00 00    	js     80100c56 <exec+0x344>
  for(last=s=path; *s; s++)
80100bce:	8b 45 08             	mov    0x8(%ebp),%eax
80100bd1:	0f b6 10             	movzbl (%eax),%edx
80100bd4:	84 d2                	test   %dl,%dl
80100bd6:	74 1a                	je     80100bf2 <exec+0x2e0>
80100bd8:	83 c0 01             	add    $0x1,%eax
80100bdb:	8b 4d 08             	mov    0x8(%ebp),%ecx
      last = s+1;
80100bde:	80 fa 2f             	cmp    $0x2f,%dl
80100be1:	0f 44 c8             	cmove  %eax,%ecx
80100be4:	83 c0 01             	add    $0x1,%eax
  for(last=s=path; *s; s++)
80100be7:	0f b6 50 ff          	movzbl -0x1(%eax),%edx
80100beb:	84 d2                	test   %dl,%dl
80100bed:	75 ef                	jne    80100bde <exec+0x2cc>
80100bef:	89 4d 08             	mov    %ecx,0x8(%ebp)
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100bf2:	83 ec 04             	sub    $0x4,%esp
80100bf5:	6a 10                	push   $0x10
80100bf7:	ff 75 08             	pushl  0x8(%ebp)
80100bfa:	8b 9d f4 fe ff ff    	mov    -0x10c(%ebp),%ebx
80100c00:	89 d8                	mov    %ebx,%eax
80100c02:	83 c0 6c             	add    $0x6c,%eax
80100c05:	50                   	push   %eax
80100c06:	e8 fe 33 00 00       	call   80104009 <safestrcpy>
  oldpgdir = curproc->pgdir;
80100c0b:	89 d8                	mov    %ebx,%eax
80100c0d:	8b 5b 04             	mov    0x4(%ebx),%ebx
  curproc->pgdir = pgdir;
80100c10:	89 78 04             	mov    %edi,0x4(%eax)
  curproc->sz = sz;
80100c13:	8b 95 f0 fe ff ff    	mov    -0x110(%ebp),%edx
80100c19:	89 10                	mov    %edx,(%eax)
  curproc->tf->eip = elf.entry;  // main
80100c1b:	89 c7                	mov    %eax,%edi
80100c1d:	8b 40 18             	mov    0x18(%eax),%eax
80100c20:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100c26:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100c29:	8b 47 18             	mov    0x18(%edi),%eax
80100c2c:	89 70 44             	mov    %esi,0x44(%eax)
  switchuvm(curproc);
80100c2f:	89 3c 24             	mov    %edi,(%esp)
80100c32:	e8 55 53 00 00       	call   80105f8c <switchuvm>
  freevm(oldpgdir);
80100c37:	89 1c 24             	mov    %ebx,(%esp)
80100c3a:	e8 df 56 00 00       	call   8010631e <freevm>
  return 0;
80100c3f:	83 c4 10             	add    $0x10,%esp
80100c42:	b8 00 00 00 00       	mov    $0x0,%eax
80100c47:	e9 2e fd ff ff       	jmp    8010097a <exec+0x68>
  ip = 0;
80100c4c:	bb 00 00 00 00       	mov    $0x0,%ebx
80100c51:	e9 85 fe ff ff       	jmp    80100adb <exec+0x1c9>
80100c56:	bb 00 00 00 00       	mov    $0x0,%ebx
80100c5b:	e9 7b fe ff ff       	jmp    80100adb <exec+0x1c9>

80100c60 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100c60:	55                   	push   %ebp
80100c61:	89 e5                	mov    %esp,%ebp
80100c63:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100c66:	68 89 80 10 80       	push   $0x80108089
80100c6b:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100c70:	e8 0f 30 00 00       	call   80103c84 <initlock>
}
80100c75:	83 c4 10             	add    $0x10,%esp
80100c78:	c9                   	leave  
80100c79:	c3                   	ret    

80100c7a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100c7a:	55                   	push   %ebp
80100c7b:	89 e5                	mov    %esp,%ebp
80100c7d:	53                   	push   %ebx
80100c7e:	83 ec 10             	sub    $0x10,%esp
  struct file *f;

  acquire(&ftable.lock);
80100c81:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100c86:	e8 41 31 00 00       	call   80103dcc <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    if(f->ref == 0){
80100c8b:	83 c4 10             	add    $0x10,%esp
80100c8e:	83 3d f8 8f 1d 80 00 	cmpl   $0x0,0x801d8ff8
80100c95:	74 2d                	je     80100cc4 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100c97:	bb 0c 90 1d 80       	mov    $0x801d900c,%ebx
    if(f->ref == 0){
80100c9c:	83 7b 04 00          	cmpl   $0x0,0x4(%ebx)
80100ca0:	74 27                	je     80100cc9 <filealloc+0x4f>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100ca2:	83 c3 18             	add    $0x18,%ebx
80100ca5:	81 fb 54 99 1d 80    	cmp    $0x801d9954,%ebx
80100cab:	72 ef                	jb     80100c9c <filealloc+0x22>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
80100cad:	83 ec 0c             	sub    $0xc,%esp
80100cb0:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100cb5:	e8 79 31 00 00       	call   80103e33 <release>
  return 0;
80100cba:	83 c4 10             	add    $0x10,%esp
80100cbd:	bb 00 00 00 00       	mov    $0x0,%ebx
80100cc2:	eb 1c                	jmp    80100ce0 <filealloc+0x66>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100cc4:	bb f4 8f 1d 80       	mov    $0x801d8ff4,%ebx
      f->ref = 1;
80100cc9:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100cd0:	83 ec 0c             	sub    $0xc,%esp
80100cd3:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100cd8:	e8 56 31 00 00       	call   80103e33 <release>
      return f;
80100cdd:	83 c4 10             	add    $0x10,%esp
}
80100ce0:	89 d8                	mov    %ebx,%eax
80100ce2:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100ce5:	c9                   	leave  
80100ce6:	c3                   	ret    

80100ce7 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100ce7:	55                   	push   %ebp
80100ce8:	89 e5                	mov    %esp,%ebp
80100cea:	53                   	push   %ebx
80100ceb:	83 ec 10             	sub    $0x10,%esp
80100cee:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100cf1:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100cf6:	e8 d1 30 00 00       	call   80103dcc <acquire>
  if(f->ref < 1)
80100cfb:	8b 43 04             	mov    0x4(%ebx),%eax
80100cfe:	83 c4 10             	add    $0x10,%esp
80100d01:	85 c0                	test   %eax,%eax
80100d03:	7e 1a                	jle    80100d1f <filedup+0x38>
    panic("filedup");
  f->ref++;
80100d05:	83 c0 01             	add    $0x1,%eax
80100d08:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100d0b:	83 ec 0c             	sub    $0xc,%esp
80100d0e:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100d13:	e8 1b 31 00 00       	call   80103e33 <release>
  return f;
}
80100d18:	89 d8                	mov    %ebx,%eax
80100d1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100d1d:	c9                   	leave  
80100d1e:	c3                   	ret    
    panic("filedup");
80100d1f:	83 ec 0c             	sub    $0xc,%esp
80100d22:	68 90 80 10 80       	push   $0x80108090
80100d27:	e8 18 f6 ff ff       	call   80100344 <panic>

80100d2c <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100d2c:	55                   	push   %ebp
80100d2d:	89 e5                	mov    %esp,%ebp
80100d2f:	57                   	push   %edi
80100d30:	56                   	push   %esi
80100d31:	53                   	push   %ebx
80100d32:	83 ec 28             	sub    $0x28,%esp
80100d35:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80100d38:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100d3d:	e8 8a 30 00 00       	call   80103dcc <acquire>
  if(f->ref < 1)
80100d42:	8b 43 04             	mov    0x4(%ebx),%eax
80100d45:	83 c4 10             	add    $0x10,%esp
80100d48:	85 c0                	test   %eax,%eax
80100d4a:	7e 22                	jle    80100d6e <fileclose+0x42>
    panic("fileclose");
  if(--f->ref > 0){
80100d4c:	83 e8 01             	sub    $0x1,%eax
80100d4f:	89 43 04             	mov    %eax,0x4(%ebx)
80100d52:	85 c0                	test   %eax,%eax
80100d54:	7e 25                	jle    80100d7b <fileclose+0x4f>
    release(&ftable.lock);
80100d56:	83 ec 0c             	sub    $0xc,%esp
80100d59:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100d5e:	e8 d0 30 00 00       	call   80103e33 <release>
80100d63:	83 c4 10             	add    $0x10,%esp
  else if(ff.type == FD_INODE){
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100d66:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100d69:	5b                   	pop    %ebx
80100d6a:	5e                   	pop    %esi
80100d6b:	5f                   	pop    %edi
80100d6c:	5d                   	pop    %ebp
80100d6d:	c3                   	ret    
    panic("fileclose");
80100d6e:	83 ec 0c             	sub    $0xc,%esp
80100d71:	68 98 80 10 80       	push   $0x80108098
80100d76:	e8 c9 f5 ff ff       	call   80100344 <panic>
  ff = *f;
80100d7b:	8b 33                	mov    (%ebx),%esi
80100d7d:	0f b6 43 09          	movzbl 0x9(%ebx),%eax
80100d81:	88 45 e7             	mov    %al,-0x19(%ebp)
80100d84:	8b 7b 0c             	mov    0xc(%ebx),%edi
80100d87:	8b 43 10             	mov    0x10(%ebx),%eax
80100d8a:	89 45 e0             	mov    %eax,-0x20(%ebp)
  f->ref = 0;
80100d8d:	c7 43 04 00 00 00 00 	movl   $0x0,0x4(%ebx)
  f->type = FD_NONE;
80100d94:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  release(&ftable.lock);
80100d9a:	83 ec 0c             	sub    $0xc,%esp
80100d9d:	68 c0 8f 1d 80       	push   $0x801d8fc0
80100da2:	e8 8c 30 00 00       	call   80103e33 <release>
  if(ff.type == FD_PIPE)
80100da7:	83 c4 10             	add    $0x10,%esp
80100daa:	83 fe 01             	cmp    $0x1,%esi
80100dad:	74 1f                	je     80100dce <fileclose+0xa2>
  else if(ff.type == FD_INODE){
80100daf:	83 fe 02             	cmp    $0x2,%esi
80100db2:	75 b2                	jne    80100d66 <fileclose+0x3a>
    begin_op();
80100db4:	e8 f4 19 00 00       	call   801027ad <begin_op>
    iput(ff.ip);
80100db9:	83 ec 0c             	sub    $0xc,%esp
80100dbc:	ff 75 e0             	pushl  -0x20(%ebp)
80100dbf:	e8 29 08 00 00       	call   801015ed <iput>
    end_op();
80100dc4:	e8 5f 1a 00 00       	call   80102828 <end_op>
80100dc9:	83 c4 10             	add    $0x10,%esp
80100dcc:	eb 98                	jmp    80100d66 <fileclose+0x3a>
    pipeclose(ff.pipe, ff.writable);
80100dce:	83 ec 08             	sub    $0x8,%esp
80100dd1:	0f be 45 e7          	movsbl -0x19(%ebp),%eax
80100dd5:	50                   	push   %eax
80100dd6:	57                   	push   %edi
80100dd7:	e8 03 21 00 00       	call   80102edf <pipeclose>
80100ddc:	83 c4 10             	add    $0x10,%esp
80100ddf:	eb 85                	jmp    80100d66 <fileclose+0x3a>

80100de1 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80100de1:	55                   	push   %ebp
80100de2:	89 e5                	mov    %esp,%ebp
80100de4:	53                   	push   %ebx
80100de5:	83 ec 04             	sub    $0x4,%esp
80100de8:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80100deb:	83 3b 02             	cmpl   $0x2,(%ebx)
80100dee:	75 31                	jne    80100e21 <filestat+0x40>
    ilock(f->ip);
80100df0:	83 ec 0c             	sub    $0xc,%esp
80100df3:	ff 73 10             	pushl  0x10(%ebx)
80100df6:	e8 eb 06 00 00       	call   801014e6 <ilock>
    stati(f->ip, st);
80100dfb:	83 c4 08             	add    $0x8,%esp
80100dfe:	ff 75 0c             	pushl  0xc(%ebp)
80100e01:	ff 73 10             	pushl  0x10(%ebx)
80100e04:	e8 46 09 00 00       	call   8010174f <stati>
    iunlock(f->ip);
80100e09:	83 c4 04             	add    $0x4,%esp
80100e0c:	ff 73 10             	pushl  0x10(%ebx)
80100e0f:	e8 94 07 00 00       	call   801015a8 <iunlock>
    return 0;
80100e14:	83 c4 10             	add    $0x10,%esp
80100e17:	b8 00 00 00 00       	mov    $0x0,%eax
  }
  return -1;
}
80100e1c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100e1f:	c9                   	leave  
80100e20:	c3                   	ret    
  return -1;
80100e21:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100e26:	eb f4                	jmp    80100e1c <filestat+0x3b>

80100e28 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80100e28:	55                   	push   %ebp
80100e29:	89 e5                	mov    %esp,%ebp
80100e2b:	56                   	push   %esi
80100e2c:	53                   	push   %ebx
80100e2d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;

  if(f->readable == 0)
80100e30:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80100e34:	74 70                	je     80100ea6 <fileread+0x7e>
    return -1;
  if(f->type == FD_PIPE)
80100e36:	8b 03                	mov    (%ebx),%eax
80100e38:	83 f8 01             	cmp    $0x1,%eax
80100e3b:	74 44                	je     80100e81 <fileread+0x59>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100e3d:	83 f8 02             	cmp    $0x2,%eax
80100e40:	75 57                	jne    80100e99 <fileread+0x71>
    ilock(f->ip);
80100e42:	83 ec 0c             	sub    $0xc,%esp
80100e45:	ff 73 10             	pushl  0x10(%ebx)
80100e48:	e8 99 06 00 00       	call   801014e6 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
80100e4d:	ff 75 10             	pushl  0x10(%ebp)
80100e50:	ff 73 14             	pushl  0x14(%ebx)
80100e53:	ff 75 0c             	pushl  0xc(%ebp)
80100e56:	ff 73 10             	pushl  0x10(%ebx)
80100e59:	e8 1c 09 00 00       	call   8010177a <readi>
80100e5e:	89 c6                	mov    %eax,%esi
80100e60:	83 c4 20             	add    $0x20,%esp
80100e63:	85 c0                	test   %eax,%eax
80100e65:	7e 03                	jle    80100e6a <fileread+0x42>
      f->off += r;
80100e67:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80100e6a:	83 ec 0c             	sub    $0xc,%esp
80100e6d:	ff 73 10             	pushl  0x10(%ebx)
80100e70:	e8 33 07 00 00       	call   801015a8 <iunlock>
    return r;
80100e75:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80100e78:	89 f0                	mov    %esi,%eax
80100e7a:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100e7d:	5b                   	pop    %ebx
80100e7e:	5e                   	pop    %esi
80100e7f:	5d                   	pop    %ebp
80100e80:	c3                   	ret    
    return piperead(f->pipe, addr, n);
80100e81:	83 ec 04             	sub    $0x4,%esp
80100e84:	ff 75 10             	pushl  0x10(%ebp)
80100e87:	ff 75 0c             	pushl  0xc(%ebp)
80100e8a:	ff 73 0c             	pushl  0xc(%ebx)
80100e8d:	e8 d2 21 00 00       	call   80103064 <piperead>
80100e92:	89 c6                	mov    %eax,%esi
80100e94:	83 c4 10             	add    $0x10,%esp
80100e97:	eb df                	jmp    80100e78 <fileread+0x50>
  panic("fileread");
80100e99:	83 ec 0c             	sub    $0xc,%esp
80100e9c:	68 a2 80 10 80       	push   $0x801080a2
80100ea1:	e8 9e f4 ff ff       	call   80100344 <panic>
    return -1;
80100ea6:	be ff ff ff ff       	mov    $0xffffffff,%esi
80100eab:	eb cb                	jmp    80100e78 <fileread+0x50>

80100ead <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
80100ead:	55                   	push   %ebp
80100eae:	89 e5                	mov    %esp,%ebp
80100eb0:	57                   	push   %edi
80100eb1:	56                   	push   %esi
80100eb2:	53                   	push   %ebx
80100eb3:	83 ec 1c             	sub    $0x1c,%esp
80100eb6:	8b 75 08             	mov    0x8(%ebp),%esi
  int r;

  if(f->writable == 0)
80100eb9:	80 7e 09 00          	cmpb   $0x0,0x9(%esi)
80100ebd:	0f 84 e8 00 00 00    	je     80100fab <filewrite+0xfe>
    return -1;
  if(f->type == FD_PIPE)
80100ec3:	8b 06                	mov    (%esi),%eax
80100ec5:	83 f8 01             	cmp    $0x1,%eax
80100ec8:	74 1a                	je     80100ee4 <filewrite+0x37>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
80100eca:	83 f8 02             	cmp    $0x2,%eax
80100ecd:	0f 85 cb 00 00 00    	jne    80100f9e <filewrite+0xf1>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80100ed3:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80100ed7:	0f 8e 9e 00 00 00    	jle    80100f7b <filewrite+0xce>
    int i = 0;
80100edd:	bf 00 00 00 00       	mov    $0x0,%edi
80100ee2:	eb 3f                	jmp    80100f23 <filewrite+0x76>
    return pipewrite(f->pipe, addr, n);
80100ee4:	83 ec 04             	sub    $0x4,%esp
80100ee7:	ff 75 10             	pushl  0x10(%ebp)
80100eea:	ff 75 0c             	pushl  0xc(%ebp)
80100eed:	ff 76 0c             	pushl  0xc(%esi)
80100ef0:	e8 76 20 00 00       	call   80102f6b <pipewrite>
80100ef5:	89 45 10             	mov    %eax,0x10(%ebp)
80100ef8:	83 c4 10             	add    $0x10,%esp
80100efb:	e9 93 00 00 00       	jmp    80100f93 <filewrite+0xe6>

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
      iunlock(f->ip);
80100f00:	83 ec 0c             	sub    $0xc,%esp
80100f03:	ff 76 10             	pushl  0x10(%esi)
80100f06:	e8 9d 06 00 00       	call   801015a8 <iunlock>
      end_op();
80100f0b:	e8 18 19 00 00       	call   80102828 <end_op>

      if(r < 0)
80100f10:	83 c4 10             	add    $0x10,%esp
80100f13:	85 db                	test   %ebx,%ebx
80100f15:	78 6b                	js     80100f82 <filewrite+0xd5>
        break;
      if(r != n1)
80100f17:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
80100f1a:	75 4e                	jne    80100f6a <filewrite+0xbd>
        panic("short filewrite");
      i += r;
80100f1c:	01 df                	add    %ebx,%edi
    while(i < n){
80100f1e:	39 7d 10             	cmp    %edi,0x10(%ebp)
80100f21:	7e 54                	jle    80100f77 <filewrite+0xca>
      int n1 = n - i;
80100f23:	8b 45 10             	mov    0x10(%ebp),%eax
80100f26:	29 f8                	sub    %edi,%eax
80100f28:	3d 00 06 00 00       	cmp    $0x600,%eax
80100f2d:	ba 00 06 00 00       	mov    $0x600,%edx
80100f32:	0f 4f c2             	cmovg  %edx,%eax
80100f35:	89 c3                	mov    %eax,%ebx
80100f37:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      begin_op();
80100f3a:	e8 6e 18 00 00       	call   801027ad <begin_op>
      ilock(f->ip);
80100f3f:	83 ec 0c             	sub    $0xc,%esp
80100f42:	ff 76 10             	pushl  0x10(%esi)
80100f45:	e8 9c 05 00 00       	call   801014e6 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
80100f4a:	53                   	push   %ebx
80100f4b:	ff 76 14             	pushl  0x14(%esi)
80100f4e:	89 f8                	mov    %edi,%eax
80100f50:	03 45 0c             	add    0xc(%ebp),%eax
80100f53:	50                   	push   %eax
80100f54:	ff 76 10             	pushl  0x10(%esi)
80100f57:	e8 1a 09 00 00       	call   80101876 <writei>
80100f5c:	89 c3                	mov    %eax,%ebx
80100f5e:	83 c4 20             	add    $0x20,%esp
80100f61:	85 c0                	test   %eax,%eax
80100f63:	7e 9b                	jle    80100f00 <filewrite+0x53>
        f->off += r;
80100f65:	01 46 14             	add    %eax,0x14(%esi)
80100f68:	eb 96                	jmp    80100f00 <filewrite+0x53>
        panic("short filewrite");
80100f6a:	83 ec 0c             	sub    $0xc,%esp
80100f6d:	68 ab 80 10 80       	push   $0x801080ab
80100f72:	e8 cd f3 ff ff       	call   80100344 <panic>
80100f77:	89 f8                	mov    %edi,%eax
80100f79:	eb 09                	jmp    80100f84 <filewrite+0xd7>
    int i = 0;
80100f7b:	b8 00 00 00 00       	mov    $0x0,%eax
80100f80:	eb 02                	jmp    80100f84 <filewrite+0xd7>
80100f82:	89 f8                	mov    %edi,%eax
    }
    return i == n ? n : -1;
80100f84:	39 45 10             	cmp    %eax,0x10(%ebp)
80100f87:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80100f8c:	0f 44 45 10          	cmove  0x10(%ebp),%eax
80100f90:	89 45 10             	mov    %eax,0x10(%ebp)
  }
  panic("filewrite");
}
80100f93:	8b 45 10             	mov    0x10(%ebp),%eax
80100f96:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100f99:	5b                   	pop    %ebx
80100f9a:	5e                   	pop    %esi
80100f9b:	5f                   	pop    %edi
80100f9c:	5d                   	pop    %ebp
80100f9d:	c3                   	ret    
  panic("filewrite");
80100f9e:	83 ec 0c             	sub    $0xc,%esp
80100fa1:	68 b1 80 10 80       	push   $0x801080b1
80100fa6:	e8 99 f3 ff ff       	call   80100344 <panic>
    return -1;
80100fab:	c7 45 10 ff ff ff ff 	movl   $0xffffffff,0x10(%ebp)
80100fb2:	eb df                	jmp    80100f93 <filewrite+0xe6>

80100fb4 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
80100fb4:	55                   	push   %ebp
80100fb5:	89 e5                	mov    %esp,%ebp
80100fb7:	56                   	push   %esi
80100fb8:	53                   	push   %ebx
80100fb9:	89 d3                	mov    %edx,%ebx
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
80100fbb:	83 ec 08             	sub    $0x8,%esp
80100fbe:	c1 ea 0c             	shr    $0xc,%edx
80100fc1:	03 15 d8 99 1d 80    	add    0x801d99d8,%edx
80100fc7:	52                   	push   %edx
80100fc8:	50                   	push   %eax
80100fc9:	e8 dc f0 ff ff       	call   801000aa <bread>
80100fce:	89 c6                	mov    %eax,%esi
  bi = b % BPB;
  m = 1 << (bi % 8);
80100fd0:	89 d9                	mov    %ebx,%ecx
80100fd2:	83 e1 07             	and    $0x7,%ecx
80100fd5:	b8 01 00 00 00       	mov    $0x1,%eax
80100fda:	d3 e0                	shl    %cl,%eax
  bi = b % BPB;
80100fdc:	81 e3 ff 0f 00 00    	and    $0xfff,%ebx
  if((bp->data[bi/8] & m) == 0)
80100fe2:	83 c4 10             	add    $0x10,%esp
80100fe5:	c1 fb 03             	sar    $0x3,%ebx
80100fe8:	0f b6 54 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%edx
80100fed:	0f b6 ca             	movzbl %dl,%ecx
80100ff0:	85 c1                	test   %eax,%ecx
80100ff2:	74 23                	je     80101017 <bfree+0x63>
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
80100ff4:	f7 d0                	not    %eax
80100ff6:	21 d0                	and    %edx,%eax
80100ff8:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
80100ffc:	83 ec 0c             	sub    $0xc,%esp
80100fff:	56                   	push   %esi
80101000:	e8 68 19 00 00       	call   8010296d <log_write>
  brelse(bp);
80101005:	89 34 24             	mov    %esi,(%esp)
80101008:	e8 b4 f1 ff ff       	call   801001c1 <brelse>
}
8010100d:	83 c4 10             	add    $0x10,%esp
80101010:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101013:	5b                   	pop    %ebx
80101014:	5e                   	pop    %esi
80101015:	5d                   	pop    %ebp
80101016:	c3                   	ret    
    panic("freeing free block");
80101017:	83 ec 0c             	sub    $0xc,%esp
8010101a:	68 bb 80 10 80       	push   $0x801080bb
8010101f:	e8 20 f3 ff ff       	call   80100344 <panic>

80101024 <balloc>:
{
80101024:	55                   	push   %ebp
80101025:	89 e5                	mov    %esp,%ebp
80101027:	57                   	push   %edi
80101028:	56                   	push   %esi
80101029:	53                   	push   %ebx
8010102a:	83 ec 2c             	sub    $0x2c,%esp
8010102d:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
80101030:	83 3d c0 99 1d 80 00 	cmpl   $0x0,0x801d99c0
80101037:	0f 84 32 01 00 00    	je     8010116f <balloc+0x14b>
8010103d:	c7 45 d8 00 00 00 00 	movl   $0x0,-0x28(%ebp)
80101044:	e9 8f 00 00 00       	jmp    801010d8 <balloc+0xb4>
80101049:	89 c3                	mov    %eax,%ebx
        bp->data[bi/8] |= m;  // Mark block in use.
8010104b:	09 ca                	or     %ecx,%edx
8010104d:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101050:	88 54 03 5c          	mov    %dl,0x5c(%ebx,%eax,1)
        log_write(bp);
80101054:	83 ec 0c             	sub    $0xc,%esp
80101057:	53                   	push   %ebx
80101058:	e8 10 19 00 00       	call   8010296d <log_write>
        brelse(bp);
8010105d:	89 1c 24             	mov    %ebx,(%esp)
80101060:	e8 5c f1 ff ff       	call   801001c1 <brelse>
  bp = bread(dev, bno);
80101065:	83 c4 08             	add    $0x8,%esp
80101068:	ff 75 e4             	pushl  -0x1c(%ebp)
8010106b:	ff 75 d4             	pushl  -0x2c(%ebp)
8010106e:	e8 37 f0 ff ff       	call   801000aa <bread>
80101073:	89 c6                	mov    %eax,%esi
  memset(bp->data, 0, BSIZE);
80101075:	83 c4 0c             	add    $0xc,%esp
80101078:	68 00 02 00 00       	push   $0x200
8010107d:	6a 00                	push   $0x0
8010107f:	8d 40 5c             	lea    0x5c(%eax),%eax
80101082:	50                   	push   %eax
80101083:	e8 f2 2d 00 00       	call   80103e7a <memset>
  log_write(bp);
80101088:	89 34 24             	mov    %esi,(%esp)
8010108b:	e8 dd 18 00 00       	call   8010296d <log_write>
  brelse(bp);
80101090:	89 34 24             	mov    %esi,(%esp)
80101093:	e8 29 f1 ff ff       	call   801001c1 <brelse>
}
80101098:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010109b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010109e:	5b                   	pop    %ebx
8010109f:	5e                   	pop    %esi
801010a0:	5f                   	pop    %edi
801010a1:	5d                   	pop    %ebp
801010a2:	c3                   	ret    
801010a3:	89 c3                	mov    %eax,%ebx
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801010a5:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      m = 1 << (bi % 8);
801010a8:	b9 01 00 00 00       	mov    $0x1,%ecx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
801010ad:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
801010b4:	eb 95                	jmp    8010104b <balloc+0x27>
    brelse(bp);
801010b6:	83 ec 0c             	sub    $0xc,%esp
801010b9:	50                   	push   %eax
801010ba:	e8 02 f1 ff ff       	call   801001c1 <brelse>
  for(b = 0; b < sb.size; b += BPB){
801010bf:	81 45 d8 00 10 00 00 	addl   $0x1000,-0x28(%ebp)
801010c6:	8b 45 d8             	mov    -0x28(%ebp),%eax
801010c9:	83 c4 10             	add    $0x10,%esp
801010cc:	39 05 c0 99 1d 80    	cmp    %eax,0x801d99c0
801010d2:	0f 86 97 00 00 00    	jbe    8010116f <balloc+0x14b>
    bp = bread(dev, BBLOCK(b, sb));
801010d8:	83 ec 08             	sub    $0x8,%esp
801010db:	8b 7d d8             	mov    -0x28(%ebp),%edi
801010de:	89 fb                	mov    %edi,%ebx
801010e0:	8d 87 ff 0f 00 00    	lea    0xfff(%edi),%eax
801010e6:	85 ff                	test   %edi,%edi
801010e8:	0f 49 c7             	cmovns %edi,%eax
801010eb:	c1 f8 0c             	sar    $0xc,%eax
801010ee:	03 05 d8 99 1d 80    	add    0x801d99d8,%eax
801010f4:	50                   	push   %eax
801010f5:	ff 75 d4             	pushl  -0x2c(%ebp)
801010f8:	e8 ad ef ff ff       	call   801000aa <bread>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
801010fd:	8b 0d c0 99 1d 80    	mov    0x801d99c0,%ecx
80101103:	83 c4 10             	add    $0x10,%esp
80101106:	39 cf                	cmp    %ecx,%edi
80101108:	73 ac                	jae    801010b6 <balloc+0x92>
      if((bp->data[bi/8] & m) == 0){  // Is block free?
8010110a:	0f b6 50 5c          	movzbl 0x5c(%eax),%edx
8010110e:	f6 c2 01             	test   $0x1,%dl
80101111:	74 90                	je     801010a3 <balloc+0x7f>
80101113:	29 f9                	sub    %edi,%ecx
80101115:	89 4d e0             	mov    %ecx,-0x20(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
80101118:	be 01 00 00 00       	mov    $0x1,%esi
8010111d:	8d 3c 1e             	lea    (%esi,%ebx,1),%edi
80101120:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80101123:	3b 75 e0             	cmp    -0x20(%ebp),%esi
80101126:	74 8e                	je     801010b6 <balloc+0x92>
      m = 1 << (bi % 8);
80101128:	89 f2                	mov    %esi,%edx
8010112a:	c1 fa 1f             	sar    $0x1f,%edx
8010112d:	c1 ea 1d             	shr    $0x1d,%edx
80101130:	8d 0c 16             	lea    (%esi,%edx,1),%ecx
80101133:	83 e1 07             	and    $0x7,%ecx
80101136:	29 d1                	sub    %edx,%ecx
80101138:	bf 01 00 00 00       	mov    $0x1,%edi
8010113d:	d3 e7                	shl    %cl,%edi
8010113f:	89 f9                	mov    %edi,%ecx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101141:	8d 56 07             	lea    0x7(%esi),%edx
80101144:	85 f6                	test   %esi,%esi
80101146:	0f 49 d6             	cmovns %esi,%edx
80101149:	c1 fa 03             	sar    $0x3,%edx
8010114c:	89 55 dc             	mov    %edx,-0x24(%ebp)
8010114f:	0f b6 54 10 5c       	movzbl 0x5c(%eax,%edx,1),%edx
80101154:	0f b6 fa             	movzbl %dl,%edi
80101157:	85 cf                	test   %ecx,%edi
80101159:	0f 84 ea fe ff ff    	je     80101049 <balloc+0x25>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010115f:	83 c6 01             	add    $0x1,%esi
80101162:	81 fe 00 10 00 00    	cmp    $0x1000,%esi
80101168:	75 b3                	jne    8010111d <balloc+0xf9>
8010116a:	e9 47 ff ff ff       	jmp    801010b6 <balloc+0x92>
  panic("balloc: out of blocks");
8010116f:	83 ec 0c             	sub    $0xc,%esp
80101172:	68 ce 80 10 80       	push   $0x801080ce
80101177:	e8 c8 f1 ff ff       	call   80100344 <panic>

8010117c <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
8010117c:	55                   	push   %ebp
8010117d:	89 e5                	mov    %esp,%ebp
8010117f:	57                   	push   %edi
80101180:	56                   	push   %esi
80101181:	53                   	push   %ebx
80101182:	83 ec 1c             	sub    $0x1c,%esp
80101185:	89 c6                	mov    %eax,%esi
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
80101187:	83 fa 0b             	cmp    $0xb,%edx
8010118a:	77 18                	ja     801011a4 <bmap+0x28>
8010118c:	8d 3c 90             	lea    (%eax,%edx,4),%edi
    if((addr = ip->addrs[bn]) == 0)
8010118f:	8b 5f 5c             	mov    0x5c(%edi),%ebx
80101192:	85 db                	test   %ebx,%ebx
80101194:	75 49                	jne    801011df <bmap+0x63>
      ip->addrs[bn] = addr = balloc(ip->dev);
80101196:	8b 00                	mov    (%eax),%eax
80101198:	e8 87 fe ff ff       	call   80101024 <balloc>
8010119d:	89 c3                	mov    %eax,%ebx
8010119f:	89 47 5c             	mov    %eax,0x5c(%edi)
801011a2:	eb 3b                	jmp    801011df <bmap+0x63>
    return addr;
  }
  bn -= NDIRECT;
801011a4:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
801011a7:	83 fb 7f             	cmp    $0x7f,%ebx
801011aa:	77 68                	ja     80101214 <bmap+0x98>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
801011ac:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
801011b2:	85 c0                	test   %eax,%eax
801011b4:	74 33                	je     801011e9 <bmap+0x6d>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
801011b6:	83 ec 08             	sub    $0x8,%esp
801011b9:	50                   	push   %eax
801011ba:	ff 36                	pushl  (%esi)
801011bc:	e8 e9 ee ff ff       	call   801000aa <bread>
801011c1:	89 c7                	mov    %eax,%edi
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
801011c3:	8d 44 98 5c          	lea    0x5c(%eax,%ebx,4),%eax
801011c7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801011ca:	8b 18                	mov    (%eax),%ebx
801011cc:	83 c4 10             	add    $0x10,%esp
801011cf:	85 db                	test   %ebx,%ebx
801011d1:	74 25                	je     801011f8 <bmap+0x7c>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
801011d3:	83 ec 0c             	sub    $0xc,%esp
801011d6:	57                   	push   %edi
801011d7:	e8 e5 ef ff ff       	call   801001c1 <brelse>
    return addr;
801011dc:	83 c4 10             	add    $0x10,%esp
  }

  panic("bmap: out of range");
}
801011df:	89 d8                	mov    %ebx,%eax
801011e1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801011e4:	5b                   	pop    %ebx
801011e5:	5e                   	pop    %esi
801011e6:	5f                   	pop    %edi
801011e7:	5d                   	pop    %ebp
801011e8:	c3                   	ret    
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801011e9:	8b 06                	mov    (%esi),%eax
801011eb:	e8 34 fe ff ff       	call   80101024 <balloc>
801011f0:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
801011f6:	eb be                	jmp    801011b6 <bmap+0x3a>
      a[bn] = addr = balloc(ip->dev);
801011f8:	8b 06                	mov    (%esi),%eax
801011fa:	e8 25 fe ff ff       	call   80101024 <balloc>
801011ff:	89 c3                	mov    %eax,%ebx
80101201:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101204:	89 18                	mov    %ebx,(%eax)
      log_write(bp);
80101206:	83 ec 0c             	sub    $0xc,%esp
80101209:	57                   	push   %edi
8010120a:	e8 5e 17 00 00       	call   8010296d <log_write>
8010120f:	83 c4 10             	add    $0x10,%esp
80101212:	eb bf                	jmp    801011d3 <bmap+0x57>
  panic("bmap: out of range");
80101214:	83 ec 0c             	sub    $0xc,%esp
80101217:	68 e4 80 10 80       	push   $0x801080e4
8010121c:	e8 23 f1 ff ff       	call   80100344 <panic>

80101221 <iget>:
{
80101221:	55                   	push   %ebp
80101222:	89 e5                	mov    %esp,%ebp
80101224:	57                   	push   %edi
80101225:	56                   	push   %esi
80101226:	53                   	push   %ebx
80101227:	83 ec 28             	sub    $0x28,%esp
8010122a:	89 c7                	mov    %eax,%edi
8010122c:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  acquire(&icache.lock);
8010122f:	68 e0 99 1d 80       	push   $0x801d99e0
80101234:	e8 93 2b 00 00       	call   80103dcc <acquire>
80101239:	83 c4 10             	add    $0x10,%esp
  empty = 0;
8010123c:	be 00 00 00 00       	mov    $0x0,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101241:	bb 14 9a 1d 80       	mov    $0x801d9a14,%ebx
80101246:	eb 1c                	jmp    80101264 <iget+0x43>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101248:	85 c0                	test   %eax,%eax
8010124a:	75 0a                	jne    80101256 <iget+0x35>
8010124c:	85 f6                	test   %esi,%esi
8010124e:	0f 94 c0             	sete   %al
80101251:	84 c0                	test   %al,%al
80101253:	0f 45 f3             	cmovne %ebx,%esi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101256:	81 c3 90 00 00 00    	add    $0x90,%ebx
8010125c:	81 fb 34 b6 1d 80    	cmp    $0x801db634,%ebx
80101262:	73 2d                	jae    80101291 <iget+0x70>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101264:	8b 43 08             	mov    0x8(%ebx),%eax
80101267:	85 c0                	test   %eax,%eax
80101269:	7e dd                	jle    80101248 <iget+0x27>
8010126b:	39 3b                	cmp    %edi,(%ebx)
8010126d:	75 e7                	jne    80101256 <iget+0x35>
8010126f:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101272:	39 4b 04             	cmp    %ecx,0x4(%ebx)
80101275:	75 df                	jne    80101256 <iget+0x35>
      ip->ref++;
80101277:	83 c0 01             	add    $0x1,%eax
8010127a:	89 43 08             	mov    %eax,0x8(%ebx)
      release(&icache.lock);
8010127d:	83 ec 0c             	sub    $0xc,%esp
80101280:	68 e0 99 1d 80       	push   $0x801d99e0
80101285:	e8 a9 2b 00 00       	call   80103e33 <release>
      return ip;
8010128a:	83 c4 10             	add    $0x10,%esp
8010128d:	89 de                	mov    %ebx,%esi
8010128f:	eb 2a                	jmp    801012bb <iget+0x9a>
  if(empty == 0)
80101291:	85 f6                	test   %esi,%esi
80101293:	74 30                	je     801012c5 <iget+0xa4>
  ip->dev = dev;
80101295:	89 3e                	mov    %edi,(%esi)
  ip->inum = inum;
80101297:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010129a:	89 46 04             	mov    %eax,0x4(%esi)
  ip->ref = 1;
8010129d:	c7 46 08 01 00 00 00 	movl   $0x1,0x8(%esi)
  ip->valid = 0;
801012a4:	c7 46 4c 00 00 00 00 	movl   $0x0,0x4c(%esi)
  release(&icache.lock);
801012ab:	83 ec 0c             	sub    $0xc,%esp
801012ae:	68 e0 99 1d 80       	push   $0x801d99e0
801012b3:	e8 7b 2b 00 00       	call   80103e33 <release>
  return ip;
801012b8:	83 c4 10             	add    $0x10,%esp
}
801012bb:	89 f0                	mov    %esi,%eax
801012bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801012c0:	5b                   	pop    %ebx
801012c1:	5e                   	pop    %esi
801012c2:	5f                   	pop    %edi
801012c3:	5d                   	pop    %ebp
801012c4:	c3                   	ret    
    panic("iget: no inodes");
801012c5:	83 ec 0c             	sub    $0xc,%esp
801012c8:	68 f7 80 10 80       	push   $0x801080f7
801012cd:	e8 72 f0 ff ff       	call   80100344 <panic>

801012d2 <readsb>:
{
801012d2:	55                   	push   %ebp
801012d3:	89 e5                	mov    %esp,%ebp
801012d5:	53                   	push   %ebx
801012d6:	83 ec 0c             	sub    $0xc,%esp
  bp = bread(dev, 1);
801012d9:	6a 01                	push   $0x1
801012db:	ff 75 08             	pushl  0x8(%ebp)
801012de:	e8 c7 ed ff ff       	call   801000aa <bread>
801012e3:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
801012e5:	83 c4 0c             	add    $0xc,%esp
801012e8:	6a 1c                	push   $0x1c
801012ea:	8d 40 5c             	lea    0x5c(%eax),%eax
801012ed:	50                   	push   %eax
801012ee:	ff 75 0c             	pushl  0xc(%ebp)
801012f1:	e8 19 2c 00 00       	call   80103f0f <memmove>
  brelse(bp);
801012f6:	89 1c 24             	mov    %ebx,(%esp)
801012f9:	e8 c3 ee ff ff       	call   801001c1 <brelse>
}
801012fe:	83 c4 10             	add    $0x10,%esp
80101301:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101304:	c9                   	leave  
80101305:	c3                   	ret    

80101306 <iinit>:
{
80101306:	55                   	push   %ebp
80101307:	89 e5                	mov    %esp,%ebp
80101309:	56                   	push   %esi
8010130a:	53                   	push   %ebx
  initlock(&icache.lock, "icache");
8010130b:	83 ec 08             	sub    $0x8,%esp
8010130e:	68 07 81 10 80       	push   $0x80108107
80101313:	68 e0 99 1d 80       	push   $0x801d99e0
80101318:	e8 67 29 00 00       	call   80103c84 <initlock>
8010131d:	bb 20 9a 1d 80       	mov    $0x801d9a20,%ebx
80101322:	be 40 b6 1d 80       	mov    $0x801db640,%esi
80101327:	83 c4 10             	add    $0x10,%esp
    initsleeplock(&icache.inode[i].lock, "inode");
8010132a:	83 ec 08             	sub    $0x8,%esp
8010132d:	68 0e 81 10 80       	push   $0x8010810e
80101332:	53                   	push   %ebx
80101333:	e8 42 28 00 00       	call   80103b7a <initsleeplock>
80101338:	81 c3 90 00 00 00    	add    $0x90,%ebx
  for(i = 0; i < NINODE; i++) {
8010133e:	83 c4 10             	add    $0x10,%esp
80101341:	39 f3                	cmp    %esi,%ebx
80101343:	75 e5                	jne    8010132a <iinit+0x24>
  readsb(dev, &sb);
80101345:	83 ec 08             	sub    $0x8,%esp
80101348:	68 c0 99 1d 80       	push   $0x801d99c0
8010134d:	ff 75 08             	pushl  0x8(%ebp)
80101350:	e8 7d ff ff ff       	call   801012d2 <readsb>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
80101355:	ff 35 d8 99 1d 80    	pushl  0x801d99d8
8010135b:	ff 35 d4 99 1d 80    	pushl  0x801d99d4
80101361:	ff 35 d0 99 1d 80    	pushl  0x801d99d0
80101367:	ff 35 cc 99 1d 80    	pushl  0x801d99cc
8010136d:	ff 35 c8 99 1d 80    	pushl  0x801d99c8
80101373:	ff 35 c4 99 1d 80    	pushl  0x801d99c4
80101379:	ff 35 c0 99 1d 80    	pushl  0x801d99c0
8010137f:	68 74 81 10 80       	push   $0x80108174
80101384:	e8 58 f2 ff ff       	call   801005e1 <cprintf>
}
80101389:	83 c4 30             	add    $0x30,%esp
8010138c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010138f:	5b                   	pop    %ebx
80101390:	5e                   	pop    %esi
80101391:	5d                   	pop    %ebp
80101392:	c3                   	ret    

80101393 <ialloc>:
{
80101393:	55                   	push   %ebp
80101394:	89 e5                	mov    %esp,%ebp
80101396:	57                   	push   %edi
80101397:	56                   	push   %esi
80101398:	53                   	push   %ebx
80101399:	83 ec 1c             	sub    $0x1c,%esp
8010139c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010139f:	89 45 e0             	mov    %eax,-0x20(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
801013a2:	83 3d c8 99 1d 80 01 	cmpl   $0x1,0x801d99c8
801013a9:	76 4d                	jbe    801013f8 <ialloc+0x65>
801013ab:	bb 01 00 00 00       	mov    $0x1,%ebx
801013b0:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
    bp = bread(dev, IBLOCK(inum, sb));
801013b3:	83 ec 08             	sub    $0x8,%esp
801013b6:	89 d8                	mov    %ebx,%eax
801013b8:	c1 e8 03             	shr    $0x3,%eax
801013bb:	03 05 d4 99 1d 80    	add    0x801d99d4,%eax
801013c1:	50                   	push   %eax
801013c2:	ff 75 08             	pushl  0x8(%ebp)
801013c5:	e8 e0 ec ff ff       	call   801000aa <bread>
801013ca:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + inum%IPB;
801013cc:	89 d8                	mov    %ebx,%eax
801013ce:	83 e0 07             	and    $0x7,%eax
801013d1:	c1 e0 06             	shl    $0x6,%eax
801013d4:	8d 7c 06 5c          	lea    0x5c(%esi,%eax,1),%edi
    if(dip->type == 0){  // a free inode
801013d8:	83 c4 10             	add    $0x10,%esp
801013db:	66 83 3f 00          	cmpw   $0x0,(%edi)
801013df:	74 24                	je     80101405 <ialloc+0x72>
    brelse(bp);
801013e1:	83 ec 0c             	sub    $0xc,%esp
801013e4:	56                   	push   %esi
801013e5:	e8 d7 ed ff ff       	call   801001c1 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
801013ea:	83 c3 01             	add    $0x1,%ebx
801013ed:	83 c4 10             	add    $0x10,%esp
801013f0:	39 1d c8 99 1d 80    	cmp    %ebx,0x801d99c8
801013f6:	77 b8                	ja     801013b0 <ialloc+0x1d>
  panic("ialloc: no inodes");
801013f8:	83 ec 0c             	sub    $0xc,%esp
801013fb:	68 14 81 10 80       	push   $0x80108114
80101400:	e8 3f ef ff ff       	call   80100344 <panic>
      memset(dip, 0, sizeof(*dip));
80101405:	83 ec 04             	sub    $0x4,%esp
80101408:	6a 40                	push   $0x40
8010140a:	6a 00                	push   $0x0
8010140c:	57                   	push   %edi
8010140d:	e8 68 2a 00 00       	call   80103e7a <memset>
      dip->type = type;
80101412:	0f b7 45 e0          	movzwl -0x20(%ebp),%eax
80101416:	66 89 07             	mov    %ax,(%edi)
      log_write(bp);   // mark it allocated on the disk
80101419:	89 34 24             	mov    %esi,(%esp)
8010141c:	e8 4c 15 00 00       	call   8010296d <log_write>
      brelse(bp);
80101421:	89 34 24             	mov    %esi,(%esp)
80101424:	e8 98 ed ff ff       	call   801001c1 <brelse>
      return iget(dev, inum);
80101429:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010142c:	8b 45 08             	mov    0x8(%ebp),%eax
8010142f:	e8 ed fd ff ff       	call   80101221 <iget>
}
80101434:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101437:	5b                   	pop    %ebx
80101438:	5e                   	pop    %esi
80101439:	5f                   	pop    %edi
8010143a:	5d                   	pop    %ebp
8010143b:	c3                   	ret    

8010143c <iupdate>:
{
8010143c:	55                   	push   %ebp
8010143d:	89 e5                	mov    %esp,%ebp
8010143f:	56                   	push   %esi
80101440:	53                   	push   %ebx
80101441:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80101444:	83 ec 08             	sub    $0x8,%esp
80101447:	8b 43 04             	mov    0x4(%ebx),%eax
8010144a:	c1 e8 03             	shr    $0x3,%eax
8010144d:	03 05 d4 99 1d 80    	add    0x801d99d4,%eax
80101453:	50                   	push   %eax
80101454:	ff 33                	pushl  (%ebx)
80101456:	e8 4f ec ff ff       	call   801000aa <bread>
8010145b:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
8010145d:	8b 43 04             	mov    0x4(%ebx),%eax
80101460:	83 e0 07             	and    $0x7,%eax
80101463:	c1 e0 06             	shl    $0x6,%eax
80101466:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
  dip->type = ip->type;
8010146a:	0f b7 53 50          	movzwl 0x50(%ebx),%edx
8010146e:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
80101471:	0f b7 53 52          	movzwl 0x52(%ebx),%edx
80101475:	66 89 50 02          	mov    %dx,0x2(%eax)
  dip->minor = ip->minor;
80101479:	0f b7 53 54          	movzwl 0x54(%ebx),%edx
8010147d:	66 89 50 04          	mov    %dx,0x4(%eax)
  dip->nlink = ip->nlink;
80101481:	0f b7 53 56          	movzwl 0x56(%ebx),%edx
80101485:	66 89 50 06          	mov    %dx,0x6(%eax)
  dip->size = ip->size;
80101489:	8b 53 58             	mov    0x58(%ebx),%edx
8010148c:	89 50 08             	mov    %edx,0x8(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010148f:	83 c4 0c             	add    $0xc,%esp
80101492:	6a 34                	push   $0x34
80101494:	83 c3 5c             	add    $0x5c,%ebx
80101497:	53                   	push   %ebx
80101498:	83 c0 0c             	add    $0xc,%eax
8010149b:	50                   	push   %eax
8010149c:	e8 6e 2a 00 00       	call   80103f0f <memmove>
  log_write(bp);
801014a1:	89 34 24             	mov    %esi,(%esp)
801014a4:	e8 c4 14 00 00       	call   8010296d <log_write>
  brelse(bp);
801014a9:	89 34 24             	mov    %esi,(%esp)
801014ac:	e8 10 ed ff ff       	call   801001c1 <brelse>
}
801014b1:	83 c4 10             	add    $0x10,%esp
801014b4:	8d 65 f8             	lea    -0x8(%ebp),%esp
801014b7:	5b                   	pop    %ebx
801014b8:	5e                   	pop    %esi
801014b9:	5d                   	pop    %ebp
801014ba:	c3                   	ret    

801014bb <idup>:
{
801014bb:	55                   	push   %ebp
801014bc:	89 e5                	mov    %esp,%ebp
801014be:	53                   	push   %ebx
801014bf:	83 ec 10             	sub    $0x10,%esp
801014c2:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
801014c5:	68 e0 99 1d 80       	push   $0x801d99e0
801014ca:	e8 fd 28 00 00       	call   80103dcc <acquire>
  ip->ref++;
801014cf:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
801014d3:	c7 04 24 e0 99 1d 80 	movl   $0x801d99e0,(%esp)
801014da:	e8 54 29 00 00       	call   80103e33 <release>
}
801014df:	89 d8                	mov    %ebx,%eax
801014e1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801014e4:	c9                   	leave  
801014e5:	c3                   	ret    

801014e6 <ilock>:
{
801014e6:	55                   	push   %ebp
801014e7:	89 e5                	mov    %esp,%ebp
801014e9:	56                   	push   %esi
801014ea:	53                   	push   %ebx
801014eb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
801014ee:	85 db                	test   %ebx,%ebx
801014f0:	74 22                	je     80101514 <ilock+0x2e>
801014f2:	83 7b 08 00          	cmpl   $0x0,0x8(%ebx)
801014f6:	7e 1c                	jle    80101514 <ilock+0x2e>
  acquiresleep(&ip->lock);
801014f8:	83 ec 0c             	sub    $0xc,%esp
801014fb:	8d 43 0c             	lea    0xc(%ebx),%eax
801014fe:	50                   	push   %eax
801014ff:	e8 a9 26 00 00       	call   80103bad <acquiresleep>
  if(ip->valid == 0){
80101504:	83 c4 10             	add    $0x10,%esp
80101507:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
8010150b:	74 14                	je     80101521 <ilock+0x3b>
}
8010150d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101510:	5b                   	pop    %ebx
80101511:	5e                   	pop    %esi
80101512:	5d                   	pop    %ebp
80101513:	c3                   	ret    
    panic("ilock");
80101514:	83 ec 0c             	sub    $0xc,%esp
80101517:	68 26 81 10 80       	push   $0x80108126
8010151c:	e8 23 ee ff ff       	call   80100344 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
80101521:	83 ec 08             	sub    $0x8,%esp
80101524:	8b 43 04             	mov    0x4(%ebx),%eax
80101527:	c1 e8 03             	shr    $0x3,%eax
8010152a:	03 05 d4 99 1d 80    	add    0x801d99d4,%eax
80101530:	50                   	push   %eax
80101531:	ff 33                	pushl  (%ebx)
80101533:	e8 72 eb ff ff       	call   801000aa <bread>
80101538:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + ip->inum%IPB;
8010153a:	8b 43 04             	mov    0x4(%ebx),%eax
8010153d:	83 e0 07             	and    $0x7,%eax
80101540:	c1 e0 06             	shl    $0x6,%eax
80101543:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    ip->type = dip->type;
80101547:	0f b7 10             	movzwl (%eax),%edx
8010154a:	66 89 53 50          	mov    %dx,0x50(%ebx)
    ip->major = dip->major;
8010154e:	0f b7 50 02          	movzwl 0x2(%eax),%edx
80101552:	66 89 53 52          	mov    %dx,0x52(%ebx)
    ip->minor = dip->minor;
80101556:	0f b7 50 04          	movzwl 0x4(%eax),%edx
8010155a:	66 89 53 54          	mov    %dx,0x54(%ebx)
    ip->nlink = dip->nlink;
8010155e:	0f b7 50 06          	movzwl 0x6(%eax),%edx
80101562:	66 89 53 56          	mov    %dx,0x56(%ebx)
    ip->size = dip->size;
80101566:	8b 50 08             	mov    0x8(%eax),%edx
80101569:	89 53 58             	mov    %edx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
8010156c:	83 c4 0c             	add    $0xc,%esp
8010156f:	6a 34                	push   $0x34
80101571:	83 c0 0c             	add    $0xc,%eax
80101574:	50                   	push   %eax
80101575:	8d 43 5c             	lea    0x5c(%ebx),%eax
80101578:	50                   	push   %eax
80101579:	e8 91 29 00 00       	call   80103f0f <memmove>
    brelse(bp);
8010157e:	89 34 24             	mov    %esi,(%esp)
80101581:	e8 3b ec ff ff       	call   801001c1 <brelse>
    ip->valid = 1;
80101586:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
8010158d:	83 c4 10             	add    $0x10,%esp
80101590:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
80101595:	0f 85 72 ff ff ff    	jne    8010150d <ilock+0x27>
      panic("ilock: no type");
8010159b:	83 ec 0c             	sub    $0xc,%esp
8010159e:	68 2c 81 10 80       	push   $0x8010812c
801015a3:	e8 9c ed ff ff       	call   80100344 <panic>

801015a8 <iunlock>:
{
801015a8:	55                   	push   %ebp
801015a9:	89 e5                	mov    %esp,%ebp
801015ab:	56                   	push   %esi
801015ac:	53                   	push   %ebx
801015ad:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
801015b0:	85 db                	test   %ebx,%ebx
801015b2:	74 2c                	je     801015e0 <iunlock+0x38>
801015b4:	8d 73 0c             	lea    0xc(%ebx),%esi
801015b7:	83 ec 0c             	sub    $0xc,%esp
801015ba:	56                   	push   %esi
801015bb:	e8 7a 26 00 00       	call   80103c3a <holdingsleep>
801015c0:	83 c4 10             	add    $0x10,%esp
801015c3:	85 c0                	test   %eax,%eax
801015c5:	74 19                	je     801015e0 <iunlock+0x38>
801015c7:	83 7b 08 00          	cmpl   $0x0,0x8(%ebx)
801015cb:	7e 13                	jle    801015e0 <iunlock+0x38>
  releasesleep(&ip->lock);
801015cd:	83 ec 0c             	sub    $0xc,%esp
801015d0:	56                   	push   %esi
801015d1:	e8 29 26 00 00       	call   80103bff <releasesleep>
}
801015d6:	83 c4 10             	add    $0x10,%esp
801015d9:	8d 65 f8             	lea    -0x8(%ebp),%esp
801015dc:	5b                   	pop    %ebx
801015dd:	5e                   	pop    %esi
801015de:	5d                   	pop    %ebp
801015df:	c3                   	ret    
    panic("iunlock");
801015e0:	83 ec 0c             	sub    $0xc,%esp
801015e3:	68 3b 81 10 80       	push   $0x8010813b
801015e8:	e8 57 ed ff ff       	call   80100344 <panic>

801015ed <iput>:
{
801015ed:	55                   	push   %ebp
801015ee:	89 e5                	mov    %esp,%ebp
801015f0:	57                   	push   %edi
801015f1:	56                   	push   %esi
801015f2:	53                   	push   %ebx
801015f3:	83 ec 28             	sub    $0x28,%esp
801015f6:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquiresleep(&ip->lock);
801015f9:	8d 73 0c             	lea    0xc(%ebx),%esi
801015fc:	56                   	push   %esi
801015fd:	e8 ab 25 00 00       	call   80103bad <acquiresleep>
  if(ip->valid && ip->nlink == 0){
80101602:	83 c4 10             	add    $0x10,%esp
80101605:	83 7b 4c 00          	cmpl   $0x0,0x4c(%ebx)
80101609:	74 07                	je     80101612 <iput+0x25>
8010160b:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
80101610:	74 30                	je     80101642 <iput+0x55>
  releasesleep(&ip->lock);
80101612:	83 ec 0c             	sub    $0xc,%esp
80101615:	56                   	push   %esi
80101616:	e8 e4 25 00 00       	call   80103bff <releasesleep>
  acquire(&icache.lock);
8010161b:	c7 04 24 e0 99 1d 80 	movl   $0x801d99e0,(%esp)
80101622:	e8 a5 27 00 00       	call   80103dcc <acquire>
  ip->ref--;
80101627:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
8010162b:	c7 04 24 e0 99 1d 80 	movl   $0x801d99e0,(%esp)
80101632:	e8 fc 27 00 00       	call   80103e33 <release>
}
80101637:	83 c4 10             	add    $0x10,%esp
8010163a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010163d:	5b                   	pop    %ebx
8010163e:	5e                   	pop    %esi
8010163f:	5f                   	pop    %edi
80101640:	5d                   	pop    %ebp
80101641:	c3                   	ret    
    acquire(&icache.lock);
80101642:	83 ec 0c             	sub    $0xc,%esp
80101645:	68 e0 99 1d 80       	push   $0x801d99e0
8010164a:	e8 7d 27 00 00       	call   80103dcc <acquire>
    int r = ip->ref;
8010164f:	8b 7b 08             	mov    0x8(%ebx),%edi
    release(&icache.lock);
80101652:	c7 04 24 e0 99 1d 80 	movl   $0x801d99e0,(%esp)
80101659:	e8 d5 27 00 00       	call   80103e33 <release>
    if(r == 1){
8010165e:	83 c4 10             	add    $0x10,%esp
80101661:	83 ff 01             	cmp    $0x1,%edi
80101664:	75 ac                	jne    80101612 <iput+0x25>
80101666:	8d 7b 5c             	lea    0x5c(%ebx),%edi
80101669:	8d 83 8c 00 00 00    	lea    0x8c(%ebx),%eax
8010166f:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80101672:	89 c6                	mov    %eax,%esi
80101674:	eb 07                	jmp    8010167d <iput+0x90>
80101676:	83 c7 04             	add    $0x4,%edi
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101679:	39 f7                	cmp    %esi,%edi
8010167b:	74 15                	je     80101692 <iput+0xa5>
    if(ip->addrs[i]){
8010167d:	8b 17                	mov    (%edi),%edx
8010167f:	85 d2                	test   %edx,%edx
80101681:	74 f3                	je     80101676 <iput+0x89>
      bfree(ip->dev, ip->addrs[i]);
80101683:	8b 03                	mov    (%ebx),%eax
80101685:	e8 2a f9 ff ff       	call   80100fb4 <bfree>
      ip->addrs[i] = 0;
8010168a:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
80101690:	eb e4                	jmp    80101676 <iput+0x89>
80101692:	8b 75 e4             	mov    -0x1c(%ebp),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80101695:	8b 83 8c 00 00 00    	mov    0x8c(%ebx),%eax
8010169b:	85 c0                	test   %eax,%eax
8010169d:	75 2d                	jne    801016cc <iput+0xdf>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
8010169f:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
801016a6:	83 ec 0c             	sub    $0xc,%esp
801016a9:	53                   	push   %ebx
801016aa:	e8 8d fd ff ff       	call   8010143c <iupdate>
      ip->type = 0;
801016af:	66 c7 43 50 00 00    	movw   $0x0,0x50(%ebx)
      iupdate(ip);
801016b5:	89 1c 24             	mov    %ebx,(%esp)
801016b8:	e8 7f fd ff ff       	call   8010143c <iupdate>
      ip->valid = 0;
801016bd:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
801016c4:	83 c4 10             	add    $0x10,%esp
801016c7:	e9 46 ff ff ff       	jmp    80101612 <iput+0x25>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
801016cc:	83 ec 08             	sub    $0x8,%esp
801016cf:	50                   	push   %eax
801016d0:	ff 33                	pushl  (%ebx)
801016d2:	e8 d3 e9 ff ff       	call   801000aa <bread>
801016d7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    a = (uint*)bp->data;
801016da:	8d 78 5c             	lea    0x5c(%eax),%edi
801016dd:	05 5c 02 00 00       	add    $0x25c,%eax
801016e2:	83 c4 10             	add    $0x10,%esp
801016e5:	89 75 e0             	mov    %esi,-0x20(%ebp)
801016e8:	89 c6                	mov    %eax,%esi
801016ea:	eb 07                	jmp    801016f3 <iput+0x106>
801016ec:	83 c7 04             	add    $0x4,%edi
    for(j = 0; j < NINDIRECT; j++){
801016ef:	39 fe                	cmp    %edi,%esi
801016f1:	74 0f                	je     80101702 <iput+0x115>
      if(a[j])
801016f3:	8b 17                	mov    (%edi),%edx
801016f5:	85 d2                	test   %edx,%edx
801016f7:	74 f3                	je     801016ec <iput+0xff>
        bfree(ip->dev, a[j]);
801016f9:	8b 03                	mov    (%ebx),%eax
801016fb:	e8 b4 f8 ff ff       	call   80100fb4 <bfree>
80101700:	eb ea                	jmp    801016ec <iput+0xff>
80101702:	8b 75 e0             	mov    -0x20(%ebp),%esi
    brelse(bp);
80101705:	83 ec 0c             	sub    $0xc,%esp
80101708:	ff 75 e4             	pushl  -0x1c(%ebp)
8010170b:	e8 b1 ea ff ff       	call   801001c1 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101710:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
80101716:	8b 03                	mov    (%ebx),%eax
80101718:	e8 97 f8 ff ff       	call   80100fb4 <bfree>
    ip->addrs[NDIRECT] = 0;
8010171d:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
80101724:	00 00 00 
80101727:	83 c4 10             	add    $0x10,%esp
8010172a:	e9 70 ff ff ff       	jmp    8010169f <iput+0xb2>

8010172f <iunlockput>:
{
8010172f:	55                   	push   %ebp
80101730:	89 e5                	mov    %esp,%ebp
80101732:	53                   	push   %ebx
80101733:	83 ec 10             	sub    $0x10,%esp
80101736:	8b 5d 08             	mov    0x8(%ebp),%ebx
  iunlock(ip);
80101739:	53                   	push   %ebx
8010173a:	e8 69 fe ff ff       	call   801015a8 <iunlock>
  iput(ip);
8010173f:	89 1c 24             	mov    %ebx,(%esp)
80101742:	e8 a6 fe ff ff       	call   801015ed <iput>
}
80101747:	83 c4 10             	add    $0x10,%esp
8010174a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010174d:	c9                   	leave  
8010174e:	c3                   	ret    

8010174f <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
8010174f:	55                   	push   %ebp
80101750:	89 e5                	mov    %esp,%ebp
80101752:	8b 55 08             	mov    0x8(%ebp),%edx
80101755:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101758:	8b 0a                	mov    (%edx),%ecx
8010175a:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
8010175d:	8b 4a 04             	mov    0x4(%edx),%ecx
80101760:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80101763:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80101767:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
8010176a:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
8010176e:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80101772:	8b 52 58             	mov    0x58(%edx),%edx
80101775:	89 50 10             	mov    %edx,0x10(%eax)
}
80101778:	5d                   	pop    %ebp
80101779:	c3                   	ret    

8010177a <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
8010177a:	55                   	push   %ebp
8010177b:	89 e5                	mov    %esp,%ebp
8010177d:	57                   	push   %edi
8010177e:	56                   	push   %esi
8010177f:	53                   	push   %ebx
80101780:	83 ec 1c             	sub    $0x1c,%esp
80101783:	8b 7d 10             	mov    0x10(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101786:	8b 45 08             	mov    0x8(%ebp),%eax
80101789:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
8010178e:	0f 84 9d 00 00 00    	je     80101831 <readi+0xb7>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80101794:	8b 45 08             	mov    0x8(%ebp),%eax
80101797:	8b 40 58             	mov    0x58(%eax),%eax
8010179a:	39 f8                	cmp    %edi,%eax
8010179c:	0f 82 c6 00 00 00    	jb     80101868 <readi+0xee>
801017a2:	89 fa                	mov    %edi,%edx
801017a4:	03 55 14             	add    0x14(%ebp),%edx
801017a7:	0f 82 c2 00 00 00    	jb     8010186f <readi+0xf5>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
801017ad:	89 c1                	mov    %eax,%ecx
801017af:	29 f9                	sub    %edi,%ecx
801017b1:	39 d0                	cmp    %edx,%eax
801017b3:	0f 43 4d 14          	cmovae 0x14(%ebp),%ecx
801017b7:	89 4d 14             	mov    %ecx,0x14(%ebp)

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
801017ba:	85 c9                	test   %ecx,%ecx
801017bc:	74 68                	je     80101826 <readi+0xac>
801017be:	be 00 00 00 00       	mov    $0x0,%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801017c3:	89 fa                	mov    %edi,%edx
801017c5:	c1 ea 09             	shr    $0x9,%edx
801017c8:	8b 45 08             	mov    0x8(%ebp),%eax
801017cb:	e8 ac f9 ff ff       	call   8010117c <bmap>
801017d0:	83 ec 08             	sub    $0x8,%esp
801017d3:	50                   	push   %eax
801017d4:	8b 45 08             	mov    0x8(%ebp),%eax
801017d7:	ff 30                	pushl  (%eax)
801017d9:	e8 cc e8 ff ff       	call   801000aa <bread>
801017de:	89 c1                	mov    %eax,%ecx
    m = min(n - tot, BSIZE - off%BSIZE);
801017e0:	89 f8                	mov    %edi,%eax
801017e2:	25 ff 01 00 00       	and    $0x1ff,%eax
801017e7:	bb 00 02 00 00       	mov    $0x200,%ebx
801017ec:	29 c3                	sub    %eax,%ebx
801017ee:	8b 55 14             	mov    0x14(%ebp),%edx
801017f1:	29 f2                	sub    %esi,%edx
801017f3:	83 c4 0c             	add    $0xc,%esp
801017f6:	39 d3                	cmp    %edx,%ebx
801017f8:	0f 47 da             	cmova  %edx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
801017fb:	53                   	push   %ebx
801017fc:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
801017ff:	8d 44 01 5c          	lea    0x5c(%ecx,%eax,1),%eax
80101803:	50                   	push   %eax
80101804:	ff 75 0c             	pushl  0xc(%ebp)
80101807:	e8 03 27 00 00       	call   80103f0f <memmove>
    brelse(bp);
8010180c:	83 c4 04             	add    $0x4,%esp
8010180f:	ff 75 e4             	pushl  -0x1c(%ebp)
80101812:	e8 aa e9 ff ff       	call   801001c1 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101817:	01 de                	add    %ebx,%esi
80101819:	01 df                	add    %ebx,%edi
8010181b:	01 5d 0c             	add    %ebx,0xc(%ebp)
8010181e:	83 c4 10             	add    $0x10,%esp
80101821:	39 75 14             	cmp    %esi,0x14(%ebp)
80101824:	77 9d                	ja     801017c3 <readi+0x49>
  }
  return n;
80101826:	8b 45 14             	mov    0x14(%ebp),%eax
}
80101829:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010182c:	5b                   	pop    %ebx
8010182d:	5e                   	pop    %esi
8010182e:	5f                   	pop    %edi
8010182f:	5d                   	pop    %ebp
80101830:	c3                   	ret    
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101831:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101835:	66 83 f8 09          	cmp    $0x9,%ax
80101839:	77 1f                	ja     8010185a <readi+0xe0>
8010183b:	98                   	cwtl   
8010183c:	8b 04 c5 60 99 1d 80 	mov    -0x7fe266a0(,%eax,8),%eax
80101843:	85 c0                	test   %eax,%eax
80101845:	74 1a                	je     80101861 <readi+0xe7>
    return devsw[ip->major].read(ip, dst, n);
80101847:	83 ec 04             	sub    $0x4,%esp
8010184a:	ff 75 14             	pushl  0x14(%ebp)
8010184d:	ff 75 0c             	pushl  0xc(%ebp)
80101850:	ff 75 08             	pushl  0x8(%ebp)
80101853:	ff d0                	call   *%eax
80101855:	83 c4 10             	add    $0x10,%esp
80101858:	eb cf                	jmp    80101829 <readi+0xaf>
      return -1;
8010185a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010185f:	eb c8                	jmp    80101829 <readi+0xaf>
80101861:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101866:	eb c1                	jmp    80101829 <readi+0xaf>
    return -1;
80101868:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010186d:	eb ba                	jmp    80101829 <readi+0xaf>
8010186f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101874:	eb b3                	jmp    80101829 <readi+0xaf>

80101876 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80101876:	55                   	push   %ebp
80101877:	89 e5                	mov    %esp,%ebp
80101879:	57                   	push   %edi
8010187a:	56                   	push   %esi
8010187b:	53                   	push   %ebx
8010187c:	83 ec 1c             	sub    $0x1c,%esp
8010187f:	8b 75 10             	mov    0x10(%ebp),%esi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101882:	8b 45 08             	mov    0x8(%ebp),%eax
80101885:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
8010188a:	0f 84 ae 00 00 00    	je     8010193e <writei+0xc8>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80101890:	8b 45 08             	mov    0x8(%ebp),%eax
80101893:	39 70 58             	cmp    %esi,0x58(%eax)
80101896:	0f 82 ed 00 00 00    	jb     80101989 <writei+0x113>
8010189c:	89 f0                	mov    %esi,%eax
8010189e:	03 45 14             	add    0x14(%ebp),%eax
    return -1;
  if(off + n > MAXFILE*BSIZE)
801018a1:	3d 00 18 01 00       	cmp    $0x11800,%eax
801018a6:	0f 87 e4 00 00 00    	ja     80101990 <writei+0x11a>
801018ac:	39 f0                	cmp    %esi,%eax
801018ae:	0f 82 dc 00 00 00    	jb     80101990 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
801018b4:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
801018b8:	74 79                	je     80101933 <writei+0xbd>
801018ba:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
801018c1:	89 f2                	mov    %esi,%edx
801018c3:	c1 ea 09             	shr    $0x9,%edx
801018c6:	8b 45 08             	mov    0x8(%ebp),%eax
801018c9:	e8 ae f8 ff ff       	call   8010117c <bmap>
801018ce:	83 ec 08             	sub    $0x8,%esp
801018d1:	50                   	push   %eax
801018d2:	8b 45 08             	mov    0x8(%ebp),%eax
801018d5:	ff 30                	pushl  (%eax)
801018d7:	e8 ce e7 ff ff       	call   801000aa <bread>
801018dc:	89 c7                	mov    %eax,%edi
    m = min(n - tot, BSIZE - off%BSIZE);
801018de:	89 f0                	mov    %esi,%eax
801018e0:	25 ff 01 00 00       	and    $0x1ff,%eax
801018e5:	bb 00 02 00 00       	mov    $0x200,%ebx
801018ea:	29 c3                	sub    %eax,%ebx
801018ec:	8b 55 14             	mov    0x14(%ebp),%edx
801018ef:	2b 55 e4             	sub    -0x1c(%ebp),%edx
801018f2:	83 c4 0c             	add    $0xc,%esp
801018f5:	39 d3                	cmp    %edx,%ebx
801018f7:	0f 47 da             	cmova  %edx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
801018fa:	53                   	push   %ebx
801018fb:	ff 75 0c             	pushl  0xc(%ebp)
801018fe:	8d 44 07 5c          	lea    0x5c(%edi,%eax,1),%eax
80101902:	50                   	push   %eax
80101903:	e8 07 26 00 00       	call   80103f0f <memmove>
    log_write(bp);
80101908:	89 3c 24             	mov    %edi,(%esp)
8010190b:	e8 5d 10 00 00       	call   8010296d <log_write>
    brelse(bp);
80101910:	89 3c 24             	mov    %edi,(%esp)
80101913:	e8 a9 e8 ff ff       	call   801001c1 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101918:	01 5d e4             	add    %ebx,-0x1c(%ebp)
8010191b:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010191e:	01 de                	add    %ebx,%esi
80101920:	01 5d 0c             	add    %ebx,0xc(%ebp)
80101923:	83 c4 10             	add    $0x10,%esp
80101926:	39 4d 14             	cmp    %ecx,0x14(%ebp)
80101929:	77 96                	ja     801018c1 <writei+0x4b>
  }

  if(n > 0 && off > ip->size){
8010192b:	8b 45 08             	mov    0x8(%ebp),%eax
8010192e:	39 70 58             	cmp    %esi,0x58(%eax)
80101931:	72 34                	jb     80101967 <writei+0xf1>
    ip->size = off;
    iupdate(ip);
  }
  return n;
80101933:	8b 45 14             	mov    0x14(%ebp),%eax
}
80101936:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101939:	5b                   	pop    %ebx
8010193a:	5e                   	pop    %esi
8010193b:	5f                   	pop    %edi
8010193c:	5d                   	pop    %ebp
8010193d:	c3                   	ret    
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
8010193e:	0f b7 40 52          	movzwl 0x52(%eax),%eax
80101942:	66 83 f8 09          	cmp    $0x9,%ax
80101946:	77 33                	ja     8010197b <writei+0x105>
80101948:	98                   	cwtl   
80101949:	8b 04 c5 64 99 1d 80 	mov    -0x7fe2669c(,%eax,8),%eax
80101950:	85 c0                	test   %eax,%eax
80101952:	74 2e                	je     80101982 <writei+0x10c>
    return devsw[ip->major].write(ip, src, n);
80101954:	83 ec 04             	sub    $0x4,%esp
80101957:	ff 75 14             	pushl  0x14(%ebp)
8010195a:	ff 75 0c             	pushl  0xc(%ebp)
8010195d:	ff 75 08             	pushl  0x8(%ebp)
80101960:	ff d0                	call   *%eax
80101962:	83 c4 10             	add    $0x10,%esp
80101965:	eb cf                	jmp    80101936 <writei+0xc0>
    ip->size = off;
80101967:	8b 45 08             	mov    0x8(%ebp),%eax
8010196a:	89 70 58             	mov    %esi,0x58(%eax)
    iupdate(ip);
8010196d:	83 ec 0c             	sub    $0xc,%esp
80101970:	50                   	push   %eax
80101971:	e8 c6 fa ff ff       	call   8010143c <iupdate>
80101976:	83 c4 10             	add    $0x10,%esp
80101979:	eb b8                	jmp    80101933 <writei+0xbd>
      return -1;
8010197b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101980:	eb b4                	jmp    80101936 <writei+0xc0>
80101982:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101987:	eb ad                	jmp    80101936 <writei+0xc0>
    return -1;
80101989:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010198e:	eb a6                	jmp    80101936 <writei+0xc0>
    return -1;
80101990:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101995:	eb 9f                	jmp    80101936 <writei+0xc0>

80101997 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80101997:	55                   	push   %ebp
80101998:	89 e5                	mov    %esp,%ebp
8010199a:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
8010199d:	6a 0e                	push   $0xe
8010199f:	ff 75 0c             	pushl  0xc(%ebp)
801019a2:	ff 75 08             	pushl  0x8(%ebp)
801019a5:	e8 c4 25 00 00       	call   80103f6e <strncmp>
}
801019aa:	c9                   	leave  
801019ab:	c3                   	ret    

801019ac <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
801019ac:	55                   	push   %ebp
801019ad:	89 e5                	mov    %esp,%ebp
801019af:	57                   	push   %edi
801019b0:	56                   	push   %esi
801019b1:	53                   	push   %ebx
801019b2:	83 ec 1c             	sub    $0x1c,%esp
801019b5:	8b 75 08             	mov    0x8(%ebp),%esi
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
801019b8:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
801019bd:	75 15                	jne    801019d4 <dirlookup+0x28>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
801019bf:	bb 00 00 00 00       	mov    $0x0,%ebx
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801019c4:	8d 7d d8             	lea    -0x28(%ebp),%edi
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
801019c7:	b8 00 00 00 00       	mov    $0x0,%eax
  for(off = 0; off < dp->size; off += sizeof(de)){
801019cc:	83 7e 58 00          	cmpl   $0x0,0x58(%esi)
801019d0:	75 24                	jne    801019f6 <dirlookup+0x4a>
801019d2:	eb 6e                	jmp    80101a42 <dirlookup+0x96>
    panic("dirlookup not DIR");
801019d4:	83 ec 0c             	sub    $0xc,%esp
801019d7:	68 43 81 10 80       	push   $0x80108143
801019dc:	e8 63 e9 ff ff       	call   80100344 <panic>
      panic("dirlookup read");
801019e1:	83 ec 0c             	sub    $0xc,%esp
801019e4:	68 55 81 10 80       	push   $0x80108155
801019e9:	e8 56 e9 ff ff       	call   80100344 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
801019ee:	83 c3 10             	add    $0x10,%ebx
801019f1:	39 5e 58             	cmp    %ebx,0x58(%esi)
801019f4:	76 47                	jbe    80101a3d <dirlookup+0x91>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801019f6:	6a 10                	push   $0x10
801019f8:	53                   	push   %ebx
801019f9:	57                   	push   %edi
801019fa:	56                   	push   %esi
801019fb:	e8 7a fd ff ff       	call   8010177a <readi>
80101a00:	83 c4 10             	add    $0x10,%esp
80101a03:	83 f8 10             	cmp    $0x10,%eax
80101a06:	75 d9                	jne    801019e1 <dirlookup+0x35>
    if(de.inum == 0)
80101a08:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101a0d:	74 df                	je     801019ee <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
80101a0f:	83 ec 08             	sub    $0x8,%esp
80101a12:	8d 45 da             	lea    -0x26(%ebp),%eax
80101a15:	50                   	push   %eax
80101a16:	ff 75 0c             	pushl  0xc(%ebp)
80101a19:	e8 79 ff ff ff       	call   80101997 <namecmp>
80101a1e:	83 c4 10             	add    $0x10,%esp
80101a21:	85 c0                	test   %eax,%eax
80101a23:	75 c9                	jne    801019ee <dirlookup+0x42>
      if(poff)
80101a25:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80101a29:	74 05                	je     80101a30 <dirlookup+0x84>
        *poff = off;
80101a2b:	8b 45 10             	mov    0x10(%ebp),%eax
80101a2e:	89 18                	mov    %ebx,(%eax)
      inum = de.inum;
80101a30:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80101a34:	8b 06                	mov    (%esi),%eax
80101a36:	e8 e6 f7 ff ff       	call   80101221 <iget>
80101a3b:	eb 05                	jmp    80101a42 <dirlookup+0x96>
  return 0;
80101a3d:	b8 00 00 00 00       	mov    $0x0,%eax
}
80101a42:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101a45:	5b                   	pop    %ebx
80101a46:	5e                   	pop    %esi
80101a47:	5f                   	pop    %edi
80101a48:	5d                   	pop    %ebp
80101a49:	c3                   	ret    

80101a4a <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80101a4a:	55                   	push   %ebp
80101a4b:	89 e5                	mov    %esp,%ebp
80101a4d:	57                   	push   %edi
80101a4e:	56                   	push   %esi
80101a4f:	53                   	push   %ebx
80101a50:	83 ec 1c             	sub    $0x1c,%esp
80101a53:	89 c6                	mov    %eax,%esi
80101a55:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101a58:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  struct inode *ip, *next;

  if(*path == '/')
80101a5b:	80 38 2f             	cmpb   $0x2f,(%eax)
80101a5e:	74 1a                	je     80101a7a <namex+0x30>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80101a60:	e8 e8 18 00 00       	call   8010334d <myproc>
80101a65:	83 ec 0c             	sub    $0xc,%esp
80101a68:	ff 70 68             	pushl  0x68(%eax)
80101a6b:	e8 4b fa ff ff       	call   801014bb <idup>
80101a70:	89 c7                	mov    %eax,%edi
80101a72:	83 c4 10             	add    $0x10,%esp
80101a75:	e9 d4 00 00 00       	jmp    80101b4e <namex+0x104>
    ip = iget(ROOTDEV, ROOTINO);
80101a7a:	ba 01 00 00 00       	mov    $0x1,%edx
80101a7f:	b8 01 00 00 00       	mov    $0x1,%eax
80101a84:	e8 98 f7 ff ff       	call   80101221 <iget>
80101a89:	89 c7                	mov    %eax,%edi
80101a8b:	e9 be 00 00 00       	jmp    80101b4e <namex+0x104>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
      iunlockput(ip);
80101a90:	83 ec 0c             	sub    $0xc,%esp
80101a93:	57                   	push   %edi
80101a94:	e8 96 fc ff ff       	call   8010172f <iunlockput>
      return 0;
80101a99:	83 c4 10             	add    $0x10,%esp
80101a9c:	bf 00 00 00 00       	mov    $0x0,%edi
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
80101aa1:	89 f8                	mov    %edi,%eax
80101aa3:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101aa6:	5b                   	pop    %ebx
80101aa7:	5e                   	pop    %esi
80101aa8:	5f                   	pop    %edi
80101aa9:	5d                   	pop    %ebp
80101aaa:	c3                   	ret    
      iunlock(ip);
80101aab:	83 ec 0c             	sub    $0xc,%esp
80101aae:	57                   	push   %edi
80101aaf:	e8 f4 fa ff ff       	call   801015a8 <iunlock>
      return ip;
80101ab4:	83 c4 10             	add    $0x10,%esp
80101ab7:	eb e8                	jmp    80101aa1 <namex+0x57>
      iunlockput(ip);
80101ab9:	83 ec 0c             	sub    $0xc,%esp
80101abc:	57                   	push   %edi
80101abd:	e8 6d fc ff ff       	call   8010172f <iunlockput>
      return 0;
80101ac2:	83 c4 10             	add    $0x10,%esp
80101ac5:	89 f7                	mov    %esi,%edi
80101ac7:	eb d8                	jmp    80101aa1 <namex+0x57>
  while(*path != '/' && *path != 0)
80101ac9:	89 f3                	mov    %esi,%ebx
  len = path - s;
80101acb:	89 d8                	mov    %ebx,%eax
80101acd:	29 f0                	sub    %esi,%eax
80101acf:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if(len >= DIRSIZ)
80101ad2:	83 f8 0d             	cmp    $0xd,%eax
80101ad5:	0f 8e b4 00 00 00    	jle    80101b8f <namex+0x145>
    memmove(name, s, DIRSIZ);
80101adb:	83 ec 04             	sub    $0x4,%esp
80101ade:	6a 0e                	push   $0xe
80101ae0:	56                   	push   %esi
80101ae1:	ff 75 e4             	pushl  -0x1c(%ebp)
80101ae4:	e8 26 24 00 00       	call   80103f0f <memmove>
80101ae9:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101aec:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101aef:	75 08                	jne    80101af9 <namex+0xaf>
    path++;
80101af1:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101af4:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101af7:	74 f8                	je     80101af1 <namex+0xa7>
  while((path = skipelem(path, name)) != 0){
80101af9:	85 db                	test   %ebx,%ebx
80101afb:	0f 84 ad 00 00 00    	je     80101bae <namex+0x164>
    ilock(ip);
80101b01:	83 ec 0c             	sub    $0xc,%esp
80101b04:	57                   	push   %edi
80101b05:	e8 dc f9 ff ff       	call   801014e6 <ilock>
    if(ip->type != T_DIR){
80101b0a:	83 c4 10             	add    $0x10,%esp
80101b0d:	66 83 7f 50 01       	cmpw   $0x1,0x50(%edi)
80101b12:	0f 85 78 ff ff ff    	jne    80101a90 <namex+0x46>
    if(nameiparent && *path == '\0'){
80101b18:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
80101b1c:	74 05                	je     80101b23 <namex+0xd9>
80101b1e:	80 3b 00             	cmpb   $0x0,(%ebx)
80101b21:	74 88                	je     80101aab <namex+0x61>
    if((next = dirlookup(ip, name, 0)) == 0){
80101b23:	83 ec 04             	sub    $0x4,%esp
80101b26:	6a 00                	push   $0x0
80101b28:	ff 75 e4             	pushl  -0x1c(%ebp)
80101b2b:	57                   	push   %edi
80101b2c:	e8 7b fe ff ff       	call   801019ac <dirlookup>
80101b31:	89 c6                	mov    %eax,%esi
80101b33:	83 c4 10             	add    $0x10,%esp
80101b36:	85 c0                	test   %eax,%eax
80101b38:	0f 84 7b ff ff ff    	je     80101ab9 <namex+0x6f>
    iunlockput(ip);
80101b3e:	83 ec 0c             	sub    $0xc,%esp
80101b41:	57                   	push   %edi
80101b42:	e8 e8 fb ff ff       	call   8010172f <iunlockput>
    ip = next;
80101b47:	83 c4 10             	add    $0x10,%esp
80101b4a:	89 f7                	mov    %esi,%edi
80101b4c:	89 de                	mov    %ebx,%esi
  while(*path == '/')
80101b4e:	0f b6 06             	movzbl (%esi),%eax
80101b51:	3c 2f                	cmp    $0x2f,%al
80101b53:	75 0a                	jne    80101b5f <namex+0x115>
    path++;
80101b55:	83 c6 01             	add    $0x1,%esi
  while(*path == '/')
80101b58:	0f b6 06             	movzbl (%esi),%eax
80101b5b:	3c 2f                	cmp    $0x2f,%al
80101b5d:	74 f6                	je     80101b55 <namex+0x10b>
  if(*path == 0)
80101b5f:	84 c0                	test   %al,%al
80101b61:	74 4b                	je     80101bae <namex+0x164>
  while(*path != '/' && *path != 0)
80101b63:	0f b6 06             	movzbl (%esi),%eax
80101b66:	3c 2f                	cmp    $0x2f,%al
80101b68:	0f 84 5b ff ff ff    	je     80101ac9 <namex+0x7f>
80101b6e:	84 c0                	test   %al,%al
80101b70:	0f 84 53 ff ff ff    	je     80101ac9 <namex+0x7f>
80101b76:	89 f3                	mov    %esi,%ebx
    path++;
80101b78:	83 c3 01             	add    $0x1,%ebx
  while(*path != '/' && *path != 0)
80101b7b:	0f b6 03             	movzbl (%ebx),%eax
80101b7e:	3c 2f                	cmp    $0x2f,%al
80101b80:	0f 84 45 ff ff ff    	je     80101acb <namex+0x81>
80101b86:	84 c0                	test   %al,%al
80101b88:	75 ee                	jne    80101b78 <namex+0x12e>
80101b8a:	e9 3c ff ff ff       	jmp    80101acb <namex+0x81>
    memmove(name, s, len);
80101b8f:	83 ec 04             	sub    $0x4,%esp
80101b92:	ff 75 e0             	pushl  -0x20(%ebp)
80101b95:	56                   	push   %esi
80101b96:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101b99:	56                   	push   %esi
80101b9a:	e8 70 23 00 00       	call   80103f0f <memmove>
    name[len] = 0;
80101b9f:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101ba2:	c6 04 0e 00          	movb   $0x0,(%esi,%ecx,1)
80101ba6:	83 c4 10             	add    $0x10,%esp
80101ba9:	e9 3e ff ff ff       	jmp    80101aec <namex+0xa2>
  if(nameiparent){
80101bae:	83 7d dc 00          	cmpl   $0x0,-0x24(%ebp)
80101bb2:	0f 84 e9 fe ff ff    	je     80101aa1 <namex+0x57>
    iput(ip);
80101bb8:	83 ec 0c             	sub    $0xc,%esp
80101bbb:	57                   	push   %edi
80101bbc:	e8 2c fa ff ff       	call   801015ed <iput>
    return 0;
80101bc1:	83 c4 10             	add    $0x10,%esp
80101bc4:	bf 00 00 00 00       	mov    $0x0,%edi
80101bc9:	e9 d3 fe ff ff       	jmp    80101aa1 <namex+0x57>

80101bce <dirlink>:
{
80101bce:	55                   	push   %ebp
80101bcf:	89 e5                	mov    %esp,%ebp
80101bd1:	57                   	push   %edi
80101bd2:	56                   	push   %esi
80101bd3:	53                   	push   %ebx
80101bd4:	83 ec 20             	sub    $0x20,%esp
80101bd7:	8b 75 08             	mov    0x8(%ebp),%esi
  if((ip = dirlookup(dp, name, 0)) != 0){
80101bda:	6a 00                	push   $0x0
80101bdc:	ff 75 0c             	pushl  0xc(%ebp)
80101bdf:	56                   	push   %esi
80101be0:	e8 c7 fd ff ff       	call   801019ac <dirlookup>
80101be5:	83 c4 10             	add    $0x10,%esp
80101be8:	85 c0                	test   %eax,%eax
80101bea:	75 6a                	jne    80101c56 <dirlink+0x88>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101bec:	8b 5e 58             	mov    0x58(%esi),%ebx
80101bef:	85 db                	test   %ebx,%ebx
80101bf1:	74 29                	je     80101c1c <dirlink+0x4e>
80101bf3:	bb 00 00 00 00       	mov    $0x0,%ebx
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101bf8:	8d 7d d8             	lea    -0x28(%ebp),%edi
80101bfb:	6a 10                	push   $0x10
80101bfd:	53                   	push   %ebx
80101bfe:	57                   	push   %edi
80101bff:	56                   	push   %esi
80101c00:	e8 75 fb ff ff       	call   8010177a <readi>
80101c05:	83 c4 10             	add    $0x10,%esp
80101c08:	83 f8 10             	cmp    $0x10,%eax
80101c0b:	75 5c                	jne    80101c69 <dirlink+0x9b>
    if(de.inum == 0)
80101c0d:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101c12:	74 08                	je     80101c1c <dirlink+0x4e>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101c14:	83 c3 10             	add    $0x10,%ebx
80101c17:	3b 5e 58             	cmp    0x58(%esi),%ebx
80101c1a:	72 df                	jb     80101bfb <dirlink+0x2d>
  strncpy(de.name, name, DIRSIZ);
80101c1c:	83 ec 04             	sub    $0x4,%esp
80101c1f:	6a 0e                	push   $0xe
80101c21:	ff 75 0c             	pushl  0xc(%ebp)
80101c24:	8d 7d d8             	lea    -0x28(%ebp),%edi
80101c27:	8d 45 da             	lea    -0x26(%ebp),%eax
80101c2a:	50                   	push   %eax
80101c2b:	e8 8a 23 00 00       	call   80103fba <strncpy>
  de.inum = inum;
80101c30:	8b 45 10             	mov    0x10(%ebp),%eax
80101c33:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101c37:	6a 10                	push   $0x10
80101c39:	53                   	push   %ebx
80101c3a:	57                   	push   %edi
80101c3b:	56                   	push   %esi
80101c3c:	e8 35 fc ff ff       	call   80101876 <writei>
80101c41:	83 c4 20             	add    $0x20,%esp
80101c44:	83 f8 10             	cmp    $0x10,%eax
80101c47:	75 2d                	jne    80101c76 <dirlink+0xa8>
  return 0;
80101c49:	b8 00 00 00 00       	mov    $0x0,%eax
}
80101c4e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c51:	5b                   	pop    %ebx
80101c52:	5e                   	pop    %esi
80101c53:	5f                   	pop    %edi
80101c54:	5d                   	pop    %ebp
80101c55:	c3                   	ret    
    iput(ip);
80101c56:	83 ec 0c             	sub    $0xc,%esp
80101c59:	50                   	push   %eax
80101c5a:	e8 8e f9 ff ff       	call   801015ed <iput>
    return -1;
80101c5f:	83 c4 10             	add    $0x10,%esp
80101c62:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101c67:	eb e5                	jmp    80101c4e <dirlink+0x80>
      panic("dirlink read");
80101c69:	83 ec 0c             	sub    $0xc,%esp
80101c6c:	68 64 81 10 80       	push   $0x80108164
80101c71:	e8 ce e6 ff ff       	call   80100344 <panic>
    panic("dirlink");
80101c76:	83 ec 0c             	sub    $0xc,%esp
80101c79:	68 86 87 10 80       	push   $0x80108786
80101c7e:	e8 c1 e6 ff ff       	call   80100344 <panic>

80101c83 <namei>:

struct inode*
namei(char *path)
{
80101c83:	55                   	push   %ebp
80101c84:	89 e5                	mov    %esp,%ebp
80101c86:	83 ec 18             	sub    $0x18,%esp
  char name[DIRSIZ];
  return namex(path, 0, name);
80101c89:	8d 4d ea             	lea    -0x16(%ebp),%ecx
80101c8c:	ba 00 00 00 00       	mov    $0x0,%edx
80101c91:	8b 45 08             	mov    0x8(%ebp),%eax
80101c94:	e8 b1 fd ff ff       	call   80101a4a <namex>
}
80101c99:	c9                   	leave  
80101c9a:	c3                   	ret    

80101c9b <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
80101c9b:	55                   	push   %ebp
80101c9c:	89 e5                	mov    %esp,%ebp
80101c9e:	83 ec 08             	sub    $0x8,%esp
  return namex(path, 1, name);
80101ca1:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80101ca4:	ba 01 00 00 00       	mov    $0x1,%edx
80101ca9:	8b 45 08             	mov    0x8(%ebp),%eax
80101cac:	e8 99 fd ff ff       	call   80101a4a <namex>
}
80101cb1:	c9                   	leave  
80101cb2:	c3                   	ret    

80101cb3 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
80101cb3:	55                   	push   %ebp
80101cb4:	89 e5                	mov    %esp,%ebp
80101cb6:	56                   	push   %esi
80101cb7:	53                   	push   %ebx
  if(b == 0)
80101cb8:	85 c0                	test   %eax,%eax
80101cba:	0f 84 84 00 00 00    	je     80101d44 <idestart+0x91>
80101cc0:	89 c6                	mov    %eax,%esi
    panic("idestart");
  if(b->blockno >= FSSIZE)
80101cc2:	8b 58 08             	mov    0x8(%eax),%ebx
80101cc5:	81 fb e7 03 00 00    	cmp    $0x3e7,%ebx
80101ccb:	0f 87 80 00 00 00    	ja     80101d51 <idestart+0x9e>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101cd1:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101cd6:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101cd7:	83 e0 c0             	and    $0xffffffc0,%eax
80101cda:	3c 40                	cmp    $0x40,%al
80101cdc:	75 f8                	jne    80101cd6 <idestart+0x23>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101cde:	b8 00 00 00 00       	mov    $0x0,%eax
80101ce3:	ba f6 03 00 00       	mov    $0x3f6,%edx
80101ce8:	ee                   	out    %al,(%dx)
80101ce9:	b8 01 00 00 00       	mov    $0x1,%eax
80101cee:	ba f2 01 00 00       	mov    $0x1f2,%edx
80101cf3:	ee                   	out    %al,(%dx)
80101cf4:	ba f3 01 00 00       	mov    $0x1f3,%edx
80101cf9:	89 d8                	mov    %ebx,%eax
80101cfb:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80101cfc:	89 d8                	mov    %ebx,%eax
80101cfe:	c1 f8 08             	sar    $0x8,%eax
80101d01:	ba f4 01 00 00       	mov    $0x1f4,%edx
80101d06:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
80101d07:	89 d8                	mov    %ebx,%eax
80101d09:	c1 f8 10             	sar    $0x10,%eax
80101d0c:	ba f5 01 00 00       	mov    $0x1f5,%edx
80101d11:	ee                   	out    %al,(%dx)
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
80101d12:	0f b6 46 04          	movzbl 0x4(%esi),%eax
80101d16:	c1 e0 04             	shl    $0x4,%eax
80101d19:	83 e0 10             	and    $0x10,%eax
80101d1c:	83 c8 e0             	or     $0xffffffe0,%eax
80101d1f:	c1 fb 18             	sar    $0x18,%ebx
80101d22:	83 e3 0f             	and    $0xf,%ebx
80101d25:	09 d8                	or     %ebx,%eax
80101d27:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101d2c:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
80101d2d:	f6 06 04             	testb  $0x4,(%esi)
80101d30:	75 2c                	jne    80101d5e <idestart+0xab>
80101d32:	b8 20 00 00 00       	mov    $0x20,%eax
80101d37:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101d3c:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
80101d3d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101d40:	5b                   	pop    %ebx
80101d41:	5e                   	pop    %esi
80101d42:	5d                   	pop    %ebp
80101d43:	c3                   	ret    
    panic("idestart");
80101d44:	83 ec 0c             	sub    $0xc,%esp
80101d47:	68 c7 81 10 80       	push   $0x801081c7
80101d4c:	e8 f3 e5 ff ff       	call   80100344 <panic>
    panic("incorrect blockno");
80101d51:	83 ec 0c             	sub    $0xc,%esp
80101d54:	68 d0 81 10 80       	push   $0x801081d0
80101d59:	e8 e6 e5 ff ff       	call   80100344 <panic>
80101d5e:	b8 30 00 00 00       	mov    $0x30,%eax
80101d63:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101d68:	ee                   	out    %al,(%dx)
    outsl(0x1f0, b->data, BSIZE/4);
80101d69:	83 c6 5c             	add    $0x5c,%esi
  asm volatile("cld; rep outsl" :
80101d6c:	b9 80 00 00 00       	mov    $0x80,%ecx
80101d71:	ba f0 01 00 00       	mov    $0x1f0,%edx
80101d76:	fc                   	cld    
80101d77:	f3 6f                	rep outsl %ds:(%esi),(%dx)
80101d79:	eb c2                	jmp    80101d3d <idestart+0x8a>

80101d7b <ideinit>:
{
80101d7b:	55                   	push   %ebp
80101d7c:	89 e5                	mov    %esp,%ebp
80101d7e:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
80101d81:	68 e2 81 10 80       	push   $0x801081e2
80101d86:	68 80 b5 10 80       	push   $0x8010b580
80101d8b:	e8 f4 1e 00 00       	call   80103c84 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
80101d90:	83 c4 08             	add    $0x8,%esp
80101d93:	a1 00 bd 1d 80       	mov    0x801dbd00,%eax
80101d98:	83 e8 01             	sub    $0x1,%eax
80101d9b:	50                   	push   %eax
80101d9c:	6a 0e                	push   $0xe
80101d9e:	e8 63 02 00 00       	call   80102006 <ioapicenable>
80101da3:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101da6:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101dab:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101dac:	83 e0 c0             	and    $0xffffffc0,%eax
80101daf:	3c 40                	cmp    $0x40,%al
80101db1:	75 f8                	jne    80101dab <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101db3:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
80101db8:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101dbd:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101dbe:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101dc3:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80101dc4:	84 c0                	test   %al,%al
80101dc6:	75 11                	jne    80101dd9 <ideinit+0x5e>
80101dc8:	b9 e7 03 00 00       	mov    $0x3e7,%ecx
80101dcd:	ec                   	in     (%dx),%al
80101dce:	84 c0                	test   %al,%al
80101dd0:	75 07                	jne    80101dd9 <ideinit+0x5e>
  for(i=0; i<1000; i++){
80101dd2:	83 e9 01             	sub    $0x1,%ecx
80101dd5:	75 f6                	jne    80101dcd <ideinit+0x52>
80101dd7:	eb 0a                	jmp    80101de3 <ideinit+0x68>
      havedisk1 = 1;
80101dd9:	c7 05 60 b5 10 80 01 	movl   $0x1,0x8010b560
80101de0:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80101de3:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80101de8:	ba f6 01 00 00       	mov    $0x1f6,%edx
80101ded:	ee                   	out    %al,(%dx)
}
80101dee:	c9                   	leave  
80101def:	c3                   	ret    

80101df0 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80101df0:	55                   	push   %ebp
80101df1:	89 e5                	mov    %esp,%ebp
80101df3:	57                   	push   %edi
80101df4:	53                   	push   %ebx
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80101df5:	83 ec 0c             	sub    $0xc,%esp
80101df8:	68 80 b5 10 80       	push   $0x8010b580
80101dfd:	e8 ca 1f 00 00       	call   80103dcc <acquire>

  if((b = idequeue) == 0){
80101e02:	8b 1d 64 b5 10 80    	mov    0x8010b564,%ebx
80101e08:	83 c4 10             	add    $0x10,%esp
80101e0b:	85 db                	test   %ebx,%ebx
80101e0d:	74 48                	je     80101e57 <ideintr+0x67>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80101e0f:	8b 43 58             	mov    0x58(%ebx),%eax
80101e12:	a3 64 b5 10 80       	mov    %eax,0x8010b564

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80101e17:	f6 03 04             	testb  $0x4,(%ebx)
80101e1a:	74 4d                	je     80101e69 <ideintr+0x79>
    insl(0x1f0, b->data, BSIZE/4);

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
  b->flags &= ~B_DIRTY;
80101e1c:	8b 03                	mov    (%ebx),%eax
80101e1e:	83 e0 fb             	and    $0xfffffffb,%eax
80101e21:	83 c8 02             	or     $0x2,%eax
80101e24:	89 03                	mov    %eax,(%ebx)
  wakeup(b);
80101e26:	83 ec 0c             	sub    $0xc,%esp
80101e29:	53                   	push   %ebx
80101e2a:	e8 4a 1b 00 00       	call   80103979 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
80101e2f:	a1 64 b5 10 80       	mov    0x8010b564,%eax
80101e34:	83 c4 10             	add    $0x10,%esp
80101e37:	85 c0                	test   %eax,%eax
80101e39:	74 05                	je     80101e40 <ideintr+0x50>
    idestart(idequeue);
80101e3b:	e8 73 fe ff ff       	call   80101cb3 <idestart>

  release(&idelock);
80101e40:	83 ec 0c             	sub    $0xc,%esp
80101e43:	68 80 b5 10 80       	push   $0x8010b580
80101e48:	e8 e6 1f 00 00       	call   80103e33 <release>
80101e4d:	83 c4 10             	add    $0x10,%esp
}
80101e50:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101e53:	5b                   	pop    %ebx
80101e54:	5f                   	pop    %edi
80101e55:	5d                   	pop    %ebp
80101e56:	c3                   	ret    
    release(&idelock);
80101e57:	83 ec 0c             	sub    $0xc,%esp
80101e5a:	68 80 b5 10 80       	push   $0x8010b580
80101e5f:	e8 cf 1f 00 00       	call   80103e33 <release>
    return;
80101e64:	83 c4 10             	add    $0x10,%esp
80101e67:	eb e7                	jmp    80101e50 <ideintr+0x60>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80101e69:	ba f7 01 00 00       	mov    $0x1f7,%edx
80101e6e:	ec                   	in     (%dx),%al
80101e6f:	89 c1                	mov    %eax,%ecx
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80101e71:	83 e0 c0             	and    $0xffffffc0,%eax
80101e74:	3c 40                	cmp    $0x40,%al
80101e76:	75 f6                	jne    80101e6e <ideintr+0x7e>
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80101e78:	f6 c1 21             	test   $0x21,%cl
80101e7b:	75 9f                	jne    80101e1c <ideintr+0x2c>
    insl(0x1f0, b->data, BSIZE/4);
80101e7d:	8d 7b 5c             	lea    0x5c(%ebx),%edi
  asm volatile("cld; rep insl" :
80101e80:	b9 80 00 00 00       	mov    $0x80,%ecx
80101e85:	ba f0 01 00 00       	mov    $0x1f0,%edx
80101e8a:	fc                   	cld    
80101e8b:	f3 6d                	rep insl (%dx),%es:(%edi)
80101e8d:	eb 8d                	jmp    80101e1c <ideintr+0x2c>

80101e8f <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
80101e8f:	55                   	push   %ebp
80101e90:	89 e5                	mov    %esp,%ebp
80101e92:	53                   	push   %ebx
80101e93:	83 ec 10             	sub    $0x10,%esp
80101e96:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
80101e99:	8d 43 0c             	lea    0xc(%ebx),%eax
80101e9c:	50                   	push   %eax
80101e9d:	e8 98 1d 00 00       	call   80103c3a <holdingsleep>
80101ea2:	83 c4 10             	add    $0x10,%esp
80101ea5:	85 c0                	test   %eax,%eax
80101ea7:	74 41                	je     80101eea <iderw+0x5b>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
80101ea9:	8b 03                	mov    (%ebx),%eax
80101eab:	83 e0 06             	and    $0x6,%eax
80101eae:	83 f8 02             	cmp    $0x2,%eax
80101eb1:	74 44                	je     80101ef7 <iderw+0x68>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
80101eb3:	83 7b 04 00          	cmpl   $0x0,0x4(%ebx)
80101eb7:	74 09                	je     80101ec2 <iderw+0x33>
80101eb9:	83 3d 60 b5 10 80 00 	cmpl   $0x0,0x8010b560
80101ec0:	74 42                	je     80101f04 <iderw+0x75>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80101ec2:	83 ec 0c             	sub    $0xc,%esp
80101ec5:	68 80 b5 10 80       	push   $0x8010b580
80101eca:	e8 fd 1e 00 00       	call   80103dcc <acquire>

  // Append b to idequeue.
  b->qnext = 0;
80101ecf:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80101ed6:	8b 15 64 b5 10 80    	mov    0x8010b564,%edx
80101edc:	83 c4 10             	add    $0x10,%esp
80101edf:	85 d2                	test   %edx,%edx
80101ee1:	75 30                	jne    80101f13 <iderw+0x84>
80101ee3:	ba 64 b5 10 80       	mov    $0x8010b564,%edx
80101ee8:	eb 33                	jmp    80101f1d <iderw+0x8e>
    panic("iderw: buf not locked");
80101eea:	83 ec 0c             	sub    $0xc,%esp
80101eed:	68 e6 81 10 80       	push   $0x801081e6
80101ef2:	e8 4d e4 ff ff       	call   80100344 <panic>
    panic("iderw: nothing to do");
80101ef7:	83 ec 0c             	sub    $0xc,%esp
80101efa:	68 fc 81 10 80       	push   $0x801081fc
80101eff:	e8 40 e4 ff ff       	call   80100344 <panic>
    panic("iderw: ide disk 1 not present");
80101f04:	83 ec 0c             	sub    $0xc,%esp
80101f07:	68 11 82 10 80       	push   $0x80108211
80101f0c:	e8 33 e4 ff ff       	call   80100344 <panic>
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80101f11:	89 c2                	mov    %eax,%edx
80101f13:	8b 42 58             	mov    0x58(%edx),%eax
80101f16:	85 c0                	test   %eax,%eax
80101f18:	75 f7                	jne    80101f11 <iderw+0x82>
80101f1a:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
80101f1d:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
80101f1f:	39 1d 64 b5 10 80    	cmp    %ebx,0x8010b564
80101f25:	74 3a                	je     80101f61 <iderw+0xd2>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80101f27:	8b 03                	mov    (%ebx),%eax
80101f29:	83 e0 06             	and    $0x6,%eax
80101f2c:	83 f8 02             	cmp    $0x2,%eax
80101f2f:	74 1b                	je     80101f4c <iderw+0xbd>
    sleep(b, &idelock);
80101f31:	83 ec 08             	sub    $0x8,%esp
80101f34:	68 80 b5 10 80       	push   $0x8010b580
80101f39:	53                   	push   %ebx
80101f3a:	e8 ba 18 00 00       	call   801037f9 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80101f3f:	8b 03                	mov    (%ebx),%eax
80101f41:	83 e0 06             	and    $0x6,%eax
80101f44:	83 c4 10             	add    $0x10,%esp
80101f47:	83 f8 02             	cmp    $0x2,%eax
80101f4a:	75 e5                	jne    80101f31 <iderw+0xa2>
  }


  release(&idelock);
80101f4c:	83 ec 0c             	sub    $0xc,%esp
80101f4f:	68 80 b5 10 80       	push   $0x8010b580
80101f54:	e8 da 1e 00 00       	call   80103e33 <release>
}
80101f59:	83 c4 10             	add    $0x10,%esp
80101f5c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101f5f:	c9                   	leave  
80101f60:	c3                   	ret    
    idestart(b);
80101f61:	89 d8                	mov    %ebx,%eax
80101f63:	e8 4b fd ff ff       	call   80101cb3 <idestart>
80101f68:	eb bd                	jmp    80101f27 <iderw+0x98>

80101f6a <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
80101f6a:	55                   	push   %ebp
80101f6b:	89 e5                	mov    %esp,%ebp
80101f6d:	56                   	push   %esi
80101f6e:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
80101f6f:	c7 05 34 b6 1d 80 00 	movl   $0xfec00000,0x801db634
80101f76:	00 c0 fe 
  ioapic->reg = reg;
80101f79:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
80101f80:	00 00 00 
  return ioapic->data;
80101f83:	a1 34 b6 1d 80       	mov    0x801db634,%eax
80101f88:	8b 58 10             	mov    0x10(%eax),%ebx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
80101f8b:	c1 eb 10             	shr    $0x10,%ebx
80101f8e:	0f b6 db             	movzbl %bl,%ebx
  ioapic->reg = reg;
80101f91:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  return ioapic->data;
80101f97:	a1 34 b6 1d 80       	mov    0x801db634,%eax
80101f9c:	8b 40 10             	mov    0x10(%eax),%eax
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
80101f9f:	0f b6 15 60 b7 1d 80 	movzbl 0x801db760,%edx
  id = ioapicread(REG_ID) >> 24;
80101fa6:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80101fa9:	39 c2                	cmp    %eax,%edx
80101fab:	75 47                	jne    80101ff4 <ioapicinit+0x8a>
{
80101fad:	ba 10 00 00 00       	mov    $0x10,%edx
80101fb2:	b8 00 00 00 00       	mov    $0x0,%eax
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
80101fb7:	8d 48 20             	lea    0x20(%eax),%ecx
80101fba:	81 c9 00 00 01 00    	or     $0x10000,%ecx
  ioapic->reg = reg;
80101fc0:	8b 35 34 b6 1d 80    	mov    0x801db634,%esi
80101fc6:	89 16                	mov    %edx,(%esi)
  ioapic->data = data;
80101fc8:	8b 35 34 b6 1d 80    	mov    0x801db634,%esi
80101fce:	89 4e 10             	mov    %ecx,0x10(%esi)
80101fd1:	8d 4a 01             	lea    0x1(%edx),%ecx
  ioapic->reg = reg;
80101fd4:	89 0e                	mov    %ecx,(%esi)
  ioapic->data = data;
80101fd6:	8b 0d 34 b6 1d 80    	mov    0x801db634,%ecx
80101fdc:	c7 41 10 00 00 00 00 	movl   $0x0,0x10(%ecx)
  for(i = 0; i <= maxintr; i++){
80101fe3:	83 c0 01             	add    $0x1,%eax
80101fe6:	83 c2 02             	add    $0x2,%edx
80101fe9:	39 c3                	cmp    %eax,%ebx
80101feb:	7d ca                	jge    80101fb7 <ioapicinit+0x4d>
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
80101fed:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101ff0:	5b                   	pop    %ebx
80101ff1:	5e                   	pop    %esi
80101ff2:	5d                   	pop    %ebp
80101ff3:	c3                   	ret    
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80101ff4:	83 ec 0c             	sub    $0xc,%esp
80101ff7:	68 30 82 10 80       	push   $0x80108230
80101ffc:	e8 e0 e5 ff ff       	call   801005e1 <cprintf>
80102001:	83 c4 10             	add    $0x10,%esp
80102004:	eb a7                	jmp    80101fad <ioapicinit+0x43>

80102006 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102006:	55                   	push   %ebp
80102007:	89 e5                	mov    %esp,%ebp
80102009:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
8010200c:	8d 50 20             	lea    0x20(%eax),%edx
8010200f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102013:	8b 0d 34 b6 1d 80    	mov    0x801db634,%ecx
80102019:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
8010201b:	8b 0d 34 b6 1d 80    	mov    0x801db634,%ecx
80102021:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102024:	8b 55 0c             	mov    0xc(%ebp),%edx
80102027:	c1 e2 18             	shl    $0x18,%edx
8010202a:	83 c0 01             	add    $0x1,%eax
  ioapic->reg = reg;
8010202d:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
8010202f:	a1 34 b6 1d 80       	mov    0x801db634,%eax
80102034:	89 50 10             	mov    %edx,0x10(%eax)
}
80102037:	5d                   	pop    %ebp
80102038:	c3                   	ret    

80102039 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
80102039:	55                   	push   %ebp
8010203a:	89 e5                	mov    %esp,%ebp
8010203c:	53                   	push   %ebx
8010203d:	83 ec 04             	sub    $0x4,%esp
80102040:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
80102043:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
80102049:	75 4c                	jne    80102097 <kfree+0x5e>
8010204b:	81 fb 94 db 1d 80    	cmp    $0x801ddb94,%ebx
80102051:	72 44                	jb     80102097 <kfree+0x5e>
80102053:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80102059:	3d ff ff 4f 00       	cmp    $0x4fffff,%eax
8010205e:	77 37                	ja     80102097 <kfree+0x5e>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
80102060:	83 ec 04             	sub    $0x4,%esp
80102063:	68 00 10 00 00       	push   $0x1000
80102068:	6a 01                	push   $0x1
8010206a:	53                   	push   %ebx
8010206b:	e8 0a 1e 00 00       	call   80103e7a <memset>

  if(kmem.use_lock)
80102070:	83 c4 10             	add    $0x10,%esp
80102073:	83 3d 74 b6 1d 80 00 	cmpl   $0x0,0x801db674
8010207a:	75 28                	jne    801020a4 <kfree+0x6b>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
8010207c:	a1 78 b6 1d 80       	mov    0x801db678,%eax
80102081:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
80102083:	89 1d 78 b6 1d 80    	mov    %ebx,0x801db678
  if(kmem.use_lock)
80102089:	83 3d 74 b6 1d 80 00 	cmpl   $0x0,0x801db674
80102090:	75 24                	jne    801020b6 <kfree+0x7d>
    release(&kmem.lock);
}
80102092:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102095:	c9                   	leave  
80102096:	c3                   	ret    
    panic("kfree");
80102097:	83 ec 0c             	sub    $0xc,%esp
8010209a:	68 62 82 10 80       	push   $0x80108262
8010209f:	e8 a0 e2 ff ff       	call   80100344 <panic>
    acquire(&kmem.lock);
801020a4:	83 ec 0c             	sub    $0xc,%esp
801020a7:	68 40 b6 1d 80       	push   $0x801db640
801020ac:	e8 1b 1d 00 00       	call   80103dcc <acquire>
801020b1:	83 c4 10             	add    $0x10,%esp
801020b4:	eb c6                	jmp    8010207c <kfree+0x43>
    release(&kmem.lock);
801020b6:	83 ec 0c             	sub    $0xc,%esp
801020b9:	68 40 b6 1d 80       	push   $0x801db640
801020be:	e8 70 1d 00 00       	call   80103e33 <release>
801020c3:	83 c4 10             	add    $0x10,%esp
}
801020c6:	eb ca                	jmp    80102092 <kfree+0x59>

801020c8 <freerange>:
{
801020c8:	55                   	push   %ebp
801020c9:	89 e5                	mov    %esp,%ebp
801020cb:	56                   	push   %esi
801020cc:	53                   	push   %ebx
801020cd:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801020d0:	8b 45 08             	mov    0x8(%ebp),%eax
801020d3:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801020d9:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801020df:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801020e5:	39 de                	cmp    %ebx,%esi
801020e7:	72 1c                	jb     80102105 <freerange+0x3d>
    kfree(p);
801020e9:	83 ec 0c             	sub    $0xc,%esp
801020ec:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
801020f2:	50                   	push   %eax
801020f3:	e8 41 ff ff ff       	call   80102039 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801020f8:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801020fe:	83 c4 10             	add    $0x10,%esp
80102101:	39 f3                	cmp    %esi,%ebx
80102103:	76 e4                	jbe    801020e9 <freerange+0x21>
}
80102105:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102108:	5b                   	pop    %ebx
80102109:	5e                   	pop    %esi
8010210a:	5d                   	pop    %ebp
8010210b:	c3                   	ret    

8010210c <kinit1>:
{
8010210c:	55                   	push   %ebp
8010210d:	89 e5                	mov    %esp,%ebp
8010210f:	83 ec 10             	sub    $0x10,%esp
  initlock(&kmem.lock, "kmem");
80102112:	68 68 82 10 80       	push   $0x80108268
80102117:	68 40 b6 1d 80       	push   $0x801db640
8010211c:	e8 63 1b 00 00       	call   80103c84 <initlock>
  kmem.use_lock = 0;
80102121:	c7 05 74 b6 1d 80 00 	movl   $0x0,0x801db674
80102128:	00 00 00 
  freerange(vstart, vend);
8010212b:	83 c4 08             	add    $0x8,%esp
8010212e:	ff 75 0c             	pushl  0xc(%ebp)
80102131:	ff 75 08             	pushl  0x8(%ebp)
80102134:	e8 8f ff ff ff       	call   801020c8 <freerange>
}
80102139:	83 c4 10             	add    $0x10,%esp
8010213c:	c9                   	leave  
8010213d:	c3                   	ret    

8010213e <kinit2>:
{
8010213e:	55                   	push   %ebp
8010213f:	89 e5                	mov    %esp,%ebp
80102141:	83 ec 10             	sub    $0x10,%esp
  freerange(vstart, vend);
80102144:	ff 75 0c             	pushl  0xc(%ebp)
80102147:	ff 75 08             	pushl  0x8(%ebp)
8010214a:	e8 79 ff ff ff       	call   801020c8 <freerange>
  kmem.use_lock = 1;
8010214f:	c7 05 74 b6 1d 80 01 	movl   $0x1,0x801db674
80102156:	00 00 00 
}
80102159:	83 c4 10             	add    $0x10,%esp
8010215c:	c9                   	leave  
8010215d:	c3                   	ret    

8010215e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
8010215e:	55                   	push   %ebp
8010215f:	89 e5                	mov    %esp,%ebp
80102161:	53                   	push   %ebx
80102162:	83 ec 04             	sub    $0x4,%esp
  struct run *r;

  if(kmem.use_lock)
80102165:	83 3d 74 b6 1d 80 00 	cmpl   $0x0,0x801db674
8010216c:	75 21                	jne    8010218f <kalloc+0x31>
    acquire(&kmem.lock);
  r = kmem.freelist;
8010216e:	8b 1d 78 b6 1d 80    	mov    0x801db678,%ebx
  if(r)
80102174:	85 db                	test   %ebx,%ebx
80102176:	74 10                	je     80102188 <kalloc+0x2a>
    kmem.freelist = r->next;
80102178:	8b 03                	mov    (%ebx),%eax
8010217a:	a3 78 b6 1d 80       	mov    %eax,0x801db678
  if(kmem.use_lock)
8010217f:	83 3d 74 b6 1d 80 00 	cmpl   $0x0,0x801db674
80102186:	75 23                	jne    801021ab <kalloc+0x4d>
    release(&kmem.lock);
  return (char*)r;
}
80102188:	89 d8                	mov    %ebx,%eax
8010218a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010218d:	c9                   	leave  
8010218e:	c3                   	ret    
    acquire(&kmem.lock);
8010218f:	83 ec 0c             	sub    $0xc,%esp
80102192:	68 40 b6 1d 80       	push   $0x801db640
80102197:	e8 30 1c 00 00       	call   80103dcc <acquire>
  r = kmem.freelist;
8010219c:	8b 1d 78 b6 1d 80    	mov    0x801db678,%ebx
  if(r)
801021a2:	83 c4 10             	add    $0x10,%esp
801021a5:	85 db                	test   %ebx,%ebx
801021a7:	75 cf                	jne    80102178 <kalloc+0x1a>
801021a9:	eb d4                	jmp    8010217f <kalloc+0x21>
    release(&kmem.lock);
801021ab:	83 ec 0c             	sub    $0xc,%esp
801021ae:	68 40 b6 1d 80       	push   $0x801db640
801021b3:	e8 7b 1c 00 00       	call   80103e33 <release>
801021b8:	83 c4 10             	add    $0x10,%esp
  return (char*)r;
801021bb:	eb cb                	jmp    80102188 <kalloc+0x2a>

801021bd <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801021bd:	ba 64 00 00 00       	mov    $0x64,%edx
801021c2:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
801021c3:	a8 01                	test   $0x1,%al
801021c5:	0f 84 bb 00 00 00    	je     80102286 <kbdgetc+0xc9>
801021cb:	ba 60 00 00 00       	mov    $0x60,%edx
801021d0:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);
801021d1:	0f b6 d0             	movzbl %al,%edx

  if(data == 0xE0){
801021d4:	81 fa e0 00 00 00    	cmp    $0xe0,%edx
801021da:	74 5b                	je     80102237 <kbdgetc+0x7a>
    shift |= E0ESC;
    return 0;
  } else if(data & 0x80){
801021dc:	84 c0                	test   %al,%al
801021de:	78 64                	js     80102244 <kbdgetc+0x87>
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
801021e0:	8b 0d b4 b5 10 80    	mov    0x8010b5b4,%ecx
801021e6:	f6 c1 40             	test   $0x40,%cl
801021e9:	74 0f                	je     801021fa <kbdgetc+0x3d>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
801021eb:	83 c8 80             	or     $0xffffff80,%eax
801021ee:	0f b6 d0             	movzbl %al,%edx
    shift &= ~E0ESC;
801021f1:	83 e1 bf             	and    $0xffffffbf,%ecx
801021f4:	89 0d b4 b5 10 80    	mov    %ecx,0x8010b5b4
  }

  shift |= shiftcode[data];
801021fa:	0f b6 8a a0 83 10 80 	movzbl -0x7fef7c60(%edx),%ecx
80102201:	0b 0d b4 b5 10 80    	or     0x8010b5b4,%ecx
  shift ^= togglecode[data];
80102207:	0f b6 82 a0 82 10 80 	movzbl -0x7fef7d60(%edx),%eax
8010220e:	31 c1                	xor    %eax,%ecx
80102210:	89 0d b4 b5 10 80    	mov    %ecx,0x8010b5b4
  c = charcode[shift & (CTL | SHIFT)][data];
80102216:	89 c8                	mov    %ecx,%eax
80102218:	83 e0 03             	and    $0x3,%eax
8010221b:	8b 04 85 80 82 10 80 	mov    -0x7fef7d80(,%eax,4),%eax
80102222:	0f b6 04 10          	movzbl (%eax,%edx,1),%eax
  if(shift & CAPSLOCK){
80102226:	f6 c1 08             	test   $0x8,%cl
80102229:	74 61                	je     8010228c <kbdgetc+0xcf>
    if('a' <= c && c <= 'z')
8010222b:	8d 50 9f             	lea    -0x61(%eax),%edx
8010222e:	83 fa 19             	cmp    $0x19,%edx
80102231:	77 46                	ja     80102279 <kbdgetc+0xbc>
      c += 'A' - 'a';
80102233:	83 e8 20             	sub    $0x20,%eax
80102236:	c3                   	ret    
    shift |= E0ESC;
80102237:	83 0d b4 b5 10 80 40 	orl    $0x40,0x8010b5b4
    return 0;
8010223e:	b8 00 00 00 00       	mov    $0x0,%eax
80102243:	c3                   	ret    
{
80102244:	55                   	push   %ebp
80102245:	89 e5                	mov    %esp,%ebp
80102247:	53                   	push   %ebx
    data = (shift & E0ESC ? data : data & 0x7F);
80102248:	8b 0d b4 b5 10 80    	mov    0x8010b5b4,%ecx
8010224e:	89 cb                	mov    %ecx,%ebx
80102250:	83 e3 40             	and    $0x40,%ebx
80102253:	83 e0 7f             	and    $0x7f,%eax
80102256:	85 db                	test   %ebx,%ebx
80102258:	0f 44 d0             	cmove  %eax,%edx
    shift &= ~(shiftcode[data] | E0ESC);
8010225b:	0f b6 82 a0 83 10 80 	movzbl -0x7fef7c60(%edx),%eax
80102262:	83 c8 40             	or     $0x40,%eax
80102265:	0f b6 c0             	movzbl %al,%eax
80102268:	f7 d0                	not    %eax
8010226a:	21 c8                	and    %ecx,%eax
8010226c:	a3 b4 b5 10 80       	mov    %eax,0x8010b5b4
    return 0;
80102271:	b8 00 00 00 00       	mov    $0x0,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
80102276:	5b                   	pop    %ebx
80102277:	5d                   	pop    %ebp
80102278:	c3                   	ret    
    else if('A' <= c && c <= 'Z')
80102279:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010227c:	8d 50 20             	lea    0x20(%eax),%edx
8010227f:	83 f9 1a             	cmp    $0x1a,%ecx
80102282:	0f 42 c2             	cmovb  %edx,%eax
  return c;
80102285:	c3                   	ret    
    return -1;
80102286:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010228b:	c3                   	ret    
}
8010228c:	f3 c3                	repz ret 

8010228e <kbdintr>:

void
kbdintr(void)
{
8010228e:	55                   	push   %ebp
8010228f:	89 e5                	mov    %esp,%ebp
80102291:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102294:	68 bd 21 10 80       	push   $0x801021bd
80102299:	e8 9d e4 ff ff       	call   8010073b <consoleintr>
}
8010229e:	83 c4 10             	add    $0x10,%esp
801022a1:	c9                   	leave  
801022a2:	c3                   	ret    

801022a3 <lapicw>:
volatile uint *lapic;  // Initialized in mp.c

//PAGEBREAK!
static void
lapicw(int index, int value)
{
801022a3:	55                   	push   %ebp
801022a4:	89 e5                	mov    %esp,%ebp
  lapic[index] = value;
801022a6:	8b 0d 7c b6 1d 80    	mov    0x801db67c,%ecx
801022ac:	8d 04 81             	lea    (%ecx,%eax,4),%eax
801022af:	89 10                	mov    %edx,(%eax)
  lapic[ID];  // wait for write to finish, by reading
801022b1:	a1 7c b6 1d 80       	mov    0x801db67c,%eax
801022b6:	8b 40 20             	mov    0x20(%eax),%eax
}
801022b9:	5d                   	pop    %ebp
801022ba:	c3                   	ret    

801022bb <fill_rtcdate>:
  return inb(CMOS_RETURN);
}

static void
fill_rtcdate(struct rtcdate *r)
{
801022bb:	55                   	push   %ebp
801022bc:	89 e5                	mov    %esp,%ebp
801022be:	56                   	push   %esi
801022bf:	53                   	push   %ebx
801022c0:	89 c3                	mov    %eax,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022c2:	be 70 00 00 00       	mov    $0x70,%esi
801022c7:	b8 00 00 00 00       	mov    $0x0,%eax
801022cc:	89 f2                	mov    %esi,%edx
801022ce:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022cf:	b9 71 00 00 00       	mov    $0x71,%ecx
801022d4:	89 ca                	mov    %ecx,%edx
801022d6:	ec                   	in     (%dx),%al
  return inb(CMOS_RETURN);
801022d7:	0f b6 c0             	movzbl %al,%eax
801022da:	89 03                	mov    %eax,(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022dc:	b8 02 00 00 00       	mov    $0x2,%eax
801022e1:	89 f2                	mov    %esi,%edx
801022e3:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022e4:	89 ca                	mov    %ecx,%edx
801022e6:	ec                   	in     (%dx),%al
801022e7:	0f b6 c0             	movzbl %al,%eax
801022ea:	89 43 04             	mov    %eax,0x4(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022ed:	b8 04 00 00 00       	mov    $0x4,%eax
801022f2:	89 f2                	mov    %esi,%edx
801022f4:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801022f5:	89 ca                	mov    %ecx,%edx
801022f7:	ec                   	in     (%dx),%al
801022f8:	0f b6 c0             	movzbl %al,%eax
801022fb:	89 43 08             	mov    %eax,0x8(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801022fe:	b8 07 00 00 00       	mov    $0x7,%eax
80102303:	89 f2                	mov    %esi,%edx
80102305:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102306:	89 ca                	mov    %ecx,%edx
80102308:	ec                   	in     (%dx),%al
80102309:	0f b6 c0             	movzbl %al,%eax
8010230c:	89 43 0c             	mov    %eax,0xc(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010230f:	b8 08 00 00 00       	mov    $0x8,%eax
80102314:	89 f2                	mov    %esi,%edx
80102316:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102317:	89 ca                	mov    %ecx,%edx
80102319:	ec                   	in     (%dx),%al
8010231a:	0f b6 c0             	movzbl %al,%eax
8010231d:	89 43 10             	mov    %eax,0x10(%ebx)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102320:	b8 09 00 00 00       	mov    $0x9,%eax
80102325:	89 f2                	mov    %esi,%edx
80102327:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102328:	89 ca                	mov    %ecx,%edx
8010232a:	ec                   	in     (%dx),%al
8010232b:	0f b6 c0             	movzbl %al,%eax
8010232e:	89 43 14             	mov    %eax,0x14(%ebx)
  r->minute = cmos_read(MINS);
  r->hour   = cmos_read(HOURS);
  r->day    = cmos_read(DAY);
  r->month  = cmos_read(MONTH);
  r->year   = cmos_read(YEAR);
}
80102331:	5b                   	pop    %ebx
80102332:	5e                   	pop    %esi
80102333:	5d                   	pop    %ebp
80102334:	c3                   	ret    

80102335 <lapicinit>:
  if(!lapic)
80102335:	83 3d 7c b6 1d 80 00 	cmpl   $0x0,0x801db67c
8010233c:	0f 84 fc 00 00 00    	je     8010243e <lapicinit+0x109>
{
80102342:	55                   	push   %ebp
80102343:	89 e5                	mov    %esp,%ebp
  lapicw(SVR, ENABLE | (T_IRQ0 + IRQ_SPURIOUS));
80102345:	ba 3f 01 00 00       	mov    $0x13f,%edx
8010234a:	b8 3c 00 00 00       	mov    $0x3c,%eax
8010234f:	e8 4f ff ff ff       	call   801022a3 <lapicw>
  lapicw(TDCR, X1);
80102354:	ba 0b 00 00 00       	mov    $0xb,%edx
80102359:	b8 f8 00 00 00       	mov    $0xf8,%eax
8010235e:	e8 40 ff ff ff       	call   801022a3 <lapicw>
  lapicw(TIMER, PERIODIC | (T_IRQ0 + IRQ_TIMER));
80102363:	ba 20 00 02 00       	mov    $0x20020,%edx
80102368:	b8 c8 00 00 00       	mov    $0xc8,%eax
8010236d:	e8 31 ff ff ff       	call   801022a3 <lapicw>
  lapicw(TICR, 10000000);
80102372:	ba 80 96 98 00       	mov    $0x989680,%edx
80102377:	b8 e0 00 00 00       	mov    $0xe0,%eax
8010237c:	e8 22 ff ff ff       	call   801022a3 <lapicw>
  lapicw(LINT0, MASKED);
80102381:	ba 00 00 01 00       	mov    $0x10000,%edx
80102386:	b8 d4 00 00 00       	mov    $0xd4,%eax
8010238b:	e8 13 ff ff ff       	call   801022a3 <lapicw>
  lapicw(LINT1, MASKED);
80102390:	ba 00 00 01 00       	mov    $0x10000,%edx
80102395:	b8 d8 00 00 00       	mov    $0xd8,%eax
8010239a:	e8 04 ff ff ff       	call   801022a3 <lapicw>
  if(((lapic[VER]>>16) & 0xFF) >= 4)
8010239f:	a1 7c b6 1d 80       	mov    0x801db67c,%eax
801023a4:	8b 40 30             	mov    0x30(%eax),%eax
801023a7:	c1 e8 10             	shr    $0x10,%eax
801023aa:	3c 03                	cmp    $0x3,%al
801023ac:	77 7c                	ja     8010242a <lapicinit+0xf5>
  lapicw(ERROR, T_IRQ0 + IRQ_ERROR);
801023ae:	ba 33 00 00 00       	mov    $0x33,%edx
801023b3:	b8 dc 00 00 00       	mov    $0xdc,%eax
801023b8:	e8 e6 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ESR, 0);
801023bd:	ba 00 00 00 00       	mov    $0x0,%edx
801023c2:	b8 a0 00 00 00       	mov    $0xa0,%eax
801023c7:	e8 d7 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ESR, 0);
801023cc:	ba 00 00 00 00       	mov    $0x0,%edx
801023d1:	b8 a0 00 00 00       	mov    $0xa0,%eax
801023d6:	e8 c8 fe ff ff       	call   801022a3 <lapicw>
  lapicw(EOI, 0);
801023db:	ba 00 00 00 00       	mov    $0x0,%edx
801023e0:	b8 2c 00 00 00       	mov    $0x2c,%eax
801023e5:	e8 b9 fe ff ff       	call   801022a3 <lapicw>
  lapicw(ICRHI, 0);
801023ea:	ba 00 00 00 00       	mov    $0x0,%edx
801023ef:	b8 c4 00 00 00       	mov    $0xc4,%eax
801023f4:	e8 aa fe ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, BCAST | INIT | LEVEL);
801023f9:	ba 00 85 08 00       	mov    $0x88500,%edx
801023fe:	b8 c0 00 00 00       	mov    $0xc0,%eax
80102403:	e8 9b fe ff ff       	call   801022a3 <lapicw>
  while(lapic[ICRLO] & DELIVS)
80102408:	8b 15 7c b6 1d 80    	mov    0x801db67c,%edx
8010240e:	8b 82 00 03 00 00    	mov    0x300(%edx),%eax
80102414:	f6 c4 10             	test   $0x10,%ah
80102417:	75 f5                	jne    8010240e <lapicinit+0xd9>
  lapicw(TPR, 0);
80102419:	ba 00 00 00 00       	mov    $0x0,%edx
8010241e:	b8 20 00 00 00       	mov    $0x20,%eax
80102423:	e8 7b fe ff ff       	call   801022a3 <lapicw>
}
80102428:	5d                   	pop    %ebp
80102429:	c3                   	ret    
    lapicw(PCINT, MASKED);
8010242a:	ba 00 00 01 00       	mov    $0x10000,%edx
8010242f:	b8 d0 00 00 00       	mov    $0xd0,%eax
80102434:	e8 6a fe ff ff       	call   801022a3 <lapicw>
80102439:	e9 70 ff ff ff       	jmp    801023ae <lapicinit+0x79>
8010243e:	f3 c3                	repz ret 

80102440 <lapicid>:
{
80102440:	55                   	push   %ebp
80102441:	89 e5                	mov    %esp,%ebp
  if (!lapic)
80102443:	8b 15 7c b6 1d 80    	mov    0x801db67c,%edx
    return 0;
80102449:	b8 00 00 00 00       	mov    $0x0,%eax
  if (!lapic)
8010244e:	85 d2                	test   %edx,%edx
80102450:	74 06                	je     80102458 <lapicid+0x18>
  return lapic[ID] >> 24;
80102452:	8b 42 20             	mov    0x20(%edx),%eax
80102455:	c1 e8 18             	shr    $0x18,%eax
}
80102458:	5d                   	pop    %ebp
80102459:	c3                   	ret    

8010245a <lapiceoi>:
  if(lapic)
8010245a:	83 3d 7c b6 1d 80 00 	cmpl   $0x0,0x801db67c
80102461:	74 14                	je     80102477 <lapiceoi+0x1d>
{
80102463:	55                   	push   %ebp
80102464:	89 e5                	mov    %esp,%ebp
    lapicw(EOI, 0);
80102466:	ba 00 00 00 00       	mov    $0x0,%edx
8010246b:	b8 2c 00 00 00       	mov    $0x2c,%eax
80102470:	e8 2e fe ff ff       	call   801022a3 <lapicw>
}
80102475:	5d                   	pop    %ebp
80102476:	c3                   	ret    
80102477:	f3 c3                	repz ret 

80102479 <microdelay>:
{
80102479:	55                   	push   %ebp
8010247a:	89 e5                	mov    %esp,%ebp
}
8010247c:	5d                   	pop    %ebp
8010247d:	c3                   	ret    

8010247e <lapicstartap>:
{
8010247e:	55                   	push   %ebp
8010247f:	89 e5                	mov    %esp,%ebp
80102481:	56                   	push   %esi
80102482:	53                   	push   %ebx
80102483:	8b 75 08             	mov    0x8(%ebp),%esi
80102486:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102489:	b8 0f 00 00 00       	mov    $0xf,%eax
8010248e:	ba 70 00 00 00       	mov    $0x70,%edx
80102493:	ee                   	out    %al,(%dx)
80102494:	b8 0a 00 00 00       	mov    $0xa,%eax
80102499:	ba 71 00 00 00       	mov    $0x71,%edx
8010249e:	ee                   	out    %al,(%dx)
  wrv[0] = 0;
8010249f:	66 c7 05 67 04 00 80 	movw   $0x0,0x80000467
801024a6:	00 00 
  wrv[1] = addr >> 4;
801024a8:	89 d8                	mov    %ebx,%eax
801024aa:	c1 e8 04             	shr    $0x4,%eax
801024ad:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapicw(ICRHI, apicid<<24);
801024b3:	c1 e6 18             	shl    $0x18,%esi
801024b6:	89 f2                	mov    %esi,%edx
801024b8:	b8 c4 00 00 00       	mov    $0xc4,%eax
801024bd:	e8 e1 fd ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, INIT | LEVEL | ASSERT);
801024c2:	ba 00 c5 00 00       	mov    $0xc500,%edx
801024c7:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024cc:	e8 d2 fd ff ff       	call   801022a3 <lapicw>
  lapicw(ICRLO, INIT | LEVEL);
801024d1:	ba 00 85 00 00       	mov    $0x8500,%edx
801024d6:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024db:	e8 c3 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
801024e0:	c1 eb 0c             	shr    $0xc,%ebx
801024e3:	80 cf 06             	or     $0x6,%bh
    lapicw(ICRHI, apicid<<24);
801024e6:	89 f2                	mov    %esi,%edx
801024e8:	b8 c4 00 00 00       	mov    $0xc4,%eax
801024ed:	e8 b1 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
801024f2:	89 da                	mov    %ebx,%edx
801024f4:	b8 c0 00 00 00       	mov    $0xc0,%eax
801024f9:	e8 a5 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRHI, apicid<<24);
801024fe:	89 f2                	mov    %esi,%edx
80102500:	b8 c4 00 00 00       	mov    $0xc4,%eax
80102505:	e8 99 fd ff ff       	call   801022a3 <lapicw>
    lapicw(ICRLO, STARTUP | (addr>>12));
8010250a:	89 da                	mov    %ebx,%edx
8010250c:	b8 c0 00 00 00       	mov    $0xc0,%eax
80102511:	e8 8d fd ff ff       	call   801022a3 <lapicw>
}
80102516:	5b                   	pop    %ebx
80102517:	5e                   	pop    %esi
80102518:	5d                   	pop    %ebp
80102519:	c3                   	ret    

8010251a <cmostime>:

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
8010251a:	55                   	push   %ebp
8010251b:	89 e5                	mov    %esp,%ebp
8010251d:	57                   	push   %edi
8010251e:	56                   	push   %esi
8010251f:	53                   	push   %ebx
80102520:	83 ec 4c             	sub    $0x4c,%esp
80102523:	8b 7d 08             	mov    0x8(%ebp),%edi
80102526:	b8 0b 00 00 00       	mov    $0xb,%eax
8010252b:	ba 70 00 00 00       	mov    $0x70,%edx
80102530:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102531:	ba 71 00 00 00       	mov    $0x71,%edx
80102536:	ec                   	in     (%dx),%al
80102537:	83 e0 04             	and    $0x4,%eax
8010253a:	88 45 b7             	mov    %al,-0x49(%ebp)

  bcd = (sb & (1 << 2)) == 0;

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
8010253d:	8d 75 d0             	lea    -0x30(%ebp),%esi
80102540:	89 f0                	mov    %esi,%eax
80102542:	e8 74 fd ff ff       	call   801022bb <fill_rtcdate>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102547:	ba 70 00 00 00       	mov    $0x70,%edx
8010254c:	b8 0a 00 00 00       	mov    $0xa,%eax
80102551:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102552:	ba 71 00 00 00       	mov    $0x71,%edx
80102557:	ec                   	in     (%dx),%al
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80102558:	84 c0                	test   %al,%al
8010255a:	78 e4                	js     80102540 <cmostime+0x26>
        continue;
    fill_rtcdate(&t2);
8010255c:	8d 5d b8             	lea    -0x48(%ebp),%ebx
8010255f:	89 d8                	mov    %ebx,%eax
80102561:	e8 55 fd ff ff       	call   801022bb <fill_rtcdate>
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102566:	83 ec 04             	sub    $0x4,%esp
80102569:	6a 18                	push   $0x18
8010256b:	53                   	push   %ebx
8010256c:	56                   	push   %esi
8010256d:	e8 4c 19 00 00       	call   80103ebe <memcmp>
80102572:	83 c4 10             	add    $0x10,%esp
80102575:	85 c0                	test   %eax,%eax
80102577:	75 c7                	jne    80102540 <cmostime+0x26>
      break;
  }

  // convert
  if(bcd) {
80102579:	80 7d b7 00          	cmpb   $0x0,-0x49(%ebp)
8010257d:	75 78                	jne    801025f7 <cmostime+0xdd>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
8010257f:	8b 45 d0             	mov    -0x30(%ebp),%eax
80102582:	89 c2                	mov    %eax,%edx
80102584:	c1 ea 04             	shr    $0x4,%edx
80102587:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010258a:	83 e0 0f             	and    $0xf,%eax
8010258d:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102590:	89 45 d0             	mov    %eax,-0x30(%ebp)
    CONV(minute);
80102593:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80102596:	89 c2                	mov    %eax,%edx
80102598:	c1 ea 04             	shr    $0x4,%edx
8010259b:	8d 14 92             	lea    (%edx,%edx,4),%edx
8010259e:	83 e0 0f             	and    $0xf,%eax
801025a1:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025a4:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    CONV(hour  );
801025a7:	8b 45 d8             	mov    -0x28(%ebp),%eax
801025aa:	89 c2                	mov    %eax,%edx
801025ac:	c1 ea 04             	shr    $0x4,%edx
801025af:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025b2:	83 e0 0f             	and    $0xf,%eax
801025b5:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025b8:	89 45 d8             	mov    %eax,-0x28(%ebp)
    CONV(day   );
801025bb:	8b 45 dc             	mov    -0x24(%ebp),%eax
801025be:	89 c2                	mov    %eax,%edx
801025c0:	c1 ea 04             	shr    $0x4,%edx
801025c3:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025c6:	83 e0 0f             	and    $0xf,%eax
801025c9:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025cc:	89 45 dc             	mov    %eax,-0x24(%ebp)
    CONV(month );
801025cf:	8b 45 e0             	mov    -0x20(%ebp),%eax
801025d2:	89 c2                	mov    %eax,%edx
801025d4:	c1 ea 04             	shr    $0x4,%edx
801025d7:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025da:	83 e0 0f             	and    $0xf,%eax
801025dd:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025e0:	89 45 e0             	mov    %eax,-0x20(%ebp)
    CONV(year  );
801025e3:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801025e6:	89 c2                	mov    %eax,%edx
801025e8:	c1 ea 04             	shr    $0x4,%edx
801025eb:	8d 14 92             	lea    (%edx,%edx,4),%edx
801025ee:	83 e0 0f             	and    $0xf,%eax
801025f1:	8d 04 50             	lea    (%eax,%edx,2),%eax
801025f4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
#undef     CONV
  }

  *r = t1;
801025f7:	8b 45 d0             	mov    -0x30(%ebp),%eax
801025fa:	89 07                	mov    %eax,(%edi)
801025fc:	8b 45 d4             	mov    -0x2c(%ebp),%eax
801025ff:	89 47 04             	mov    %eax,0x4(%edi)
80102602:	8b 45 d8             	mov    -0x28(%ebp),%eax
80102605:	89 47 08             	mov    %eax,0x8(%edi)
80102608:	8b 45 dc             	mov    -0x24(%ebp),%eax
8010260b:	89 47 0c             	mov    %eax,0xc(%edi)
8010260e:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102611:	89 47 10             	mov    %eax,0x10(%edi)
80102614:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80102617:	89 47 14             	mov    %eax,0x14(%edi)
  r->year += 2000;
8010261a:	81 47 14 d0 07 00 00 	addl   $0x7d0,0x14(%edi)
}
80102621:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102624:	5b                   	pop    %ebx
80102625:	5e                   	pop    %esi
80102626:	5f                   	pop    %edi
80102627:	5d                   	pop    %ebp
80102628:	c3                   	ret    

80102629 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80102629:	83 3d c8 b6 1d 80 00 	cmpl   $0x0,0x801db6c8
80102630:	0f 8e 84 00 00 00    	jle    801026ba <install_trans+0x91>
{
80102636:	55                   	push   %ebp
80102637:	89 e5                	mov    %esp,%ebp
80102639:	57                   	push   %edi
8010263a:	56                   	push   %esi
8010263b:	53                   	push   %ebx
8010263c:	83 ec 1c             	sub    $0x1c,%esp
  for (tail = 0; tail < log.lh.n; tail++) {
8010263f:	bb 00 00 00 00       	mov    $0x0,%ebx
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80102644:	be 80 b6 1d 80       	mov    $0x801db680,%esi
80102649:	83 ec 08             	sub    $0x8,%esp
8010264c:	89 d8                	mov    %ebx,%eax
8010264e:	03 46 34             	add    0x34(%esi),%eax
80102651:	83 c0 01             	add    $0x1,%eax
80102654:	50                   	push   %eax
80102655:	ff 76 44             	pushl  0x44(%esi)
80102658:	e8 4d da ff ff       	call   801000aa <bread>
8010265d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102660:	83 c4 08             	add    $0x8,%esp
80102663:	ff 34 9d cc b6 1d 80 	pushl  -0x7fe24934(,%ebx,4)
8010266a:	ff 76 44             	pushl  0x44(%esi)
8010266d:	e8 38 da ff ff       	call   801000aa <bread>
80102672:	89 c7                	mov    %eax,%edi
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102674:	83 c4 0c             	add    $0xc,%esp
80102677:	68 00 02 00 00       	push   $0x200
8010267c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010267f:	83 c0 5c             	add    $0x5c,%eax
80102682:	50                   	push   %eax
80102683:	8d 47 5c             	lea    0x5c(%edi),%eax
80102686:	50                   	push   %eax
80102687:	e8 83 18 00 00       	call   80103f0f <memmove>
    bwrite(dbuf);  // write dst to disk
8010268c:	89 3c 24             	mov    %edi,(%esp)
8010268f:	e8 f2 da ff ff       	call   80100186 <bwrite>
    brelse(lbuf);
80102694:	83 c4 04             	add    $0x4,%esp
80102697:	ff 75 e4             	pushl  -0x1c(%ebp)
8010269a:	e8 22 db ff ff       	call   801001c1 <brelse>
    brelse(dbuf);
8010269f:	89 3c 24             	mov    %edi,(%esp)
801026a2:	e8 1a db ff ff       	call   801001c1 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801026a7:	83 c3 01             	add    $0x1,%ebx
801026aa:	83 c4 10             	add    $0x10,%esp
801026ad:	39 5e 48             	cmp    %ebx,0x48(%esi)
801026b0:	7f 97                	jg     80102649 <install_trans+0x20>
  }
}
801026b2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801026b5:	5b                   	pop    %ebx
801026b6:	5e                   	pop    %esi
801026b7:	5f                   	pop    %edi
801026b8:	5d                   	pop    %ebp
801026b9:	c3                   	ret    
801026ba:	f3 c3                	repz ret 

801026bc <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
801026bc:	55                   	push   %ebp
801026bd:	89 e5                	mov    %esp,%ebp
801026bf:	53                   	push   %ebx
801026c0:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
801026c3:	ff 35 b4 b6 1d 80    	pushl  0x801db6b4
801026c9:	ff 35 c4 b6 1d 80    	pushl  0x801db6c4
801026cf:	e8 d6 d9 ff ff       	call   801000aa <bread>
801026d4:	89 c3                	mov    %eax,%ebx
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
801026d6:	8b 0d c8 b6 1d 80    	mov    0x801db6c8,%ecx
801026dc:	89 48 5c             	mov    %ecx,0x5c(%eax)
  for (i = 0; i < log.lh.n; i++) {
801026df:	83 c4 10             	add    $0x10,%esp
801026e2:	85 c9                	test   %ecx,%ecx
801026e4:	7e 19                	jle    801026ff <write_head+0x43>
801026e6:	c1 e1 02             	shl    $0x2,%ecx
801026e9:	b8 00 00 00 00       	mov    $0x0,%eax
    hb->block[i] = log.lh.block[i];
801026ee:	8b 90 cc b6 1d 80    	mov    -0x7fe24934(%eax),%edx
801026f4:	89 54 03 60          	mov    %edx,0x60(%ebx,%eax,1)
801026f8:	83 c0 04             	add    $0x4,%eax
  for (i = 0; i < log.lh.n; i++) {
801026fb:	39 c8                	cmp    %ecx,%eax
801026fd:	75 ef                	jne    801026ee <write_head+0x32>
  }
  bwrite(buf);
801026ff:	83 ec 0c             	sub    $0xc,%esp
80102702:	53                   	push   %ebx
80102703:	e8 7e da ff ff       	call   80100186 <bwrite>
  brelse(buf);
80102708:	89 1c 24             	mov    %ebx,(%esp)
8010270b:	e8 b1 da ff ff       	call   801001c1 <brelse>
}
80102710:	83 c4 10             	add    $0x10,%esp
80102713:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102716:	c9                   	leave  
80102717:	c3                   	ret    

80102718 <initlog>:
{
80102718:	55                   	push   %ebp
80102719:	89 e5                	mov    %esp,%ebp
8010271b:	53                   	push   %ebx
8010271c:	83 ec 2c             	sub    $0x2c,%esp
8010271f:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
80102722:	68 a0 84 10 80       	push   $0x801084a0
80102727:	68 80 b6 1d 80       	push   $0x801db680
8010272c:	e8 53 15 00 00       	call   80103c84 <initlock>
  readsb(dev, &sb);
80102731:	83 c4 08             	add    $0x8,%esp
80102734:	8d 45 dc             	lea    -0x24(%ebp),%eax
80102737:	50                   	push   %eax
80102738:	53                   	push   %ebx
80102739:	e8 94 eb ff ff       	call   801012d2 <readsb>
  log.start = sb.logstart;
8010273e:	8b 45 ec             	mov    -0x14(%ebp),%eax
80102741:	a3 b4 b6 1d 80       	mov    %eax,0x801db6b4
  log.size = sb.nlog;
80102746:	8b 55 e8             	mov    -0x18(%ebp),%edx
80102749:	89 15 b8 b6 1d 80    	mov    %edx,0x801db6b8
  log.dev = dev;
8010274f:	89 1d c4 b6 1d 80    	mov    %ebx,0x801db6c4
  struct buf *buf = bread(log.dev, log.start);
80102755:	83 c4 08             	add    $0x8,%esp
80102758:	50                   	push   %eax
80102759:	53                   	push   %ebx
8010275a:	e8 4b d9 ff ff       	call   801000aa <bread>
  log.lh.n = lh->n;
8010275f:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102762:	89 1d c8 b6 1d 80    	mov    %ebx,0x801db6c8
  for (i = 0; i < log.lh.n; i++) {
80102768:	83 c4 10             	add    $0x10,%esp
8010276b:	85 db                	test   %ebx,%ebx
8010276d:	7e 19                	jle    80102788 <initlog+0x70>
8010276f:	c1 e3 02             	shl    $0x2,%ebx
80102772:	ba 00 00 00 00       	mov    $0x0,%edx
    log.lh.block[i] = lh->block[i];
80102777:	8b 4c 10 60          	mov    0x60(%eax,%edx,1),%ecx
8010277b:	89 8a cc b6 1d 80    	mov    %ecx,-0x7fe24934(%edx)
80102781:	83 c2 04             	add    $0x4,%edx
  for (i = 0; i < log.lh.n; i++) {
80102784:	39 d3                	cmp    %edx,%ebx
80102786:	75 ef                	jne    80102777 <initlog+0x5f>
  brelse(buf);
80102788:	83 ec 0c             	sub    $0xc,%esp
8010278b:	50                   	push   %eax
8010278c:	e8 30 da ff ff       	call   801001c1 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
80102791:	e8 93 fe ff ff       	call   80102629 <install_trans>
  log.lh.n = 0;
80102796:	c7 05 c8 b6 1d 80 00 	movl   $0x0,0x801db6c8
8010279d:	00 00 00 
  write_head(); // clear the log
801027a0:	e8 17 ff ff ff       	call   801026bc <write_head>
}
801027a5:	83 c4 10             	add    $0x10,%esp
801027a8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801027ab:	c9                   	leave  
801027ac:	c3                   	ret    

801027ad <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
801027ad:	55                   	push   %ebp
801027ae:	89 e5                	mov    %esp,%ebp
801027b0:	53                   	push   %ebx
801027b1:	83 ec 10             	sub    $0x10,%esp
  acquire(&log.lock);
801027b4:	68 80 b6 1d 80       	push   $0x801db680
801027b9:	e8 0e 16 00 00       	call   80103dcc <acquire>
801027be:	83 c4 10             	add    $0x10,%esp
  while(1){
    if(log.committing){
801027c1:	bb 80 b6 1d 80       	mov    $0x801db680,%ebx
801027c6:	eb 15                	jmp    801027dd <begin_op+0x30>
      sleep(&log, &log.lock);
801027c8:	83 ec 08             	sub    $0x8,%esp
801027cb:	68 80 b6 1d 80       	push   $0x801db680
801027d0:	68 80 b6 1d 80       	push   $0x801db680
801027d5:	e8 1f 10 00 00       	call   801037f9 <sleep>
801027da:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
801027dd:	83 7b 40 00          	cmpl   $0x0,0x40(%ebx)
801027e1:	75 e5                	jne    801027c8 <begin_op+0x1b>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
801027e3:	8b 43 3c             	mov    0x3c(%ebx),%eax
801027e6:	83 c0 01             	add    $0x1,%eax
801027e9:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
801027ec:	8b 53 48             	mov    0x48(%ebx),%edx
801027ef:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
801027f2:	83 fa 1e             	cmp    $0x1e,%edx
801027f5:	7e 17                	jle    8010280e <begin_op+0x61>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
801027f7:	83 ec 08             	sub    $0x8,%esp
801027fa:	68 80 b6 1d 80       	push   $0x801db680
801027ff:	68 80 b6 1d 80       	push   $0x801db680
80102804:	e8 f0 0f 00 00       	call   801037f9 <sleep>
80102809:	83 c4 10             	add    $0x10,%esp
8010280c:	eb cf                	jmp    801027dd <begin_op+0x30>
    } else {
      log.outstanding += 1;
8010280e:	a3 bc b6 1d 80       	mov    %eax,0x801db6bc
      release(&log.lock);
80102813:	83 ec 0c             	sub    $0xc,%esp
80102816:	68 80 b6 1d 80       	push   $0x801db680
8010281b:	e8 13 16 00 00       	call   80103e33 <release>
      break;
    }
  }
}
80102820:	83 c4 10             	add    $0x10,%esp
80102823:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102826:	c9                   	leave  
80102827:	c3                   	ret    

80102828 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80102828:	55                   	push   %ebp
80102829:	89 e5                	mov    %esp,%ebp
8010282b:	57                   	push   %edi
8010282c:	56                   	push   %esi
8010282d:	53                   	push   %ebx
8010282e:	83 ec 28             	sub    $0x28,%esp
  int do_commit = 0;

  acquire(&log.lock);
80102831:	68 80 b6 1d 80       	push   $0x801db680
80102836:	e8 91 15 00 00       	call   80103dcc <acquire>
  log.outstanding -= 1;
8010283b:	a1 bc b6 1d 80       	mov    0x801db6bc,%eax
80102840:	8d 58 ff             	lea    -0x1(%eax),%ebx
80102843:	89 1d bc b6 1d 80    	mov    %ebx,0x801db6bc
  if(log.committing)
80102849:	83 c4 10             	add    $0x10,%esp
8010284c:	83 3d c0 b6 1d 80 00 	cmpl   $0x0,0x801db6c0
80102853:	0f 85 e9 00 00 00    	jne    80102942 <end_op+0x11a>
    panic("log.committing");
  if(log.outstanding == 0){
80102859:	85 db                	test   %ebx,%ebx
8010285b:	0f 85 ee 00 00 00    	jne    8010294f <end_op+0x127>
    do_commit = 1;
    log.committing = 1;
80102861:	c7 05 c0 b6 1d 80 01 	movl   $0x1,0x801db6c0
80102868:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
8010286b:	83 ec 0c             	sub    $0xc,%esp
8010286e:	68 80 b6 1d 80       	push   $0x801db680
80102873:	e8 bb 15 00 00       	call   80103e33 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80102878:	83 c4 10             	add    $0x10,%esp
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
8010287b:	be 80 b6 1d 80       	mov    $0x801db680,%esi
  if (log.lh.n > 0) {
80102880:	83 3d c8 b6 1d 80 00 	cmpl   $0x0,0x801db6c8
80102887:	7e 7f                	jle    80102908 <end_op+0xe0>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80102889:	83 ec 08             	sub    $0x8,%esp
8010288c:	89 d8                	mov    %ebx,%eax
8010288e:	03 46 34             	add    0x34(%esi),%eax
80102891:	83 c0 01             	add    $0x1,%eax
80102894:	50                   	push   %eax
80102895:	ff 76 44             	pushl  0x44(%esi)
80102898:	e8 0d d8 ff ff       	call   801000aa <bread>
8010289d:	89 c7                	mov    %eax,%edi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
8010289f:	83 c4 08             	add    $0x8,%esp
801028a2:	ff 34 9d cc b6 1d 80 	pushl  -0x7fe24934(,%ebx,4)
801028a9:	ff 76 44             	pushl  0x44(%esi)
801028ac:	e8 f9 d7 ff ff       	call   801000aa <bread>
    memmove(to->data, from->data, BSIZE);
801028b1:	83 c4 0c             	add    $0xc,%esp
801028b4:	68 00 02 00 00       	push   $0x200
801028b9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801028bc:	83 c0 5c             	add    $0x5c,%eax
801028bf:	50                   	push   %eax
801028c0:	8d 47 5c             	lea    0x5c(%edi),%eax
801028c3:	50                   	push   %eax
801028c4:	e8 46 16 00 00       	call   80103f0f <memmove>
    bwrite(to);  // write the log
801028c9:	89 3c 24             	mov    %edi,(%esp)
801028cc:	e8 b5 d8 ff ff       	call   80100186 <bwrite>
    brelse(from);
801028d1:	83 c4 04             	add    $0x4,%esp
801028d4:	ff 75 e4             	pushl  -0x1c(%ebp)
801028d7:	e8 e5 d8 ff ff       	call   801001c1 <brelse>
    brelse(to);
801028dc:	89 3c 24             	mov    %edi,(%esp)
801028df:	e8 dd d8 ff ff       	call   801001c1 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
801028e4:	83 c3 01             	add    $0x1,%ebx
801028e7:	83 c4 10             	add    $0x10,%esp
801028ea:	3b 5e 48             	cmp    0x48(%esi),%ebx
801028ed:	7c 9a                	jl     80102889 <end_op+0x61>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
801028ef:	e8 c8 fd ff ff       	call   801026bc <write_head>
    install_trans(); // Now install writes to home locations
801028f4:	e8 30 fd ff ff       	call   80102629 <install_trans>
    log.lh.n = 0;
801028f9:	c7 05 c8 b6 1d 80 00 	movl   $0x0,0x801db6c8
80102900:	00 00 00 
    write_head();    // Erase the transaction from the log
80102903:	e8 b4 fd ff ff       	call   801026bc <write_head>
    acquire(&log.lock);
80102908:	83 ec 0c             	sub    $0xc,%esp
8010290b:	68 80 b6 1d 80       	push   $0x801db680
80102910:	e8 b7 14 00 00       	call   80103dcc <acquire>
    log.committing = 0;
80102915:	c7 05 c0 b6 1d 80 00 	movl   $0x0,0x801db6c0
8010291c:	00 00 00 
    wakeup(&log);
8010291f:	c7 04 24 80 b6 1d 80 	movl   $0x801db680,(%esp)
80102926:	e8 4e 10 00 00       	call   80103979 <wakeup>
    release(&log.lock);
8010292b:	c7 04 24 80 b6 1d 80 	movl   $0x801db680,(%esp)
80102932:	e8 fc 14 00 00       	call   80103e33 <release>
80102937:	83 c4 10             	add    $0x10,%esp
}
8010293a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010293d:	5b                   	pop    %ebx
8010293e:	5e                   	pop    %esi
8010293f:	5f                   	pop    %edi
80102940:	5d                   	pop    %ebp
80102941:	c3                   	ret    
    panic("log.committing");
80102942:	83 ec 0c             	sub    $0xc,%esp
80102945:	68 a4 84 10 80       	push   $0x801084a4
8010294a:	e8 f5 d9 ff ff       	call   80100344 <panic>
    wakeup(&log);
8010294f:	83 ec 0c             	sub    $0xc,%esp
80102952:	68 80 b6 1d 80       	push   $0x801db680
80102957:	e8 1d 10 00 00       	call   80103979 <wakeup>
  release(&log.lock);
8010295c:	c7 04 24 80 b6 1d 80 	movl   $0x801db680,(%esp)
80102963:	e8 cb 14 00 00       	call   80103e33 <release>
80102968:	83 c4 10             	add    $0x10,%esp
8010296b:	eb cd                	jmp    8010293a <end_op+0x112>

8010296d <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
8010296d:	55                   	push   %ebp
8010296e:	89 e5                	mov    %esp,%ebp
80102970:	53                   	push   %ebx
80102971:	83 ec 04             	sub    $0x4,%esp
80102974:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80102977:	8b 15 c8 b6 1d 80    	mov    0x801db6c8,%edx
8010297d:	83 fa 1d             	cmp    $0x1d,%edx
80102980:	7f 6b                	jg     801029ed <log_write+0x80>
80102982:	a1 b8 b6 1d 80       	mov    0x801db6b8,%eax
80102987:	83 e8 01             	sub    $0x1,%eax
8010298a:	39 c2                	cmp    %eax,%edx
8010298c:	7d 5f                	jge    801029ed <log_write+0x80>
    panic("too big a transaction");
  if (log.outstanding < 1)
8010298e:	83 3d bc b6 1d 80 00 	cmpl   $0x0,0x801db6bc
80102995:	7e 63                	jle    801029fa <log_write+0x8d>
    panic("log_write outside of trans");

  acquire(&log.lock);
80102997:	83 ec 0c             	sub    $0xc,%esp
8010299a:	68 80 b6 1d 80       	push   $0x801db680
8010299f:	e8 28 14 00 00       	call   80103dcc <acquire>
  for (i = 0; i < log.lh.n; i++) {
801029a4:	8b 15 c8 b6 1d 80    	mov    0x801db6c8,%edx
801029aa:	83 c4 10             	add    $0x10,%esp
801029ad:	85 d2                	test   %edx,%edx
801029af:	7e 56                	jle    80102a07 <log_write+0x9a>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
801029b1:	8b 4b 08             	mov    0x8(%ebx),%ecx
801029b4:	39 0d cc b6 1d 80    	cmp    %ecx,0x801db6cc
801029ba:	74 5b                	je     80102a17 <log_write+0xaa>
  for (i = 0; i < log.lh.n; i++) {
801029bc:	b8 00 00 00 00       	mov    $0x0,%eax
801029c1:	83 c0 01             	add    $0x1,%eax
801029c4:	39 d0                	cmp    %edx,%eax
801029c6:	74 56                	je     80102a1e <log_write+0xb1>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
801029c8:	39 0c 85 cc b6 1d 80 	cmp    %ecx,-0x7fe24934(,%eax,4)
801029cf:	75 f0                	jne    801029c1 <log_write+0x54>
      break;
  }
  log.lh.block[i] = b->blockno;
801029d1:	89 0c 85 cc b6 1d 80 	mov    %ecx,-0x7fe24934(,%eax,4)
  if (i == log.lh.n)
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
801029d8:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
801029db:	83 ec 0c             	sub    $0xc,%esp
801029de:	68 80 b6 1d 80       	push   $0x801db680
801029e3:	e8 4b 14 00 00       	call   80103e33 <release>
}
801029e8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801029eb:	c9                   	leave  
801029ec:	c3                   	ret    
    panic("too big a transaction");
801029ed:	83 ec 0c             	sub    $0xc,%esp
801029f0:	68 b3 84 10 80       	push   $0x801084b3
801029f5:	e8 4a d9 ff ff       	call   80100344 <panic>
    panic("log_write outside of trans");
801029fa:	83 ec 0c             	sub    $0xc,%esp
801029fd:	68 c9 84 10 80       	push   $0x801084c9
80102a02:	e8 3d d9 ff ff       	call   80100344 <panic>
  log.lh.block[i] = b->blockno;
80102a07:	8b 43 08             	mov    0x8(%ebx),%eax
80102a0a:	a3 cc b6 1d 80       	mov    %eax,0x801db6cc
  if (i == log.lh.n)
80102a0f:	85 d2                	test   %edx,%edx
80102a11:	75 c5                	jne    801029d8 <log_write+0x6b>
  for (i = 0; i < log.lh.n; i++) {
80102a13:	89 d0                	mov    %edx,%eax
80102a15:	eb 11                	jmp    80102a28 <log_write+0xbb>
80102a17:	b8 00 00 00 00       	mov    $0x0,%eax
80102a1c:	eb b3                	jmp    801029d1 <log_write+0x64>
  log.lh.block[i] = b->blockno;
80102a1e:	8b 53 08             	mov    0x8(%ebx),%edx
80102a21:	89 14 85 cc b6 1d 80 	mov    %edx,-0x7fe24934(,%eax,4)
    log.lh.n++;
80102a28:	83 c0 01             	add    $0x1,%eax
80102a2b:	a3 c8 b6 1d 80       	mov    %eax,0x801db6c8
80102a30:	eb a6                	jmp    801029d8 <log_write+0x6b>

80102a32 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
80102a32:	55                   	push   %ebp
80102a33:	89 e5                	mov    %esp,%ebp
80102a35:	53                   	push   %ebx
80102a36:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
80102a39:	e8 f4 08 00 00       	call   80103332 <cpuid>
80102a3e:	89 c3                	mov    %eax,%ebx
80102a40:	e8 ed 08 00 00       	call   80103332 <cpuid>
80102a45:	83 ec 04             	sub    $0x4,%esp
80102a48:	53                   	push   %ebx
80102a49:	50                   	push   %eax
80102a4a:	68 e4 84 10 80       	push   $0x801084e4
80102a4f:	e8 8d db ff ff       	call   801005e1 <cprintf>
  idtinit();       // load idt register
80102a54:	e8 61 25 00 00       	call   80104fba <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
80102a59:	e8 5d 08 00 00       	call   801032bb <mycpu>
80102a5e:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
80102a60:	b8 01 00 00 00       	mov    $0x1,%eax
80102a65:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
80102a6c:	e8 5b 0b 00 00       	call   801035cc <scheduler>

80102a71 <mpenter>:
{
80102a71:	55                   	push   %ebp
80102a72:	89 e5                	mov    %esp,%ebp
80102a74:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80102a77:	e8 fe 34 00 00       	call   80105f7a <switchkvm>
  seginit();
80102a7c:	e8 12 34 00 00       	call   80105e93 <seginit>
  lapicinit();
80102a81:	e8 af f8 ff ff       	call   80102335 <lapicinit>
  mpmain();
80102a86:	e8 a7 ff ff ff       	call   80102a32 <mpmain>

80102a8b <main>:
{
80102a8b:	8d 4c 24 04          	lea    0x4(%esp),%ecx
80102a8f:	83 e4 f0             	and    $0xfffffff0,%esp
80102a92:	ff 71 fc             	pushl  -0x4(%ecx)
80102a95:	55                   	push   %ebp
80102a96:	89 e5                	mov    %esp,%ebp
80102a98:	53                   	push   %ebx
80102a99:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
80102a9a:	83 ec 08             	sub    $0x8,%esp
80102a9d:	68 00 00 40 80       	push   $0x80400000
80102aa2:	68 94 db 1d 80       	push   $0x801ddb94
80102aa7:	e8 60 f6 ff ff       	call   8010210c <kinit1>
  kvmalloc();      // kernel page table
80102aac:	e8 4e 39 00 00       	call   801063ff <kvmalloc>
  mpinit();        // detect other processors
80102ab1:	e8 55 01 00 00       	call   80102c0b <mpinit>
  lapicinit();     // interrupt controller
80102ab6:	e8 7a f8 ff ff       	call   80102335 <lapicinit>
  seginit();       // segment descriptors
80102abb:	e8 d3 33 00 00       	call   80105e93 <seginit>
  picinit();       // disable pic
80102ac0:	e8 06 03 00 00       	call   80102dcb <picinit>
  ioapicinit();    // another interrupt controller
80102ac5:	e8 a0 f4 ff ff       	call   80101f6a <ioapicinit>
  consoleinit();   // console hardware
80102aca:	e8 ff dd ff ff       	call   801008ce <consoleinit>
  uartinit();      // serial port
80102acf:	e8 a6 27 00 00       	call   8010527a <uartinit>
  pinit();         // process table
80102ad4:	e8 b4 07 00 00       	call   8010328d <pinit>
  tvinit();        // trap vectors
80102ad9:	e8 51 24 00 00       	call   80104f2f <tvinit>
  binit();         // buffer cache
80102ade:	e8 51 d5 ff ff       	call   80100034 <binit>
  fileinit();      // file table
80102ae3:	e8 78 e1 ff ff       	call   80100c60 <fileinit>
  ideinit();       // disk 
80102ae8:	e8 8e f2 ff ff       	call   80101d7b <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80102aed:	83 c4 0c             	add    $0xc,%esp
80102af0:	68 8a 00 00 00       	push   $0x8a
80102af5:	68 8c b4 10 80       	push   $0x8010b48c
80102afa:	68 00 70 00 80       	push   $0x80007000
80102aff:	e8 0b 14 00 00       	call   80103f0f <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
80102b04:	69 05 00 bd 1d 80 b0 	imul   $0xb0,0x801dbd00,%eax
80102b0b:	00 00 00 
80102b0e:	05 80 b7 1d 80       	add    $0x801db780,%eax
80102b13:	83 c4 10             	add    $0x10,%esp
80102b16:	3d 80 b7 1d 80       	cmp    $0x801db780,%eax
80102b1b:	76 6c                	jbe    80102b89 <main+0xfe>
80102b1d:	bb 80 b7 1d 80       	mov    $0x801db780,%ebx
80102b22:	eb 19                	jmp    80102b3d <main+0xb2>
80102b24:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80102b2a:	69 05 00 bd 1d 80 b0 	imul   $0xb0,0x801dbd00,%eax
80102b31:	00 00 00 
80102b34:	05 80 b7 1d 80       	add    $0x801db780,%eax
80102b39:	39 c3                	cmp    %eax,%ebx
80102b3b:	73 4c                	jae    80102b89 <main+0xfe>
    if(c == mycpu())  // We've started already.
80102b3d:	e8 79 07 00 00       	call   801032bb <mycpu>
80102b42:	39 d8                	cmp    %ebx,%eax
80102b44:	74 de                	je     80102b24 <main+0x99>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80102b46:	e8 13 f6 ff ff       	call   8010215e <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
80102b4b:	05 00 10 00 00       	add    $0x1000,%eax
80102b50:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    *(void(**)(void))(code-8) = mpenter;
80102b55:	c7 05 f8 6f 00 80 71 	movl   $0x80102a71,0x80006ff8
80102b5c:	2a 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80102b5f:	c7 05 f4 6f 00 80 00 	movl   $0x10a000,0x80006ff4
80102b66:	a0 10 00 

    lapicstartap(c->apicid, V2P(code));
80102b69:	83 ec 08             	sub    $0x8,%esp
80102b6c:	68 00 70 00 00       	push   $0x7000
80102b71:	0f b6 03             	movzbl (%ebx),%eax
80102b74:	50                   	push   %eax
80102b75:	e8 04 f9 ff ff       	call   8010247e <lapicstartap>
80102b7a:	83 c4 10             	add    $0x10,%esp

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80102b7d:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
80102b83:	85 c0                	test   %eax,%eax
80102b85:	74 f6                	je     80102b7d <main+0xf2>
80102b87:	eb 9b                	jmp    80102b24 <main+0x99>
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
80102b89:	83 ec 08             	sub    $0x8,%esp
80102b8c:	68 00 00 50 80       	push   $0x80500000
80102b91:	68 00 00 40 80       	push   $0x80400000
80102b96:	e8 a3 f5 ff ff       	call   8010213e <kinit2>
  slabinit ();     // PROJ-SLAB
80102b9b:	e8 a5 3c 00 00       	call   80106845 <slabinit>
  userinit();      // first user process
80102ba0:	e8 cc 07 00 00       	call   80103371 <userinit>
  mpmain();        // finish this processor's setup
80102ba5:	e8 88 fe ff ff       	call   80102a32 <mpmain>

80102baa <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
80102baa:	55                   	push   %ebp
80102bab:	89 e5                	mov    %esp,%ebp
80102bad:	57                   	push   %edi
80102bae:	56                   	push   %esi
80102baf:	53                   	push   %ebx
80102bb0:	83 ec 0c             	sub    $0xc,%esp
  uchar *e, *p, *addr;

  addr = P2V(a);
80102bb3:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
  e = addr+len;
80102bb9:	8d 34 13             	lea    (%ebx,%edx,1),%esi
  for(p = addr; p < e; p += sizeof(struct mp))
80102bbc:	39 f3                	cmp    %esi,%ebx
80102bbe:	72 12                	jb     80102bd2 <mpsearch1+0x28>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
      return (struct mp*)p;
  return 0;
80102bc0:	bb 00 00 00 00       	mov    $0x0,%ebx
80102bc5:	eb 3a                	jmp    80102c01 <mpsearch1+0x57>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80102bc7:	84 c0                	test   %al,%al
80102bc9:	74 36                	je     80102c01 <mpsearch1+0x57>
  for(p = addr; p < e; p += sizeof(struct mp))
80102bcb:	83 c3 10             	add    $0x10,%ebx
80102bce:	39 de                	cmp    %ebx,%esi
80102bd0:	76 2a                	jbe    80102bfc <mpsearch1+0x52>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80102bd2:	83 ec 04             	sub    $0x4,%esp
80102bd5:	6a 04                	push   $0x4
80102bd7:	68 f8 84 10 80       	push   $0x801084f8
80102bdc:	53                   	push   %ebx
80102bdd:	e8 dc 12 00 00       	call   80103ebe <memcmp>
80102be2:	83 c4 10             	add    $0x10,%esp
80102be5:	85 c0                	test   %eax,%eax
80102be7:	75 e2                	jne    80102bcb <mpsearch1+0x21>
80102be9:	89 d9                	mov    %ebx,%ecx
80102beb:	8d 7b 10             	lea    0x10(%ebx),%edi
    sum += addr[i];
80102bee:	0f b6 11             	movzbl (%ecx),%edx
80102bf1:	01 d0                	add    %edx,%eax
80102bf3:	83 c1 01             	add    $0x1,%ecx
  for(i=0; i<len; i++)
80102bf6:	39 f9                	cmp    %edi,%ecx
80102bf8:	75 f4                	jne    80102bee <mpsearch1+0x44>
80102bfa:	eb cb                	jmp    80102bc7 <mpsearch1+0x1d>
  return 0;
80102bfc:	bb 00 00 00 00       	mov    $0x0,%ebx
}
80102c01:	89 d8                	mov    %ebx,%eax
80102c03:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102c06:	5b                   	pop    %ebx
80102c07:	5e                   	pop    %esi
80102c08:	5f                   	pop    %edi
80102c09:	5d                   	pop    %ebp
80102c0a:	c3                   	ret    

80102c0b <mpinit>:
  return conf;
}

void
mpinit(void)
{
80102c0b:	55                   	push   %ebp
80102c0c:	89 e5                	mov    %esp,%ebp
80102c0e:	57                   	push   %edi
80102c0f:	56                   	push   %esi
80102c10:	53                   	push   %ebx
80102c11:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80102c14:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80102c1b:	c1 e0 08             	shl    $0x8,%eax
80102c1e:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80102c25:	09 d0                	or     %edx,%eax
80102c27:	c1 e0 04             	shl    $0x4,%eax
80102c2a:	85 c0                	test   %eax,%eax
80102c2c:	0f 84 b0 00 00 00    	je     80102ce2 <mpinit+0xd7>
    if((mp = mpsearch1(p, 1024)))
80102c32:	ba 00 04 00 00       	mov    $0x400,%edx
80102c37:	e8 6e ff ff ff       	call   80102baa <mpsearch1>
80102c3c:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102c3f:	85 c0                	test   %eax,%eax
80102c41:	0f 84 cb 00 00 00    	je     80102d12 <mpinit+0x107>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80102c47:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102c4a:	8b 58 04             	mov    0x4(%eax),%ebx
80102c4d:	85 db                	test   %ebx,%ebx
80102c4f:	0f 84 d7 00 00 00    	je     80102d2c <mpinit+0x121>
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
80102c55:	8d b3 00 00 00 80    	lea    -0x80000000(%ebx),%esi
  if(memcmp(conf, "PCMP", 4) != 0)
80102c5b:	83 ec 04             	sub    $0x4,%esp
80102c5e:	6a 04                	push   $0x4
80102c60:	68 fd 84 10 80       	push   $0x801084fd
80102c65:	56                   	push   %esi
80102c66:	e8 53 12 00 00       	call   80103ebe <memcmp>
80102c6b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80102c6e:	83 c4 10             	add    $0x10,%esp
80102c71:	85 c0                	test   %eax,%eax
80102c73:	0f 85 b3 00 00 00    	jne    80102d2c <mpinit+0x121>
  if(conf->version != 1 && conf->version != 4)
80102c79:	0f b6 83 06 00 00 80 	movzbl -0x7ffffffa(%ebx),%eax
80102c80:	3c 01                	cmp    $0x1,%al
80102c82:	74 08                	je     80102c8c <mpinit+0x81>
80102c84:	3c 04                	cmp    $0x4,%al
80102c86:	0f 85 a0 00 00 00    	jne    80102d2c <mpinit+0x121>
  if(sum((uchar*)conf, conf->length) != 0)
80102c8c:	0f b7 93 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edx
  for(i=0; i<len; i++)
80102c93:	66 85 d2             	test   %dx,%dx
80102c96:	74 1f                	je     80102cb7 <mpinit+0xac>
80102c98:	89 f0                	mov    %esi,%eax
80102c9a:	0f b7 d2             	movzwl %dx,%edx
80102c9d:	8d bc 13 00 00 00 80 	lea    -0x80000000(%ebx,%edx,1),%edi
  sum = 0;
80102ca4:	8b 55 e4             	mov    -0x1c(%ebp),%edx
    sum += addr[i];
80102ca7:	0f b6 08             	movzbl (%eax),%ecx
80102caa:	01 ca                	add    %ecx,%edx
80102cac:	83 c0 01             	add    $0x1,%eax
  for(i=0; i<len; i++)
80102caf:	39 c7                	cmp    %eax,%edi
80102cb1:	75 f4                	jne    80102ca7 <mpinit+0x9c>
  if(sum((uchar*)conf, conf->length) != 0)
80102cb3:	84 d2                	test   %dl,%dl
80102cb5:	75 75                	jne    80102d2c <mpinit+0x121>
  struct mp *mp;
  struct mpconf *conf;
  struct mpproc *proc;
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
80102cb7:	85 f6                	test   %esi,%esi
80102cb9:	74 71                	je     80102d2c <mpinit+0x121>
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
80102cbb:	8b 83 24 00 00 80    	mov    -0x7fffffdc(%ebx),%eax
80102cc1:	a3 7c b6 1d 80       	mov    %eax,0x801db67c
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102cc6:	8d 83 2c 00 00 80    	lea    -0x7fffffd4(%ebx),%eax
80102ccc:	0f b7 93 04 00 00 80 	movzwl -0x7ffffffc(%ebx),%edx
80102cd3:	01 d6                	add    %edx,%esi
  ismp = 1;
80102cd5:	b9 01 00 00 00       	mov    $0x1,%ecx
    case MPIOINTR:
    case MPLINTR:
      p += 8;
      continue;
    default:
      ismp = 0;
80102cda:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102cdd:	e9 88 00 00 00       	jmp    80102d6a <mpinit+0x15f>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80102ce2:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80102ce9:	c1 e0 08             	shl    $0x8,%eax
80102cec:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
80102cf3:	09 d0                	or     %edx,%eax
80102cf5:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80102cf8:	2d 00 04 00 00       	sub    $0x400,%eax
80102cfd:	ba 00 04 00 00       	mov    $0x400,%edx
80102d02:	e8 a3 fe ff ff       	call   80102baa <mpsearch1>
80102d07:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102d0a:	85 c0                	test   %eax,%eax
80102d0c:	0f 85 35 ff ff ff    	jne    80102c47 <mpinit+0x3c>
  return mpsearch1(0xF0000, 0x10000);
80102d12:	ba 00 00 01 00       	mov    $0x10000,%edx
80102d17:	b8 00 00 0f 00       	mov    $0xf0000,%eax
80102d1c:	e8 89 fe ff ff       	call   80102baa <mpsearch1>
80102d21:	89 45 e0             	mov    %eax,-0x20(%ebp)
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
80102d24:	85 c0                	test   %eax,%eax
80102d26:	0f 85 1b ff ff ff    	jne    80102c47 <mpinit+0x3c>
    panic("Expect to run on an SMP");
80102d2c:	83 ec 0c             	sub    $0xc,%esp
80102d2f:	68 02 85 10 80       	push   $0x80108502
80102d34:	e8 0b d6 ff ff       	call   80100344 <panic>
      ismp = 0;
80102d39:	89 f9                	mov    %edi,%ecx
80102d3b:	eb 34                	jmp    80102d71 <mpinit+0x166>
      if(ncpu < NCPU) {
80102d3d:	8b 15 00 bd 1d 80    	mov    0x801dbd00,%edx
80102d43:	83 fa 07             	cmp    $0x7,%edx
80102d46:	7f 1f                	jg     80102d67 <mpinit+0x15c>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
80102d48:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80102d4b:	69 da b0 00 00 00    	imul   $0xb0,%edx,%ebx
80102d51:	0f b6 50 01          	movzbl 0x1(%eax),%edx
80102d55:	88 93 80 b7 1d 80    	mov    %dl,-0x7fe24880(%ebx)
        ncpu++;
80102d5b:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80102d5e:	83 c2 01             	add    $0x1,%edx
80102d61:	89 15 00 bd 1d 80    	mov    %edx,0x801dbd00
      p += sizeof(struct mpproc);
80102d67:	83 c0 14             	add    $0x14,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80102d6a:	39 f0                	cmp    %esi,%eax
80102d6c:	73 26                	jae    80102d94 <mpinit+0x189>
    switch(*p){
80102d6e:	0f b6 10             	movzbl (%eax),%edx
80102d71:	80 fa 04             	cmp    $0x4,%dl
80102d74:	77 c3                	ja     80102d39 <mpinit+0x12e>
80102d76:	0f b6 d2             	movzbl %dl,%edx
80102d79:	ff 24 95 3c 85 10 80 	jmp    *-0x7fef7ac4(,%edx,4)
      ioapicid = ioapic->apicno;
80102d80:	0f b6 50 01          	movzbl 0x1(%eax),%edx
80102d84:	88 15 60 b7 1d 80    	mov    %dl,0x801db760
      p += sizeof(struct mpioapic);
80102d8a:	83 c0 08             	add    $0x8,%eax
      continue;
80102d8d:	eb db                	jmp    80102d6a <mpinit+0x15f>
      p += 8;
80102d8f:	83 c0 08             	add    $0x8,%eax
      continue;
80102d92:	eb d6                	jmp    80102d6a <mpinit+0x15f>
      break;
    }
  }
  if(!ismp)
80102d94:	85 c9                	test   %ecx,%ecx
80102d96:	74 26                	je     80102dbe <mpinit+0x1b3>
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
80102d98:	8b 45 e0             	mov    -0x20(%ebp),%eax
80102d9b:	80 78 0c 00          	cmpb   $0x0,0xc(%eax)
80102d9f:	74 15                	je     80102db6 <mpinit+0x1ab>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102da1:	b8 70 00 00 00       	mov    $0x70,%eax
80102da6:	ba 22 00 00 00       	mov    $0x22,%edx
80102dab:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102dac:	ba 23 00 00 00       	mov    $0x23,%edx
80102db1:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
80102db2:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102db5:	ee                   	out    %al,(%dx)
  }
}
80102db6:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102db9:	5b                   	pop    %ebx
80102dba:	5e                   	pop    %esi
80102dbb:	5f                   	pop    %edi
80102dbc:	5d                   	pop    %ebp
80102dbd:	c3                   	ret    
    panic("Didn't find a suitable machine");
80102dbe:	83 ec 0c             	sub    $0xc,%esp
80102dc1:	68 1c 85 10 80       	push   $0x8010851c
80102dc6:	e8 79 d5 ff ff       	call   80100344 <panic>

80102dcb <picinit>:
#define IO_PIC2         0xA0    // Slave (IRQs 8-15)

// Don't use the 8259A interrupt controllers.  Xv6 assumes SMP hardware.
void
picinit(void)
{
80102dcb:	55                   	push   %ebp
80102dcc:	89 e5                	mov    %esp,%ebp
80102dce:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102dd3:	ba 21 00 00 00       	mov    $0x21,%edx
80102dd8:	ee                   	out    %al,(%dx)
80102dd9:	ba a1 00 00 00       	mov    $0xa1,%edx
80102dde:	ee                   	out    %al,(%dx)
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80102ddf:	5d                   	pop    %ebp
80102de0:	c3                   	ret    

80102de1 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80102de1:	55                   	push   %ebp
80102de2:	89 e5                	mov    %esp,%ebp
80102de4:	57                   	push   %edi
80102de5:	56                   	push   %esi
80102de6:	53                   	push   %ebx
80102de7:	83 ec 0c             	sub    $0xc,%esp
80102dea:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102ded:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
80102df0:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80102df6:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
80102dfc:	e8 79 de ff ff       	call   80100c7a <filealloc>
80102e01:	89 03                	mov    %eax,(%ebx)
80102e03:	85 c0                	test   %eax,%eax
80102e05:	0f 84 a9 00 00 00    	je     80102eb4 <pipealloc+0xd3>
80102e0b:	e8 6a de ff ff       	call   80100c7a <filealloc>
80102e10:	89 06                	mov    %eax,(%esi)
80102e12:	85 c0                	test   %eax,%eax
80102e14:	0f 84 88 00 00 00    	je     80102ea2 <pipealloc+0xc1>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
80102e1a:	e8 3f f3 ff ff       	call   8010215e <kalloc>
80102e1f:	89 c7                	mov    %eax,%edi
80102e21:	85 c0                	test   %eax,%eax
80102e23:	75 0b                	jne    80102e30 <pipealloc+0x4f>

//PAGEBREAK: 20
 bad:
  if(p)
    kfree((char*)p);
  if(*f0)
80102e25:	8b 03                	mov    (%ebx),%eax
80102e27:	85 c0                	test   %eax,%eax
80102e29:	75 7d                	jne    80102ea8 <pipealloc+0xc7>
80102e2b:	e9 84 00 00 00       	jmp    80102eb4 <pipealloc+0xd3>
  p->readopen = 1;
80102e30:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
80102e37:	00 00 00 
  p->writeopen = 1;
80102e3a:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
80102e41:	00 00 00 
  p->nwrite = 0;
80102e44:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
80102e4b:	00 00 00 
  p->nread = 0;
80102e4e:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
80102e55:	00 00 00 
  initlock(&p->lock, "pipe");
80102e58:	83 ec 08             	sub    $0x8,%esp
80102e5b:	68 50 85 10 80       	push   $0x80108550
80102e60:	50                   	push   %eax
80102e61:	e8 1e 0e 00 00       	call   80103c84 <initlock>
  (*f0)->type = FD_PIPE;
80102e66:	8b 03                	mov    (%ebx),%eax
80102e68:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80102e6e:	8b 03                	mov    (%ebx),%eax
80102e70:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
80102e74:	8b 03                	mov    (%ebx),%eax
80102e76:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80102e7a:	8b 03                	mov    (%ebx),%eax
80102e7c:	89 78 0c             	mov    %edi,0xc(%eax)
  (*f1)->type = FD_PIPE;
80102e7f:	8b 06                	mov    (%esi),%eax
80102e81:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80102e87:	8b 06                	mov    (%esi),%eax
80102e89:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80102e8d:	8b 06                	mov    (%esi),%eax
80102e8f:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
80102e93:	8b 06                	mov    (%esi),%eax
80102e95:	89 78 0c             	mov    %edi,0xc(%eax)
  return 0;
80102e98:	83 c4 10             	add    $0x10,%esp
80102e9b:	b8 00 00 00 00       	mov    $0x0,%eax
80102ea0:	eb 2e                	jmp    80102ed0 <pipealloc+0xef>
  if(*f0)
80102ea2:	8b 03                	mov    (%ebx),%eax
80102ea4:	85 c0                	test   %eax,%eax
80102ea6:	74 30                	je     80102ed8 <pipealloc+0xf7>
    fileclose(*f0);
80102ea8:	83 ec 0c             	sub    $0xc,%esp
80102eab:	50                   	push   %eax
80102eac:	e8 7b de ff ff       	call   80100d2c <fileclose>
80102eb1:	83 c4 10             	add    $0x10,%esp
  if(*f1)
80102eb4:	8b 16                	mov    (%esi),%edx
    fileclose(*f1);
  return -1;
80102eb6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  if(*f1)
80102ebb:	85 d2                	test   %edx,%edx
80102ebd:	74 11                	je     80102ed0 <pipealloc+0xef>
    fileclose(*f1);
80102ebf:	83 ec 0c             	sub    $0xc,%esp
80102ec2:	52                   	push   %edx
80102ec3:	e8 64 de ff ff       	call   80100d2c <fileclose>
80102ec8:	83 c4 10             	add    $0x10,%esp
  return -1;
80102ecb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80102ed0:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102ed3:	5b                   	pop    %ebx
80102ed4:	5e                   	pop    %esi
80102ed5:	5f                   	pop    %edi
80102ed6:	5d                   	pop    %ebp
80102ed7:	c3                   	ret    
  return -1;
80102ed8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102edd:	eb f1                	jmp    80102ed0 <pipealloc+0xef>

80102edf <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80102edf:	55                   	push   %ebp
80102ee0:	89 e5                	mov    %esp,%ebp
80102ee2:	53                   	push   %ebx
80102ee3:	83 ec 10             	sub    $0x10,%esp
80102ee6:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&p->lock);
80102ee9:	53                   	push   %ebx
80102eea:	e8 dd 0e 00 00       	call   80103dcc <acquire>
  if(writable){
80102eef:	83 c4 10             	add    $0x10,%esp
80102ef2:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
80102ef6:	74 3f                	je     80102f37 <pipeclose+0x58>
    p->writeopen = 0;
80102ef8:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
80102eff:	00 00 00 
    wakeup(&p->nread);
80102f02:	83 ec 0c             	sub    $0xc,%esp
80102f05:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80102f0b:	50                   	push   %eax
80102f0c:	e8 68 0a 00 00       	call   80103979 <wakeup>
80102f11:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
80102f14:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80102f1b:	75 09                	jne    80102f26 <pipeclose+0x47>
80102f1d:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
80102f24:	74 2f                	je     80102f55 <pipeclose+0x76>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
80102f26:	83 ec 0c             	sub    $0xc,%esp
80102f29:	53                   	push   %ebx
80102f2a:	e8 04 0f 00 00       	call   80103e33 <release>
80102f2f:	83 c4 10             	add    $0x10,%esp
}
80102f32:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102f35:	c9                   	leave  
80102f36:	c3                   	ret    
    p->readopen = 0;
80102f37:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80102f3e:	00 00 00 
    wakeup(&p->nwrite);
80102f41:	83 ec 0c             	sub    $0xc,%esp
80102f44:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
80102f4a:	50                   	push   %eax
80102f4b:	e8 29 0a 00 00       	call   80103979 <wakeup>
80102f50:	83 c4 10             	add    $0x10,%esp
80102f53:	eb bf                	jmp    80102f14 <pipeclose+0x35>
    release(&p->lock);
80102f55:	83 ec 0c             	sub    $0xc,%esp
80102f58:	53                   	push   %ebx
80102f59:	e8 d5 0e 00 00       	call   80103e33 <release>
    kfree((char*)p);
80102f5e:	89 1c 24             	mov    %ebx,(%esp)
80102f61:	e8 d3 f0 ff ff       	call   80102039 <kfree>
80102f66:	83 c4 10             	add    $0x10,%esp
80102f69:	eb c7                	jmp    80102f32 <pipeclose+0x53>

80102f6b <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80102f6b:	55                   	push   %ebp
80102f6c:	89 e5                	mov    %esp,%ebp
80102f6e:	57                   	push   %edi
80102f6f:	56                   	push   %esi
80102f70:	53                   	push   %ebx
80102f71:	83 ec 28             	sub    $0x28,%esp
80102f74:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102f77:	8b 75 0c             	mov    0xc(%ebp),%esi
  int i;

  acquire(&p->lock);
80102f7a:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80102f7d:	53                   	push   %ebx
80102f7e:	e8 49 0e 00 00       	call   80103dcc <acquire>
  for(i = 0; i < n; i++){
80102f83:	83 c4 10             	add    $0x10,%esp
80102f86:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80102f8a:	0f 8e b5 00 00 00    	jle    80103045 <pipewrite+0xda>
80102f90:	89 75 e0             	mov    %esi,-0x20(%ebp)
80102f93:	03 75 10             	add    0x10(%ebp),%esi
80102f96:	89 75 dc             	mov    %esi,-0x24(%ebp)
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80102f99:	8d bb 34 02 00 00    	lea    0x234(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80102f9f:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80102fa5:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80102fab:	05 00 02 00 00       	add    $0x200,%eax
80102fb0:	39 c2                	cmp    %eax,%edx
80102fb2:	75 69                	jne    8010301d <pipewrite+0xb2>
      if(p->readopen == 0 || myproc()->killed){
80102fb4:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80102fbb:	74 47                	je     80103004 <pipewrite+0x99>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80102fbd:	8d b3 38 02 00 00    	lea    0x238(%ebx),%esi
      if(p->readopen == 0 || myproc()->killed){
80102fc3:	e8 85 03 00 00       	call   8010334d <myproc>
80102fc8:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80102fcc:	75 36                	jne    80103004 <pipewrite+0x99>
      wakeup(&p->nread);
80102fce:	83 ec 0c             	sub    $0xc,%esp
80102fd1:	57                   	push   %edi
80102fd2:	e8 a2 09 00 00       	call   80103979 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80102fd7:	83 c4 08             	add    $0x8,%esp
80102fda:	ff 75 e4             	pushl  -0x1c(%ebp)
80102fdd:	56                   	push   %esi
80102fde:	e8 16 08 00 00       	call   801037f9 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80102fe3:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
80102fe9:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80102fef:	05 00 02 00 00       	add    $0x200,%eax
80102ff4:	83 c4 10             	add    $0x10,%esp
80102ff7:	39 c2                	cmp    %eax,%edx
80102ff9:	75 22                	jne    8010301d <pipewrite+0xb2>
      if(p->readopen == 0 || myproc()->killed){
80102ffb:	83 bb 3c 02 00 00 00 	cmpl   $0x0,0x23c(%ebx)
80103002:	75 bf                	jne    80102fc3 <pipewrite+0x58>
        release(&p->lock);
80103004:	83 ec 0c             	sub    $0xc,%esp
80103007:	53                   	push   %ebx
80103008:	e8 26 0e 00 00       	call   80103e33 <release>
        return -1;
8010300d:	83 c4 10             	add    $0x10,%esp
80103010:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
80103015:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103018:	5b                   	pop    %ebx
80103019:	5e                   	pop    %esi
8010301a:	5f                   	pop    %edi
8010301b:	5d                   	pop    %ebp
8010301c:	c3                   	ret    
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
8010301d:	8d 42 01             	lea    0x1(%edx),%eax
80103020:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
80103026:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80103029:	0f b6 01             	movzbl (%ecx),%eax
8010302c:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
80103032:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
80103036:	83 c1 01             	add    $0x1,%ecx
80103039:	89 4d e0             	mov    %ecx,-0x20(%ebp)
  for(i = 0; i < n; i++){
8010303c:	3b 4d dc             	cmp    -0x24(%ebp),%ecx
8010303f:	0f 85 5a ff ff ff    	jne    80102f9f <pipewrite+0x34>
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
80103045:	83 ec 0c             	sub    $0xc,%esp
80103048:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
8010304e:	50                   	push   %eax
8010304f:	e8 25 09 00 00       	call   80103979 <wakeup>
  release(&p->lock);
80103054:	89 1c 24             	mov    %ebx,(%esp)
80103057:	e8 d7 0d 00 00       	call   80103e33 <release>
  return n;
8010305c:	83 c4 10             	add    $0x10,%esp
8010305f:	8b 45 10             	mov    0x10(%ebp),%eax
80103062:	eb b1                	jmp    80103015 <pipewrite+0xaa>

80103064 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
80103064:	55                   	push   %ebp
80103065:	89 e5                	mov    %esp,%ebp
80103067:	57                   	push   %edi
80103068:	56                   	push   %esi
80103069:	53                   	push   %ebx
8010306a:	83 ec 18             	sub    $0x18,%esp
8010306d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int i;

  acquire(&p->lock);
80103070:	53                   	push   %ebx
80103071:	e8 56 0d 00 00       	call   80103dcc <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
80103076:	83 c4 10             	add    $0x10,%esp
80103079:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
8010307f:	39 83 34 02 00 00    	cmp    %eax,0x234(%ebx)
80103085:	75 7c                	jne    80103103 <piperead+0x9f>
80103087:	89 de                	mov    %ebx,%esi
80103089:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
80103090:	74 35                	je     801030c7 <piperead+0x63>
    if(myproc()->killed){
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80103092:	8d bb 34 02 00 00    	lea    0x234(%ebx),%edi
    if(myproc()->killed){
80103098:	e8 b0 02 00 00       	call   8010334d <myproc>
8010309d:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
801030a1:	75 4d                	jne    801030f0 <piperead+0x8c>
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
801030a3:	83 ec 08             	sub    $0x8,%esp
801030a6:	56                   	push   %esi
801030a7:	57                   	push   %edi
801030a8:	e8 4c 07 00 00       	call   801037f9 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
801030ad:	83 c4 10             	add    $0x10,%esp
801030b0:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
801030b6:	39 83 34 02 00 00    	cmp    %eax,0x234(%ebx)
801030bc:	75 45                	jne    80103103 <piperead+0x9f>
801030be:	83 bb 40 02 00 00 00 	cmpl   $0x0,0x240(%ebx)
801030c5:	75 d1                	jne    80103098 <piperead+0x34>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801030c7:	be 00 00 00 00       	mov    $0x0,%esi
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
801030cc:	83 ec 0c             	sub    $0xc,%esp
801030cf:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
801030d5:	50                   	push   %eax
801030d6:	e8 9e 08 00 00       	call   80103979 <wakeup>
  release(&p->lock);
801030db:	89 1c 24             	mov    %ebx,(%esp)
801030de:	e8 50 0d 00 00       	call   80103e33 <release>
  return i;
801030e3:	83 c4 10             	add    $0x10,%esp
}
801030e6:	89 f0                	mov    %esi,%eax
801030e8:	8d 65 f4             	lea    -0xc(%ebp),%esp
801030eb:	5b                   	pop    %ebx
801030ec:	5e                   	pop    %esi
801030ed:	5f                   	pop    %edi
801030ee:	5d                   	pop    %ebp
801030ef:	c3                   	ret    
      release(&p->lock);
801030f0:	83 ec 0c             	sub    $0xc,%esp
801030f3:	53                   	push   %ebx
801030f4:	e8 3a 0d 00 00       	call   80103e33 <release>
      return -1;
801030f9:	83 c4 10             	add    $0x10,%esp
801030fc:	be ff ff ff ff       	mov    $0xffffffff,%esi
80103101:	eb e3                	jmp    801030e6 <piperead+0x82>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103103:	83 7d 10 00          	cmpl   $0x0,0x10(%ebp)
80103107:	7e 3c                	jle    80103145 <piperead+0xe1>
    if(p->nread == p->nwrite)
80103109:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
8010310f:	be 00 00 00 00       	mov    $0x0,%esi
    addr[i] = p->data[p->nread++ % PIPESIZE];
80103114:	8d 50 01             	lea    0x1(%eax),%edx
80103117:	89 93 34 02 00 00    	mov    %edx,0x234(%ebx)
8010311d:	25 ff 01 00 00       	and    $0x1ff,%eax
80103122:	0f b6 44 03 34       	movzbl 0x34(%ebx,%eax,1),%eax
80103127:	8b 4d 0c             	mov    0xc(%ebp),%ecx
8010312a:	88 04 31             	mov    %al,(%ecx,%esi,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
8010312d:	83 c6 01             	add    $0x1,%esi
80103130:	39 75 10             	cmp    %esi,0x10(%ebp)
80103133:	74 97                	je     801030cc <piperead+0x68>
    if(p->nread == p->nwrite)
80103135:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
8010313b:	3b 83 38 02 00 00    	cmp    0x238(%ebx),%eax
80103141:	75 d1                	jne    80103114 <piperead+0xb0>
80103143:	eb 87                	jmp    801030cc <piperead+0x68>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103145:	be 00 00 00 00       	mov    $0x0,%esi
8010314a:	eb 80                	jmp    801030cc <piperead+0x68>

8010314c <wakeup1>:
//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
8010314c:	55                   	push   %ebp
8010314d:	89 e5                	mov    %esp,%ebp
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
8010314f:	ba 54 bd 1d 80       	mov    $0x801dbd54,%edx
80103154:	eb 0e                	jmp    80103164 <wakeup1+0x18>
80103156:	81 c2 84 00 00 00    	add    $0x84,%edx
8010315c:	81 fa 94 c5 1d 80    	cmp    $0x801dc594,%edx
80103162:	73 14                	jae    80103178 <wakeup1+0x2c>
    if(p->state == SLEEPING && p->chan == chan)
80103164:	83 7a 0c 02          	cmpl   $0x2,0xc(%edx)
80103168:	75 ec                	jne    80103156 <wakeup1+0xa>
8010316a:	39 42 20             	cmp    %eax,0x20(%edx)
8010316d:	75 e7                	jne    80103156 <wakeup1+0xa>
      p->state = RUNNABLE;
8010316f:	c7 42 0c 03 00 00 00 	movl   $0x3,0xc(%edx)
80103176:	eb de                	jmp    80103156 <wakeup1+0xa>
}
80103178:	5d                   	pop    %ebp
80103179:	c3                   	ret    

8010317a <allocproc>:
{
8010317a:	55                   	push   %ebp
8010317b:	89 e5                	mov    %esp,%ebp
8010317d:	53                   	push   %ebx
8010317e:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
80103181:	68 20 bd 1d 80       	push   $0x801dbd20
80103186:	e8 41 0c 00 00       	call   80103dcc <acquire>
    if(p->state == UNUSED)
8010318b:	83 c4 10             	add    $0x10,%esp
8010318e:	83 3d 60 bd 1d 80 00 	cmpl   $0x0,0x801dbd60
80103195:	74 30                	je     801031c7 <allocproc+0x4d>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103197:	bb d8 bd 1d 80       	mov    $0x801dbdd8,%ebx
    if(p->state == UNUSED)
8010319c:	83 7b 0c 00          	cmpl   $0x0,0xc(%ebx)
801031a0:	74 2a                	je     801031cc <allocproc+0x52>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801031a2:	81 c3 84 00 00 00    	add    $0x84,%ebx
801031a8:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
801031ae:	72 ec                	jb     8010319c <allocproc+0x22>
  release(&ptable.lock);
801031b0:	83 ec 0c             	sub    $0xc,%esp
801031b3:	68 20 bd 1d 80       	push   $0x801dbd20
801031b8:	e8 76 0c 00 00       	call   80103e33 <release>
  return 0;
801031bd:	83 c4 10             	add    $0x10,%esp
801031c0:	bb 00 00 00 00       	mov    $0x0,%ebx
801031c5:	eb 6e                	jmp    80103235 <allocproc+0xbb>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801031c7:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
  p->state = EMBRYO;
801031cc:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->pid = nextpid++;
801031d3:	a1 04 b0 10 80       	mov    0x8010b004,%eax
801031d8:	8d 50 01             	lea    0x1(%eax),%edx
801031db:	89 15 04 b0 10 80    	mov    %edx,0x8010b004
801031e1:	89 43 10             	mov    %eax,0x10(%ebx)
  release(&ptable.lock);
801031e4:	83 ec 0c             	sub    $0xc,%esp
801031e7:	68 20 bd 1d 80       	push   $0x801dbd20
801031ec:	e8 42 0c 00 00       	call   80103e33 <release>
  if((p->kstack = kalloc()) == 0){
801031f1:	e8 68 ef ff ff       	call   8010215e <kalloc>
801031f6:	89 43 08             	mov    %eax,0x8(%ebx)
801031f9:	83 c4 10             	add    $0x10,%esp
801031fc:	85 c0                	test   %eax,%eax
801031fe:	74 3c                	je     8010323c <allocproc+0xc2>
  sp -= sizeof *p->tf;
80103200:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
80103206:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
80103209:	c7 80 b0 0f 00 00 24 	movl   $0x80104f24,0xfb0(%eax)
80103210:	4f 10 80 
  sp -= sizeof *p->context;
80103213:	05 9c 0f 00 00       	add    $0xf9c,%eax
  p->context = (struct context*)sp;
80103218:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
8010321b:	83 ec 04             	sub    $0x4,%esp
8010321e:	6a 14                	push   $0x14
80103220:	6a 00                	push   $0x0
80103222:	50                   	push   %eax
80103223:	e8 52 0c 00 00       	call   80103e7a <memset>
  p->context->eip = (uint)forkret;
80103228:	8b 43 1c             	mov    0x1c(%ebx),%eax
8010322b:	c7 40 10 4a 32 10 80 	movl   $0x8010324a,0x10(%eax)
  return p;
80103232:	83 c4 10             	add    $0x10,%esp
}
80103235:	89 d8                	mov    %ebx,%eax
80103237:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010323a:	c9                   	leave  
8010323b:	c3                   	ret    
    p->state = UNUSED;
8010323c:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return 0;
80103243:	bb 00 00 00 00       	mov    $0x0,%ebx
80103248:	eb eb                	jmp    80103235 <allocproc+0xbb>

8010324a <forkret>:
{
8010324a:	55                   	push   %ebp
8010324b:	89 e5                	mov    %esp,%ebp
8010324d:	83 ec 14             	sub    $0x14,%esp
  release(&ptable.lock);
80103250:	68 20 bd 1d 80       	push   $0x801dbd20
80103255:	e8 d9 0b 00 00       	call   80103e33 <release>
  if (first) {
8010325a:	83 c4 10             	add    $0x10,%esp
8010325d:	83 3d 00 b0 10 80 00 	cmpl   $0x0,0x8010b000
80103264:	75 02                	jne    80103268 <forkret+0x1e>
}
80103266:	c9                   	leave  
80103267:	c3                   	ret    
    first = 0;
80103268:	c7 05 00 b0 10 80 00 	movl   $0x0,0x8010b000
8010326f:	00 00 00 
    iinit(ROOTDEV);
80103272:	83 ec 0c             	sub    $0xc,%esp
80103275:	6a 01                	push   $0x1
80103277:	e8 8a e0 ff ff       	call   80101306 <iinit>
    initlog(ROOTDEV);
8010327c:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
80103283:	e8 90 f4 ff ff       	call   80102718 <initlog>
80103288:	83 c4 10             	add    $0x10,%esp
}
8010328b:	eb d9                	jmp    80103266 <forkret+0x1c>

8010328d <pinit>:
{
8010328d:	55                   	push   %ebp
8010328e:	89 e5                	mov    %esp,%ebp
80103290:	83 ec 0c             	sub    $0xc,%esp
  memset(ptable.proc, 0, sizeof *ptable.proc);
80103293:	68 84 00 00 00       	push   $0x84
80103298:	6a 00                	push   $0x0
8010329a:	68 54 bd 1d 80       	push   $0x801dbd54
8010329f:	e8 d6 0b 00 00       	call   80103e7a <memset>
  initlock(&ptable.lock, "ptable");
801032a4:	83 c4 08             	add    $0x8,%esp
801032a7:	68 55 85 10 80       	push   $0x80108555
801032ac:	68 20 bd 1d 80       	push   $0x801dbd20
801032b1:	e8 ce 09 00 00       	call   80103c84 <initlock>
}
801032b6:	83 c4 10             	add    $0x10,%esp
801032b9:	c9                   	leave  
801032ba:	c3                   	ret    

801032bb <mycpu>:
{
801032bb:	55                   	push   %ebp
801032bc:	89 e5                	mov    %esp,%ebp
801032be:	56                   	push   %esi
801032bf:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
801032c0:	9c                   	pushf  
801032c1:	58                   	pop    %eax
  if(readeflags()&FL_IF)
801032c2:	f6 c4 02             	test   $0x2,%ah
801032c5:	75 4a                	jne    80103311 <mycpu+0x56>
  apicid = lapicid();
801032c7:	e8 74 f1 ff ff       	call   80102440 <lapicid>
  for (i = 0; i < ncpu; ++i) {
801032cc:	8b 35 00 bd 1d 80    	mov    0x801dbd00,%esi
801032d2:	85 f6                	test   %esi,%esi
801032d4:	7e 4f                	jle    80103325 <mycpu+0x6a>
    if (cpus[i].apicid == apicid)
801032d6:	0f b6 15 80 b7 1d 80 	movzbl 0x801db780,%edx
801032dd:	39 d0                	cmp    %edx,%eax
801032df:	74 3d                	je     8010331e <mycpu+0x63>
801032e1:	b9 30 b8 1d 80       	mov    $0x801db830,%ecx
  for (i = 0; i < ncpu; ++i) {
801032e6:	ba 00 00 00 00       	mov    $0x0,%edx
801032eb:	83 c2 01             	add    $0x1,%edx
801032ee:	39 f2                	cmp    %esi,%edx
801032f0:	74 33                	je     80103325 <mycpu+0x6a>
    if (cpus[i].apicid == apicid)
801032f2:	0f b6 19             	movzbl (%ecx),%ebx
801032f5:	81 c1 b0 00 00 00    	add    $0xb0,%ecx
801032fb:	39 c3                	cmp    %eax,%ebx
801032fd:	75 ec                	jne    801032eb <mycpu+0x30>
      return &cpus[i];
801032ff:	69 c2 b0 00 00 00    	imul   $0xb0,%edx,%eax
80103305:	05 80 b7 1d 80       	add    $0x801db780,%eax
}
8010330a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010330d:	5b                   	pop    %ebx
8010330e:	5e                   	pop    %esi
8010330f:	5d                   	pop    %ebp
80103310:	c3                   	ret    
    panic("mycpu called with interrupts enabled\n");
80103311:	83 ec 0c             	sub    $0xc,%esp
80103314:	68 50 86 10 80       	push   $0x80108650
80103319:	e8 26 d0 ff ff       	call   80100344 <panic>
  for (i = 0; i < ncpu; ++i) {
8010331e:	ba 00 00 00 00       	mov    $0x0,%edx
80103323:	eb da                	jmp    801032ff <mycpu+0x44>
  panic("unknown apicid\n");
80103325:	83 ec 0c             	sub    $0xc,%esp
80103328:	68 5c 85 10 80       	push   $0x8010855c
8010332d:	e8 12 d0 ff ff       	call   80100344 <panic>

80103332 <cpuid>:
cpuid() {
80103332:	55                   	push   %ebp
80103333:	89 e5                	mov    %esp,%ebp
80103335:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
80103338:	e8 7e ff ff ff       	call   801032bb <mycpu>
8010333d:	2d 80 b7 1d 80       	sub    $0x801db780,%eax
80103342:	c1 f8 04             	sar    $0x4,%eax
80103345:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
8010334b:	c9                   	leave  
8010334c:	c3                   	ret    

8010334d <myproc>:
myproc(void) {
8010334d:	55                   	push   %ebp
8010334e:	89 e5                	mov    %esp,%ebp
80103350:	53                   	push   %ebx
80103351:	83 ec 04             	sub    $0x4,%esp
  pushcli();
80103354:	e8 a2 09 00 00       	call   80103cfb <pushcli>
  c = mycpu();
80103359:	e8 5d ff ff ff       	call   801032bb <mycpu>
  p = c->proc;
8010335e:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103364:	e8 cf 09 00 00       	call   80103d38 <popcli>
}
80103369:	89 d8                	mov    %ebx,%eax
8010336b:	83 c4 04             	add    $0x4,%esp
8010336e:	5b                   	pop    %ebx
8010336f:	5d                   	pop    %ebp
80103370:	c3                   	ret    

80103371 <userinit>:
{
80103371:	55                   	push   %ebp
80103372:	89 e5                	mov    %esp,%ebp
80103374:	53                   	push   %ebx
80103375:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80103378:	e8 fd fd ff ff       	call   8010317a <allocproc>
8010337d:	89 c3                	mov    %eax,%ebx
  initproc = p;
8010337f:	a3 b8 b5 10 80       	mov    %eax,0x8010b5b8
  if((p->pgdir = setupkvm()) == 0)
80103384:	e8 08 30 00 00       	call   80106391 <setupkvm>
80103389:	89 43 04             	mov    %eax,0x4(%ebx)
8010338c:	85 c0                	test   %eax,%eax
8010338e:	0f 84 b7 00 00 00    	je     8010344b <userinit+0xda>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
80103394:	83 ec 04             	sub    $0x4,%esp
80103397:	68 2c 00 00 00       	push   $0x2c
8010339c:	68 60 b4 10 80       	push   $0x8010b460
801033a1:	50                   	push   %eax
801033a2:	e8 e3 2c 00 00       	call   8010608a <inituvm>
  p->sz = PGSIZE;
801033a7:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
801033ad:	83 c4 0c             	add    $0xc,%esp
801033b0:	6a 4c                	push   $0x4c
801033b2:	6a 00                	push   $0x0
801033b4:	ff 73 18             	pushl  0x18(%ebx)
801033b7:	e8 be 0a 00 00       	call   80103e7a <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
801033bc:	8b 43 18             	mov    0x18(%ebx),%eax
801033bf:	66 c7 40 3c 1b 00    	movw   $0x1b,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
801033c5:	8b 43 18             	mov    0x18(%ebx),%eax
801033c8:	66 c7 40 2c 23 00    	movw   $0x23,0x2c(%eax)
  p->tf->es = p->tf->ds;
801033ce:	8b 43 18             	mov    0x18(%ebx),%eax
801033d1:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
801033d5:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
801033d9:	8b 43 18             	mov    0x18(%ebx),%eax
801033dc:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
801033e0:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
801033e4:	8b 43 18             	mov    0x18(%ebx),%eax
801033e7:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
801033ee:	8b 43 18             	mov    0x18(%ebx),%eax
801033f1:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
801033f8:	8b 43 18             	mov    0x18(%ebx),%eax
801033fb:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103402:	83 c4 0c             	add    $0xc,%esp
80103405:	6a 10                	push   $0x10
80103407:	68 85 85 10 80       	push   $0x80108585
8010340c:	8d 43 6c             	lea    0x6c(%ebx),%eax
8010340f:	50                   	push   %eax
80103410:	e8 f4 0b 00 00       	call   80104009 <safestrcpy>
  p->cwd = namei("/");
80103415:	c7 04 24 8e 85 10 80 	movl   $0x8010858e,(%esp)
8010341c:	e8 62 e8 ff ff       	call   80101c83 <namei>
80103421:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
80103424:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
8010342b:	e8 9c 09 00 00       	call   80103dcc <acquire>
  p->state = RUNNABLE;
80103430:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
80103437:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
8010343e:	e8 f0 09 00 00       	call   80103e33 <release>
}
80103443:	83 c4 10             	add    $0x10,%esp
80103446:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103449:	c9                   	leave  
8010344a:	c3                   	ret    
    panic("userinit: out of memory?");
8010344b:	83 ec 0c             	sub    $0xc,%esp
8010344e:	68 6c 85 10 80       	push   $0x8010856c
80103453:	e8 ec ce ff ff       	call   80100344 <panic>

80103458 <growproc>:
{
80103458:	55                   	push   %ebp
80103459:	89 e5                	mov    %esp,%ebp
8010345b:	56                   	push   %esi
8010345c:	53                   	push   %ebx
8010345d:	8b 75 08             	mov    0x8(%ebp),%esi
  struct proc *curproc = myproc();
80103460:	e8 e8 fe ff ff       	call   8010334d <myproc>
80103465:	89 c3                	mov    %eax,%ebx
  sz = curproc->sz;
80103467:	8b 00                	mov    (%eax),%eax
  if(n > 0){
80103469:	85 f6                	test   %esi,%esi
8010346b:	7f 21                	jg     8010348e <growproc+0x36>
  } else if(n < 0){
8010346d:	85 f6                	test   %esi,%esi
8010346f:	79 33                	jns    801034a4 <growproc+0x4c>
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103471:	83 ec 04             	sub    $0x4,%esp
80103474:	01 c6                	add    %eax,%esi
80103476:	56                   	push   %esi
80103477:	50                   	push   %eax
80103478:	ff 73 04             	pushl  0x4(%ebx)
8010347b:	e8 21 2d 00 00       	call   801061a1 <deallocuvm>
80103480:	83 c4 10             	add    $0x10,%esp
80103483:	85 c0                	test   %eax,%eax
80103485:	75 1d                	jne    801034a4 <growproc+0x4c>
      return -1;
80103487:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010348c:	eb 29                	jmp    801034b7 <growproc+0x5f>
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
8010348e:	83 ec 04             	sub    $0x4,%esp
80103491:	01 c6                	add    %eax,%esi
80103493:	56                   	push   %esi
80103494:	50                   	push   %eax
80103495:	ff 73 04             	pushl  0x4(%ebx)
80103498:	e8 93 2d 00 00       	call   80106230 <allocuvm>
8010349d:	83 c4 10             	add    $0x10,%esp
801034a0:	85 c0                	test   %eax,%eax
801034a2:	74 1a                	je     801034be <growproc+0x66>
  curproc->sz = sz;
801034a4:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
801034a6:	83 ec 0c             	sub    $0xc,%esp
801034a9:	53                   	push   %ebx
801034aa:	e8 dd 2a 00 00       	call   80105f8c <switchuvm>
  return 0;
801034af:	83 c4 10             	add    $0x10,%esp
801034b2:	b8 00 00 00 00       	mov    $0x0,%eax
}
801034b7:	8d 65 f8             	lea    -0x8(%ebp),%esp
801034ba:	5b                   	pop    %ebx
801034bb:	5e                   	pop    %esi
801034bc:	5d                   	pop    %ebp
801034bd:	c3                   	ret    
      return -1;
801034be:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801034c3:	eb f2                	jmp    801034b7 <growproc+0x5f>

801034c5 <fork>:
{
801034c5:	55                   	push   %ebp
801034c6:	89 e5                	mov    %esp,%ebp
801034c8:	57                   	push   %edi
801034c9:	56                   	push   %esi
801034ca:	53                   	push   %ebx
801034cb:	83 ec 1c             	sub    $0x1c,%esp
  struct proc *curproc = myproc();
801034ce:	e8 7a fe ff ff       	call   8010334d <myproc>
801034d3:	89 c3                	mov    %eax,%ebx
  if((np = allocproc()) == 0){
801034d5:	e8 a0 fc ff ff       	call   8010317a <allocproc>
801034da:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801034dd:	85 c0                	test   %eax,%eax
801034df:	0f 84 e0 00 00 00    	je     801035c5 <fork+0x100>
801034e5:	89 c7                	mov    %eax,%edi
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
801034e7:	83 ec 08             	sub    $0x8,%esp
801034ea:	ff 33                	pushl  (%ebx)
801034ec:	ff 73 04             	pushl  0x4(%ebx)
801034ef:	e8 4e 2f 00 00       	call   80106442 <copyuvm>
801034f4:	89 47 04             	mov    %eax,0x4(%edi)
801034f7:	83 c4 10             	add    $0x10,%esp
801034fa:	85 c0                	test   %eax,%eax
801034fc:	74 2a                	je     80103528 <fork+0x63>
  np->sz = curproc->sz;
801034fe:	8b 03                	mov    (%ebx),%eax
80103500:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80103503:	89 01                	mov    %eax,(%ecx)
  np->parent = curproc;
80103505:	89 c8                	mov    %ecx,%eax
80103507:	89 59 14             	mov    %ebx,0x14(%ecx)
  *np->tf = *curproc->tf;
8010350a:	8b 73 18             	mov    0x18(%ebx),%esi
8010350d:	8b 79 18             	mov    0x18(%ecx),%edi
80103510:	b9 13 00 00 00       	mov    $0x13,%ecx
80103515:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  np->tf->eax = 0;
80103517:	8b 40 18             	mov    0x18(%eax),%eax
8010351a:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
  for(i = 0; i < NOFILE; i++)
80103521:	be 00 00 00 00       	mov    $0x0,%esi
80103526:	eb 2e                	jmp    80103556 <fork+0x91>
    kfree(np->kstack);
80103528:	83 ec 0c             	sub    $0xc,%esp
8010352b:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
8010352e:	ff 73 08             	pushl  0x8(%ebx)
80103531:	e8 03 eb ff ff       	call   80102039 <kfree>
    np->kstack = 0;
80103536:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    np->state = UNUSED;
8010353d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80103544:	83 c4 10             	add    $0x10,%esp
80103547:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
8010354c:	eb 6d                	jmp    801035bb <fork+0xf6>
  for(i = 0; i < NOFILE; i++)
8010354e:	83 c6 01             	add    $0x1,%esi
80103551:	83 fe 10             	cmp    $0x10,%esi
80103554:	74 1d                	je     80103573 <fork+0xae>
    if(curproc->ofile[i])
80103556:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
8010355a:	85 c0                	test   %eax,%eax
8010355c:	74 f0                	je     8010354e <fork+0x89>
      np->ofile[i] = filedup(curproc->ofile[i]);
8010355e:	83 ec 0c             	sub    $0xc,%esp
80103561:	50                   	push   %eax
80103562:	e8 80 d7 ff ff       	call   80100ce7 <filedup>
80103567:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010356a:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
8010356e:	83 c4 10             	add    $0x10,%esp
80103571:	eb db                	jmp    8010354e <fork+0x89>
  np->cwd = idup(curproc->cwd);
80103573:	83 ec 0c             	sub    $0xc,%esp
80103576:	ff 73 68             	pushl  0x68(%ebx)
80103579:	e8 3d df ff ff       	call   801014bb <idup>
8010357e:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80103581:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103584:	83 c4 0c             	add    $0xc,%esp
80103587:	6a 10                	push   $0x10
80103589:	83 c3 6c             	add    $0x6c,%ebx
8010358c:	53                   	push   %ebx
8010358d:	8d 47 6c             	lea    0x6c(%edi),%eax
80103590:	50                   	push   %eax
80103591:	e8 73 0a 00 00       	call   80104009 <safestrcpy>
  pid = np->pid;
80103596:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
80103599:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
801035a0:	e8 27 08 00 00       	call   80103dcc <acquire>
  np->state = RUNNABLE;
801035a5:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
801035ac:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
801035b3:	e8 7b 08 00 00       	call   80103e33 <release>
  return pid;
801035b8:	83 c4 10             	add    $0x10,%esp
}
801035bb:	89 d8                	mov    %ebx,%eax
801035bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
801035c0:	5b                   	pop    %ebx
801035c1:	5e                   	pop    %esi
801035c2:	5f                   	pop    %edi
801035c3:	5d                   	pop    %ebp
801035c4:	c3                   	ret    
    return -1;
801035c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801035ca:	eb ef                	jmp    801035bb <fork+0xf6>

801035cc <scheduler>:
{
801035cc:	55                   	push   %ebp
801035cd:	89 e5                	mov    %esp,%ebp
801035cf:	57                   	push   %edi
801035d0:	56                   	push   %esi
801035d1:	53                   	push   %ebx
801035d2:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
801035d5:	e8 e1 fc ff ff       	call   801032bb <mycpu>
801035da:	89 c6                	mov    %eax,%esi
  c->proc = 0;
801035dc:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
801035e3:	00 00 00 
      swtch(&(c->scheduler), p->context);
801035e6:	8d 78 04             	lea    0x4(%eax),%edi
801035e9:	eb 5a                	jmp    80103645 <scheduler+0x79>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801035eb:	81 c3 84 00 00 00    	add    $0x84,%ebx
801035f1:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
801035f7:	73 3c                	jae    80103635 <scheduler+0x69>
      if(p->state != RUNNABLE)
801035f9:	83 7b 0c 03          	cmpl   $0x3,0xc(%ebx)
801035fd:	75 ec                	jne    801035eb <scheduler+0x1f>
      c->proc = p;
801035ff:	89 9e ac 00 00 00    	mov    %ebx,0xac(%esi)
      switchuvm(p);
80103605:	83 ec 0c             	sub    $0xc,%esp
80103608:	53                   	push   %ebx
80103609:	e8 7e 29 00 00       	call   80105f8c <switchuvm>
      p->state = RUNNING;
8010360e:	c7 43 0c 04 00 00 00 	movl   $0x4,0xc(%ebx)
      swtch(&(c->scheduler), p->context);
80103615:	83 c4 08             	add    $0x8,%esp
80103618:	ff 73 1c             	pushl  0x1c(%ebx)
8010361b:	57                   	push   %edi
8010361c:	e8 3e 0a 00 00       	call   8010405f <swtch>
      switchkvm();
80103621:	e8 54 29 00 00       	call   80105f7a <switchkvm>
      c->proc = 0;
80103626:	c7 86 ac 00 00 00 00 	movl   $0x0,0xac(%esi)
8010362d:	00 00 00 
80103630:	83 c4 10             	add    $0x10,%esp
80103633:	eb b6                	jmp    801035eb <scheduler+0x1f>
    release(&ptable.lock);
80103635:	83 ec 0c             	sub    $0xc,%esp
80103638:	68 20 bd 1d 80       	push   $0x801dbd20
8010363d:	e8 f1 07 00 00       	call   80103e33 <release>
    sti();
80103642:	83 c4 10             	add    $0x10,%esp
  asm volatile("sti");
80103645:	fb                   	sti    
    acquire(&ptable.lock);
80103646:	83 ec 0c             	sub    $0xc,%esp
80103649:	68 20 bd 1d 80       	push   $0x801dbd20
8010364e:	e8 79 07 00 00       	call   80103dcc <acquire>
80103653:	83 c4 10             	add    $0x10,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103656:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
8010365b:	eb 9c                	jmp    801035f9 <scheduler+0x2d>

8010365d <sched>:
{
8010365d:	55                   	push   %ebp
8010365e:	89 e5                	mov    %esp,%ebp
80103660:	56                   	push   %esi
80103661:	53                   	push   %ebx
  struct proc *p = myproc();
80103662:	e8 e6 fc ff ff       	call   8010334d <myproc>
80103667:	89 c3                	mov    %eax,%ebx
  if(!holding(&ptable.lock))
80103669:	83 ec 0c             	sub    $0xc,%esp
8010366c:	68 20 bd 1d 80       	push   $0x801dbd20
80103671:	e8 22 07 00 00       	call   80103d98 <holding>
80103676:	83 c4 10             	add    $0x10,%esp
80103679:	85 c0                	test   %eax,%eax
8010367b:	74 4f                	je     801036cc <sched+0x6f>
  if(mycpu()->ncli != 1)
8010367d:	e8 39 fc ff ff       	call   801032bb <mycpu>
80103682:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103689:	75 4e                	jne    801036d9 <sched+0x7c>
  if(p->state == RUNNING)
8010368b:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
8010368f:	74 55                	je     801036e6 <sched+0x89>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103691:	9c                   	pushf  
80103692:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103693:	f6 c4 02             	test   $0x2,%ah
80103696:	75 5b                	jne    801036f3 <sched+0x96>
  intena = mycpu()->intena;
80103698:	e8 1e fc ff ff       	call   801032bb <mycpu>
8010369d:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
801036a3:	e8 13 fc ff ff       	call   801032bb <mycpu>
801036a8:	83 ec 08             	sub    $0x8,%esp
801036ab:	ff 70 04             	pushl  0x4(%eax)
801036ae:	83 c3 1c             	add    $0x1c,%ebx
801036b1:	53                   	push   %ebx
801036b2:	e8 a8 09 00 00       	call   8010405f <swtch>
  mycpu()->intena = intena;
801036b7:	e8 ff fb ff ff       	call   801032bb <mycpu>
801036bc:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
801036c2:	83 c4 10             	add    $0x10,%esp
801036c5:	8d 65 f8             	lea    -0x8(%ebp),%esp
801036c8:	5b                   	pop    %ebx
801036c9:	5e                   	pop    %esi
801036ca:	5d                   	pop    %ebp
801036cb:	c3                   	ret    
    panic("sched ptable.lock");
801036cc:	83 ec 0c             	sub    $0xc,%esp
801036cf:	68 90 85 10 80       	push   $0x80108590
801036d4:	e8 6b cc ff ff       	call   80100344 <panic>
    panic("sched locks");
801036d9:	83 ec 0c             	sub    $0xc,%esp
801036dc:	68 a2 85 10 80       	push   $0x801085a2
801036e1:	e8 5e cc ff ff       	call   80100344 <panic>
    panic("sched running");
801036e6:	83 ec 0c             	sub    $0xc,%esp
801036e9:	68 ae 85 10 80       	push   $0x801085ae
801036ee:	e8 51 cc ff ff       	call   80100344 <panic>
    panic("sched interruptible");
801036f3:	83 ec 0c             	sub    $0xc,%esp
801036f6:	68 bc 85 10 80       	push   $0x801085bc
801036fb:	e8 44 cc ff ff       	call   80100344 <panic>

80103700 <exit>:
{
80103700:	55                   	push   %ebp
80103701:	89 e5                	mov    %esp,%ebp
80103703:	57                   	push   %edi
80103704:	56                   	push   %esi
80103705:	53                   	push   %ebx
80103706:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
80103709:	e8 3f fc ff ff       	call   8010334d <myproc>
8010370e:	89 c6                	mov    %eax,%esi
80103710:	8d 58 28             	lea    0x28(%eax),%ebx
80103713:	8d 78 68             	lea    0x68(%eax),%edi
  if(curproc == initproc)
80103716:	39 05 b8 b5 10 80    	cmp    %eax,0x8010b5b8
8010371c:	75 14                	jne    80103732 <exit+0x32>
    panic("init exiting");
8010371e:	83 ec 0c             	sub    $0xc,%esp
80103721:	68 d0 85 10 80       	push   $0x801085d0
80103726:	e8 19 cc ff ff       	call   80100344 <panic>
8010372b:	83 c3 04             	add    $0x4,%ebx
  for(fd = 0; fd < NOFILE; fd++){
8010372e:	39 df                	cmp    %ebx,%edi
80103730:	74 1a                	je     8010374c <exit+0x4c>
    if(curproc->ofile[fd]){
80103732:	8b 03                	mov    (%ebx),%eax
80103734:	85 c0                	test   %eax,%eax
80103736:	74 f3                	je     8010372b <exit+0x2b>
      fileclose(curproc->ofile[fd]);
80103738:	83 ec 0c             	sub    $0xc,%esp
8010373b:	50                   	push   %eax
8010373c:	e8 eb d5 ff ff       	call   80100d2c <fileclose>
      curproc->ofile[fd] = 0;
80103741:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
80103747:	83 c4 10             	add    $0x10,%esp
8010374a:	eb df                	jmp    8010372b <exit+0x2b>
  begin_op();
8010374c:	e8 5c f0 ff ff       	call   801027ad <begin_op>
  iput(curproc->cwd);
80103751:	83 ec 0c             	sub    $0xc,%esp
80103754:	ff 76 68             	pushl  0x68(%esi)
80103757:	e8 91 de ff ff       	call   801015ed <iput>
  end_op();
8010375c:	e8 c7 f0 ff ff       	call   80102828 <end_op>
  curproc->cwd = 0;
80103761:	c7 46 68 00 00 00 00 	movl   $0x0,0x68(%esi)
  acquire(&ptable.lock);
80103768:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
8010376f:	e8 58 06 00 00       	call   80103dcc <acquire>
  wakeup1(curproc->parent);
80103774:	8b 46 14             	mov    0x14(%esi),%eax
80103777:	e8 d0 f9 ff ff       	call   8010314c <wakeup1>
8010377c:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
8010377f:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
80103784:	eb 0e                	jmp    80103794 <exit+0x94>
80103786:	81 c3 84 00 00 00    	add    $0x84,%ebx
8010378c:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
80103792:	73 1a                	jae    801037ae <exit+0xae>
    if(p->parent == curproc){
80103794:	39 73 14             	cmp    %esi,0x14(%ebx)
80103797:	75 ed                	jne    80103786 <exit+0x86>
      p->parent = initproc;
80103799:	a1 b8 b5 10 80       	mov    0x8010b5b8,%eax
8010379e:	89 43 14             	mov    %eax,0x14(%ebx)
      if(p->state == ZOMBIE)
801037a1:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
801037a5:	75 df                	jne    80103786 <exit+0x86>
        wakeup1(initproc);
801037a7:	e8 a0 f9 ff ff       	call   8010314c <wakeup1>
801037ac:	eb d8                	jmp    80103786 <exit+0x86>
  curproc->state = ZOMBIE;
801037ae:	c7 46 0c 05 00 00 00 	movl   $0x5,0xc(%esi)
  sched();
801037b5:	e8 a3 fe ff ff       	call   8010365d <sched>
  panic("zombie exit");
801037ba:	83 ec 0c             	sub    $0xc,%esp
801037bd:	68 dd 85 10 80       	push   $0x801085dd
801037c2:	e8 7d cb ff ff       	call   80100344 <panic>

801037c7 <yield>:
{
801037c7:	55                   	push   %ebp
801037c8:	89 e5                	mov    %esp,%ebp
801037ca:	83 ec 14             	sub    $0x14,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
801037cd:	68 20 bd 1d 80       	push   $0x801dbd20
801037d2:	e8 f5 05 00 00       	call   80103dcc <acquire>
  myproc()->state = RUNNABLE;
801037d7:	e8 71 fb ff ff       	call   8010334d <myproc>
801037dc:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  sched();
801037e3:	e8 75 fe ff ff       	call   8010365d <sched>
  release(&ptable.lock);
801037e8:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
801037ef:	e8 3f 06 00 00       	call   80103e33 <release>
}
801037f4:	83 c4 10             	add    $0x10,%esp
801037f7:	c9                   	leave  
801037f8:	c3                   	ret    

801037f9 <sleep>:
{
801037f9:	55                   	push   %ebp
801037fa:	89 e5                	mov    %esp,%ebp
801037fc:	57                   	push   %edi
801037fd:	56                   	push   %esi
801037fe:	53                   	push   %ebx
801037ff:	83 ec 0c             	sub    $0xc,%esp
80103802:	8b 7d 08             	mov    0x8(%ebp),%edi
80103805:	8b 75 0c             	mov    0xc(%ebp),%esi
  struct proc *p = myproc();
80103808:	e8 40 fb ff ff       	call   8010334d <myproc>
  if(p == 0)
8010380d:	85 c0                	test   %eax,%eax
8010380f:	74 58                	je     80103869 <sleep+0x70>
80103811:	89 c3                	mov    %eax,%ebx
  if(lk == 0)
80103813:	85 f6                	test   %esi,%esi
80103815:	74 5f                	je     80103876 <sleep+0x7d>
  if(lk != &ptable.lock){  //DOC: sleeplock0
80103817:	81 fe 20 bd 1d 80    	cmp    $0x801dbd20,%esi
8010381d:	74 64                	je     80103883 <sleep+0x8a>
    acquire(&ptable.lock);  //DOC: sleeplock1
8010381f:	83 ec 0c             	sub    $0xc,%esp
80103822:	68 20 bd 1d 80       	push   $0x801dbd20
80103827:	e8 a0 05 00 00       	call   80103dcc <acquire>
    release(lk);
8010382c:	89 34 24             	mov    %esi,(%esp)
8010382f:	e8 ff 05 00 00       	call   80103e33 <release>
  p->chan = chan;
80103834:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80103837:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
8010383e:	e8 1a fe ff ff       	call   8010365d <sched>
  p->chan = 0;
80103843:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
8010384a:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
80103851:	e8 dd 05 00 00       	call   80103e33 <release>
    acquire(lk);
80103856:	89 34 24             	mov    %esi,(%esp)
80103859:	e8 6e 05 00 00       	call   80103dcc <acquire>
8010385e:	83 c4 10             	add    $0x10,%esp
}
80103861:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103864:	5b                   	pop    %ebx
80103865:	5e                   	pop    %esi
80103866:	5f                   	pop    %edi
80103867:	5d                   	pop    %ebp
80103868:	c3                   	ret    
    panic("sleep");
80103869:	83 ec 0c             	sub    $0xc,%esp
8010386c:	68 e9 85 10 80       	push   $0x801085e9
80103871:	e8 ce ca ff ff       	call   80100344 <panic>
    panic("sleep without lk");
80103876:	83 ec 0c             	sub    $0xc,%esp
80103879:	68 ef 85 10 80       	push   $0x801085ef
8010387e:	e8 c1 ca ff ff       	call   80100344 <panic>
  p->chan = chan;
80103883:	89 78 20             	mov    %edi,0x20(%eax)
  p->state = SLEEPING;
80103886:	c7 40 0c 02 00 00 00 	movl   $0x2,0xc(%eax)
  sched();
8010388d:	e8 cb fd ff ff       	call   8010365d <sched>
  p->chan = 0;
80103892:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
80103899:	eb c6                	jmp    80103861 <sleep+0x68>

8010389b <wait>:
{
8010389b:	55                   	push   %ebp
8010389c:	89 e5                	mov    %esp,%ebp
8010389e:	57                   	push   %edi
8010389f:	56                   	push   %esi
801038a0:	53                   	push   %ebx
801038a1:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
801038a4:	e8 a4 fa ff ff       	call   8010334d <myproc>
801038a9:	89 c6                	mov    %eax,%esi
  acquire(&ptable.lock);
801038ab:	83 ec 0c             	sub    $0xc,%esp
801038ae:	68 20 bd 1d 80       	push   $0x801dbd20
801038b3:	e8 14 05 00 00       	call   80103dcc <acquire>
801038b8:	83 c4 10             	add    $0x10,%esp
      havekids = 1;
801038bb:	bf 01 00 00 00       	mov    $0x1,%edi
    havekids = 0;
801038c0:	b8 00 00 00 00       	mov    $0x0,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801038c5:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
801038ca:	eb 5f                	jmp    8010392b <wait+0x90>
        pid = p->pid;
801038cc:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
801038cf:	83 ec 0c             	sub    $0xc,%esp
801038d2:	ff 73 08             	pushl  0x8(%ebx)
801038d5:	e8 5f e7 ff ff       	call   80102039 <kfree>
        p->kstack = 0;
801038da:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
801038e1:	83 c4 04             	add    $0x4,%esp
801038e4:	ff 73 04             	pushl  0x4(%ebx)
801038e7:	e8 32 2a 00 00       	call   8010631e <freevm>
        p->pid = 0;
801038ec:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
801038f3:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
801038fa:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
801038fe:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
80103905:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
8010390c:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
80103913:	e8 1b 05 00 00       	call   80103e33 <release>
        return pid;
80103918:	83 c4 10             	add    $0x10,%esp
8010391b:	eb 3c                	jmp    80103959 <wait+0xbe>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
8010391d:	81 c3 84 00 00 00    	add    $0x84,%ebx
80103923:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
80103929:	73 0f                	jae    8010393a <wait+0x9f>
      if(p->parent != curproc)
8010392b:	39 73 14             	cmp    %esi,0x14(%ebx)
8010392e:	75 ed                	jne    8010391d <wait+0x82>
      if(p->state == ZOMBIE){
80103930:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80103934:	74 96                	je     801038cc <wait+0x31>
      havekids = 1;
80103936:	89 f8                	mov    %edi,%eax
80103938:	eb e3                	jmp    8010391d <wait+0x82>
    if(!havekids || curproc->killed){
8010393a:	85 c0                	test   %eax,%eax
8010393c:	74 06                	je     80103944 <wait+0xa9>
8010393e:	83 7e 24 00          	cmpl   $0x0,0x24(%esi)
80103942:	74 1f                	je     80103963 <wait+0xc8>
      release(&ptable.lock);
80103944:	83 ec 0c             	sub    $0xc,%esp
80103947:	68 20 bd 1d 80       	push   $0x801dbd20
8010394c:	e8 e2 04 00 00       	call   80103e33 <release>
      return -1;
80103951:	83 c4 10             	add    $0x10,%esp
80103954:	be ff ff ff ff       	mov    $0xffffffff,%esi
}
80103959:	89 f0                	mov    %esi,%eax
8010395b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010395e:	5b                   	pop    %ebx
8010395f:	5e                   	pop    %esi
80103960:	5f                   	pop    %edi
80103961:	5d                   	pop    %ebp
80103962:	c3                   	ret    
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
80103963:	83 ec 08             	sub    $0x8,%esp
80103966:	68 20 bd 1d 80       	push   $0x801dbd20
8010396b:	56                   	push   %esi
8010396c:	e8 88 fe ff ff       	call   801037f9 <sleep>
    havekids = 0;
80103971:	83 c4 10             	add    $0x10,%esp
80103974:	e9 47 ff ff ff       	jmp    801038c0 <wait+0x25>

80103979 <wakeup>:

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
80103979:	55                   	push   %ebp
8010397a:	89 e5                	mov    %esp,%ebp
8010397c:	83 ec 14             	sub    $0x14,%esp
  acquire(&ptable.lock);
8010397f:	68 20 bd 1d 80       	push   $0x801dbd20
80103984:	e8 43 04 00 00       	call   80103dcc <acquire>
  wakeup1(chan);
80103989:	8b 45 08             	mov    0x8(%ebp),%eax
8010398c:	e8 bb f7 ff ff       	call   8010314c <wakeup1>
  release(&ptable.lock);
80103991:	c7 04 24 20 bd 1d 80 	movl   $0x801dbd20,(%esp)
80103998:	e8 96 04 00 00       	call   80103e33 <release>
}
8010399d:	83 c4 10             	add    $0x10,%esp
801039a0:	c9                   	leave  
801039a1:	c3                   	ret    

801039a2 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
801039a2:	55                   	push   %ebp
801039a3:	89 e5                	mov    %esp,%ebp
801039a5:	53                   	push   %ebx
801039a6:	83 ec 10             	sub    $0x10,%esp
801039a9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
801039ac:	68 20 bd 1d 80       	push   $0x801dbd20
801039b1:	e8 16 04 00 00       	call   80103dcc <acquire>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
801039b6:	83 c4 10             	add    $0x10,%esp
801039b9:	3b 1d 64 bd 1d 80    	cmp    0x801dbd64,%ebx
801039bf:	74 2d                	je     801039ee <kill+0x4c>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801039c1:	b8 d8 bd 1d 80       	mov    $0x801dbdd8,%eax
    if(p->pid == pid){
801039c6:	39 58 10             	cmp    %ebx,0x10(%eax)
801039c9:	74 28                	je     801039f3 <kill+0x51>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801039cb:	05 84 00 00 00       	add    $0x84,%eax
801039d0:	3d 94 c5 1d 80       	cmp    $0x801dc594,%eax
801039d5:	72 ef                	jb     801039c6 <kill+0x24>
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
801039d7:	83 ec 0c             	sub    $0xc,%esp
801039da:	68 20 bd 1d 80       	push   $0x801dbd20
801039df:	e8 4f 04 00 00       	call   80103e33 <release>
  return -1;
801039e4:	83 c4 10             	add    $0x10,%esp
801039e7:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801039ec:	eb 27                	jmp    80103a15 <kill+0x73>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801039ee:	b8 54 bd 1d 80       	mov    $0x801dbd54,%eax
      p->killed = 1;
801039f3:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      if(p->state == SLEEPING)
801039fa:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801039fe:	74 1a                	je     80103a1a <kill+0x78>
      release(&ptable.lock);
80103a00:	83 ec 0c             	sub    $0xc,%esp
80103a03:	68 20 bd 1d 80       	push   $0x801dbd20
80103a08:	e8 26 04 00 00       	call   80103e33 <release>
      return 0;
80103a0d:	83 c4 10             	add    $0x10,%esp
80103a10:	b8 00 00 00 00       	mov    $0x0,%eax
}
80103a15:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a18:	c9                   	leave  
80103a19:	c3                   	ret    
        p->state = RUNNABLE;
80103a1a:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103a21:	eb dd                	jmp    80103a00 <kill+0x5e>

80103a23 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80103a23:	55                   	push   %ebp
80103a24:	89 e5                	mov    %esp,%ebp
80103a26:	57                   	push   %edi
80103a27:	56                   	push   %esi
80103a28:	53                   	push   %ebx
80103a29:	83 ec 3c             	sub    $0x3c,%esp
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103a2c:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
80103a31:	8d 7d e8             	lea    -0x18(%ebp),%edi
80103a34:	eb 39                	jmp    80103a6f <procdump+0x4c>
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s %p", p->pid, state, p->name);
80103a36:	8d 53 6c             	lea    0x6c(%ebx),%edx
80103a39:	52                   	push   %edx
80103a3a:	50                   	push   %eax
80103a3b:	ff 73 10             	pushl  0x10(%ebx)
80103a3e:	68 04 86 10 80       	push   $0x80108604
80103a43:	e8 99 cb ff ff       	call   801005e1 <cprintf>
    //cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
80103a48:	83 c4 10             	add    $0x10,%esp
80103a4b:	83 7b 0c 02          	cmpl   $0x2,0xc(%ebx)
80103a4f:	74 42                	je     80103a93 <procdump+0x70>
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
80103a51:	83 ec 0c             	sub    $0xc,%esp
80103a54:	68 9f 89 10 80       	push   $0x8010899f
80103a59:	e8 83 cb ff ff       	call   801005e1 <cprintf>
80103a5e:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103a61:	81 c3 84 00 00 00    	add    $0x84,%ebx
80103a67:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
80103a6d:	73 7b                	jae    80103aea <procdump+0xc7>
    if(p->state == UNUSED)
80103a6f:	8b 53 0c             	mov    0xc(%ebx),%edx
80103a72:	85 d2                	test   %edx,%edx
80103a74:	74 eb                	je     80103a61 <procdump+0x3e>
      state = "???";
80103a76:	b8 00 86 10 80       	mov    $0x80108600,%eax
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80103a7b:	83 fa 05             	cmp    $0x5,%edx
80103a7e:	77 b6                	ja     80103a36 <procdump+0x13>
80103a80:	8b 04 95 90 86 10 80 	mov    -0x7fef7970(,%edx,4),%eax
80103a87:	85 c0                	test   %eax,%eax
      state = "???";
80103a89:	ba 00 86 10 80       	mov    $0x80108600,%edx
80103a8e:	0f 44 c2             	cmove  %edx,%eax
80103a91:	eb a3                	jmp    80103a36 <procdump+0x13>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80103a93:	83 ec 08             	sub    $0x8,%esp
80103a96:	8d 45 c0             	lea    -0x40(%ebp),%eax
80103a99:	50                   	push   %eax
80103a9a:	8b 43 1c             	mov    0x1c(%ebx),%eax
80103a9d:	8b 40 0c             	mov    0xc(%eax),%eax
80103aa0:	83 c0 08             	add    $0x8,%eax
80103aa3:	50                   	push   %eax
80103aa4:	e8 f6 01 00 00       	call   80103c9f <getcallerpcs>
      for(i=0; i<10 && pc[i] != 0; i++)
80103aa9:	8b 45 c0             	mov    -0x40(%ebp),%eax
80103aac:	83 c4 10             	add    $0x10,%esp
80103aaf:	85 c0                	test   %eax,%eax
80103ab1:	74 9e                	je     80103a51 <procdump+0x2e>
        cprintf(" %p", pc[i]);
80103ab3:	83 ec 08             	sub    $0x8,%esp
80103ab6:	50                   	push   %eax
80103ab7:	68 0c 86 10 80       	push   $0x8010860c
80103abc:	e8 20 cb ff ff       	call   801005e1 <cprintf>
80103ac1:	8d 75 c4             	lea    -0x3c(%ebp),%esi
80103ac4:	83 c4 10             	add    $0x10,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80103ac7:	8b 06                	mov    (%esi),%eax
80103ac9:	85 c0                	test   %eax,%eax
80103acb:	74 84                	je     80103a51 <procdump+0x2e>
        cprintf(" %p", pc[i]);
80103acd:	83 ec 08             	sub    $0x8,%esp
80103ad0:	50                   	push   %eax
80103ad1:	68 0c 86 10 80       	push   $0x8010860c
80103ad6:	e8 06 cb ff ff       	call   801005e1 <cprintf>
80103adb:	83 c6 04             	add    $0x4,%esi
      for(i=0; i<10 && pc[i] != 0; i++)
80103ade:	83 c4 10             	add    $0x10,%esp
80103ae1:	39 f7                	cmp    %esi,%edi
80103ae3:	75 e2                	jne    80103ac7 <procdump+0xa4>
80103ae5:	e9 67 ff ff ff       	jmp    80103a51 <procdump+0x2e>
  }
}
80103aea:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103aed:	5b                   	pop    %ebx
80103aee:	5e                   	pop    %esi
80103aef:	5f                   	pop    %edi
80103af0:	5d                   	pop    %ebp
80103af1:	c3                   	ret    

80103af2 <ps>:

void
ps(void)
{
80103af2:	55                   	push   %ebp
80103af3:	89 e5                	mov    %esp,%ebp
80103af5:	57                   	push   %edi
80103af6:	56                   	push   %esi
80103af7:	53                   	push   %ebx
80103af8:	83 ec 18             	sub    $0x18,%esp
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state, *name;

	acquire(&ptable.lock);
80103afb:	68 20 bd 1d 80       	push   $0x801dbd20
80103b00:	e8 c7 02 00 00       	call   80103dcc <acquire>
80103b05:	83 c4 10             	add    $0x10,%esp

	for( p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103b08:	bb 54 bd 1d 80       	mov    $0x801dbd54,%ebx
	{   
    	if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
				state = states[p->state];
			else
				state = "???";
80103b0d:	bf 00 86 10 80       	mov    $0x80108600,%edi
80103b12:	be 10 86 10 80       	mov    $0x80108610,%esi
80103b17:	eb 2e                	jmp    80103b47 <ps+0x55>
80103b19:	8d 4b 6c             	lea    0x6c(%ebx),%ecx
80103b1c:	85 c0                	test   %eax,%eax
80103b1e:	89 c8                	mov    %ecx,%eax
80103b20:	0f 44 c6             	cmove  %esi,%eax
			if(p->state == UNUSED)
				name = "unknown";
			else
				name = p->name;

    	cprintf("%d %s %s %p\n", p->pid, state, name, p);
80103b23:	83 ec 0c             	sub    $0xc,%esp
80103b26:	53                   	push   %ebx
80103b27:	50                   	push   %eax
80103b28:	52                   	push   %edx
80103b29:	ff 73 10             	pushl  0x10(%ebx)
80103b2c:	68 18 86 10 80       	push   $0x80108618
80103b31:	e8 ab ca ff ff       	call   801005e1 <cprintf>
	for( p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103b36:	81 c3 84 00 00 00    	add    $0x84,%ebx
80103b3c:	83 c4 20             	add    $0x20,%esp
80103b3f:	81 fb 94 c5 1d 80    	cmp    $0x801dc594,%ebx
80103b45:	73 1b                	jae    80103b62 <ps+0x70>
    	if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80103b47:	8b 43 0c             	mov    0xc(%ebx),%eax
				state = "???";
80103b4a:	ba 00 86 10 80       	mov    $0x80108600,%edx
    	if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
80103b4f:	83 f8 05             	cmp    $0x5,%eax
80103b52:	77 c5                	ja     80103b19 <ps+0x27>
80103b54:	8b 14 85 78 86 10 80 	mov    -0x7fef7988(,%eax,4),%edx
80103b5b:	85 d2                	test   %edx,%edx
				state = "???";
80103b5d:	0f 44 d7             	cmove  %edi,%edx
80103b60:	eb b7                	jmp    80103b19 <ps+0x27>

    }   
    release(&ptable.lock);
80103b62:	83 ec 0c             	sub    $0xc,%esp
80103b65:	68 20 bd 1d 80       	push   $0x801dbd20
80103b6a:	e8 c4 02 00 00       	call   80103e33 <release>
    return;
80103b6f:	83 c4 10             	add    $0x10,%esp
}
80103b72:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103b75:	5b                   	pop    %ebx
80103b76:	5e                   	pop    %esi
80103b77:	5f                   	pop    %edi
80103b78:	5d                   	pop    %ebp
80103b79:	c3                   	ret    

80103b7a <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
80103b7a:	55                   	push   %ebp
80103b7b:	89 e5                	mov    %esp,%ebp
80103b7d:	53                   	push   %ebx
80103b7e:	83 ec 0c             	sub    $0xc,%esp
80103b81:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
80103b84:	68 a8 86 10 80       	push   $0x801086a8
80103b89:	8d 43 04             	lea    0x4(%ebx),%eax
80103b8c:	50                   	push   %eax
80103b8d:	e8 f2 00 00 00       	call   80103c84 <initlock>
  lk->name = name;
80103b92:	8b 45 0c             	mov    0xc(%ebp),%eax
80103b95:	89 43 38             	mov    %eax,0x38(%ebx)
  lk->locked = 0;
80103b98:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80103b9e:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
}
80103ba5:	83 c4 10             	add    $0x10,%esp
80103ba8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103bab:	c9                   	leave  
80103bac:	c3                   	ret    

80103bad <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80103bad:	55                   	push   %ebp
80103bae:	89 e5                	mov    %esp,%ebp
80103bb0:	56                   	push   %esi
80103bb1:	53                   	push   %ebx
80103bb2:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80103bb5:	8d 73 04             	lea    0x4(%ebx),%esi
80103bb8:	83 ec 0c             	sub    $0xc,%esp
80103bbb:	56                   	push   %esi
80103bbc:	e8 0b 02 00 00       	call   80103dcc <acquire>
  while (lk->locked) {
80103bc1:	83 c4 10             	add    $0x10,%esp
80103bc4:	83 3b 00             	cmpl   $0x0,(%ebx)
80103bc7:	74 12                	je     80103bdb <acquiresleep+0x2e>
    sleep(lk, &lk->lk);
80103bc9:	83 ec 08             	sub    $0x8,%esp
80103bcc:	56                   	push   %esi
80103bcd:	53                   	push   %ebx
80103bce:	e8 26 fc ff ff       	call   801037f9 <sleep>
  while (lk->locked) {
80103bd3:	83 c4 10             	add    $0x10,%esp
80103bd6:	83 3b 00             	cmpl   $0x0,(%ebx)
80103bd9:	75 ee                	jne    80103bc9 <acquiresleep+0x1c>
  }
  lk->locked = 1;
80103bdb:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
80103be1:	e8 67 f7 ff ff       	call   8010334d <myproc>
80103be6:	8b 40 10             	mov    0x10(%eax),%eax
80103be9:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
80103bec:	83 ec 0c             	sub    $0xc,%esp
80103bef:	56                   	push   %esi
80103bf0:	e8 3e 02 00 00       	call   80103e33 <release>
}
80103bf5:	83 c4 10             	add    $0x10,%esp
80103bf8:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103bfb:	5b                   	pop    %ebx
80103bfc:	5e                   	pop    %esi
80103bfd:	5d                   	pop    %ebp
80103bfe:	c3                   	ret    

80103bff <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80103bff:	55                   	push   %ebp
80103c00:	89 e5                	mov    %esp,%ebp
80103c02:	56                   	push   %esi
80103c03:	53                   	push   %ebx
80103c04:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80103c07:	8d 73 04             	lea    0x4(%ebx),%esi
80103c0a:	83 ec 0c             	sub    $0xc,%esp
80103c0d:	56                   	push   %esi
80103c0e:	e8 b9 01 00 00       	call   80103dcc <acquire>
  lk->locked = 0;
80103c13:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
80103c19:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
80103c20:	89 1c 24             	mov    %ebx,(%esp)
80103c23:	e8 51 fd ff ff       	call   80103979 <wakeup>
  release(&lk->lk);
80103c28:	89 34 24             	mov    %esi,(%esp)
80103c2b:	e8 03 02 00 00       	call   80103e33 <release>
}
80103c30:	83 c4 10             	add    $0x10,%esp
80103c33:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103c36:	5b                   	pop    %ebx
80103c37:	5e                   	pop    %esi
80103c38:	5d                   	pop    %ebp
80103c39:	c3                   	ret    

80103c3a <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
80103c3a:	55                   	push   %ebp
80103c3b:	89 e5                	mov    %esp,%ebp
80103c3d:	57                   	push   %edi
80103c3e:	56                   	push   %esi
80103c3f:	53                   	push   %ebx
80103c40:	83 ec 18             	sub    $0x18,%esp
80103c43:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
80103c46:	8d 73 04             	lea    0x4(%ebx),%esi
80103c49:	56                   	push   %esi
80103c4a:	e8 7d 01 00 00       	call   80103dcc <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
80103c4f:	83 c4 10             	add    $0x10,%esp
80103c52:	bf 00 00 00 00       	mov    $0x0,%edi
80103c57:	83 3b 00             	cmpl   $0x0,(%ebx)
80103c5a:	75 13                	jne    80103c6f <holdingsleep+0x35>
  release(&lk->lk);
80103c5c:	83 ec 0c             	sub    $0xc,%esp
80103c5f:	56                   	push   %esi
80103c60:	e8 ce 01 00 00       	call   80103e33 <release>
  return r;
}
80103c65:	89 f8                	mov    %edi,%eax
80103c67:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103c6a:	5b                   	pop    %ebx
80103c6b:	5e                   	pop    %esi
80103c6c:	5f                   	pop    %edi
80103c6d:	5d                   	pop    %ebp
80103c6e:	c3                   	ret    
  r = lk->locked && (lk->pid == myproc()->pid);
80103c6f:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
80103c72:	e8 d6 f6 ff ff       	call   8010334d <myproc>
80103c77:	39 58 10             	cmp    %ebx,0x10(%eax)
80103c7a:	0f 94 c0             	sete   %al
80103c7d:	0f b6 c0             	movzbl %al,%eax
80103c80:	89 c7                	mov    %eax,%edi
80103c82:	eb d8                	jmp    80103c5c <holdingsleep+0x22>

80103c84 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80103c84:	55                   	push   %ebp
80103c85:	89 e5                	mov    %esp,%ebp
80103c87:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80103c8a:	8b 55 0c             	mov    0xc(%ebp),%edx
80103c8d:	89 50 04             	mov    %edx,0x4(%eax)
  lk->locked = 0;
80103c90:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->cpu = 0;
80103c96:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80103c9d:	5d                   	pop    %ebp
80103c9e:	c3                   	ret    

80103c9f <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80103c9f:	55                   	push   %ebp
80103ca0:	89 e5                	mov    %esp,%ebp
80103ca2:	53                   	push   %ebx
80103ca3:	8b 45 08             	mov    0x8(%ebp),%eax
80103ca6:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
  for(i = 0; i < 10; i++){
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80103ca9:	8d 90 f8 ff ff 7f    	lea    0x7ffffff8(%eax),%edx
80103caf:	81 fa fe ff ff 7f    	cmp    $0x7ffffffe,%edx
80103cb5:	77 2d                	ja     80103ce4 <getcallerpcs+0x45>
      break;
    pcs[i] = ebp[1];     // saved %eip
80103cb7:	8b 50 fc             	mov    -0x4(%eax),%edx
80103cba:	89 11                	mov    %edx,(%ecx)
    ebp = (uint*)ebp[0]; // saved %ebp
80103cbc:	8b 50 f8             	mov    -0x8(%eax),%edx
  for(i = 0; i < 10; i++){
80103cbf:	b8 01 00 00 00       	mov    $0x1,%eax
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80103cc4:	8d 9a 00 00 00 80    	lea    -0x80000000(%edx),%ebx
80103cca:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80103cd0:	77 17                	ja     80103ce9 <getcallerpcs+0x4a>
    pcs[i] = ebp[1];     // saved %eip
80103cd2:	8b 5a 04             	mov    0x4(%edx),%ebx
80103cd5:	89 1c 81             	mov    %ebx,(%ecx,%eax,4)
    ebp = (uint*)ebp[0]; // saved %ebp
80103cd8:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
80103cda:	83 c0 01             	add    $0x1,%eax
80103cdd:	83 f8 0a             	cmp    $0xa,%eax
80103ce0:	75 e2                	jne    80103cc4 <getcallerpcs+0x25>
80103ce2:	eb 14                	jmp    80103cf8 <getcallerpcs+0x59>
80103ce4:	b8 00 00 00 00       	mov    $0x0,%eax
  }
  for(; i < 10; i++)
    pcs[i] = 0;
80103ce9:	c7 04 81 00 00 00 00 	movl   $0x0,(%ecx,%eax,4)
  for(; i < 10; i++)
80103cf0:	83 c0 01             	add    $0x1,%eax
80103cf3:	83 f8 09             	cmp    $0x9,%eax
80103cf6:	7e f1                	jle    80103ce9 <getcallerpcs+0x4a>
}
80103cf8:	5b                   	pop    %ebx
80103cf9:	5d                   	pop    %ebp
80103cfa:	c3                   	ret    

80103cfb <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
80103cfb:	55                   	push   %ebp
80103cfc:	89 e5                	mov    %esp,%ebp
80103cfe:	53                   	push   %ebx
80103cff:	83 ec 04             	sub    $0x4,%esp
80103d02:	9c                   	pushf  
80103d03:	5b                   	pop    %ebx
  asm volatile("cli");
80103d04:	fa                   	cli    
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
80103d05:	e8 b1 f5 ff ff       	call   801032bb <mycpu>
80103d0a:	83 b8 a4 00 00 00 00 	cmpl   $0x0,0xa4(%eax)
80103d11:	74 12                	je     80103d25 <pushcli+0x2a>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
80103d13:	e8 a3 f5 ff ff       	call   801032bb <mycpu>
80103d18:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
80103d1f:	83 c4 04             	add    $0x4,%esp
80103d22:	5b                   	pop    %ebx
80103d23:	5d                   	pop    %ebp
80103d24:	c3                   	ret    
    mycpu()->intena = eflags & FL_IF;
80103d25:	e8 91 f5 ff ff       	call   801032bb <mycpu>
80103d2a:	81 e3 00 02 00 00    	and    $0x200,%ebx
80103d30:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
80103d36:	eb db                	jmp    80103d13 <pushcli+0x18>

80103d38 <popcli>:

void
popcli(void)
{
80103d38:	55                   	push   %ebp
80103d39:	89 e5                	mov    %esp,%ebp
80103d3b:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103d3e:	9c                   	pushf  
80103d3f:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103d40:	f6 c4 02             	test   $0x2,%ah
80103d43:	75 28                	jne    80103d6d <popcli+0x35>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
80103d45:	e8 71 f5 ff ff       	call   801032bb <mycpu>
80103d4a:	8b 88 a4 00 00 00    	mov    0xa4(%eax),%ecx
80103d50:	8d 51 ff             	lea    -0x1(%ecx),%edx
80103d53:	89 90 a4 00 00 00    	mov    %edx,0xa4(%eax)
80103d59:	85 d2                	test   %edx,%edx
80103d5b:	78 1d                	js     80103d7a <popcli+0x42>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
80103d5d:	e8 59 f5 ff ff       	call   801032bb <mycpu>
80103d62:	83 b8 a4 00 00 00 00 	cmpl   $0x0,0xa4(%eax)
80103d69:	74 1c                	je     80103d87 <popcli+0x4f>
    sti();
}
80103d6b:	c9                   	leave  
80103d6c:	c3                   	ret    
    panic("popcli - interruptible");
80103d6d:	83 ec 0c             	sub    $0xc,%esp
80103d70:	68 b3 86 10 80       	push   $0x801086b3
80103d75:	e8 ca c5 ff ff       	call   80100344 <panic>
    panic("popcli");
80103d7a:	83 ec 0c             	sub    $0xc,%esp
80103d7d:	68 ca 86 10 80       	push   $0x801086ca
80103d82:	e8 bd c5 ff ff       	call   80100344 <panic>
  if(mycpu()->ncli == 0 && mycpu()->intena)
80103d87:	e8 2f f5 ff ff       	call   801032bb <mycpu>
80103d8c:	83 b8 a8 00 00 00 00 	cmpl   $0x0,0xa8(%eax)
80103d93:	74 d6                	je     80103d6b <popcli+0x33>
  asm volatile("sti");
80103d95:	fb                   	sti    
}
80103d96:	eb d3                	jmp    80103d6b <popcli+0x33>

80103d98 <holding>:
{
80103d98:	55                   	push   %ebp
80103d99:	89 e5                	mov    %esp,%ebp
80103d9b:	56                   	push   %esi
80103d9c:	53                   	push   %ebx
80103d9d:	8b 75 08             	mov    0x8(%ebp),%esi
  pushcli();
80103da0:	e8 56 ff ff ff       	call   80103cfb <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80103da5:	bb 00 00 00 00       	mov    $0x0,%ebx
80103daa:	83 3e 00             	cmpl   $0x0,(%esi)
80103dad:	75 0b                	jne    80103dba <holding+0x22>
  popcli();
80103daf:	e8 84 ff ff ff       	call   80103d38 <popcli>
}
80103db4:	89 d8                	mov    %ebx,%eax
80103db6:	5b                   	pop    %ebx
80103db7:	5e                   	pop    %esi
80103db8:	5d                   	pop    %ebp
80103db9:	c3                   	ret    
  r = lock->locked && lock->cpu == mycpu();
80103dba:	8b 5e 08             	mov    0x8(%esi),%ebx
80103dbd:	e8 f9 f4 ff ff       	call   801032bb <mycpu>
80103dc2:	39 c3                	cmp    %eax,%ebx
80103dc4:	0f 94 c3             	sete   %bl
80103dc7:	0f b6 db             	movzbl %bl,%ebx
80103dca:	eb e3                	jmp    80103daf <holding+0x17>

80103dcc <acquire>:
{
80103dcc:	55                   	push   %ebp
80103dcd:	89 e5                	mov    %esp,%ebp
80103dcf:	53                   	push   %ebx
80103dd0:	83 ec 04             	sub    $0x4,%esp
  pushcli(); // disable interrupts to avoid deadlock.
80103dd3:	e8 23 ff ff ff       	call   80103cfb <pushcli>
  if(holding(lk))
80103dd8:	83 ec 0c             	sub    $0xc,%esp
80103ddb:	ff 75 08             	pushl  0x8(%ebp)
80103dde:	e8 b5 ff ff ff       	call   80103d98 <holding>
80103de3:	83 c4 10             	add    $0x10,%esp
80103de6:	85 c0                	test   %eax,%eax
80103de8:	75 3c                	jne    80103e26 <acquire+0x5a>
  asm volatile("lock; xchgl %0, %1" :
80103dea:	b9 01 00 00 00       	mov    $0x1,%ecx
  while(xchg(&lk->locked, 1) != 0)
80103def:	8b 55 08             	mov    0x8(%ebp),%edx
80103df2:	89 c8                	mov    %ecx,%eax
80103df4:	f0 87 02             	lock xchg %eax,(%edx)
80103df7:	85 c0                	test   %eax,%eax
80103df9:	75 f4                	jne    80103def <acquire+0x23>
  __sync_synchronize();
80103dfb:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80103e00:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103e03:	e8 b3 f4 ff ff       	call   801032bb <mycpu>
80103e08:	89 43 08             	mov    %eax,0x8(%ebx)
  getcallerpcs(&lk, lk->pcs);
80103e0b:	83 ec 08             	sub    $0x8,%esp
80103e0e:	8b 45 08             	mov    0x8(%ebp),%eax
80103e11:	83 c0 0c             	add    $0xc,%eax
80103e14:	50                   	push   %eax
80103e15:	8d 45 08             	lea    0x8(%ebp),%eax
80103e18:	50                   	push   %eax
80103e19:	e8 81 fe ff ff       	call   80103c9f <getcallerpcs>
}
80103e1e:	83 c4 10             	add    $0x10,%esp
80103e21:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103e24:	c9                   	leave  
80103e25:	c3                   	ret    
    panic("acquire");
80103e26:	83 ec 0c             	sub    $0xc,%esp
80103e29:	68 d1 86 10 80       	push   $0x801086d1
80103e2e:	e8 11 c5 ff ff       	call   80100344 <panic>

80103e33 <release>:
{
80103e33:	55                   	push   %ebp
80103e34:	89 e5                	mov    %esp,%ebp
80103e36:	53                   	push   %ebx
80103e37:	83 ec 10             	sub    $0x10,%esp
80103e3a:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holding(lk))
80103e3d:	53                   	push   %ebx
80103e3e:	e8 55 ff ff ff       	call   80103d98 <holding>
80103e43:	83 c4 10             	add    $0x10,%esp
80103e46:	85 c0                	test   %eax,%eax
80103e48:	74 23                	je     80103e6d <release+0x3a>
  lk->pcs[0] = 0;
80103e4a:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
80103e51:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
80103e58:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
80103e5d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  popcli();
80103e63:	e8 d0 fe ff ff       	call   80103d38 <popcli>
}
80103e68:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103e6b:	c9                   	leave  
80103e6c:	c3                   	ret    
    panic("release");
80103e6d:	83 ec 0c             	sub    $0xc,%esp
80103e70:	68 d9 86 10 80       	push   $0x801086d9
80103e75:	e8 ca c4 ff ff       	call   80100344 <panic>

80103e7a <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
80103e7a:	55                   	push   %ebp
80103e7b:	89 e5                	mov    %esp,%ebp
80103e7d:	57                   	push   %edi
80103e7e:	53                   	push   %ebx
80103e7f:	8b 55 08             	mov    0x8(%ebp),%edx
80103e82:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
80103e85:	f6 c2 03             	test   $0x3,%dl
80103e88:	75 05                	jne    80103e8f <memset+0x15>
80103e8a:	f6 c1 03             	test   $0x3,%cl
80103e8d:	74 0e                	je     80103e9d <memset+0x23>
  asm volatile("cld; rep stosb" :
80103e8f:	89 d7                	mov    %edx,%edi
80103e91:	8b 45 0c             	mov    0xc(%ebp),%eax
80103e94:	fc                   	cld    
80103e95:	f3 aa                	rep stos %al,%es:(%edi)
    c &= 0xFF;
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
  } else
    stosb(dst, c, n);
  return dst;
}
80103e97:	89 d0                	mov    %edx,%eax
80103e99:	5b                   	pop    %ebx
80103e9a:	5f                   	pop    %edi
80103e9b:	5d                   	pop    %ebp
80103e9c:	c3                   	ret    
    c &= 0xFF;
80103e9d:	0f b6 7d 0c          	movzbl 0xc(%ebp),%edi
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80103ea1:	c1 e9 02             	shr    $0x2,%ecx
80103ea4:	89 f8                	mov    %edi,%eax
80103ea6:	c1 e0 18             	shl    $0x18,%eax
80103ea9:	89 fb                	mov    %edi,%ebx
80103eab:	c1 e3 10             	shl    $0x10,%ebx
80103eae:	09 d8                	or     %ebx,%eax
80103eb0:	09 f8                	or     %edi,%eax
80103eb2:	c1 e7 08             	shl    $0x8,%edi
80103eb5:	09 f8                	or     %edi,%eax
  asm volatile("cld; rep stosl" :
80103eb7:	89 d7                	mov    %edx,%edi
80103eb9:	fc                   	cld    
80103eba:	f3 ab                	rep stos %eax,%es:(%edi)
80103ebc:	eb d9                	jmp    80103e97 <memset+0x1d>

80103ebe <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80103ebe:	55                   	push   %ebp
80103ebf:	89 e5                	mov    %esp,%ebp
80103ec1:	57                   	push   %edi
80103ec2:	56                   	push   %esi
80103ec3:	53                   	push   %ebx
80103ec4:	8b 75 08             	mov    0x8(%ebp),%esi
80103ec7:	8b 7d 0c             	mov    0xc(%ebp),%edi
80103eca:	8b 5d 10             	mov    0x10(%ebp),%ebx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
80103ecd:	85 db                	test   %ebx,%ebx
80103ecf:	74 37                	je     80103f08 <memcmp+0x4a>
    if(*s1 != *s2)
80103ed1:	0f b6 16             	movzbl (%esi),%edx
80103ed4:	0f b6 0f             	movzbl (%edi),%ecx
80103ed7:	38 ca                	cmp    %cl,%dl
80103ed9:	75 19                	jne    80103ef4 <memcmp+0x36>
80103edb:	b8 01 00 00 00       	mov    $0x1,%eax
  while(n-- > 0){
80103ee0:	39 d8                	cmp    %ebx,%eax
80103ee2:	74 1d                	je     80103f01 <memcmp+0x43>
    if(*s1 != *s2)
80103ee4:	0f b6 14 06          	movzbl (%esi,%eax,1),%edx
80103ee8:	83 c0 01             	add    $0x1,%eax
80103eeb:	0f b6 4c 07 ff       	movzbl -0x1(%edi,%eax,1),%ecx
80103ef0:	38 ca                	cmp    %cl,%dl
80103ef2:	74 ec                	je     80103ee0 <memcmp+0x22>
      return *s1 - *s2;
80103ef4:	0f b6 c2             	movzbl %dl,%eax
80103ef7:	0f b6 c9             	movzbl %cl,%ecx
80103efa:	29 c8                	sub    %ecx,%eax
    s1++, s2++;
  }

  return 0;
}
80103efc:	5b                   	pop    %ebx
80103efd:	5e                   	pop    %esi
80103efe:	5f                   	pop    %edi
80103eff:	5d                   	pop    %ebp
80103f00:	c3                   	ret    
  return 0;
80103f01:	b8 00 00 00 00       	mov    $0x0,%eax
80103f06:	eb f4                	jmp    80103efc <memcmp+0x3e>
80103f08:	b8 00 00 00 00       	mov    $0x0,%eax
80103f0d:	eb ed                	jmp    80103efc <memcmp+0x3e>

80103f0f <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80103f0f:	55                   	push   %ebp
80103f10:	89 e5                	mov    %esp,%ebp
80103f12:	56                   	push   %esi
80103f13:	53                   	push   %ebx
80103f14:	8b 45 08             	mov    0x8(%ebp),%eax
80103f17:	8b 5d 0c             	mov    0xc(%ebp),%ebx
80103f1a:	8b 75 10             	mov    0x10(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
80103f1d:	39 c3                	cmp    %eax,%ebx
80103f1f:	72 1b                	jb     80103f3c <memmove+0x2d>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
80103f21:	ba 00 00 00 00       	mov    $0x0,%edx
80103f26:	85 f6                	test   %esi,%esi
80103f28:	74 0e                	je     80103f38 <memmove+0x29>
      *d++ = *s++;
80103f2a:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
80103f2e:	88 0c 10             	mov    %cl,(%eax,%edx,1)
80103f31:	83 c2 01             	add    $0x1,%edx
    while(n-- > 0)
80103f34:	39 d6                	cmp    %edx,%esi
80103f36:	75 f2                	jne    80103f2a <memmove+0x1b>

  return dst;
}
80103f38:	5b                   	pop    %ebx
80103f39:	5e                   	pop    %esi
80103f3a:	5d                   	pop    %ebp
80103f3b:	c3                   	ret    
  if(s < d && s + n > d){
80103f3c:	8d 14 33             	lea    (%ebx,%esi,1),%edx
80103f3f:	39 d0                	cmp    %edx,%eax
80103f41:	73 de                	jae    80103f21 <memmove+0x12>
    while(n-- > 0)
80103f43:	8d 56 ff             	lea    -0x1(%esi),%edx
80103f46:	85 f6                	test   %esi,%esi
80103f48:	74 ee                	je     80103f38 <memmove+0x29>
      *--d = *--s;
80103f4a:	0f b6 0c 13          	movzbl (%ebx,%edx,1),%ecx
80103f4e:	88 0c 10             	mov    %cl,(%eax,%edx,1)
    while(n-- > 0)
80103f51:	83 ea 01             	sub    $0x1,%edx
80103f54:	83 fa ff             	cmp    $0xffffffff,%edx
80103f57:	75 f1                	jne    80103f4a <memmove+0x3b>
80103f59:	eb dd                	jmp    80103f38 <memmove+0x29>

80103f5b <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
80103f5b:	55                   	push   %ebp
80103f5c:	89 e5                	mov    %esp,%ebp
  return memmove(dst, src, n);
80103f5e:	ff 75 10             	pushl  0x10(%ebp)
80103f61:	ff 75 0c             	pushl  0xc(%ebp)
80103f64:	ff 75 08             	pushl  0x8(%ebp)
80103f67:	e8 a3 ff ff ff       	call   80103f0f <memmove>
}
80103f6c:	c9                   	leave  
80103f6d:	c3                   	ret    

80103f6e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
80103f6e:	55                   	push   %ebp
80103f6f:	89 e5                	mov    %esp,%ebp
80103f71:	53                   	push   %ebx
80103f72:	8b 45 08             	mov    0x8(%ebp),%eax
80103f75:	8b 55 0c             	mov    0xc(%ebp),%edx
80103f78:	8b 5d 10             	mov    0x10(%ebp),%ebx
  while(n > 0 && *p && *p == *q)
80103f7b:	85 db                	test   %ebx,%ebx
80103f7d:	74 2d                	je     80103fac <strncmp+0x3e>
80103f7f:	0f b6 08             	movzbl (%eax),%ecx
80103f82:	84 c9                	test   %cl,%cl
80103f84:	74 1b                	je     80103fa1 <strncmp+0x33>
80103f86:	3a 0a                	cmp    (%edx),%cl
80103f88:	75 17                	jne    80103fa1 <strncmp+0x33>
80103f8a:	01 c3                	add    %eax,%ebx
    n--, p++, q++;
80103f8c:	83 c0 01             	add    $0x1,%eax
80103f8f:	83 c2 01             	add    $0x1,%edx
  while(n > 0 && *p && *p == *q)
80103f92:	39 d8                	cmp    %ebx,%eax
80103f94:	74 1d                	je     80103fb3 <strncmp+0x45>
80103f96:	0f b6 08             	movzbl (%eax),%ecx
80103f99:	84 c9                	test   %cl,%cl
80103f9b:	74 04                	je     80103fa1 <strncmp+0x33>
80103f9d:	3a 0a                	cmp    (%edx),%cl
80103f9f:	74 eb                	je     80103f8c <strncmp+0x1e>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
80103fa1:	0f b6 00             	movzbl (%eax),%eax
80103fa4:	0f b6 12             	movzbl (%edx),%edx
80103fa7:	29 d0                	sub    %edx,%eax
}
80103fa9:	5b                   	pop    %ebx
80103faa:	5d                   	pop    %ebp
80103fab:	c3                   	ret    
    return 0;
80103fac:	b8 00 00 00 00       	mov    $0x0,%eax
80103fb1:	eb f6                	jmp    80103fa9 <strncmp+0x3b>
80103fb3:	b8 00 00 00 00       	mov    $0x0,%eax
80103fb8:	eb ef                	jmp    80103fa9 <strncmp+0x3b>

80103fba <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80103fba:	55                   	push   %ebp
80103fbb:	89 e5                	mov    %esp,%ebp
80103fbd:	57                   	push   %edi
80103fbe:	56                   	push   %esi
80103fbf:	53                   	push   %ebx
80103fc0:	8b 7d 08             	mov    0x8(%ebp),%edi
80103fc3:	8b 5d 0c             	mov    0xc(%ebp),%ebx
80103fc6:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
80103fc9:	89 f9                	mov    %edi,%ecx
80103fcb:	eb 02                	jmp    80103fcf <strncpy+0x15>
80103fcd:	89 f2                	mov    %esi,%edx
80103fcf:	8d 72 ff             	lea    -0x1(%edx),%esi
80103fd2:	85 d2                	test   %edx,%edx
80103fd4:	7e 11                	jle    80103fe7 <strncpy+0x2d>
80103fd6:	83 c3 01             	add    $0x1,%ebx
80103fd9:	83 c1 01             	add    $0x1,%ecx
80103fdc:	0f b6 43 ff          	movzbl -0x1(%ebx),%eax
80103fe0:	88 41 ff             	mov    %al,-0x1(%ecx)
80103fe3:	84 c0                	test   %al,%al
80103fe5:	75 e6                	jne    80103fcd <strncpy+0x13>
    ;
  while(n-- > 0)
80103fe7:	bb 00 00 00 00       	mov    $0x0,%ebx
80103fec:	83 ea 01             	sub    $0x1,%edx
80103fef:	85 f6                	test   %esi,%esi
80103ff1:	7e 0f                	jle    80104002 <strncpy+0x48>
    *s++ = 0;
80103ff3:	c6 04 19 00          	movb   $0x0,(%ecx,%ebx,1)
80103ff7:	83 c3 01             	add    $0x1,%ebx
80103ffa:	89 d6                	mov    %edx,%esi
80103ffc:	29 de                	sub    %ebx,%esi
  while(n-- > 0)
80103ffe:	85 f6                	test   %esi,%esi
80104000:	7f f1                	jg     80103ff3 <strncpy+0x39>
  return os;
}
80104002:	89 f8                	mov    %edi,%eax
80104004:	5b                   	pop    %ebx
80104005:	5e                   	pop    %esi
80104006:	5f                   	pop    %edi
80104007:	5d                   	pop    %ebp
80104008:	c3                   	ret    

80104009 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
80104009:	55                   	push   %ebp
8010400a:	89 e5                	mov    %esp,%ebp
8010400c:	56                   	push   %esi
8010400d:	53                   	push   %ebx
8010400e:	8b 45 08             	mov    0x8(%ebp),%eax
80104011:	8b 55 0c             	mov    0xc(%ebp),%edx
80104014:	8b 4d 10             	mov    0x10(%ebp),%ecx
  char *os;

  os = s;
  if(n <= 0)
80104017:	85 c9                	test   %ecx,%ecx
80104019:	7e 1e                	jle    80104039 <safestrcpy+0x30>
8010401b:	8d 74 0a ff          	lea    -0x1(%edx,%ecx,1),%esi
8010401f:	89 c1                	mov    %eax,%ecx
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
80104021:	39 f2                	cmp    %esi,%edx
80104023:	74 11                	je     80104036 <safestrcpy+0x2d>
80104025:	83 c2 01             	add    $0x1,%edx
80104028:	83 c1 01             	add    $0x1,%ecx
8010402b:	0f b6 5a ff          	movzbl -0x1(%edx),%ebx
8010402f:	88 59 ff             	mov    %bl,-0x1(%ecx)
80104032:	84 db                	test   %bl,%bl
80104034:	75 eb                	jne    80104021 <safestrcpy+0x18>
    ;
  *s = 0;
80104036:	c6 01 00             	movb   $0x0,(%ecx)
  return os;
}
80104039:	5b                   	pop    %ebx
8010403a:	5e                   	pop    %esi
8010403b:	5d                   	pop    %ebp
8010403c:	c3                   	ret    

8010403d <strlen>:

int
strlen(const char *s)
{
8010403d:	55                   	push   %ebp
8010403e:	89 e5                	mov    %esp,%ebp
80104040:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
80104043:	80 3a 00             	cmpb   $0x0,(%edx)
80104046:	74 10                	je     80104058 <strlen+0x1b>
80104048:	b8 00 00 00 00       	mov    $0x0,%eax
8010404d:	83 c0 01             	add    $0x1,%eax
80104050:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
80104054:	75 f7                	jne    8010404d <strlen+0x10>
    ;
  return n;
}
80104056:	5d                   	pop    %ebp
80104057:	c3                   	ret    
  for(n = 0; s[n]; n++)
80104058:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
8010405d:	eb f7                	jmp    80104056 <strlen+0x19>

8010405f <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
8010405f:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
80104063:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80104067:	55                   	push   %ebp
  pushl %ebx
80104068:	53                   	push   %ebx
  pushl %esi
80104069:	56                   	push   %esi
  pushl %edi
8010406a:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
8010406b:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
8010406d:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
8010406f:	5f                   	pop    %edi
  popl %esi
80104070:	5e                   	pop    %esi
  popl %ebx
80104071:	5b                   	pop    %ebx
  popl %ebp
80104072:	5d                   	pop    %ebp
  ret
80104073:	c3                   	ret    

80104074 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80104074:	55                   	push   %ebp
80104075:	89 e5                	mov    %esp,%ebp
80104077:	53                   	push   %ebx
80104078:	83 ec 04             	sub    $0x4,%esp
8010407b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
8010407e:	e8 ca f2 ff ff       	call   8010334d <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104083:	8b 00                	mov    (%eax),%eax
80104085:	39 d8                	cmp    %ebx,%eax
80104087:	76 19                	jbe    801040a2 <fetchint+0x2e>
80104089:	8d 53 04             	lea    0x4(%ebx),%edx
8010408c:	39 d0                	cmp    %edx,%eax
8010408e:	72 19                	jb     801040a9 <fetchint+0x35>
    return -1;
  *ip = *(int*)(addr);
80104090:	8b 13                	mov    (%ebx),%edx
80104092:	8b 45 0c             	mov    0xc(%ebp),%eax
80104095:	89 10                	mov    %edx,(%eax)
  return 0;
80104097:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010409c:	83 c4 04             	add    $0x4,%esp
8010409f:	5b                   	pop    %ebx
801040a0:	5d                   	pop    %ebp
801040a1:	c3                   	ret    
    return -1;
801040a2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040a7:	eb f3                	jmp    8010409c <fetchint+0x28>
801040a9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040ae:	eb ec                	jmp    8010409c <fetchint+0x28>

801040b0 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
801040b0:	55                   	push   %ebp
801040b1:	89 e5                	mov    %esp,%ebp
801040b3:	53                   	push   %ebx
801040b4:	83 ec 04             	sub    $0x4,%esp
801040b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
801040ba:	e8 8e f2 ff ff       	call   8010334d <myproc>

  if(addr >= curproc->sz)
801040bf:	39 18                	cmp    %ebx,(%eax)
801040c1:	76 2f                	jbe    801040f2 <fetchstr+0x42>
    return -1;
  *pp = (char*)addr;
801040c3:	89 da                	mov    %ebx,%edx
801040c5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801040c8:	89 19                	mov    %ebx,(%ecx)
  ep = (char*)curproc->sz;
801040ca:	8b 00                	mov    (%eax),%eax
  for(s = *pp; s < ep; s++){
801040cc:	39 c3                	cmp    %eax,%ebx
801040ce:	73 29                	jae    801040f9 <fetchstr+0x49>
    if(*s == 0)
801040d0:	80 3b 00             	cmpb   $0x0,(%ebx)
801040d3:	74 0c                	je     801040e1 <fetchstr+0x31>
  for(s = *pp; s < ep; s++){
801040d5:	83 c2 01             	add    $0x1,%edx
801040d8:	39 d0                	cmp    %edx,%eax
801040da:	76 0f                	jbe    801040eb <fetchstr+0x3b>
    if(*s == 0)
801040dc:	80 3a 00             	cmpb   $0x0,(%edx)
801040df:	75 f4                	jne    801040d5 <fetchstr+0x25>
      return s - *pp;
801040e1:	89 d0                	mov    %edx,%eax
801040e3:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
801040e5:	83 c4 04             	add    $0x4,%esp
801040e8:	5b                   	pop    %ebx
801040e9:	5d                   	pop    %ebp
801040ea:	c3                   	ret    
  return -1;
801040eb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040f0:	eb f3                	jmp    801040e5 <fetchstr+0x35>
    return -1;
801040f2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040f7:	eb ec                	jmp    801040e5 <fetchstr+0x35>
  return -1;
801040f9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801040fe:	eb e5                	jmp    801040e5 <fetchstr+0x35>

80104100 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104100:	55                   	push   %ebp
80104101:	89 e5                	mov    %esp,%ebp
80104103:	83 ec 08             	sub    $0x8,%esp
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104106:	e8 42 f2 ff ff       	call   8010334d <myproc>
8010410b:	83 ec 08             	sub    $0x8,%esp
8010410e:	ff 75 0c             	pushl  0xc(%ebp)
80104111:	8b 40 18             	mov    0x18(%eax),%eax
80104114:	8b 40 44             	mov    0x44(%eax),%eax
80104117:	8b 55 08             	mov    0x8(%ebp),%edx
8010411a:	8d 44 90 04          	lea    0x4(%eax,%edx,4),%eax
8010411e:	50                   	push   %eax
8010411f:	e8 50 ff ff ff       	call   80104074 <fetchint>
}
80104124:	c9                   	leave  
80104125:	c3                   	ret    

80104126 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80104126:	55                   	push   %ebp
80104127:	89 e5                	mov    %esp,%ebp
80104129:	56                   	push   %esi
8010412a:	53                   	push   %ebx
8010412b:	83 ec 10             	sub    $0x10,%esp
8010412e:	8b 5d 10             	mov    0x10(%ebp),%ebx
  int i;
  struct proc *curproc = myproc();
80104131:	e8 17 f2 ff ff       	call   8010334d <myproc>
80104136:	89 c6                	mov    %eax,%esi
 
  if(argint(n, &i) < 0)
80104138:	83 ec 08             	sub    $0x8,%esp
8010413b:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010413e:	50                   	push   %eax
8010413f:	ff 75 08             	pushl  0x8(%ebp)
80104142:	e8 b9 ff ff ff       	call   80104100 <argint>
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104147:	83 c4 10             	add    $0x10,%esp
8010414a:	85 db                	test   %ebx,%ebx
8010414c:	78 24                	js     80104172 <argptr+0x4c>
8010414e:	85 c0                	test   %eax,%eax
80104150:	78 20                	js     80104172 <argptr+0x4c>
80104152:	8b 16                	mov    (%esi),%edx
80104154:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104157:	39 c2                	cmp    %eax,%edx
80104159:	76 1e                	jbe    80104179 <argptr+0x53>
8010415b:	01 c3                	add    %eax,%ebx
8010415d:	39 da                	cmp    %ebx,%edx
8010415f:	72 1f                	jb     80104180 <argptr+0x5a>
    return -1;
  *pp = (char*)i;
80104161:	8b 55 0c             	mov    0xc(%ebp),%edx
80104164:	89 02                	mov    %eax,(%edx)
  return 0;
80104166:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010416b:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010416e:	5b                   	pop    %ebx
8010416f:	5e                   	pop    %esi
80104170:	5d                   	pop    %ebp
80104171:	c3                   	ret    
    return -1;
80104172:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104177:	eb f2                	jmp    8010416b <argptr+0x45>
80104179:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010417e:	eb eb                	jmp    8010416b <argptr+0x45>
80104180:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104185:	eb e4                	jmp    8010416b <argptr+0x45>

80104187 <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
80104187:	55                   	push   %ebp
80104188:	89 e5                	mov    %esp,%ebp
8010418a:	83 ec 20             	sub    $0x20,%esp
  int addr;
  if(argint(n, &addr) < 0)
8010418d:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104190:	50                   	push   %eax
80104191:	ff 75 08             	pushl  0x8(%ebp)
80104194:	e8 67 ff ff ff       	call   80104100 <argint>
80104199:	83 c4 10             	add    $0x10,%esp
8010419c:	85 c0                	test   %eax,%eax
8010419e:	78 13                	js     801041b3 <argstr+0x2c>
    return -1;
  return fetchstr(addr, pp);
801041a0:	83 ec 08             	sub    $0x8,%esp
801041a3:	ff 75 0c             	pushl  0xc(%ebp)
801041a6:	ff 75 f4             	pushl  -0xc(%ebp)
801041a9:	e8 02 ff ff ff       	call   801040b0 <fetchstr>
801041ae:	83 c4 10             	add    $0x10,%esp
}
801041b1:	c9                   	leave  
801041b2:	c3                   	ret    
    return -1;
801041b3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801041b8:	eb f7                	jmp    801041b1 <argstr+0x2a>

801041ba <syscall>:
[SYS_ps]		sys_ps,
};

void
syscall(void)
{
801041ba:	55                   	push   %ebp
801041bb:	89 e5                	mov    %esp,%ebp
801041bd:	53                   	push   %ebx
801041be:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
801041c1:	e8 87 f1 ff ff       	call   8010334d <myproc>
801041c6:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
801041c8:	8b 40 18             	mov    0x18(%eax),%eax
801041cb:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
801041ce:	8d 50 ff             	lea    -0x1(%eax),%edx
801041d1:	83 fa 16             	cmp    $0x16,%edx
801041d4:	77 18                	ja     801041ee <syscall+0x34>
801041d6:	8b 14 85 00 87 10 80 	mov    -0x7fef7900(,%eax,4),%edx
801041dd:	85 d2                	test   %edx,%edx
801041df:	74 0d                	je     801041ee <syscall+0x34>
    curproc->tf->eax = syscalls[num]();
801041e1:	ff d2                	call   *%edx
801041e3:	8b 53 18             	mov    0x18(%ebx),%edx
801041e6:	89 42 1c             	mov    %eax,0x1c(%edx)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
801041e9:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801041ec:	c9                   	leave  
801041ed:	c3                   	ret    
    cprintf("%d %s: unknown sys call %d\n",
801041ee:	50                   	push   %eax
            curproc->pid, curproc->name, num);
801041ef:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
801041f2:	50                   	push   %eax
801041f3:	ff 73 10             	pushl  0x10(%ebx)
801041f6:	68 e1 86 10 80       	push   $0x801086e1
801041fb:	e8 e1 c3 ff ff       	call   801005e1 <cprintf>
    curproc->tf->eax = -1;
80104200:	8b 43 18             	mov    0x18(%ebx),%eax
80104203:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
8010420a:	83 c4 10             	add    $0x10,%esp
}
8010420d:	eb da                	jmp    801041e9 <syscall+0x2f>

8010420f <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
8010420f:	55                   	push   %ebp
80104210:	89 e5                	mov    %esp,%ebp
80104212:	56                   	push   %esi
80104213:	53                   	push   %ebx
80104214:	83 ec 18             	sub    $0x18,%esp
80104217:	89 d6                	mov    %edx,%esi
80104219:	89 cb                	mov    %ecx,%ebx
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
8010421b:	8d 55 f4             	lea    -0xc(%ebp),%edx
8010421e:	52                   	push   %edx
8010421f:	50                   	push   %eax
80104220:	e8 db fe ff ff       	call   80104100 <argint>
80104225:	83 c4 10             	add    $0x10,%esp
80104228:	85 c0                	test   %eax,%eax
8010422a:	78 2e                	js     8010425a <argfd+0x4b>
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
8010422c:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104230:	77 2f                	ja     80104261 <argfd+0x52>
80104232:	e8 16 f1 ff ff       	call   8010334d <myproc>
80104237:	8b 4d f4             	mov    -0xc(%ebp),%ecx
8010423a:	8b 54 88 28          	mov    0x28(%eax,%ecx,4),%edx
8010423e:	85 d2                	test   %edx,%edx
80104240:	74 26                	je     80104268 <argfd+0x59>
    return -1;
  if(pfd)
80104242:	85 f6                	test   %esi,%esi
80104244:	74 02                	je     80104248 <argfd+0x39>
    *pfd = fd;
80104246:	89 0e                	mov    %ecx,(%esi)
  if(pf)
    *pf = f;
  return 0;
80104248:	b8 00 00 00 00       	mov    $0x0,%eax
  if(pf)
8010424d:	85 db                	test   %ebx,%ebx
8010424f:	74 02                	je     80104253 <argfd+0x44>
    *pf = f;
80104251:	89 13                	mov    %edx,(%ebx)
}
80104253:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104256:	5b                   	pop    %ebx
80104257:	5e                   	pop    %esi
80104258:	5d                   	pop    %ebp
80104259:	c3                   	ret    
    return -1;
8010425a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010425f:	eb f2                	jmp    80104253 <argfd+0x44>
    return -1;
80104261:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104266:	eb eb                	jmp    80104253 <argfd+0x44>
80104268:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010426d:	eb e4                	jmp    80104253 <argfd+0x44>

8010426f <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
8010426f:	55                   	push   %ebp
80104270:	89 e5                	mov    %esp,%ebp
80104272:	53                   	push   %ebx
80104273:	83 ec 04             	sub    $0x4,%esp
80104276:	89 c3                	mov    %eax,%ebx
  int fd;
  struct proc *curproc = myproc();
80104278:	e8 d0 f0 ff ff       	call   8010334d <myproc>

  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd] == 0){
8010427d:	83 78 28 00          	cmpl   $0x0,0x28(%eax)
80104281:	74 1b                	je     8010429e <fdalloc+0x2f>
  for(fd = 0; fd < NOFILE; fd++){
80104283:	ba 01 00 00 00       	mov    $0x1,%edx
    if(curproc->ofile[fd] == 0){
80104288:	83 7c 90 28 00       	cmpl   $0x0,0x28(%eax,%edx,4)
8010428d:	74 14                	je     801042a3 <fdalloc+0x34>
  for(fd = 0; fd < NOFILE; fd++){
8010428f:	83 c2 01             	add    $0x1,%edx
80104292:	83 fa 10             	cmp    $0x10,%edx
80104295:	75 f1                	jne    80104288 <fdalloc+0x19>
      curproc->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
80104297:	ba ff ff ff ff       	mov    $0xffffffff,%edx
8010429c:	eb 09                	jmp    801042a7 <fdalloc+0x38>
  for(fd = 0; fd < NOFILE; fd++){
8010429e:	ba 00 00 00 00       	mov    $0x0,%edx
      curproc->ofile[fd] = f;
801042a3:	89 5c 90 28          	mov    %ebx,0x28(%eax,%edx,4)
}
801042a7:	89 d0                	mov    %edx,%eax
801042a9:	83 c4 04             	add    $0x4,%esp
801042ac:	5b                   	pop    %ebx
801042ad:	5d                   	pop    %ebp
801042ae:	c3                   	ret    

801042af <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
801042af:	55                   	push   %ebp
801042b0:	89 e5                	mov    %esp,%ebp
801042b2:	57                   	push   %edi
801042b3:	56                   	push   %esi
801042b4:	53                   	push   %ebx
801042b5:	83 ec 34             	sub    $0x34,%esp
801042b8:	89 55 d4             	mov    %edx,-0x2c(%ebp)
801042bb:	89 4d d0             	mov    %ecx,-0x30(%ebp)
801042be:	8b 7d 08             	mov    0x8(%ebp),%edi
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
801042c1:	8d 55 da             	lea    -0x26(%ebp),%edx
801042c4:	52                   	push   %edx
801042c5:	50                   	push   %eax
801042c6:	e8 d0 d9 ff ff       	call   80101c9b <nameiparent>
801042cb:	89 c6                	mov    %eax,%esi
801042cd:	83 c4 10             	add    $0x10,%esp
801042d0:	85 c0                	test   %eax,%eax
801042d2:	0f 84 32 01 00 00    	je     8010440a <create+0x15b>
    return 0;
  ilock(dp);
801042d8:	83 ec 0c             	sub    $0xc,%esp
801042db:	50                   	push   %eax
801042dc:	e8 05 d2 ff ff       	call   801014e6 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
801042e1:	83 c4 0c             	add    $0xc,%esp
801042e4:	6a 00                	push   $0x0
801042e6:	8d 45 da             	lea    -0x26(%ebp),%eax
801042e9:	50                   	push   %eax
801042ea:	56                   	push   %esi
801042eb:	e8 bc d6 ff ff       	call   801019ac <dirlookup>
801042f0:	89 c3                	mov    %eax,%ebx
801042f2:	83 c4 10             	add    $0x10,%esp
801042f5:	85 c0                	test   %eax,%eax
801042f7:	74 3f                	je     80104338 <create+0x89>
    iunlockput(dp);
801042f9:	83 ec 0c             	sub    $0xc,%esp
801042fc:	56                   	push   %esi
801042fd:	e8 2d d4 ff ff       	call   8010172f <iunlockput>
    ilock(ip);
80104302:	89 1c 24             	mov    %ebx,(%esp)
80104305:	e8 dc d1 ff ff       	call   801014e6 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
8010430a:	83 c4 10             	add    $0x10,%esp
8010430d:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
80104312:	75 11                	jne    80104325 <create+0x76>
80104314:	66 83 7b 50 02       	cmpw   $0x2,0x50(%ebx)
80104319:	75 0a                	jne    80104325 <create+0x76>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
8010431b:	89 d8                	mov    %ebx,%eax
8010431d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104320:	5b                   	pop    %ebx
80104321:	5e                   	pop    %esi
80104322:	5f                   	pop    %edi
80104323:	5d                   	pop    %ebp
80104324:	c3                   	ret    
    iunlockput(ip);
80104325:	83 ec 0c             	sub    $0xc,%esp
80104328:	53                   	push   %ebx
80104329:	e8 01 d4 ff ff       	call   8010172f <iunlockput>
    return 0;
8010432e:	83 c4 10             	add    $0x10,%esp
80104331:	bb 00 00 00 00       	mov    $0x0,%ebx
80104336:	eb e3                	jmp    8010431b <create+0x6c>
  if((ip = ialloc(dp->dev, type)) == 0)
80104338:	83 ec 08             	sub    $0x8,%esp
8010433b:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
8010433f:	50                   	push   %eax
80104340:	ff 36                	pushl  (%esi)
80104342:	e8 4c d0 ff ff       	call   80101393 <ialloc>
80104347:	89 c3                	mov    %eax,%ebx
80104349:	83 c4 10             	add    $0x10,%esp
8010434c:	85 c0                	test   %eax,%eax
8010434e:	74 55                	je     801043a5 <create+0xf6>
  ilock(ip);
80104350:	83 ec 0c             	sub    $0xc,%esp
80104353:	50                   	push   %eax
80104354:	e8 8d d1 ff ff       	call   801014e6 <ilock>
  ip->major = major;
80104359:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
8010435d:	66 89 43 52          	mov    %ax,0x52(%ebx)
  ip->minor = minor;
80104361:	66 89 7b 54          	mov    %di,0x54(%ebx)
  ip->nlink = 1;
80104365:	66 c7 43 56 01 00    	movw   $0x1,0x56(%ebx)
  iupdate(ip);
8010436b:	89 1c 24             	mov    %ebx,(%esp)
8010436e:	e8 c9 d0 ff ff       	call   8010143c <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80104373:	83 c4 10             	add    $0x10,%esp
80104376:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
8010437b:	74 35                	je     801043b2 <create+0x103>
  if(dirlink(dp, name, ip->inum) < 0)
8010437d:	83 ec 04             	sub    $0x4,%esp
80104380:	ff 73 04             	pushl  0x4(%ebx)
80104383:	8d 45 da             	lea    -0x26(%ebp),%eax
80104386:	50                   	push   %eax
80104387:	56                   	push   %esi
80104388:	e8 41 d8 ff ff       	call   80101bce <dirlink>
8010438d:	83 c4 10             	add    $0x10,%esp
80104390:	85 c0                	test   %eax,%eax
80104392:	78 69                	js     801043fd <create+0x14e>
  iunlockput(dp);
80104394:	83 ec 0c             	sub    $0xc,%esp
80104397:	56                   	push   %esi
80104398:	e8 92 d3 ff ff       	call   8010172f <iunlockput>
  return ip;
8010439d:	83 c4 10             	add    $0x10,%esp
801043a0:	e9 76 ff ff ff       	jmp    8010431b <create+0x6c>
    panic("create: ialloc");
801043a5:	83 ec 0c             	sub    $0xc,%esp
801043a8:	68 60 87 10 80       	push   $0x80108760
801043ad:	e8 92 bf ff ff       	call   80100344 <panic>
    dp->nlink++;  // for ".."
801043b2:	66 83 46 56 01       	addw   $0x1,0x56(%esi)
    iupdate(dp);
801043b7:	83 ec 0c             	sub    $0xc,%esp
801043ba:	56                   	push   %esi
801043bb:	e8 7c d0 ff ff       	call   8010143c <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
801043c0:	83 c4 0c             	add    $0xc,%esp
801043c3:	ff 73 04             	pushl  0x4(%ebx)
801043c6:	68 70 87 10 80       	push   $0x80108770
801043cb:	53                   	push   %ebx
801043cc:	e8 fd d7 ff ff       	call   80101bce <dirlink>
801043d1:	83 c4 10             	add    $0x10,%esp
801043d4:	85 c0                	test   %eax,%eax
801043d6:	78 18                	js     801043f0 <create+0x141>
801043d8:	83 ec 04             	sub    $0x4,%esp
801043db:	ff 76 04             	pushl  0x4(%esi)
801043de:	68 6f 87 10 80       	push   $0x8010876f
801043e3:	53                   	push   %ebx
801043e4:	e8 e5 d7 ff ff       	call   80101bce <dirlink>
801043e9:	83 c4 10             	add    $0x10,%esp
801043ec:	85 c0                	test   %eax,%eax
801043ee:	79 8d                	jns    8010437d <create+0xce>
      panic("create dots");
801043f0:	83 ec 0c             	sub    $0xc,%esp
801043f3:	68 72 87 10 80       	push   $0x80108772
801043f8:	e8 47 bf ff ff       	call   80100344 <panic>
    panic("create: dirlink");
801043fd:	83 ec 0c             	sub    $0xc,%esp
80104400:	68 7e 87 10 80       	push   $0x8010877e
80104405:	e8 3a bf ff ff       	call   80100344 <panic>
    return 0;
8010440a:	89 c3                	mov    %eax,%ebx
8010440c:	e9 0a ff ff ff       	jmp    8010431b <create+0x6c>

80104411 <sys_dup>:
{
80104411:	55                   	push   %ebp
80104412:	89 e5                	mov    %esp,%ebp
80104414:	53                   	push   %ebx
80104415:	83 ec 14             	sub    $0x14,%esp
  if(argfd(0, 0, &f) < 0)
80104418:	8d 4d f4             	lea    -0xc(%ebp),%ecx
8010441b:	ba 00 00 00 00       	mov    $0x0,%edx
80104420:	b8 00 00 00 00       	mov    $0x0,%eax
80104425:	e8 e5 fd ff ff       	call   8010420f <argfd>
8010442a:	85 c0                	test   %eax,%eax
8010442c:	78 23                	js     80104451 <sys_dup+0x40>
  if((fd=fdalloc(f)) < 0)
8010442e:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104431:	e8 39 fe ff ff       	call   8010426f <fdalloc>
80104436:	89 c3                	mov    %eax,%ebx
80104438:	85 c0                	test   %eax,%eax
8010443a:	78 1c                	js     80104458 <sys_dup+0x47>
  filedup(f);
8010443c:	83 ec 0c             	sub    $0xc,%esp
8010443f:	ff 75 f4             	pushl  -0xc(%ebp)
80104442:	e8 a0 c8 ff ff       	call   80100ce7 <filedup>
  return fd;
80104447:	83 c4 10             	add    $0x10,%esp
}
8010444a:	89 d8                	mov    %ebx,%eax
8010444c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010444f:	c9                   	leave  
80104450:	c3                   	ret    
    return -1;
80104451:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104456:	eb f2                	jmp    8010444a <sys_dup+0x39>
    return -1;
80104458:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
8010445d:	eb eb                	jmp    8010444a <sys_dup+0x39>

8010445f <sys_read>:
{
8010445f:	55                   	push   %ebp
80104460:	89 e5                	mov    %esp,%ebp
80104462:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80104465:	8d 4d f4             	lea    -0xc(%ebp),%ecx
80104468:	ba 00 00 00 00       	mov    $0x0,%edx
8010446d:	b8 00 00 00 00       	mov    $0x0,%eax
80104472:	e8 98 fd ff ff       	call   8010420f <argfd>
80104477:	85 c0                	test   %eax,%eax
80104479:	78 43                	js     801044be <sys_read+0x5f>
8010447b:	83 ec 08             	sub    $0x8,%esp
8010447e:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104481:	50                   	push   %eax
80104482:	6a 02                	push   $0x2
80104484:	e8 77 fc ff ff       	call   80104100 <argint>
80104489:	83 c4 10             	add    $0x10,%esp
8010448c:	85 c0                	test   %eax,%eax
8010448e:	78 35                	js     801044c5 <sys_read+0x66>
80104490:	83 ec 04             	sub    $0x4,%esp
80104493:	ff 75 f0             	pushl  -0x10(%ebp)
80104496:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104499:	50                   	push   %eax
8010449a:	6a 01                	push   $0x1
8010449c:	e8 85 fc ff ff       	call   80104126 <argptr>
801044a1:	83 c4 10             	add    $0x10,%esp
801044a4:	85 c0                	test   %eax,%eax
801044a6:	78 24                	js     801044cc <sys_read+0x6d>
  return fileread(f, p, n);
801044a8:	83 ec 04             	sub    $0x4,%esp
801044ab:	ff 75 f0             	pushl  -0x10(%ebp)
801044ae:	ff 75 ec             	pushl  -0x14(%ebp)
801044b1:	ff 75 f4             	pushl  -0xc(%ebp)
801044b4:	e8 6f c9 ff ff       	call   80100e28 <fileread>
801044b9:	83 c4 10             	add    $0x10,%esp
}
801044bc:	c9                   	leave  
801044bd:	c3                   	ret    
    return -1;
801044be:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801044c3:	eb f7                	jmp    801044bc <sys_read+0x5d>
801044c5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801044ca:	eb f0                	jmp    801044bc <sys_read+0x5d>
801044cc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801044d1:	eb e9                	jmp    801044bc <sys_read+0x5d>

801044d3 <sys_write>:
{
801044d3:	55                   	push   %ebp
801044d4:	89 e5                	mov    %esp,%ebp
801044d6:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
801044d9:	8d 4d f4             	lea    -0xc(%ebp),%ecx
801044dc:	ba 00 00 00 00       	mov    $0x0,%edx
801044e1:	b8 00 00 00 00       	mov    $0x0,%eax
801044e6:	e8 24 fd ff ff       	call   8010420f <argfd>
801044eb:	85 c0                	test   %eax,%eax
801044ed:	78 43                	js     80104532 <sys_write+0x5f>
801044ef:	83 ec 08             	sub    $0x8,%esp
801044f2:	8d 45 f0             	lea    -0x10(%ebp),%eax
801044f5:	50                   	push   %eax
801044f6:	6a 02                	push   $0x2
801044f8:	e8 03 fc ff ff       	call   80104100 <argint>
801044fd:	83 c4 10             	add    $0x10,%esp
80104500:	85 c0                	test   %eax,%eax
80104502:	78 35                	js     80104539 <sys_write+0x66>
80104504:	83 ec 04             	sub    $0x4,%esp
80104507:	ff 75 f0             	pushl  -0x10(%ebp)
8010450a:	8d 45 ec             	lea    -0x14(%ebp),%eax
8010450d:	50                   	push   %eax
8010450e:	6a 01                	push   $0x1
80104510:	e8 11 fc ff ff       	call   80104126 <argptr>
80104515:	83 c4 10             	add    $0x10,%esp
80104518:	85 c0                	test   %eax,%eax
8010451a:	78 24                	js     80104540 <sys_write+0x6d>
  return filewrite(f, p, n);
8010451c:	83 ec 04             	sub    $0x4,%esp
8010451f:	ff 75 f0             	pushl  -0x10(%ebp)
80104522:	ff 75 ec             	pushl  -0x14(%ebp)
80104525:	ff 75 f4             	pushl  -0xc(%ebp)
80104528:	e8 80 c9 ff ff       	call   80100ead <filewrite>
8010452d:	83 c4 10             	add    $0x10,%esp
}
80104530:	c9                   	leave  
80104531:	c3                   	ret    
    return -1;
80104532:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104537:	eb f7                	jmp    80104530 <sys_write+0x5d>
80104539:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010453e:	eb f0                	jmp    80104530 <sys_write+0x5d>
80104540:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104545:	eb e9                	jmp    80104530 <sys_write+0x5d>

80104547 <sys_close>:
{
80104547:	55                   	push   %ebp
80104548:	89 e5                	mov    %esp,%ebp
8010454a:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, &fd, &f) < 0)
8010454d:	8d 4d f0             	lea    -0x10(%ebp),%ecx
80104550:	8d 55 f4             	lea    -0xc(%ebp),%edx
80104553:	b8 00 00 00 00       	mov    $0x0,%eax
80104558:	e8 b2 fc ff ff       	call   8010420f <argfd>
8010455d:	85 c0                	test   %eax,%eax
8010455f:	78 25                	js     80104586 <sys_close+0x3f>
  myproc()->ofile[fd] = 0;
80104561:	e8 e7 ed ff ff       	call   8010334d <myproc>
80104566:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104569:	c7 44 90 28 00 00 00 	movl   $0x0,0x28(%eax,%edx,4)
80104570:	00 
  fileclose(f);
80104571:	83 ec 0c             	sub    $0xc,%esp
80104574:	ff 75 f0             	pushl  -0x10(%ebp)
80104577:	e8 b0 c7 ff ff       	call   80100d2c <fileclose>
  return 0;
8010457c:	83 c4 10             	add    $0x10,%esp
8010457f:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104584:	c9                   	leave  
80104585:	c3                   	ret    
    return -1;
80104586:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010458b:	eb f7                	jmp    80104584 <sys_close+0x3d>

8010458d <sys_fstat>:
{
8010458d:	55                   	push   %ebp
8010458e:	89 e5                	mov    %esp,%ebp
80104590:	83 ec 18             	sub    $0x18,%esp
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
80104593:	8d 4d f4             	lea    -0xc(%ebp),%ecx
80104596:	ba 00 00 00 00       	mov    $0x0,%edx
8010459b:	b8 00 00 00 00       	mov    $0x0,%eax
801045a0:	e8 6a fc ff ff       	call   8010420f <argfd>
801045a5:	85 c0                	test   %eax,%eax
801045a7:	78 2a                	js     801045d3 <sys_fstat+0x46>
801045a9:	83 ec 04             	sub    $0x4,%esp
801045ac:	6a 14                	push   $0x14
801045ae:	8d 45 f0             	lea    -0x10(%ebp),%eax
801045b1:	50                   	push   %eax
801045b2:	6a 01                	push   $0x1
801045b4:	e8 6d fb ff ff       	call   80104126 <argptr>
801045b9:	83 c4 10             	add    $0x10,%esp
801045bc:	85 c0                	test   %eax,%eax
801045be:	78 1a                	js     801045da <sys_fstat+0x4d>
  return filestat(f, st);
801045c0:	83 ec 08             	sub    $0x8,%esp
801045c3:	ff 75 f0             	pushl  -0x10(%ebp)
801045c6:	ff 75 f4             	pushl  -0xc(%ebp)
801045c9:	e8 13 c8 ff ff       	call   80100de1 <filestat>
801045ce:	83 c4 10             	add    $0x10,%esp
}
801045d1:	c9                   	leave  
801045d2:	c3                   	ret    
    return -1;
801045d3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801045d8:	eb f7                	jmp    801045d1 <sys_fstat+0x44>
801045da:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801045df:	eb f0                	jmp    801045d1 <sys_fstat+0x44>

801045e1 <sys_link>:
{
801045e1:	55                   	push   %ebp
801045e2:	89 e5                	mov    %esp,%ebp
801045e4:	56                   	push   %esi
801045e5:	53                   	push   %ebx
801045e6:	83 ec 28             	sub    $0x28,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
801045e9:	8d 45 e0             	lea    -0x20(%ebp),%eax
801045ec:	50                   	push   %eax
801045ed:	6a 00                	push   $0x0
801045ef:	e8 93 fb ff ff       	call   80104187 <argstr>
801045f4:	83 c4 10             	add    $0x10,%esp
801045f7:	85 c0                	test   %eax,%eax
801045f9:	0f 88 26 01 00 00    	js     80104725 <sys_link+0x144>
801045ff:	83 ec 08             	sub    $0x8,%esp
80104602:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104605:	50                   	push   %eax
80104606:	6a 01                	push   $0x1
80104608:	e8 7a fb ff ff       	call   80104187 <argstr>
8010460d:	83 c4 10             	add    $0x10,%esp
80104610:	85 c0                	test   %eax,%eax
80104612:	0f 88 14 01 00 00    	js     8010472c <sys_link+0x14b>
  begin_op();
80104618:	e8 90 e1 ff ff       	call   801027ad <begin_op>
  if((ip = namei(old)) == 0){
8010461d:	83 ec 0c             	sub    $0xc,%esp
80104620:	ff 75 e0             	pushl  -0x20(%ebp)
80104623:	e8 5b d6 ff ff       	call   80101c83 <namei>
80104628:	89 c3                	mov    %eax,%ebx
8010462a:	83 c4 10             	add    $0x10,%esp
8010462d:	85 c0                	test   %eax,%eax
8010462f:	0f 84 93 00 00 00    	je     801046c8 <sys_link+0xe7>
  ilock(ip);
80104635:	83 ec 0c             	sub    $0xc,%esp
80104638:	50                   	push   %eax
80104639:	e8 a8 ce ff ff       	call   801014e6 <ilock>
  if(ip->type == T_DIR){
8010463e:	83 c4 10             	add    $0x10,%esp
80104641:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104646:	0f 84 88 00 00 00    	je     801046d4 <sys_link+0xf3>
  ip->nlink++;
8010464c:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  iupdate(ip);
80104651:	83 ec 0c             	sub    $0xc,%esp
80104654:	53                   	push   %ebx
80104655:	e8 e2 cd ff ff       	call   8010143c <iupdate>
  iunlock(ip);
8010465a:	89 1c 24             	mov    %ebx,(%esp)
8010465d:	e8 46 cf ff ff       	call   801015a8 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
80104662:	83 c4 08             	add    $0x8,%esp
80104665:	8d 45 ea             	lea    -0x16(%ebp),%eax
80104668:	50                   	push   %eax
80104669:	ff 75 e4             	pushl  -0x1c(%ebp)
8010466c:	e8 2a d6 ff ff       	call   80101c9b <nameiparent>
80104671:	89 c6                	mov    %eax,%esi
80104673:	83 c4 10             	add    $0x10,%esp
80104676:	85 c0                	test   %eax,%eax
80104678:	74 7e                	je     801046f8 <sys_link+0x117>
  ilock(dp);
8010467a:	83 ec 0c             	sub    $0xc,%esp
8010467d:	50                   	push   %eax
8010467e:	e8 63 ce ff ff       	call   801014e6 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
80104683:	83 c4 10             	add    $0x10,%esp
80104686:	8b 03                	mov    (%ebx),%eax
80104688:	39 06                	cmp    %eax,(%esi)
8010468a:	75 60                	jne    801046ec <sys_link+0x10b>
8010468c:	83 ec 04             	sub    $0x4,%esp
8010468f:	ff 73 04             	pushl  0x4(%ebx)
80104692:	8d 45 ea             	lea    -0x16(%ebp),%eax
80104695:	50                   	push   %eax
80104696:	56                   	push   %esi
80104697:	e8 32 d5 ff ff       	call   80101bce <dirlink>
8010469c:	83 c4 10             	add    $0x10,%esp
8010469f:	85 c0                	test   %eax,%eax
801046a1:	78 49                	js     801046ec <sys_link+0x10b>
  iunlockput(dp);
801046a3:	83 ec 0c             	sub    $0xc,%esp
801046a6:	56                   	push   %esi
801046a7:	e8 83 d0 ff ff       	call   8010172f <iunlockput>
  iput(ip);
801046ac:	89 1c 24             	mov    %ebx,(%esp)
801046af:	e8 39 cf ff ff       	call   801015ed <iput>
  end_op();
801046b4:	e8 6f e1 ff ff       	call   80102828 <end_op>
  return 0;
801046b9:	83 c4 10             	add    $0x10,%esp
801046bc:	b8 00 00 00 00       	mov    $0x0,%eax
}
801046c1:	8d 65 f8             	lea    -0x8(%ebp),%esp
801046c4:	5b                   	pop    %ebx
801046c5:	5e                   	pop    %esi
801046c6:	5d                   	pop    %ebp
801046c7:	c3                   	ret    
    end_op();
801046c8:	e8 5b e1 ff ff       	call   80102828 <end_op>
    return -1;
801046cd:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801046d2:	eb ed                	jmp    801046c1 <sys_link+0xe0>
    iunlockput(ip);
801046d4:	83 ec 0c             	sub    $0xc,%esp
801046d7:	53                   	push   %ebx
801046d8:	e8 52 d0 ff ff       	call   8010172f <iunlockput>
    end_op();
801046dd:	e8 46 e1 ff ff       	call   80102828 <end_op>
    return -1;
801046e2:	83 c4 10             	add    $0x10,%esp
801046e5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801046ea:	eb d5                	jmp    801046c1 <sys_link+0xe0>
    iunlockput(dp);
801046ec:	83 ec 0c             	sub    $0xc,%esp
801046ef:	56                   	push   %esi
801046f0:	e8 3a d0 ff ff       	call   8010172f <iunlockput>
    goto bad;
801046f5:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
801046f8:	83 ec 0c             	sub    $0xc,%esp
801046fb:	53                   	push   %ebx
801046fc:	e8 e5 cd ff ff       	call   801014e6 <ilock>
  ip->nlink--;
80104701:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
80104706:	89 1c 24             	mov    %ebx,(%esp)
80104709:	e8 2e cd ff ff       	call   8010143c <iupdate>
  iunlockput(ip);
8010470e:	89 1c 24             	mov    %ebx,(%esp)
80104711:	e8 19 d0 ff ff       	call   8010172f <iunlockput>
  end_op();
80104716:	e8 0d e1 ff ff       	call   80102828 <end_op>
  return -1;
8010471b:	83 c4 10             	add    $0x10,%esp
8010471e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104723:	eb 9c                	jmp    801046c1 <sys_link+0xe0>
    return -1;
80104725:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010472a:	eb 95                	jmp    801046c1 <sys_link+0xe0>
8010472c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104731:	eb 8e                	jmp    801046c1 <sys_link+0xe0>

80104733 <sys_unlink>:
{
80104733:	55                   	push   %ebp
80104734:	89 e5                	mov    %esp,%ebp
80104736:	57                   	push   %edi
80104737:	56                   	push   %esi
80104738:	53                   	push   %ebx
80104739:	83 ec 54             	sub    $0x54,%esp
  if(argstr(0, &path) < 0)
8010473c:	8d 45 c4             	lea    -0x3c(%ebp),%eax
8010473f:	50                   	push   %eax
80104740:	6a 00                	push   $0x0
80104742:	e8 40 fa ff ff       	call   80104187 <argstr>
80104747:	83 c4 10             	add    $0x10,%esp
8010474a:	85 c0                	test   %eax,%eax
8010474c:	0f 88 81 01 00 00    	js     801048d3 <sys_unlink+0x1a0>
  begin_op();
80104752:	e8 56 e0 ff ff       	call   801027ad <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80104757:	83 ec 08             	sub    $0x8,%esp
8010475a:	8d 45 ca             	lea    -0x36(%ebp),%eax
8010475d:	50                   	push   %eax
8010475e:	ff 75 c4             	pushl  -0x3c(%ebp)
80104761:	e8 35 d5 ff ff       	call   80101c9b <nameiparent>
80104766:	89 c7                	mov    %eax,%edi
80104768:	83 c4 10             	add    $0x10,%esp
8010476b:	85 c0                	test   %eax,%eax
8010476d:	0f 84 df 00 00 00    	je     80104852 <sys_unlink+0x11f>
  ilock(dp);
80104773:	83 ec 0c             	sub    $0xc,%esp
80104776:	50                   	push   %eax
80104777:	e8 6a cd ff ff       	call   801014e6 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
8010477c:	83 c4 08             	add    $0x8,%esp
8010477f:	68 70 87 10 80       	push   $0x80108770
80104784:	8d 45 ca             	lea    -0x36(%ebp),%eax
80104787:	50                   	push   %eax
80104788:	e8 0a d2 ff ff       	call   80101997 <namecmp>
8010478d:	83 c4 10             	add    $0x10,%esp
80104790:	85 c0                	test   %eax,%eax
80104792:	0f 84 51 01 00 00    	je     801048e9 <sys_unlink+0x1b6>
80104798:	83 ec 08             	sub    $0x8,%esp
8010479b:	68 6f 87 10 80       	push   $0x8010876f
801047a0:	8d 45 ca             	lea    -0x36(%ebp),%eax
801047a3:	50                   	push   %eax
801047a4:	e8 ee d1 ff ff       	call   80101997 <namecmp>
801047a9:	83 c4 10             	add    $0x10,%esp
801047ac:	85 c0                	test   %eax,%eax
801047ae:	0f 84 35 01 00 00    	je     801048e9 <sys_unlink+0x1b6>
  if((ip = dirlookup(dp, name, &off)) == 0)
801047b4:	83 ec 04             	sub    $0x4,%esp
801047b7:	8d 45 c0             	lea    -0x40(%ebp),%eax
801047ba:	50                   	push   %eax
801047bb:	8d 45 ca             	lea    -0x36(%ebp),%eax
801047be:	50                   	push   %eax
801047bf:	57                   	push   %edi
801047c0:	e8 e7 d1 ff ff       	call   801019ac <dirlookup>
801047c5:	89 c3                	mov    %eax,%ebx
801047c7:	83 c4 10             	add    $0x10,%esp
801047ca:	85 c0                	test   %eax,%eax
801047cc:	0f 84 17 01 00 00    	je     801048e9 <sys_unlink+0x1b6>
  ilock(ip);
801047d2:	83 ec 0c             	sub    $0xc,%esp
801047d5:	50                   	push   %eax
801047d6:	e8 0b cd ff ff       	call   801014e6 <ilock>
  if(ip->nlink < 1)
801047db:	83 c4 10             	add    $0x10,%esp
801047de:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
801047e3:	7e 79                	jle    8010485e <sys_unlink+0x12b>
  if(ip->type == T_DIR && !isdirempty(ip)){
801047e5:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
801047ea:	74 7f                	je     8010486b <sys_unlink+0x138>
  memset(&de, 0, sizeof(de));
801047ec:	83 ec 04             	sub    $0x4,%esp
801047ef:	6a 10                	push   $0x10
801047f1:	6a 00                	push   $0x0
801047f3:	8d 75 d8             	lea    -0x28(%ebp),%esi
801047f6:	56                   	push   %esi
801047f7:	e8 7e f6 ff ff       	call   80103e7a <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
801047fc:	6a 10                	push   $0x10
801047fe:	ff 75 c0             	pushl  -0x40(%ebp)
80104801:	56                   	push   %esi
80104802:	57                   	push   %edi
80104803:	e8 6e d0 ff ff       	call   80101876 <writei>
80104808:	83 c4 20             	add    $0x20,%esp
8010480b:	83 f8 10             	cmp    $0x10,%eax
8010480e:	0f 85 9c 00 00 00    	jne    801048b0 <sys_unlink+0x17d>
  if(ip->type == T_DIR){
80104814:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104819:	0f 84 9e 00 00 00    	je     801048bd <sys_unlink+0x18a>
  iunlockput(dp);
8010481f:	83 ec 0c             	sub    $0xc,%esp
80104822:	57                   	push   %edi
80104823:	e8 07 cf ff ff       	call   8010172f <iunlockput>
  ip->nlink--;
80104828:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010482d:	89 1c 24             	mov    %ebx,(%esp)
80104830:	e8 07 cc ff ff       	call   8010143c <iupdate>
  iunlockput(ip);
80104835:	89 1c 24             	mov    %ebx,(%esp)
80104838:	e8 f2 ce ff ff       	call   8010172f <iunlockput>
  end_op();
8010483d:	e8 e6 df ff ff       	call   80102828 <end_op>
  return 0;
80104842:	83 c4 10             	add    $0x10,%esp
80104845:	b8 00 00 00 00       	mov    $0x0,%eax
}
8010484a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010484d:	5b                   	pop    %ebx
8010484e:	5e                   	pop    %esi
8010484f:	5f                   	pop    %edi
80104850:	5d                   	pop    %ebp
80104851:	c3                   	ret    
    end_op();
80104852:	e8 d1 df ff ff       	call   80102828 <end_op>
    return -1;
80104857:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010485c:	eb ec                	jmp    8010484a <sys_unlink+0x117>
    panic("unlink: nlink < 1");
8010485e:	83 ec 0c             	sub    $0xc,%esp
80104861:	68 8e 87 10 80       	push   $0x8010878e
80104866:	e8 d9 ba ff ff       	call   80100344 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
8010486b:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
8010486f:	0f 86 77 ff ff ff    	jbe    801047ec <sys_unlink+0xb9>
80104875:	be 20 00 00 00       	mov    $0x20,%esi
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
8010487a:	6a 10                	push   $0x10
8010487c:	56                   	push   %esi
8010487d:	8d 45 b0             	lea    -0x50(%ebp),%eax
80104880:	50                   	push   %eax
80104881:	53                   	push   %ebx
80104882:	e8 f3 ce ff ff       	call   8010177a <readi>
80104887:	83 c4 10             	add    $0x10,%esp
8010488a:	83 f8 10             	cmp    $0x10,%eax
8010488d:	75 14                	jne    801048a3 <sys_unlink+0x170>
    if(de.inum != 0)
8010488f:	66 83 7d b0 00       	cmpw   $0x0,-0x50(%ebp)
80104894:	75 47                	jne    801048dd <sys_unlink+0x1aa>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80104896:	83 c6 10             	add    $0x10,%esi
80104899:	3b 73 58             	cmp    0x58(%ebx),%esi
8010489c:	72 dc                	jb     8010487a <sys_unlink+0x147>
8010489e:	e9 49 ff ff ff       	jmp    801047ec <sys_unlink+0xb9>
      panic("isdirempty: readi");
801048a3:	83 ec 0c             	sub    $0xc,%esp
801048a6:	68 a0 87 10 80       	push   $0x801087a0
801048ab:	e8 94 ba ff ff       	call   80100344 <panic>
    panic("unlink: writei");
801048b0:	83 ec 0c             	sub    $0xc,%esp
801048b3:	68 b2 87 10 80       	push   $0x801087b2
801048b8:	e8 87 ba ff ff       	call   80100344 <panic>
    dp->nlink--;
801048bd:	66 83 6f 56 01       	subw   $0x1,0x56(%edi)
    iupdate(dp);
801048c2:	83 ec 0c             	sub    $0xc,%esp
801048c5:	57                   	push   %edi
801048c6:	e8 71 cb ff ff       	call   8010143c <iupdate>
801048cb:	83 c4 10             	add    $0x10,%esp
801048ce:	e9 4c ff ff ff       	jmp    8010481f <sys_unlink+0xec>
    return -1;
801048d3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048d8:	e9 6d ff ff ff       	jmp    8010484a <sys_unlink+0x117>
    iunlockput(ip);
801048dd:	83 ec 0c             	sub    $0xc,%esp
801048e0:	53                   	push   %ebx
801048e1:	e8 49 ce ff ff       	call   8010172f <iunlockput>
    goto bad;
801048e6:	83 c4 10             	add    $0x10,%esp
  iunlockput(dp);
801048e9:	83 ec 0c             	sub    $0xc,%esp
801048ec:	57                   	push   %edi
801048ed:	e8 3d ce ff ff       	call   8010172f <iunlockput>
  end_op();
801048f2:	e8 31 df ff ff       	call   80102828 <end_op>
  return -1;
801048f7:	83 c4 10             	add    $0x10,%esp
801048fa:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801048ff:	e9 46 ff ff ff       	jmp    8010484a <sys_unlink+0x117>

80104904 <sys_open>:

int
sys_open(void)
{
80104904:	55                   	push   %ebp
80104905:	89 e5                	mov    %esp,%ebp
80104907:	57                   	push   %edi
80104908:	56                   	push   %esi
80104909:	53                   	push   %ebx
8010490a:	83 ec 24             	sub    $0x24,%esp
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
8010490d:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104910:	50                   	push   %eax
80104911:	6a 00                	push   $0x0
80104913:	e8 6f f8 ff ff       	call   80104187 <argstr>
80104918:	83 c4 10             	add    $0x10,%esp
8010491b:	85 c0                	test   %eax,%eax
8010491d:	0f 88 0b 01 00 00    	js     80104a2e <sys_open+0x12a>
80104923:	83 ec 08             	sub    $0x8,%esp
80104926:	8d 45 e0             	lea    -0x20(%ebp),%eax
80104929:	50                   	push   %eax
8010492a:	6a 01                	push   $0x1
8010492c:	e8 cf f7 ff ff       	call   80104100 <argint>
80104931:	83 c4 10             	add    $0x10,%esp
80104934:	85 c0                	test   %eax,%eax
80104936:	0f 88 f9 00 00 00    	js     80104a35 <sys_open+0x131>
    return -1;

  begin_op();
8010493c:	e8 6c de ff ff       	call   801027ad <begin_op>

  if(omode & O_CREATE){
80104941:	f6 45 e1 02          	testb  $0x2,-0x1f(%ebp)
80104945:	0f 84 8a 00 00 00    	je     801049d5 <sys_open+0xd1>
    ip = create(path, T_FILE, 0, 0);
8010494b:	83 ec 0c             	sub    $0xc,%esp
8010494e:	6a 00                	push   $0x0
80104950:	b9 00 00 00 00       	mov    $0x0,%ecx
80104955:	ba 02 00 00 00       	mov    $0x2,%edx
8010495a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010495d:	e8 4d f9 ff ff       	call   801042af <create>
80104962:	89 c6                	mov    %eax,%esi
    if(ip == 0){
80104964:	83 c4 10             	add    $0x10,%esp
80104967:	85 c0                	test   %eax,%eax
80104969:	74 5e                	je     801049c9 <sys_open+0xc5>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
8010496b:	e8 0a c3 ff ff       	call   80100c7a <filealloc>
80104970:	89 c3                	mov    %eax,%ebx
80104972:	85 c0                	test   %eax,%eax
80104974:	0f 84 ce 00 00 00    	je     80104a48 <sys_open+0x144>
8010497a:	e8 f0 f8 ff ff       	call   8010426f <fdalloc>
8010497f:	89 c7                	mov    %eax,%edi
80104981:	85 c0                	test   %eax,%eax
80104983:	0f 88 b3 00 00 00    	js     80104a3c <sys_open+0x138>
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80104989:	83 ec 0c             	sub    $0xc,%esp
8010498c:	56                   	push   %esi
8010498d:	e8 16 cc ff ff       	call   801015a8 <iunlock>
  end_op();
80104992:	e8 91 de ff ff       	call   80102828 <end_op>

  f->type = FD_INODE;
80104997:	c7 03 02 00 00 00    	movl   $0x2,(%ebx)
  f->ip = ip;
8010499d:	89 73 10             	mov    %esi,0x10(%ebx)
  f->off = 0;
801049a0:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
  f->readable = !(omode & O_WRONLY);
801049a7:	8b 55 e0             	mov    -0x20(%ebp),%edx
801049aa:	89 d0                	mov    %edx,%eax
801049ac:	83 f0 01             	xor    $0x1,%eax
801049af:	83 e0 01             	and    $0x1,%eax
801049b2:	88 43 08             	mov    %al,0x8(%ebx)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
801049b5:	83 c4 10             	add    $0x10,%esp
801049b8:	f6 c2 03             	test   $0x3,%dl
801049bb:	0f 95 43 09          	setne  0x9(%ebx)
  return fd;
}
801049bf:	89 f8                	mov    %edi,%eax
801049c1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801049c4:	5b                   	pop    %ebx
801049c5:	5e                   	pop    %esi
801049c6:	5f                   	pop    %edi
801049c7:	5d                   	pop    %ebp
801049c8:	c3                   	ret    
      end_op();
801049c9:	e8 5a de ff ff       	call   80102828 <end_op>
      return -1;
801049ce:	bf ff ff ff ff       	mov    $0xffffffff,%edi
801049d3:	eb ea                	jmp    801049bf <sys_open+0xbb>
    if((ip = namei(path)) == 0){
801049d5:	83 ec 0c             	sub    $0xc,%esp
801049d8:	ff 75 e4             	pushl  -0x1c(%ebp)
801049db:	e8 a3 d2 ff ff       	call   80101c83 <namei>
801049e0:	89 c6                	mov    %eax,%esi
801049e2:	83 c4 10             	add    $0x10,%esp
801049e5:	85 c0                	test   %eax,%eax
801049e7:	74 39                	je     80104a22 <sys_open+0x11e>
    ilock(ip);
801049e9:	83 ec 0c             	sub    $0xc,%esp
801049ec:	50                   	push   %eax
801049ed:	e8 f4 ca ff ff       	call   801014e6 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
801049f2:	83 c4 10             	add    $0x10,%esp
801049f5:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
801049fa:	0f 85 6b ff ff ff    	jne    8010496b <sys_open+0x67>
80104a00:	83 7d e0 00          	cmpl   $0x0,-0x20(%ebp)
80104a04:	0f 84 61 ff ff ff    	je     8010496b <sys_open+0x67>
      iunlockput(ip);
80104a0a:	83 ec 0c             	sub    $0xc,%esp
80104a0d:	56                   	push   %esi
80104a0e:	e8 1c cd ff ff       	call   8010172f <iunlockput>
      end_op();
80104a13:	e8 10 de ff ff       	call   80102828 <end_op>
      return -1;
80104a18:	83 c4 10             	add    $0x10,%esp
80104a1b:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104a20:	eb 9d                	jmp    801049bf <sys_open+0xbb>
      end_op();
80104a22:	e8 01 de ff ff       	call   80102828 <end_op>
      return -1;
80104a27:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104a2c:	eb 91                	jmp    801049bf <sys_open+0xbb>
    return -1;
80104a2e:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104a33:	eb 8a                	jmp    801049bf <sys_open+0xbb>
80104a35:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104a3a:	eb 83                	jmp    801049bf <sys_open+0xbb>
      fileclose(f);
80104a3c:	83 ec 0c             	sub    $0xc,%esp
80104a3f:	53                   	push   %ebx
80104a40:	e8 e7 c2 ff ff       	call   80100d2c <fileclose>
80104a45:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80104a48:	83 ec 0c             	sub    $0xc,%esp
80104a4b:	56                   	push   %esi
80104a4c:	e8 de cc ff ff       	call   8010172f <iunlockput>
    end_op();
80104a51:	e8 d2 dd ff ff       	call   80102828 <end_op>
    return -1;
80104a56:	83 c4 10             	add    $0x10,%esp
80104a59:	bf ff ff ff ff       	mov    $0xffffffff,%edi
80104a5e:	e9 5c ff ff ff       	jmp    801049bf <sys_open+0xbb>

80104a63 <sys_mkdir>:

int
sys_mkdir(void)
{
80104a63:	55                   	push   %ebp
80104a64:	89 e5                	mov    %esp,%ebp
80104a66:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80104a69:	e8 3f dd ff ff       	call   801027ad <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
80104a6e:	83 ec 08             	sub    $0x8,%esp
80104a71:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104a74:	50                   	push   %eax
80104a75:	6a 00                	push   $0x0
80104a77:	e8 0b f7 ff ff       	call   80104187 <argstr>
80104a7c:	83 c4 10             	add    $0x10,%esp
80104a7f:	85 c0                	test   %eax,%eax
80104a81:	78 36                	js     80104ab9 <sys_mkdir+0x56>
80104a83:	83 ec 0c             	sub    $0xc,%esp
80104a86:	6a 00                	push   $0x0
80104a88:	b9 00 00 00 00       	mov    $0x0,%ecx
80104a8d:	ba 01 00 00 00       	mov    $0x1,%edx
80104a92:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104a95:	e8 15 f8 ff ff       	call   801042af <create>
80104a9a:	83 c4 10             	add    $0x10,%esp
80104a9d:	85 c0                	test   %eax,%eax
80104a9f:	74 18                	je     80104ab9 <sys_mkdir+0x56>
    end_op();
    return -1;
  }
  iunlockput(ip);
80104aa1:	83 ec 0c             	sub    $0xc,%esp
80104aa4:	50                   	push   %eax
80104aa5:	e8 85 cc ff ff       	call   8010172f <iunlockput>
  end_op();
80104aaa:	e8 79 dd ff ff       	call   80102828 <end_op>
  return 0;
80104aaf:	83 c4 10             	add    $0x10,%esp
80104ab2:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104ab7:	c9                   	leave  
80104ab8:	c3                   	ret    
    end_op();
80104ab9:	e8 6a dd ff ff       	call   80102828 <end_op>
    return -1;
80104abe:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ac3:	eb f2                	jmp    80104ab7 <sys_mkdir+0x54>

80104ac5 <sys_mknod>:

int
sys_mknod(void)
{
80104ac5:	55                   	push   %ebp
80104ac6:	89 e5                	mov    %esp,%ebp
80104ac8:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
80104acb:	e8 dd dc ff ff       	call   801027ad <begin_op>
  if((argstr(0, &path)) < 0 ||
80104ad0:	83 ec 08             	sub    $0x8,%esp
80104ad3:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104ad6:	50                   	push   %eax
80104ad7:	6a 00                	push   $0x0
80104ad9:	e8 a9 f6 ff ff       	call   80104187 <argstr>
80104ade:	83 c4 10             	add    $0x10,%esp
80104ae1:	85 c0                	test   %eax,%eax
80104ae3:	78 62                	js     80104b47 <sys_mknod+0x82>
     argint(1, &major) < 0 ||
80104ae5:	83 ec 08             	sub    $0x8,%esp
80104ae8:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104aeb:	50                   	push   %eax
80104aec:	6a 01                	push   $0x1
80104aee:	e8 0d f6 ff ff       	call   80104100 <argint>
  if((argstr(0, &path)) < 0 ||
80104af3:	83 c4 10             	add    $0x10,%esp
80104af6:	85 c0                	test   %eax,%eax
80104af8:	78 4d                	js     80104b47 <sys_mknod+0x82>
     argint(2, &minor) < 0 ||
80104afa:	83 ec 08             	sub    $0x8,%esp
80104afd:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104b00:	50                   	push   %eax
80104b01:	6a 02                	push   $0x2
80104b03:	e8 f8 f5 ff ff       	call   80104100 <argint>
     argint(1, &major) < 0 ||
80104b08:	83 c4 10             	add    $0x10,%esp
80104b0b:	85 c0                	test   %eax,%eax
80104b0d:	78 38                	js     80104b47 <sys_mknod+0x82>
     (ip = create(path, T_DEV, major, minor)) == 0){
80104b0f:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
     argint(2, &minor) < 0 ||
80104b13:	83 ec 0c             	sub    $0xc,%esp
     (ip = create(path, T_DEV, major, minor)) == 0){
80104b16:	0f bf 45 ec          	movswl -0x14(%ebp),%eax
     argint(2, &minor) < 0 ||
80104b1a:	50                   	push   %eax
80104b1b:	ba 03 00 00 00       	mov    $0x3,%edx
80104b20:	8b 45 f4             	mov    -0xc(%ebp),%eax
80104b23:	e8 87 f7 ff ff       	call   801042af <create>
80104b28:	83 c4 10             	add    $0x10,%esp
80104b2b:	85 c0                	test   %eax,%eax
80104b2d:	74 18                	je     80104b47 <sys_mknod+0x82>
    end_op();
    return -1;
  }
  iunlockput(ip);
80104b2f:	83 ec 0c             	sub    $0xc,%esp
80104b32:	50                   	push   %eax
80104b33:	e8 f7 cb ff ff       	call   8010172f <iunlockput>
  end_op();
80104b38:	e8 eb dc ff ff       	call   80102828 <end_op>
  return 0;
80104b3d:	83 c4 10             	add    $0x10,%esp
80104b40:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104b45:	c9                   	leave  
80104b46:	c3                   	ret    
    end_op();
80104b47:	e8 dc dc ff ff       	call   80102828 <end_op>
    return -1;
80104b4c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104b51:	eb f2                	jmp    80104b45 <sys_mknod+0x80>

80104b53 <sys_chdir>:

int
sys_chdir(void)
{
80104b53:	55                   	push   %ebp
80104b54:	89 e5                	mov    %esp,%ebp
80104b56:	56                   	push   %esi
80104b57:	53                   	push   %ebx
80104b58:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
80104b5b:	e8 ed e7 ff ff       	call   8010334d <myproc>
80104b60:	89 c6                	mov    %eax,%esi
  
  begin_op();
80104b62:	e8 46 dc ff ff       	call   801027ad <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
80104b67:	83 ec 08             	sub    $0x8,%esp
80104b6a:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104b6d:	50                   	push   %eax
80104b6e:	6a 00                	push   $0x0
80104b70:	e8 12 f6 ff ff       	call   80104187 <argstr>
80104b75:	83 c4 10             	add    $0x10,%esp
80104b78:	85 c0                	test   %eax,%eax
80104b7a:	78 52                	js     80104bce <sys_chdir+0x7b>
80104b7c:	83 ec 0c             	sub    $0xc,%esp
80104b7f:	ff 75 f4             	pushl  -0xc(%ebp)
80104b82:	e8 fc d0 ff ff       	call   80101c83 <namei>
80104b87:	89 c3                	mov    %eax,%ebx
80104b89:	83 c4 10             	add    $0x10,%esp
80104b8c:	85 c0                	test   %eax,%eax
80104b8e:	74 3e                	je     80104bce <sys_chdir+0x7b>
    end_op();
    return -1;
  }
  ilock(ip);
80104b90:	83 ec 0c             	sub    $0xc,%esp
80104b93:	50                   	push   %eax
80104b94:	e8 4d c9 ff ff       	call   801014e6 <ilock>
  if(ip->type != T_DIR){
80104b99:	83 c4 10             	add    $0x10,%esp
80104b9c:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80104ba1:	75 37                	jne    80104bda <sys_chdir+0x87>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
80104ba3:	83 ec 0c             	sub    $0xc,%esp
80104ba6:	53                   	push   %ebx
80104ba7:	e8 fc c9 ff ff       	call   801015a8 <iunlock>
  iput(curproc->cwd);
80104bac:	83 c4 04             	add    $0x4,%esp
80104baf:	ff 76 68             	pushl  0x68(%esi)
80104bb2:	e8 36 ca ff ff       	call   801015ed <iput>
  end_op();
80104bb7:	e8 6c dc ff ff       	call   80102828 <end_op>
  curproc->cwd = ip;
80104bbc:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
80104bbf:	83 c4 10             	add    $0x10,%esp
80104bc2:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104bc7:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104bca:	5b                   	pop    %ebx
80104bcb:	5e                   	pop    %esi
80104bcc:	5d                   	pop    %ebp
80104bcd:	c3                   	ret    
    end_op();
80104bce:	e8 55 dc ff ff       	call   80102828 <end_op>
    return -1;
80104bd3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104bd8:	eb ed                	jmp    80104bc7 <sys_chdir+0x74>
    iunlockput(ip);
80104bda:	83 ec 0c             	sub    $0xc,%esp
80104bdd:	53                   	push   %ebx
80104bde:	e8 4c cb ff ff       	call   8010172f <iunlockput>
    end_op();
80104be3:	e8 40 dc ff ff       	call   80102828 <end_op>
    return -1;
80104be8:	83 c4 10             	add    $0x10,%esp
80104beb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104bf0:	eb d5                	jmp    80104bc7 <sys_chdir+0x74>

80104bf2 <sys_exec>:

int
sys_exec(void)
{
80104bf2:	55                   	push   %ebp
80104bf3:	89 e5                	mov    %esp,%ebp
80104bf5:	57                   	push   %edi
80104bf6:	56                   	push   %esi
80104bf7:	53                   	push   %ebx
80104bf8:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80104bfe:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80104c01:	50                   	push   %eax
80104c02:	6a 00                	push   $0x0
80104c04:	e8 7e f5 ff ff       	call   80104187 <argstr>
80104c09:	83 c4 10             	add    $0x10,%esp
80104c0c:	85 c0                	test   %eax,%eax
80104c0e:	0f 88 b4 00 00 00    	js     80104cc8 <sys_exec+0xd6>
80104c14:	83 ec 08             	sub    $0x8,%esp
80104c17:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
80104c1d:	50                   	push   %eax
80104c1e:	6a 01                	push   $0x1
80104c20:	e8 db f4 ff ff       	call   80104100 <argint>
80104c25:	83 c4 10             	add    $0x10,%esp
80104c28:	85 c0                	test   %eax,%eax
80104c2a:	0f 88 9f 00 00 00    	js     80104ccf <sys_exec+0xdd>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
80104c30:	83 ec 04             	sub    $0x4,%esp
80104c33:	68 80 00 00 00       	push   $0x80
80104c38:	6a 00                	push   $0x0
80104c3a:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80104c40:	50                   	push   %eax
80104c41:	e8 34 f2 ff ff       	call   80103e7a <memset>
80104c46:	83 c4 10             	add    $0x10,%esp
  for(i=0;; i++){
80104c49:	be 00 00 00 00       	mov    $0x0,%esi
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
80104c4e:	8d bd 5c ff ff ff    	lea    -0xa4(%ebp),%edi
80104c54:	8d 1c b5 00 00 00 00 	lea    0x0(,%esi,4),%ebx
80104c5b:	83 ec 08             	sub    $0x8,%esp
80104c5e:	57                   	push   %edi
80104c5f:	89 d8                	mov    %ebx,%eax
80104c61:	03 85 60 ff ff ff    	add    -0xa0(%ebp),%eax
80104c67:	50                   	push   %eax
80104c68:	e8 07 f4 ff ff       	call   80104074 <fetchint>
80104c6d:	83 c4 10             	add    $0x10,%esp
80104c70:	85 c0                	test   %eax,%eax
80104c72:	78 62                	js     80104cd6 <sys_exec+0xe4>
      return -1;
    if(uarg == 0){
80104c74:	8b 85 5c ff ff ff    	mov    -0xa4(%ebp),%eax
80104c7a:	85 c0                	test   %eax,%eax
80104c7c:	74 28                	je     80104ca6 <sys_exec+0xb4>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
80104c7e:	83 ec 08             	sub    $0x8,%esp
80104c81:	8d 95 64 ff ff ff    	lea    -0x9c(%ebp),%edx
80104c87:	01 d3                	add    %edx,%ebx
80104c89:	53                   	push   %ebx
80104c8a:	50                   	push   %eax
80104c8b:	e8 20 f4 ff ff       	call   801040b0 <fetchstr>
80104c90:	83 c4 10             	add    $0x10,%esp
80104c93:	85 c0                	test   %eax,%eax
80104c95:	78 4c                	js     80104ce3 <sys_exec+0xf1>
  for(i=0;; i++){
80104c97:	83 c6 01             	add    $0x1,%esi
    if(i >= NELEM(argv))
80104c9a:	83 fe 20             	cmp    $0x20,%esi
80104c9d:	75 b5                	jne    80104c54 <sys_exec+0x62>
      return -1;
80104c9f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ca4:	eb 35                	jmp    80104cdb <sys_exec+0xe9>
      argv[i] = 0;
80104ca6:	c7 84 b5 64 ff ff ff 	movl   $0x0,-0x9c(%ebp,%esi,4)
80104cad:	00 00 00 00 
      return -1;
  }
  return exec(path, argv);
80104cb1:	83 ec 08             	sub    $0x8,%esp
80104cb4:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80104cba:	50                   	push   %eax
80104cbb:	ff 75 e4             	pushl  -0x1c(%ebp)
80104cbe:	e8 4f bc ff ff       	call   80100912 <exec>
80104cc3:	83 c4 10             	add    $0x10,%esp
80104cc6:	eb 13                	jmp    80104cdb <sys_exec+0xe9>
    return -1;
80104cc8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ccd:	eb 0c                	jmp    80104cdb <sys_exec+0xe9>
80104ccf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104cd4:	eb 05                	jmp    80104cdb <sys_exec+0xe9>
      return -1;
80104cd6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104cdb:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104cde:	5b                   	pop    %ebx
80104cdf:	5e                   	pop    %esi
80104ce0:	5f                   	pop    %edi
80104ce1:	5d                   	pop    %ebp
80104ce2:	c3                   	ret    
      return -1;
80104ce3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ce8:	eb f1                	jmp    80104cdb <sys_exec+0xe9>

80104cea <sys_pipe>:

int
sys_pipe(void)
{
80104cea:	55                   	push   %ebp
80104ceb:	89 e5                	mov    %esp,%ebp
80104ced:	53                   	push   %ebx
80104cee:	83 ec 18             	sub    $0x18,%esp
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80104cf1:	6a 08                	push   $0x8
80104cf3:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104cf6:	50                   	push   %eax
80104cf7:	6a 00                	push   $0x0
80104cf9:	e8 28 f4 ff ff       	call   80104126 <argptr>
80104cfe:	83 c4 10             	add    $0x10,%esp
80104d01:	85 c0                	test   %eax,%eax
80104d03:	78 46                	js     80104d4b <sys_pipe+0x61>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80104d05:	83 ec 08             	sub    $0x8,%esp
80104d08:	8d 45 ec             	lea    -0x14(%ebp),%eax
80104d0b:	50                   	push   %eax
80104d0c:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104d0f:	50                   	push   %eax
80104d10:	e8 cc e0 ff ff       	call   80102de1 <pipealloc>
80104d15:	83 c4 10             	add    $0x10,%esp
80104d18:	85 c0                	test   %eax,%eax
80104d1a:	78 36                	js     80104d52 <sys_pipe+0x68>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80104d1c:	8b 45 f0             	mov    -0x10(%ebp),%eax
80104d1f:	e8 4b f5 ff ff       	call   8010426f <fdalloc>
80104d24:	89 c3                	mov    %eax,%ebx
80104d26:	85 c0                	test   %eax,%eax
80104d28:	78 3c                	js     80104d66 <sys_pipe+0x7c>
80104d2a:	8b 45 ec             	mov    -0x14(%ebp),%eax
80104d2d:	e8 3d f5 ff ff       	call   8010426f <fdalloc>
80104d32:	85 c0                	test   %eax,%eax
80104d34:	78 23                	js     80104d59 <sys_pipe+0x6f>
      myproc()->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  fd[0] = fd0;
80104d36:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104d39:	89 1a                	mov    %ebx,(%edx)
  fd[1] = fd1;
80104d3b:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104d3e:	89 42 04             	mov    %eax,0x4(%edx)
  return 0;
80104d41:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104d46:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104d49:	c9                   	leave  
80104d4a:	c3                   	ret    
    return -1;
80104d4b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d50:	eb f4                	jmp    80104d46 <sys_pipe+0x5c>
    return -1;
80104d52:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d57:	eb ed                	jmp    80104d46 <sys_pipe+0x5c>
      myproc()->ofile[fd0] = 0;
80104d59:	e8 ef e5 ff ff       	call   8010334d <myproc>
80104d5e:	c7 44 98 28 00 00 00 	movl   $0x0,0x28(%eax,%ebx,4)
80104d65:	00 
    fileclose(rf);
80104d66:	83 ec 0c             	sub    $0xc,%esp
80104d69:	ff 75 f0             	pushl  -0x10(%ebp)
80104d6c:	e8 bb bf ff ff       	call   80100d2c <fileclose>
    fileclose(wf);
80104d71:	83 c4 04             	add    $0x4,%esp
80104d74:	ff 75 ec             	pushl  -0x14(%ebp)
80104d77:	e8 b0 bf ff ff       	call   80100d2c <fileclose>
    return -1;
80104d7c:	83 c4 10             	add    $0x10,%esp
80104d7f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104d84:	eb c0                	jmp    80104d46 <sys_pipe+0x5c>

80104d86 <sys_fork>:
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
80104d86:	55                   	push   %ebp
80104d87:	89 e5                	mov    %esp,%ebp
80104d89:	83 ec 08             	sub    $0x8,%esp
  return fork();
80104d8c:	e8 34 e7 ff ff       	call   801034c5 <fork>
}
80104d91:	c9                   	leave  
80104d92:	c3                   	ret    

80104d93 <sys_exit>:

int
sys_exit(void)
{
80104d93:	55                   	push   %ebp
80104d94:	89 e5                	mov    %esp,%ebp
80104d96:	83 ec 08             	sub    $0x8,%esp
  exit();
80104d99:	e8 62 e9 ff ff       	call   80103700 <exit>
  return 0;  // not reached
}
80104d9e:	b8 00 00 00 00       	mov    $0x0,%eax
80104da3:	c9                   	leave  
80104da4:	c3                   	ret    

80104da5 <sys_wait>:

int
sys_wait(void)
{
80104da5:	55                   	push   %ebp
80104da6:	89 e5                	mov    %esp,%ebp
80104da8:	83 ec 08             	sub    $0x8,%esp
  return wait();
80104dab:	e8 eb ea ff ff       	call   8010389b <wait>
}
80104db0:	c9                   	leave  
80104db1:	c3                   	ret    

80104db2 <sys_kill>:

int
sys_kill(void)
{
80104db2:	55                   	push   %ebp
80104db3:	89 e5                	mov    %esp,%ebp
80104db5:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
80104db8:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104dbb:	50                   	push   %eax
80104dbc:	6a 00                	push   $0x0
80104dbe:	e8 3d f3 ff ff       	call   80104100 <argint>
80104dc3:	83 c4 10             	add    $0x10,%esp
80104dc6:	85 c0                	test   %eax,%eax
80104dc8:	78 10                	js     80104dda <sys_kill+0x28>
    return -1;
  return kill(pid);
80104dca:	83 ec 0c             	sub    $0xc,%esp
80104dcd:	ff 75 f4             	pushl  -0xc(%ebp)
80104dd0:	e8 cd eb ff ff       	call   801039a2 <kill>
80104dd5:	83 c4 10             	add    $0x10,%esp
}
80104dd8:	c9                   	leave  
80104dd9:	c3                   	ret    
    return -1;
80104dda:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ddf:	eb f7                	jmp    80104dd8 <sys_kill+0x26>

80104de1 <sys_getpid>:

int
sys_getpid(void)
{
80104de1:	55                   	push   %ebp
80104de2:	89 e5                	mov    %esp,%ebp
80104de4:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80104de7:	e8 61 e5 ff ff       	call   8010334d <myproc>
80104dec:	8b 40 10             	mov    0x10(%eax),%eax
}
80104def:	c9                   	leave  
80104df0:	c3                   	ret    

80104df1 <sys_sbrk>:

int
sys_sbrk(void)
{
80104df1:	55                   	push   %ebp
80104df2:	89 e5                	mov    %esp,%ebp
80104df4:	53                   	push   %ebx
80104df5:	83 ec 1c             	sub    $0x1c,%esp
  int addr;
  int n;

  if(argint(0, &n) < 0)
80104df8:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104dfb:	50                   	push   %eax
80104dfc:	6a 00                	push   $0x0
80104dfe:	e8 fd f2 ff ff       	call   80104100 <argint>
80104e03:	83 c4 10             	add    $0x10,%esp
80104e06:	85 c0                	test   %eax,%eax
80104e08:	78 26                	js     80104e30 <sys_sbrk+0x3f>
    return -1;
  addr = myproc()->sz;
80104e0a:	e8 3e e5 ff ff       	call   8010334d <myproc>
80104e0f:	8b 18                	mov    (%eax),%ebx
  if(growproc(n) < 0)
80104e11:	83 ec 0c             	sub    $0xc,%esp
80104e14:	ff 75 f4             	pushl  -0xc(%ebp)
80104e17:	e8 3c e6 ff ff       	call   80103458 <growproc>
80104e1c:	83 c4 10             	add    $0x10,%esp
80104e1f:	85 c0                	test   %eax,%eax
    return -1;
80104e21:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104e26:	0f 48 d8             	cmovs  %eax,%ebx
  return addr;
}
80104e29:	89 d8                	mov    %ebx,%eax
80104e2b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104e2e:	c9                   	leave  
80104e2f:	c3                   	ret    
    return -1;
80104e30:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80104e35:	eb f2                	jmp    80104e29 <sys_sbrk+0x38>

80104e37 <sys_sleep>:

int
sys_sleep(void)
{
80104e37:	55                   	push   %ebp
80104e38:	89 e5                	mov    %esp,%ebp
80104e3a:	53                   	push   %ebx
80104e3b:	83 ec 1c             	sub    $0x1c,%esp
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
80104e3e:	8d 45 f4             	lea    -0xc(%ebp),%eax
80104e41:	50                   	push   %eax
80104e42:	6a 00                	push   $0x0
80104e44:	e8 b7 f2 ff ff       	call   80104100 <argint>
80104e49:	83 c4 10             	add    $0x10,%esp
80104e4c:	85 c0                	test   %eax,%eax
80104e4e:	78 79                	js     80104ec9 <sys_sleep+0x92>
    return -1;
  acquire(&tickslock);
80104e50:	83 ec 0c             	sub    $0xc,%esp
80104e53:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104e58:	e8 6f ef ff ff       	call   80103dcc <acquire>
  ticks0 = ticks;
80104e5d:	8b 1d e0 cd 1d 80    	mov    0x801dcde0,%ebx
  while(ticks - ticks0 < n){
80104e63:	83 c4 10             	add    $0x10,%esp
80104e66:	83 7d f4 00          	cmpl   $0x0,-0xc(%ebp)
80104e6a:	74 2c                	je     80104e98 <sys_sleep+0x61>
    if(myproc()->killed){
80104e6c:	e8 dc e4 ff ff       	call   8010334d <myproc>
80104e71:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80104e75:	75 3b                	jne    80104eb2 <sys_sleep+0x7b>
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
80104e77:	83 ec 08             	sub    $0x8,%esp
80104e7a:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104e7f:	68 e0 cd 1d 80       	push   $0x801dcde0
80104e84:	e8 70 e9 ff ff       	call   801037f9 <sleep>
  while(ticks - ticks0 < n){
80104e89:	a1 e0 cd 1d 80       	mov    0x801dcde0,%eax
80104e8e:	29 d8                	sub    %ebx,%eax
80104e90:	83 c4 10             	add    $0x10,%esp
80104e93:	3b 45 f4             	cmp    -0xc(%ebp),%eax
80104e96:	72 d4                	jb     80104e6c <sys_sleep+0x35>
  }
  release(&tickslock);
80104e98:	83 ec 0c             	sub    $0xc,%esp
80104e9b:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104ea0:	e8 8e ef ff ff       	call   80103e33 <release>
  return 0;
80104ea5:	83 c4 10             	add    $0x10,%esp
80104ea8:	b8 00 00 00 00       	mov    $0x0,%eax
}
80104ead:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104eb0:	c9                   	leave  
80104eb1:	c3                   	ret    
      release(&tickslock);
80104eb2:	83 ec 0c             	sub    $0xc,%esp
80104eb5:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104eba:	e8 74 ef ff ff       	call   80103e33 <release>
      return -1;
80104ebf:	83 c4 10             	add    $0x10,%esp
80104ec2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ec7:	eb e4                	jmp    80104ead <sys_sleep+0x76>
    return -1;
80104ec9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ece:	eb dd                	jmp    80104ead <sys_sleep+0x76>

80104ed0 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
80104ed0:	55                   	push   %ebp
80104ed1:	89 e5                	mov    %esp,%ebp
80104ed3:	53                   	push   %ebx
80104ed4:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
80104ed7:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104edc:	e8 eb ee ff ff       	call   80103dcc <acquire>
  xticks = ticks;
80104ee1:	8b 1d e0 cd 1d 80    	mov    0x801dcde0,%ebx
  release(&tickslock);
80104ee7:	c7 04 24 a0 c5 1d 80 	movl   $0x801dc5a0,(%esp)
80104eee:	e8 40 ef ff ff       	call   80103e33 <release>
  return xticks;
}
80104ef3:	89 d8                	mov    %ebx,%eax
80104ef5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104ef8:	c9                   	leave  
80104ef9:	c3                   	ret    

80104efa <sys_ps>:

int
sys_ps(void)
{
80104efa:	55                   	push   %ebp
80104efb:	89 e5                	mov    %esp,%ebp
80104efd:	83 ec 08             	sub    $0x8,%esp
  ps();
80104f00:	e8 ed eb ff ff       	call   80103af2 <ps>
  return 0;
}
80104f05:	b8 00 00 00 00       	mov    $0x0,%eax
80104f0a:	c9                   	leave  
80104f0b:	c3                   	ret    

80104f0c <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
80104f0c:	1e                   	push   %ds
  pushl %es
80104f0d:	06                   	push   %es
  pushl %fs
80104f0e:	0f a0                	push   %fs
  pushl %gs
80104f10:	0f a8                	push   %gs
  pushal
80104f12:	60                   	pusha  
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80104f13:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80104f17:	8e d8                	mov    %eax,%ds
  movw %ax, %es
80104f19:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
80104f1b:	54                   	push   %esp
  call trap
80104f1c:	e8 bd 00 00 00       	call   80104fde <trap>
  addl $4, %esp
80104f21:	83 c4 04             	add    $0x4,%esp

80104f24 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80104f24:	61                   	popa   
  popl %gs
80104f25:	0f a9                	pop    %gs
  popl %fs
80104f27:	0f a1                	pop    %fs
  popl %es
80104f29:	07                   	pop    %es
  popl %ds
80104f2a:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
80104f2b:	83 c4 08             	add    $0x8,%esp
  iret
80104f2e:	cf                   	iret   

80104f2f <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
80104f2f:	55                   	push   %ebp
80104f30:	89 e5                	mov    %esp,%ebp
80104f32:	83 ec 08             	sub    $0x8,%esp
  int i;

  for(i = 0; i < 256; i++)
80104f35:	b8 00 00 00 00       	mov    $0x0,%eax
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80104f3a:	8b 14 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%edx
80104f41:	66 89 14 c5 e0 c5 1d 	mov    %dx,-0x7fe23a20(,%eax,8)
80104f48:	80 
80104f49:	66 c7 04 c5 e2 c5 1d 	movw   $0x8,-0x7fe23a1e(,%eax,8)
80104f50:	80 08 00 
80104f53:	c6 04 c5 e4 c5 1d 80 	movb   $0x0,-0x7fe23a1c(,%eax,8)
80104f5a:	00 
80104f5b:	c6 04 c5 e5 c5 1d 80 	movb   $0x8e,-0x7fe23a1b(,%eax,8)
80104f62:	8e 
80104f63:	c1 ea 10             	shr    $0x10,%edx
80104f66:	66 89 14 c5 e6 c5 1d 	mov    %dx,-0x7fe23a1a(,%eax,8)
80104f6d:	80 
  for(i = 0; i < 256; i++)
80104f6e:	83 c0 01             	add    $0x1,%eax
80104f71:	3d 00 01 00 00       	cmp    $0x100,%eax
80104f76:	75 c2                	jne    80104f3a <tvinit+0xb>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80104f78:	a1 08 b1 10 80       	mov    0x8010b108,%eax
80104f7d:	66 a3 e0 c7 1d 80    	mov    %ax,0x801dc7e0
80104f83:	66 c7 05 e2 c7 1d 80 	movw   $0x8,0x801dc7e2
80104f8a:	08 00 
80104f8c:	c6 05 e4 c7 1d 80 00 	movb   $0x0,0x801dc7e4
80104f93:	c6 05 e5 c7 1d 80 ef 	movb   $0xef,0x801dc7e5
80104f9a:	c1 e8 10             	shr    $0x10,%eax
80104f9d:	66 a3 e6 c7 1d 80    	mov    %ax,0x801dc7e6

  initlock(&tickslock, "time");
80104fa3:	83 ec 08             	sub    $0x8,%esp
80104fa6:	68 c1 87 10 80       	push   $0x801087c1
80104fab:	68 a0 c5 1d 80       	push   $0x801dc5a0
80104fb0:	e8 cf ec ff ff       	call   80103c84 <initlock>
}
80104fb5:	83 c4 10             	add    $0x10,%esp
80104fb8:	c9                   	leave  
80104fb9:	c3                   	ret    

80104fba <idtinit>:

void
idtinit(void)
{
80104fba:	55                   	push   %ebp
80104fbb:	89 e5                	mov    %esp,%ebp
80104fbd:	83 ec 10             	sub    $0x10,%esp
  pd[0] = size-1;
80104fc0:	66 c7 45 fa ff 07    	movw   $0x7ff,-0x6(%ebp)
  pd[1] = (uint)p;
80104fc6:	b8 e0 c5 1d 80       	mov    $0x801dc5e0,%eax
80104fcb:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80104fcf:	c1 e8 10             	shr    $0x10,%eax
80104fd2:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80104fd6:	8d 45 fa             	lea    -0x6(%ebp),%eax
80104fd9:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80104fdc:	c9                   	leave  
80104fdd:	c3                   	ret    

80104fde <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80104fde:	55                   	push   %ebp
80104fdf:	89 e5                	mov    %esp,%ebp
80104fe1:	57                   	push   %edi
80104fe2:	56                   	push   %esi
80104fe3:	53                   	push   %ebx
80104fe4:	83 ec 1c             	sub    $0x1c,%esp
80104fe7:	8b 7d 08             	mov    0x8(%ebp),%edi
  if(tf->trapno == T_SYSCALL){
80104fea:	8b 47 30             	mov    0x30(%edi),%eax
80104fed:	83 f8 40             	cmp    $0x40,%eax
80104ff0:	74 13                	je     80105005 <trap+0x27>
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
80104ff2:	83 e8 20             	sub    $0x20,%eax
80104ff5:	83 f8 1f             	cmp    $0x1f,%eax
80104ff8:	0f 87 37 01 00 00    	ja     80105135 <trap+0x157>
80104ffe:	ff 24 85 68 88 10 80 	jmp    *-0x7fef7798(,%eax,4)
    if(myproc()->killed)
80105005:	e8 43 e3 ff ff       	call   8010334d <myproc>
8010500a:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
8010500e:	75 1f                	jne    8010502f <trap+0x51>
    myproc()->tf = tf;
80105010:	e8 38 e3 ff ff       	call   8010334d <myproc>
80105015:	89 78 18             	mov    %edi,0x18(%eax)
    syscall();
80105018:	e8 9d f1 ff ff       	call   801041ba <syscall>
    if(myproc()->killed)
8010501d:	e8 2b e3 ff ff       	call   8010334d <myproc>
80105022:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80105026:	74 7e                	je     801050a6 <trap+0xc8>
      exit();
80105028:	e8 d3 e6 ff ff       	call   80103700 <exit>
8010502d:	eb 77                	jmp    801050a6 <trap+0xc8>
      exit();
8010502f:	e8 cc e6 ff ff       	call   80103700 <exit>
80105034:	eb da                	jmp    80105010 <trap+0x32>
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
80105036:	e8 f7 e2 ff ff       	call   80103332 <cpuid>
8010503b:	85 c0                	test   %eax,%eax
8010503d:	74 6f                	je     801050ae <trap+0xd0>
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
8010503f:	e8 16 d4 ff ff       	call   8010245a <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105044:	e8 04 e3 ff ff       	call   8010334d <myproc>
80105049:	85 c0                	test   %eax,%eax
8010504b:	74 1c                	je     80105069 <trap+0x8b>
8010504d:	e8 fb e2 ff ff       	call   8010334d <myproc>
80105052:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80105056:	74 11                	je     80105069 <trap+0x8b>
80105058:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
8010505c:	83 e0 03             	and    $0x3,%eax
8010505f:	66 83 f8 03          	cmp    $0x3,%ax
80105063:	0f 84 60 01 00 00    	je     801051c9 <trap+0x1eb>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80105069:	e8 df e2 ff ff       	call   8010334d <myproc>
8010506e:	85 c0                	test   %eax,%eax
80105070:	74 0f                	je     80105081 <trap+0xa3>
80105072:	e8 d6 e2 ff ff       	call   8010334d <myproc>
80105077:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
8010507b:	0f 84 52 01 00 00    	je     801051d3 <trap+0x1f5>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105081:	e8 c7 e2 ff ff       	call   8010334d <myproc>
80105086:	85 c0                	test   %eax,%eax
80105088:	74 1c                	je     801050a6 <trap+0xc8>
8010508a:	e8 be e2 ff ff       	call   8010334d <myproc>
8010508f:	83 78 24 00          	cmpl   $0x0,0x24(%eax)
80105093:	74 11                	je     801050a6 <trap+0xc8>
80105095:	0f b7 47 3c          	movzwl 0x3c(%edi),%eax
80105099:	83 e0 03             	and    $0x3,%eax
8010509c:	66 83 f8 03          	cmp    $0x3,%ax
801050a0:	0f 84 41 01 00 00    	je     801051e7 <trap+0x209>
    exit();
}
801050a6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801050a9:	5b                   	pop    %ebx
801050aa:	5e                   	pop    %esi
801050ab:	5f                   	pop    %edi
801050ac:	5d                   	pop    %ebp
801050ad:	c3                   	ret    
      acquire(&tickslock);
801050ae:	83 ec 0c             	sub    $0xc,%esp
801050b1:	68 a0 c5 1d 80       	push   $0x801dc5a0
801050b6:	e8 11 ed ff ff       	call   80103dcc <acquire>
      ticks++;
801050bb:	83 05 e0 cd 1d 80 01 	addl   $0x1,0x801dcde0
      wakeup(&ticks);
801050c2:	c7 04 24 e0 cd 1d 80 	movl   $0x801dcde0,(%esp)
801050c9:	e8 ab e8 ff ff       	call   80103979 <wakeup>
      release(&tickslock);
801050ce:	c7 04 24 a0 c5 1d 80 	movl   $0x801dc5a0,(%esp)
801050d5:	e8 59 ed ff ff       	call   80103e33 <release>
801050da:	83 c4 10             	add    $0x10,%esp
801050dd:	e9 5d ff ff ff       	jmp    8010503f <trap+0x61>
    ideintr();
801050e2:	e8 09 cd ff ff       	call   80101df0 <ideintr>
    lapiceoi();
801050e7:	e8 6e d3 ff ff       	call   8010245a <lapiceoi>
    break;
801050ec:	e9 53 ff ff ff       	jmp    80105044 <trap+0x66>
    kbdintr();
801050f1:	e8 98 d1 ff ff       	call   8010228e <kbdintr>
    lapiceoi();
801050f6:	e8 5f d3 ff ff       	call   8010245a <lapiceoi>
    break;
801050fb:	e9 44 ff ff ff       	jmp    80105044 <trap+0x66>
    uartintr();
80105100:	e8 1a 02 00 00       	call   8010531f <uartintr>
    lapiceoi();
80105105:	e8 50 d3 ff ff       	call   8010245a <lapiceoi>
    break;
8010510a:	e9 35 ff ff ff       	jmp    80105044 <trap+0x66>
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
8010510f:	8b 77 38             	mov    0x38(%edi),%esi
80105112:	0f b7 5f 3c          	movzwl 0x3c(%edi),%ebx
80105116:	e8 17 e2 ff ff       	call   80103332 <cpuid>
8010511b:	56                   	push   %esi
8010511c:	53                   	push   %ebx
8010511d:	50                   	push   %eax
8010511e:	68 cc 87 10 80       	push   $0x801087cc
80105123:	e8 b9 b4 ff ff       	call   801005e1 <cprintf>
    lapiceoi();
80105128:	e8 2d d3 ff ff       	call   8010245a <lapiceoi>
    break;
8010512d:	83 c4 10             	add    $0x10,%esp
80105130:	e9 0f ff ff ff       	jmp    80105044 <trap+0x66>
    if(myproc() == 0 || (tf->cs&3) == 0){
80105135:	e8 13 e2 ff ff       	call   8010334d <myproc>
8010513a:	85 c0                	test   %eax,%eax
8010513c:	74 60                	je     8010519e <trap+0x1c0>
8010513e:	f6 47 3c 03          	testb  $0x3,0x3c(%edi)
80105142:	74 5a                	je     8010519e <trap+0x1c0>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
80105144:	0f 20 d0             	mov    %cr2,%eax
80105147:	89 45 d8             	mov    %eax,-0x28(%ebp)
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010514a:	8b 77 38             	mov    0x38(%edi),%esi
8010514d:	e8 e0 e1 ff ff       	call   80103332 <cpuid>
80105152:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80105155:	8b 5f 34             	mov    0x34(%edi),%ebx
80105158:	8b 4f 30             	mov    0x30(%edi),%ecx
8010515b:	89 4d e0             	mov    %ecx,-0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
8010515e:	e8 ea e1 ff ff       	call   8010334d <myproc>
80105163:	89 45 dc             	mov    %eax,-0x24(%ebp)
80105166:	e8 e2 e1 ff ff       	call   8010334d <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010516b:	ff 75 d8             	pushl  -0x28(%ebp)
8010516e:	56                   	push   %esi
8010516f:	ff 75 e4             	pushl  -0x1c(%ebp)
80105172:	53                   	push   %ebx
80105173:	ff 75 e0             	pushl  -0x20(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80105176:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105179:	83 c2 6c             	add    $0x6c,%edx
    cprintf("pid %d %s: trap %d err %d on cpu %d "
8010517c:	52                   	push   %edx
8010517d:	ff 70 10             	pushl  0x10(%eax)
80105180:	68 24 88 10 80       	push   $0x80108824
80105185:	e8 57 b4 ff ff       	call   801005e1 <cprintf>
    myproc()->killed = 1;
8010518a:	83 c4 20             	add    $0x20,%esp
8010518d:	e8 bb e1 ff ff       	call   8010334d <myproc>
80105192:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
80105199:	e9 a6 fe ff ff       	jmp    80105044 <trap+0x66>
8010519e:	0f 20 d6             	mov    %cr2,%esi
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
801051a1:	8b 5f 38             	mov    0x38(%edi),%ebx
801051a4:	e8 89 e1 ff ff       	call   80103332 <cpuid>
801051a9:	83 ec 0c             	sub    $0xc,%esp
801051ac:	56                   	push   %esi
801051ad:	53                   	push   %ebx
801051ae:	50                   	push   %eax
801051af:	ff 77 30             	pushl  0x30(%edi)
801051b2:	68 f0 87 10 80       	push   $0x801087f0
801051b7:	e8 25 b4 ff ff       	call   801005e1 <cprintf>
      panic("trap");
801051bc:	83 c4 14             	add    $0x14,%esp
801051bf:	68 c6 87 10 80       	push   $0x801087c6
801051c4:	e8 7b b1 ff ff       	call   80100344 <panic>
    exit();
801051c9:	e8 32 e5 ff ff       	call   80103700 <exit>
801051ce:	e9 96 fe ff ff       	jmp    80105069 <trap+0x8b>
  if(myproc() && myproc()->state == RUNNING &&
801051d3:	83 7f 30 20          	cmpl   $0x20,0x30(%edi)
801051d7:	0f 85 a4 fe ff ff    	jne    80105081 <trap+0xa3>
    yield();
801051dd:	e8 e5 e5 ff ff       	call   801037c7 <yield>
801051e2:	e9 9a fe ff ff       	jmp    80105081 <trap+0xa3>
    exit();
801051e7:	e8 14 e5 ff ff       	call   80103700 <exit>
801051ec:	e9 b5 fe ff ff       	jmp    801050a6 <trap+0xc8>

801051f1 <uartgetc>:
  outb(COM1+0, c);
}

static int
uartgetc(void)
{
801051f1:	55                   	push   %ebp
801051f2:	89 e5                	mov    %esp,%ebp
  if(!uart)
801051f4:	83 3d bc b5 10 80 00 	cmpl   $0x0,0x8010b5bc
801051fb:	74 15                	je     80105212 <uartgetc+0x21>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801051fd:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105202:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
80105203:	a8 01                	test   $0x1,%al
80105205:	74 12                	je     80105219 <uartgetc+0x28>
80105207:	ba f8 03 00 00       	mov    $0x3f8,%edx
8010520c:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
8010520d:	0f b6 c0             	movzbl %al,%eax
}
80105210:	5d                   	pop    %ebp
80105211:	c3                   	ret    
    return -1;
80105212:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105217:	eb f7                	jmp    80105210 <uartgetc+0x1f>
    return -1;
80105219:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010521e:	eb f0                	jmp    80105210 <uartgetc+0x1f>

80105220 <uartputc>:
  if(!uart)
80105220:	83 3d bc b5 10 80 00 	cmpl   $0x0,0x8010b5bc
80105227:	74 4f                	je     80105278 <uartputc+0x58>
{
80105229:	55                   	push   %ebp
8010522a:	89 e5                	mov    %esp,%ebp
8010522c:	56                   	push   %esi
8010522d:	53                   	push   %ebx
8010522e:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105233:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80105234:	a8 20                	test   $0x20,%al
80105236:	75 30                	jne    80105268 <uartputc+0x48>
    microdelay(10);
80105238:	83 ec 0c             	sub    $0xc,%esp
8010523b:	6a 0a                	push   $0xa
8010523d:	e8 37 d2 ff ff       	call   80102479 <microdelay>
80105242:	83 c4 10             	add    $0x10,%esp
80105245:	bb 7f 00 00 00       	mov    $0x7f,%ebx
8010524a:	be fd 03 00 00       	mov    $0x3fd,%esi
8010524f:	89 f2                	mov    %esi,%edx
80105251:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80105252:	a8 20                	test   $0x20,%al
80105254:	75 12                	jne    80105268 <uartputc+0x48>
    microdelay(10);
80105256:	83 ec 0c             	sub    $0xc,%esp
80105259:	6a 0a                	push   $0xa
8010525b:	e8 19 d2 ff ff       	call   80102479 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80105260:	83 c4 10             	add    $0x10,%esp
80105263:	83 eb 01             	sub    $0x1,%ebx
80105266:	75 e7                	jne    8010524f <uartputc+0x2f>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80105268:	8b 45 08             	mov    0x8(%ebp),%eax
8010526b:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105270:	ee                   	out    %al,(%dx)
}
80105271:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105274:	5b                   	pop    %ebx
80105275:	5e                   	pop    %esi
80105276:	5d                   	pop    %ebp
80105277:	c3                   	ret    
80105278:	f3 c3                	repz ret 

8010527a <uartinit>:
{
8010527a:	55                   	push   %ebp
8010527b:	89 e5                	mov    %esp,%ebp
8010527d:	56                   	push   %esi
8010527e:	53                   	push   %ebx
8010527f:	b9 00 00 00 00       	mov    $0x0,%ecx
80105284:	ba fa 03 00 00       	mov    $0x3fa,%edx
80105289:	89 c8                	mov    %ecx,%eax
8010528b:	ee                   	out    %al,(%dx)
8010528c:	be fb 03 00 00       	mov    $0x3fb,%esi
80105291:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
80105296:	89 f2                	mov    %esi,%edx
80105298:	ee                   	out    %al,(%dx)
80105299:	b8 0c 00 00 00       	mov    $0xc,%eax
8010529e:	ba f8 03 00 00       	mov    $0x3f8,%edx
801052a3:	ee                   	out    %al,(%dx)
801052a4:	bb f9 03 00 00       	mov    $0x3f9,%ebx
801052a9:	89 c8                	mov    %ecx,%eax
801052ab:	89 da                	mov    %ebx,%edx
801052ad:	ee                   	out    %al,(%dx)
801052ae:	b8 03 00 00 00       	mov    $0x3,%eax
801052b3:	89 f2                	mov    %esi,%edx
801052b5:	ee                   	out    %al,(%dx)
801052b6:	ba fc 03 00 00       	mov    $0x3fc,%edx
801052bb:	89 c8                	mov    %ecx,%eax
801052bd:	ee                   	out    %al,(%dx)
801052be:	b8 01 00 00 00       	mov    $0x1,%eax
801052c3:	89 da                	mov    %ebx,%edx
801052c5:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801052c6:	ba fd 03 00 00       	mov    $0x3fd,%edx
801052cb:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
801052cc:	3c ff                	cmp    $0xff,%al
801052ce:	74 48                	je     80105318 <uartinit+0x9e>
  uart = 1;
801052d0:	c7 05 bc b5 10 80 01 	movl   $0x1,0x8010b5bc
801052d7:	00 00 00 
801052da:	ba fa 03 00 00       	mov    $0x3fa,%edx
801052df:	ec                   	in     (%dx),%al
801052e0:	ba f8 03 00 00       	mov    $0x3f8,%edx
801052e5:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
801052e6:	83 ec 08             	sub    $0x8,%esp
801052e9:	6a 00                	push   $0x0
801052eb:	6a 04                	push   $0x4
801052ed:	e8 14 cd ff ff       	call   80102006 <ioapicenable>
801052f2:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
801052f5:	bb e8 88 10 80       	mov    $0x801088e8,%ebx
801052fa:	b8 78 00 00 00       	mov    $0x78,%eax
    uartputc(*p);
801052ff:	83 ec 0c             	sub    $0xc,%esp
80105302:	0f be c0             	movsbl %al,%eax
80105305:	50                   	push   %eax
80105306:	e8 15 ff ff ff       	call   80105220 <uartputc>
  for(p="xv6...\n"; *p; p++)
8010530b:	83 c3 01             	add    $0x1,%ebx
8010530e:	0f b6 03             	movzbl (%ebx),%eax
80105311:	83 c4 10             	add    $0x10,%esp
80105314:	84 c0                	test   %al,%al
80105316:	75 e7                	jne    801052ff <uartinit+0x85>
}
80105318:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010531b:	5b                   	pop    %ebx
8010531c:	5e                   	pop    %esi
8010531d:	5d                   	pop    %ebp
8010531e:	c3                   	ret    

8010531f <uartintr>:

void
uartintr(void)
{
8010531f:	55                   	push   %ebp
80105320:	89 e5                	mov    %esp,%ebp
80105322:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
80105325:	68 f1 51 10 80       	push   $0x801051f1
8010532a:	e8 0c b4 ff ff       	call   8010073b <consoleintr>
}
8010532f:	83 c4 10             	add    $0x10,%esp
80105332:	c9                   	leave  
80105333:	c3                   	ret    

80105334 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
80105334:	6a 00                	push   $0x0
  pushl $0
80105336:	6a 00                	push   $0x0
  jmp alltraps
80105338:	e9 cf fb ff ff       	jmp    80104f0c <alltraps>

8010533d <vector1>:
.globl vector1
vector1:
  pushl $0
8010533d:	6a 00                	push   $0x0
  pushl $1
8010533f:	6a 01                	push   $0x1
  jmp alltraps
80105341:	e9 c6 fb ff ff       	jmp    80104f0c <alltraps>

80105346 <vector2>:
.globl vector2
vector2:
  pushl $0
80105346:	6a 00                	push   $0x0
  pushl $2
80105348:	6a 02                	push   $0x2
  jmp alltraps
8010534a:	e9 bd fb ff ff       	jmp    80104f0c <alltraps>

8010534f <vector3>:
.globl vector3
vector3:
  pushl $0
8010534f:	6a 00                	push   $0x0
  pushl $3
80105351:	6a 03                	push   $0x3
  jmp alltraps
80105353:	e9 b4 fb ff ff       	jmp    80104f0c <alltraps>

80105358 <vector4>:
.globl vector4
vector4:
  pushl $0
80105358:	6a 00                	push   $0x0
  pushl $4
8010535a:	6a 04                	push   $0x4
  jmp alltraps
8010535c:	e9 ab fb ff ff       	jmp    80104f0c <alltraps>

80105361 <vector5>:
.globl vector5
vector5:
  pushl $0
80105361:	6a 00                	push   $0x0
  pushl $5
80105363:	6a 05                	push   $0x5
  jmp alltraps
80105365:	e9 a2 fb ff ff       	jmp    80104f0c <alltraps>

8010536a <vector6>:
.globl vector6
vector6:
  pushl $0
8010536a:	6a 00                	push   $0x0
  pushl $6
8010536c:	6a 06                	push   $0x6
  jmp alltraps
8010536e:	e9 99 fb ff ff       	jmp    80104f0c <alltraps>

80105373 <vector7>:
.globl vector7
vector7:
  pushl $0
80105373:	6a 00                	push   $0x0
  pushl $7
80105375:	6a 07                	push   $0x7
  jmp alltraps
80105377:	e9 90 fb ff ff       	jmp    80104f0c <alltraps>

8010537c <vector8>:
.globl vector8
vector8:
  pushl $8
8010537c:	6a 08                	push   $0x8
  jmp alltraps
8010537e:	e9 89 fb ff ff       	jmp    80104f0c <alltraps>

80105383 <vector9>:
.globl vector9
vector9:
  pushl $0
80105383:	6a 00                	push   $0x0
  pushl $9
80105385:	6a 09                	push   $0x9
  jmp alltraps
80105387:	e9 80 fb ff ff       	jmp    80104f0c <alltraps>

8010538c <vector10>:
.globl vector10
vector10:
  pushl $10
8010538c:	6a 0a                	push   $0xa
  jmp alltraps
8010538e:	e9 79 fb ff ff       	jmp    80104f0c <alltraps>

80105393 <vector11>:
.globl vector11
vector11:
  pushl $11
80105393:	6a 0b                	push   $0xb
  jmp alltraps
80105395:	e9 72 fb ff ff       	jmp    80104f0c <alltraps>

8010539a <vector12>:
.globl vector12
vector12:
  pushl $12
8010539a:	6a 0c                	push   $0xc
  jmp alltraps
8010539c:	e9 6b fb ff ff       	jmp    80104f0c <alltraps>

801053a1 <vector13>:
.globl vector13
vector13:
  pushl $13
801053a1:	6a 0d                	push   $0xd
  jmp alltraps
801053a3:	e9 64 fb ff ff       	jmp    80104f0c <alltraps>

801053a8 <vector14>:
.globl vector14
vector14:
  pushl $14
801053a8:	6a 0e                	push   $0xe
  jmp alltraps
801053aa:	e9 5d fb ff ff       	jmp    80104f0c <alltraps>

801053af <vector15>:
.globl vector15
vector15:
  pushl $0
801053af:	6a 00                	push   $0x0
  pushl $15
801053b1:	6a 0f                	push   $0xf
  jmp alltraps
801053b3:	e9 54 fb ff ff       	jmp    80104f0c <alltraps>

801053b8 <vector16>:
.globl vector16
vector16:
  pushl $0
801053b8:	6a 00                	push   $0x0
  pushl $16
801053ba:	6a 10                	push   $0x10
  jmp alltraps
801053bc:	e9 4b fb ff ff       	jmp    80104f0c <alltraps>

801053c1 <vector17>:
.globl vector17
vector17:
  pushl $17
801053c1:	6a 11                	push   $0x11
  jmp alltraps
801053c3:	e9 44 fb ff ff       	jmp    80104f0c <alltraps>

801053c8 <vector18>:
.globl vector18
vector18:
  pushl $0
801053c8:	6a 00                	push   $0x0
  pushl $18
801053ca:	6a 12                	push   $0x12
  jmp alltraps
801053cc:	e9 3b fb ff ff       	jmp    80104f0c <alltraps>

801053d1 <vector19>:
.globl vector19
vector19:
  pushl $0
801053d1:	6a 00                	push   $0x0
  pushl $19
801053d3:	6a 13                	push   $0x13
  jmp alltraps
801053d5:	e9 32 fb ff ff       	jmp    80104f0c <alltraps>

801053da <vector20>:
.globl vector20
vector20:
  pushl $0
801053da:	6a 00                	push   $0x0
  pushl $20
801053dc:	6a 14                	push   $0x14
  jmp alltraps
801053de:	e9 29 fb ff ff       	jmp    80104f0c <alltraps>

801053e3 <vector21>:
.globl vector21
vector21:
  pushl $0
801053e3:	6a 00                	push   $0x0
  pushl $21
801053e5:	6a 15                	push   $0x15
  jmp alltraps
801053e7:	e9 20 fb ff ff       	jmp    80104f0c <alltraps>

801053ec <vector22>:
.globl vector22
vector22:
  pushl $0
801053ec:	6a 00                	push   $0x0
  pushl $22
801053ee:	6a 16                	push   $0x16
  jmp alltraps
801053f0:	e9 17 fb ff ff       	jmp    80104f0c <alltraps>

801053f5 <vector23>:
.globl vector23
vector23:
  pushl $0
801053f5:	6a 00                	push   $0x0
  pushl $23
801053f7:	6a 17                	push   $0x17
  jmp alltraps
801053f9:	e9 0e fb ff ff       	jmp    80104f0c <alltraps>

801053fe <vector24>:
.globl vector24
vector24:
  pushl $0
801053fe:	6a 00                	push   $0x0
  pushl $24
80105400:	6a 18                	push   $0x18
  jmp alltraps
80105402:	e9 05 fb ff ff       	jmp    80104f0c <alltraps>

80105407 <vector25>:
.globl vector25
vector25:
  pushl $0
80105407:	6a 00                	push   $0x0
  pushl $25
80105409:	6a 19                	push   $0x19
  jmp alltraps
8010540b:	e9 fc fa ff ff       	jmp    80104f0c <alltraps>

80105410 <vector26>:
.globl vector26
vector26:
  pushl $0
80105410:	6a 00                	push   $0x0
  pushl $26
80105412:	6a 1a                	push   $0x1a
  jmp alltraps
80105414:	e9 f3 fa ff ff       	jmp    80104f0c <alltraps>

80105419 <vector27>:
.globl vector27
vector27:
  pushl $0
80105419:	6a 00                	push   $0x0
  pushl $27
8010541b:	6a 1b                	push   $0x1b
  jmp alltraps
8010541d:	e9 ea fa ff ff       	jmp    80104f0c <alltraps>

80105422 <vector28>:
.globl vector28
vector28:
  pushl $0
80105422:	6a 00                	push   $0x0
  pushl $28
80105424:	6a 1c                	push   $0x1c
  jmp alltraps
80105426:	e9 e1 fa ff ff       	jmp    80104f0c <alltraps>

8010542b <vector29>:
.globl vector29
vector29:
  pushl $0
8010542b:	6a 00                	push   $0x0
  pushl $29
8010542d:	6a 1d                	push   $0x1d
  jmp alltraps
8010542f:	e9 d8 fa ff ff       	jmp    80104f0c <alltraps>

80105434 <vector30>:
.globl vector30
vector30:
  pushl $0
80105434:	6a 00                	push   $0x0
  pushl $30
80105436:	6a 1e                	push   $0x1e
  jmp alltraps
80105438:	e9 cf fa ff ff       	jmp    80104f0c <alltraps>

8010543d <vector31>:
.globl vector31
vector31:
  pushl $0
8010543d:	6a 00                	push   $0x0
  pushl $31
8010543f:	6a 1f                	push   $0x1f
  jmp alltraps
80105441:	e9 c6 fa ff ff       	jmp    80104f0c <alltraps>

80105446 <vector32>:
.globl vector32
vector32:
  pushl $0
80105446:	6a 00                	push   $0x0
  pushl $32
80105448:	6a 20                	push   $0x20
  jmp alltraps
8010544a:	e9 bd fa ff ff       	jmp    80104f0c <alltraps>

8010544f <vector33>:
.globl vector33
vector33:
  pushl $0
8010544f:	6a 00                	push   $0x0
  pushl $33
80105451:	6a 21                	push   $0x21
  jmp alltraps
80105453:	e9 b4 fa ff ff       	jmp    80104f0c <alltraps>

80105458 <vector34>:
.globl vector34
vector34:
  pushl $0
80105458:	6a 00                	push   $0x0
  pushl $34
8010545a:	6a 22                	push   $0x22
  jmp alltraps
8010545c:	e9 ab fa ff ff       	jmp    80104f0c <alltraps>

80105461 <vector35>:
.globl vector35
vector35:
  pushl $0
80105461:	6a 00                	push   $0x0
  pushl $35
80105463:	6a 23                	push   $0x23
  jmp alltraps
80105465:	e9 a2 fa ff ff       	jmp    80104f0c <alltraps>

8010546a <vector36>:
.globl vector36
vector36:
  pushl $0
8010546a:	6a 00                	push   $0x0
  pushl $36
8010546c:	6a 24                	push   $0x24
  jmp alltraps
8010546e:	e9 99 fa ff ff       	jmp    80104f0c <alltraps>

80105473 <vector37>:
.globl vector37
vector37:
  pushl $0
80105473:	6a 00                	push   $0x0
  pushl $37
80105475:	6a 25                	push   $0x25
  jmp alltraps
80105477:	e9 90 fa ff ff       	jmp    80104f0c <alltraps>

8010547c <vector38>:
.globl vector38
vector38:
  pushl $0
8010547c:	6a 00                	push   $0x0
  pushl $38
8010547e:	6a 26                	push   $0x26
  jmp alltraps
80105480:	e9 87 fa ff ff       	jmp    80104f0c <alltraps>

80105485 <vector39>:
.globl vector39
vector39:
  pushl $0
80105485:	6a 00                	push   $0x0
  pushl $39
80105487:	6a 27                	push   $0x27
  jmp alltraps
80105489:	e9 7e fa ff ff       	jmp    80104f0c <alltraps>

8010548e <vector40>:
.globl vector40
vector40:
  pushl $0
8010548e:	6a 00                	push   $0x0
  pushl $40
80105490:	6a 28                	push   $0x28
  jmp alltraps
80105492:	e9 75 fa ff ff       	jmp    80104f0c <alltraps>

80105497 <vector41>:
.globl vector41
vector41:
  pushl $0
80105497:	6a 00                	push   $0x0
  pushl $41
80105499:	6a 29                	push   $0x29
  jmp alltraps
8010549b:	e9 6c fa ff ff       	jmp    80104f0c <alltraps>

801054a0 <vector42>:
.globl vector42
vector42:
  pushl $0
801054a0:	6a 00                	push   $0x0
  pushl $42
801054a2:	6a 2a                	push   $0x2a
  jmp alltraps
801054a4:	e9 63 fa ff ff       	jmp    80104f0c <alltraps>

801054a9 <vector43>:
.globl vector43
vector43:
  pushl $0
801054a9:	6a 00                	push   $0x0
  pushl $43
801054ab:	6a 2b                	push   $0x2b
  jmp alltraps
801054ad:	e9 5a fa ff ff       	jmp    80104f0c <alltraps>

801054b2 <vector44>:
.globl vector44
vector44:
  pushl $0
801054b2:	6a 00                	push   $0x0
  pushl $44
801054b4:	6a 2c                	push   $0x2c
  jmp alltraps
801054b6:	e9 51 fa ff ff       	jmp    80104f0c <alltraps>

801054bb <vector45>:
.globl vector45
vector45:
  pushl $0
801054bb:	6a 00                	push   $0x0
  pushl $45
801054bd:	6a 2d                	push   $0x2d
  jmp alltraps
801054bf:	e9 48 fa ff ff       	jmp    80104f0c <alltraps>

801054c4 <vector46>:
.globl vector46
vector46:
  pushl $0
801054c4:	6a 00                	push   $0x0
  pushl $46
801054c6:	6a 2e                	push   $0x2e
  jmp alltraps
801054c8:	e9 3f fa ff ff       	jmp    80104f0c <alltraps>

801054cd <vector47>:
.globl vector47
vector47:
  pushl $0
801054cd:	6a 00                	push   $0x0
  pushl $47
801054cf:	6a 2f                	push   $0x2f
  jmp alltraps
801054d1:	e9 36 fa ff ff       	jmp    80104f0c <alltraps>

801054d6 <vector48>:
.globl vector48
vector48:
  pushl $0
801054d6:	6a 00                	push   $0x0
  pushl $48
801054d8:	6a 30                	push   $0x30
  jmp alltraps
801054da:	e9 2d fa ff ff       	jmp    80104f0c <alltraps>

801054df <vector49>:
.globl vector49
vector49:
  pushl $0
801054df:	6a 00                	push   $0x0
  pushl $49
801054e1:	6a 31                	push   $0x31
  jmp alltraps
801054e3:	e9 24 fa ff ff       	jmp    80104f0c <alltraps>

801054e8 <vector50>:
.globl vector50
vector50:
  pushl $0
801054e8:	6a 00                	push   $0x0
  pushl $50
801054ea:	6a 32                	push   $0x32
  jmp alltraps
801054ec:	e9 1b fa ff ff       	jmp    80104f0c <alltraps>

801054f1 <vector51>:
.globl vector51
vector51:
  pushl $0
801054f1:	6a 00                	push   $0x0
  pushl $51
801054f3:	6a 33                	push   $0x33
  jmp alltraps
801054f5:	e9 12 fa ff ff       	jmp    80104f0c <alltraps>

801054fa <vector52>:
.globl vector52
vector52:
  pushl $0
801054fa:	6a 00                	push   $0x0
  pushl $52
801054fc:	6a 34                	push   $0x34
  jmp alltraps
801054fe:	e9 09 fa ff ff       	jmp    80104f0c <alltraps>

80105503 <vector53>:
.globl vector53
vector53:
  pushl $0
80105503:	6a 00                	push   $0x0
  pushl $53
80105505:	6a 35                	push   $0x35
  jmp alltraps
80105507:	e9 00 fa ff ff       	jmp    80104f0c <alltraps>

8010550c <vector54>:
.globl vector54
vector54:
  pushl $0
8010550c:	6a 00                	push   $0x0
  pushl $54
8010550e:	6a 36                	push   $0x36
  jmp alltraps
80105510:	e9 f7 f9 ff ff       	jmp    80104f0c <alltraps>

80105515 <vector55>:
.globl vector55
vector55:
  pushl $0
80105515:	6a 00                	push   $0x0
  pushl $55
80105517:	6a 37                	push   $0x37
  jmp alltraps
80105519:	e9 ee f9 ff ff       	jmp    80104f0c <alltraps>

8010551e <vector56>:
.globl vector56
vector56:
  pushl $0
8010551e:	6a 00                	push   $0x0
  pushl $56
80105520:	6a 38                	push   $0x38
  jmp alltraps
80105522:	e9 e5 f9 ff ff       	jmp    80104f0c <alltraps>

80105527 <vector57>:
.globl vector57
vector57:
  pushl $0
80105527:	6a 00                	push   $0x0
  pushl $57
80105529:	6a 39                	push   $0x39
  jmp alltraps
8010552b:	e9 dc f9 ff ff       	jmp    80104f0c <alltraps>

80105530 <vector58>:
.globl vector58
vector58:
  pushl $0
80105530:	6a 00                	push   $0x0
  pushl $58
80105532:	6a 3a                	push   $0x3a
  jmp alltraps
80105534:	e9 d3 f9 ff ff       	jmp    80104f0c <alltraps>

80105539 <vector59>:
.globl vector59
vector59:
  pushl $0
80105539:	6a 00                	push   $0x0
  pushl $59
8010553b:	6a 3b                	push   $0x3b
  jmp alltraps
8010553d:	e9 ca f9 ff ff       	jmp    80104f0c <alltraps>

80105542 <vector60>:
.globl vector60
vector60:
  pushl $0
80105542:	6a 00                	push   $0x0
  pushl $60
80105544:	6a 3c                	push   $0x3c
  jmp alltraps
80105546:	e9 c1 f9 ff ff       	jmp    80104f0c <alltraps>

8010554b <vector61>:
.globl vector61
vector61:
  pushl $0
8010554b:	6a 00                	push   $0x0
  pushl $61
8010554d:	6a 3d                	push   $0x3d
  jmp alltraps
8010554f:	e9 b8 f9 ff ff       	jmp    80104f0c <alltraps>

80105554 <vector62>:
.globl vector62
vector62:
  pushl $0
80105554:	6a 00                	push   $0x0
  pushl $62
80105556:	6a 3e                	push   $0x3e
  jmp alltraps
80105558:	e9 af f9 ff ff       	jmp    80104f0c <alltraps>

8010555d <vector63>:
.globl vector63
vector63:
  pushl $0
8010555d:	6a 00                	push   $0x0
  pushl $63
8010555f:	6a 3f                	push   $0x3f
  jmp alltraps
80105561:	e9 a6 f9 ff ff       	jmp    80104f0c <alltraps>

80105566 <vector64>:
.globl vector64
vector64:
  pushl $0
80105566:	6a 00                	push   $0x0
  pushl $64
80105568:	6a 40                	push   $0x40
  jmp alltraps
8010556a:	e9 9d f9 ff ff       	jmp    80104f0c <alltraps>

8010556f <vector65>:
.globl vector65
vector65:
  pushl $0
8010556f:	6a 00                	push   $0x0
  pushl $65
80105571:	6a 41                	push   $0x41
  jmp alltraps
80105573:	e9 94 f9 ff ff       	jmp    80104f0c <alltraps>

80105578 <vector66>:
.globl vector66
vector66:
  pushl $0
80105578:	6a 00                	push   $0x0
  pushl $66
8010557a:	6a 42                	push   $0x42
  jmp alltraps
8010557c:	e9 8b f9 ff ff       	jmp    80104f0c <alltraps>

80105581 <vector67>:
.globl vector67
vector67:
  pushl $0
80105581:	6a 00                	push   $0x0
  pushl $67
80105583:	6a 43                	push   $0x43
  jmp alltraps
80105585:	e9 82 f9 ff ff       	jmp    80104f0c <alltraps>

8010558a <vector68>:
.globl vector68
vector68:
  pushl $0
8010558a:	6a 00                	push   $0x0
  pushl $68
8010558c:	6a 44                	push   $0x44
  jmp alltraps
8010558e:	e9 79 f9 ff ff       	jmp    80104f0c <alltraps>

80105593 <vector69>:
.globl vector69
vector69:
  pushl $0
80105593:	6a 00                	push   $0x0
  pushl $69
80105595:	6a 45                	push   $0x45
  jmp alltraps
80105597:	e9 70 f9 ff ff       	jmp    80104f0c <alltraps>

8010559c <vector70>:
.globl vector70
vector70:
  pushl $0
8010559c:	6a 00                	push   $0x0
  pushl $70
8010559e:	6a 46                	push   $0x46
  jmp alltraps
801055a0:	e9 67 f9 ff ff       	jmp    80104f0c <alltraps>

801055a5 <vector71>:
.globl vector71
vector71:
  pushl $0
801055a5:	6a 00                	push   $0x0
  pushl $71
801055a7:	6a 47                	push   $0x47
  jmp alltraps
801055a9:	e9 5e f9 ff ff       	jmp    80104f0c <alltraps>

801055ae <vector72>:
.globl vector72
vector72:
  pushl $0
801055ae:	6a 00                	push   $0x0
  pushl $72
801055b0:	6a 48                	push   $0x48
  jmp alltraps
801055b2:	e9 55 f9 ff ff       	jmp    80104f0c <alltraps>

801055b7 <vector73>:
.globl vector73
vector73:
  pushl $0
801055b7:	6a 00                	push   $0x0
  pushl $73
801055b9:	6a 49                	push   $0x49
  jmp alltraps
801055bb:	e9 4c f9 ff ff       	jmp    80104f0c <alltraps>

801055c0 <vector74>:
.globl vector74
vector74:
  pushl $0
801055c0:	6a 00                	push   $0x0
  pushl $74
801055c2:	6a 4a                	push   $0x4a
  jmp alltraps
801055c4:	e9 43 f9 ff ff       	jmp    80104f0c <alltraps>

801055c9 <vector75>:
.globl vector75
vector75:
  pushl $0
801055c9:	6a 00                	push   $0x0
  pushl $75
801055cb:	6a 4b                	push   $0x4b
  jmp alltraps
801055cd:	e9 3a f9 ff ff       	jmp    80104f0c <alltraps>

801055d2 <vector76>:
.globl vector76
vector76:
  pushl $0
801055d2:	6a 00                	push   $0x0
  pushl $76
801055d4:	6a 4c                	push   $0x4c
  jmp alltraps
801055d6:	e9 31 f9 ff ff       	jmp    80104f0c <alltraps>

801055db <vector77>:
.globl vector77
vector77:
  pushl $0
801055db:	6a 00                	push   $0x0
  pushl $77
801055dd:	6a 4d                	push   $0x4d
  jmp alltraps
801055df:	e9 28 f9 ff ff       	jmp    80104f0c <alltraps>

801055e4 <vector78>:
.globl vector78
vector78:
  pushl $0
801055e4:	6a 00                	push   $0x0
  pushl $78
801055e6:	6a 4e                	push   $0x4e
  jmp alltraps
801055e8:	e9 1f f9 ff ff       	jmp    80104f0c <alltraps>

801055ed <vector79>:
.globl vector79
vector79:
  pushl $0
801055ed:	6a 00                	push   $0x0
  pushl $79
801055ef:	6a 4f                	push   $0x4f
  jmp alltraps
801055f1:	e9 16 f9 ff ff       	jmp    80104f0c <alltraps>

801055f6 <vector80>:
.globl vector80
vector80:
  pushl $0
801055f6:	6a 00                	push   $0x0
  pushl $80
801055f8:	6a 50                	push   $0x50
  jmp alltraps
801055fa:	e9 0d f9 ff ff       	jmp    80104f0c <alltraps>

801055ff <vector81>:
.globl vector81
vector81:
  pushl $0
801055ff:	6a 00                	push   $0x0
  pushl $81
80105601:	6a 51                	push   $0x51
  jmp alltraps
80105603:	e9 04 f9 ff ff       	jmp    80104f0c <alltraps>

80105608 <vector82>:
.globl vector82
vector82:
  pushl $0
80105608:	6a 00                	push   $0x0
  pushl $82
8010560a:	6a 52                	push   $0x52
  jmp alltraps
8010560c:	e9 fb f8 ff ff       	jmp    80104f0c <alltraps>

80105611 <vector83>:
.globl vector83
vector83:
  pushl $0
80105611:	6a 00                	push   $0x0
  pushl $83
80105613:	6a 53                	push   $0x53
  jmp alltraps
80105615:	e9 f2 f8 ff ff       	jmp    80104f0c <alltraps>

8010561a <vector84>:
.globl vector84
vector84:
  pushl $0
8010561a:	6a 00                	push   $0x0
  pushl $84
8010561c:	6a 54                	push   $0x54
  jmp alltraps
8010561e:	e9 e9 f8 ff ff       	jmp    80104f0c <alltraps>

80105623 <vector85>:
.globl vector85
vector85:
  pushl $0
80105623:	6a 00                	push   $0x0
  pushl $85
80105625:	6a 55                	push   $0x55
  jmp alltraps
80105627:	e9 e0 f8 ff ff       	jmp    80104f0c <alltraps>

8010562c <vector86>:
.globl vector86
vector86:
  pushl $0
8010562c:	6a 00                	push   $0x0
  pushl $86
8010562e:	6a 56                	push   $0x56
  jmp alltraps
80105630:	e9 d7 f8 ff ff       	jmp    80104f0c <alltraps>

80105635 <vector87>:
.globl vector87
vector87:
  pushl $0
80105635:	6a 00                	push   $0x0
  pushl $87
80105637:	6a 57                	push   $0x57
  jmp alltraps
80105639:	e9 ce f8 ff ff       	jmp    80104f0c <alltraps>

8010563e <vector88>:
.globl vector88
vector88:
  pushl $0
8010563e:	6a 00                	push   $0x0
  pushl $88
80105640:	6a 58                	push   $0x58
  jmp alltraps
80105642:	e9 c5 f8 ff ff       	jmp    80104f0c <alltraps>

80105647 <vector89>:
.globl vector89
vector89:
  pushl $0
80105647:	6a 00                	push   $0x0
  pushl $89
80105649:	6a 59                	push   $0x59
  jmp alltraps
8010564b:	e9 bc f8 ff ff       	jmp    80104f0c <alltraps>

80105650 <vector90>:
.globl vector90
vector90:
  pushl $0
80105650:	6a 00                	push   $0x0
  pushl $90
80105652:	6a 5a                	push   $0x5a
  jmp alltraps
80105654:	e9 b3 f8 ff ff       	jmp    80104f0c <alltraps>

80105659 <vector91>:
.globl vector91
vector91:
  pushl $0
80105659:	6a 00                	push   $0x0
  pushl $91
8010565b:	6a 5b                	push   $0x5b
  jmp alltraps
8010565d:	e9 aa f8 ff ff       	jmp    80104f0c <alltraps>

80105662 <vector92>:
.globl vector92
vector92:
  pushl $0
80105662:	6a 00                	push   $0x0
  pushl $92
80105664:	6a 5c                	push   $0x5c
  jmp alltraps
80105666:	e9 a1 f8 ff ff       	jmp    80104f0c <alltraps>

8010566b <vector93>:
.globl vector93
vector93:
  pushl $0
8010566b:	6a 00                	push   $0x0
  pushl $93
8010566d:	6a 5d                	push   $0x5d
  jmp alltraps
8010566f:	e9 98 f8 ff ff       	jmp    80104f0c <alltraps>

80105674 <vector94>:
.globl vector94
vector94:
  pushl $0
80105674:	6a 00                	push   $0x0
  pushl $94
80105676:	6a 5e                	push   $0x5e
  jmp alltraps
80105678:	e9 8f f8 ff ff       	jmp    80104f0c <alltraps>

8010567d <vector95>:
.globl vector95
vector95:
  pushl $0
8010567d:	6a 00                	push   $0x0
  pushl $95
8010567f:	6a 5f                	push   $0x5f
  jmp alltraps
80105681:	e9 86 f8 ff ff       	jmp    80104f0c <alltraps>

80105686 <vector96>:
.globl vector96
vector96:
  pushl $0
80105686:	6a 00                	push   $0x0
  pushl $96
80105688:	6a 60                	push   $0x60
  jmp alltraps
8010568a:	e9 7d f8 ff ff       	jmp    80104f0c <alltraps>

8010568f <vector97>:
.globl vector97
vector97:
  pushl $0
8010568f:	6a 00                	push   $0x0
  pushl $97
80105691:	6a 61                	push   $0x61
  jmp alltraps
80105693:	e9 74 f8 ff ff       	jmp    80104f0c <alltraps>

80105698 <vector98>:
.globl vector98
vector98:
  pushl $0
80105698:	6a 00                	push   $0x0
  pushl $98
8010569a:	6a 62                	push   $0x62
  jmp alltraps
8010569c:	e9 6b f8 ff ff       	jmp    80104f0c <alltraps>

801056a1 <vector99>:
.globl vector99
vector99:
  pushl $0
801056a1:	6a 00                	push   $0x0
  pushl $99
801056a3:	6a 63                	push   $0x63
  jmp alltraps
801056a5:	e9 62 f8 ff ff       	jmp    80104f0c <alltraps>

801056aa <vector100>:
.globl vector100
vector100:
  pushl $0
801056aa:	6a 00                	push   $0x0
  pushl $100
801056ac:	6a 64                	push   $0x64
  jmp alltraps
801056ae:	e9 59 f8 ff ff       	jmp    80104f0c <alltraps>

801056b3 <vector101>:
.globl vector101
vector101:
  pushl $0
801056b3:	6a 00                	push   $0x0
  pushl $101
801056b5:	6a 65                	push   $0x65
  jmp alltraps
801056b7:	e9 50 f8 ff ff       	jmp    80104f0c <alltraps>

801056bc <vector102>:
.globl vector102
vector102:
  pushl $0
801056bc:	6a 00                	push   $0x0
  pushl $102
801056be:	6a 66                	push   $0x66
  jmp alltraps
801056c0:	e9 47 f8 ff ff       	jmp    80104f0c <alltraps>

801056c5 <vector103>:
.globl vector103
vector103:
  pushl $0
801056c5:	6a 00                	push   $0x0
  pushl $103
801056c7:	6a 67                	push   $0x67
  jmp alltraps
801056c9:	e9 3e f8 ff ff       	jmp    80104f0c <alltraps>

801056ce <vector104>:
.globl vector104
vector104:
  pushl $0
801056ce:	6a 00                	push   $0x0
  pushl $104
801056d0:	6a 68                	push   $0x68
  jmp alltraps
801056d2:	e9 35 f8 ff ff       	jmp    80104f0c <alltraps>

801056d7 <vector105>:
.globl vector105
vector105:
  pushl $0
801056d7:	6a 00                	push   $0x0
  pushl $105
801056d9:	6a 69                	push   $0x69
  jmp alltraps
801056db:	e9 2c f8 ff ff       	jmp    80104f0c <alltraps>

801056e0 <vector106>:
.globl vector106
vector106:
  pushl $0
801056e0:	6a 00                	push   $0x0
  pushl $106
801056e2:	6a 6a                	push   $0x6a
  jmp alltraps
801056e4:	e9 23 f8 ff ff       	jmp    80104f0c <alltraps>

801056e9 <vector107>:
.globl vector107
vector107:
  pushl $0
801056e9:	6a 00                	push   $0x0
  pushl $107
801056eb:	6a 6b                	push   $0x6b
  jmp alltraps
801056ed:	e9 1a f8 ff ff       	jmp    80104f0c <alltraps>

801056f2 <vector108>:
.globl vector108
vector108:
  pushl $0
801056f2:	6a 00                	push   $0x0
  pushl $108
801056f4:	6a 6c                	push   $0x6c
  jmp alltraps
801056f6:	e9 11 f8 ff ff       	jmp    80104f0c <alltraps>

801056fb <vector109>:
.globl vector109
vector109:
  pushl $0
801056fb:	6a 00                	push   $0x0
  pushl $109
801056fd:	6a 6d                	push   $0x6d
  jmp alltraps
801056ff:	e9 08 f8 ff ff       	jmp    80104f0c <alltraps>

80105704 <vector110>:
.globl vector110
vector110:
  pushl $0
80105704:	6a 00                	push   $0x0
  pushl $110
80105706:	6a 6e                	push   $0x6e
  jmp alltraps
80105708:	e9 ff f7 ff ff       	jmp    80104f0c <alltraps>

8010570d <vector111>:
.globl vector111
vector111:
  pushl $0
8010570d:	6a 00                	push   $0x0
  pushl $111
8010570f:	6a 6f                	push   $0x6f
  jmp alltraps
80105711:	e9 f6 f7 ff ff       	jmp    80104f0c <alltraps>

80105716 <vector112>:
.globl vector112
vector112:
  pushl $0
80105716:	6a 00                	push   $0x0
  pushl $112
80105718:	6a 70                	push   $0x70
  jmp alltraps
8010571a:	e9 ed f7 ff ff       	jmp    80104f0c <alltraps>

8010571f <vector113>:
.globl vector113
vector113:
  pushl $0
8010571f:	6a 00                	push   $0x0
  pushl $113
80105721:	6a 71                	push   $0x71
  jmp alltraps
80105723:	e9 e4 f7 ff ff       	jmp    80104f0c <alltraps>

80105728 <vector114>:
.globl vector114
vector114:
  pushl $0
80105728:	6a 00                	push   $0x0
  pushl $114
8010572a:	6a 72                	push   $0x72
  jmp alltraps
8010572c:	e9 db f7 ff ff       	jmp    80104f0c <alltraps>

80105731 <vector115>:
.globl vector115
vector115:
  pushl $0
80105731:	6a 00                	push   $0x0
  pushl $115
80105733:	6a 73                	push   $0x73
  jmp alltraps
80105735:	e9 d2 f7 ff ff       	jmp    80104f0c <alltraps>

8010573a <vector116>:
.globl vector116
vector116:
  pushl $0
8010573a:	6a 00                	push   $0x0
  pushl $116
8010573c:	6a 74                	push   $0x74
  jmp alltraps
8010573e:	e9 c9 f7 ff ff       	jmp    80104f0c <alltraps>

80105743 <vector117>:
.globl vector117
vector117:
  pushl $0
80105743:	6a 00                	push   $0x0
  pushl $117
80105745:	6a 75                	push   $0x75
  jmp alltraps
80105747:	e9 c0 f7 ff ff       	jmp    80104f0c <alltraps>

8010574c <vector118>:
.globl vector118
vector118:
  pushl $0
8010574c:	6a 00                	push   $0x0
  pushl $118
8010574e:	6a 76                	push   $0x76
  jmp alltraps
80105750:	e9 b7 f7 ff ff       	jmp    80104f0c <alltraps>

80105755 <vector119>:
.globl vector119
vector119:
  pushl $0
80105755:	6a 00                	push   $0x0
  pushl $119
80105757:	6a 77                	push   $0x77
  jmp alltraps
80105759:	e9 ae f7 ff ff       	jmp    80104f0c <alltraps>

8010575e <vector120>:
.globl vector120
vector120:
  pushl $0
8010575e:	6a 00                	push   $0x0
  pushl $120
80105760:	6a 78                	push   $0x78
  jmp alltraps
80105762:	e9 a5 f7 ff ff       	jmp    80104f0c <alltraps>

80105767 <vector121>:
.globl vector121
vector121:
  pushl $0
80105767:	6a 00                	push   $0x0
  pushl $121
80105769:	6a 79                	push   $0x79
  jmp alltraps
8010576b:	e9 9c f7 ff ff       	jmp    80104f0c <alltraps>

80105770 <vector122>:
.globl vector122
vector122:
  pushl $0
80105770:	6a 00                	push   $0x0
  pushl $122
80105772:	6a 7a                	push   $0x7a
  jmp alltraps
80105774:	e9 93 f7 ff ff       	jmp    80104f0c <alltraps>

80105779 <vector123>:
.globl vector123
vector123:
  pushl $0
80105779:	6a 00                	push   $0x0
  pushl $123
8010577b:	6a 7b                	push   $0x7b
  jmp alltraps
8010577d:	e9 8a f7 ff ff       	jmp    80104f0c <alltraps>

80105782 <vector124>:
.globl vector124
vector124:
  pushl $0
80105782:	6a 00                	push   $0x0
  pushl $124
80105784:	6a 7c                	push   $0x7c
  jmp alltraps
80105786:	e9 81 f7 ff ff       	jmp    80104f0c <alltraps>

8010578b <vector125>:
.globl vector125
vector125:
  pushl $0
8010578b:	6a 00                	push   $0x0
  pushl $125
8010578d:	6a 7d                	push   $0x7d
  jmp alltraps
8010578f:	e9 78 f7 ff ff       	jmp    80104f0c <alltraps>

80105794 <vector126>:
.globl vector126
vector126:
  pushl $0
80105794:	6a 00                	push   $0x0
  pushl $126
80105796:	6a 7e                	push   $0x7e
  jmp alltraps
80105798:	e9 6f f7 ff ff       	jmp    80104f0c <alltraps>

8010579d <vector127>:
.globl vector127
vector127:
  pushl $0
8010579d:	6a 00                	push   $0x0
  pushl $127
8010579f:	6a 7f                	push   $0x7f
  jmp alltraps
801057a1:	e9 66 f7 ff ff       	jmp    80104f0c <alltraps>

801057a6 <vector128>:
.globl vector128
vector128:
  pushl $0
801057a6:	6a 00                	push   $0x0
  pushl $128
801057a8:	68 80 00 00 00       	push   $0x80
  jmp alltraps
801057ad:	e9 5a f7 ff ff       	jmp    80104f0c <alltraps>

801057b2 <vector129>:
.globl vector129
vector129:
  pushl $0
801057b2:	6a 00                	push   $0x0
  pushl $129
801057b4:	68 81 00 00 00       	push   $0x81
  jmp alltraps
801057b9:	e9 4e f7 ff ff       	jmp    80104f0c <alltraps>

801057be <vector130>:
.globl vector130
vector130:
  pushl $0
801057be:	6a 00                	push   $0x0
  pushl $130
801057c0:	68 82 00 00 00       	push   $0x82
  jmp alltraps
801057c5:	e9 42 f7 ff ff       	jmp    80104f0c <alltraps>

801057ca <vector131>:
.globl vector131
vector131:
  pushl $0
801057ca:	6a 00                	push   $0x0
  pushl $131
801057cc:	68 83 00 00 00       	push   $0x83
  jmp alltraps
801057d1:	e9 36 f7 ff ff       	jmp    80104f0c <alltraps>

801057d6 <vector132>:
.globl vector132
vector132:
  pushl $0
801057d6:	6a 00                	push   $0x0
  pushl $132
801057d8:	68 84 00 00 00       	push   $0x84
  jmp alltraps
801057dd:	e9 2a f7 ff ff       	jmp    80104f0c <alltraps>

801057e2 <vector133>:
.globl vector133
vector133:
  pushl $0
801057e2:	6a 00                	push   $0x0
  pushl $133
801057e4:	68 85 00 00 00       	push   $0x85
  jmp alltraps
801057e9:	e9 1e f7 ff ff       	jmp    80104f0c <alltraps>

801057ee <vector134>:
.globl vector134
vector134:
  pushl $0
801057ee:	6a 00                	push   $0x0
  pushl $134
801057f0:	68 86 00 00 00       	push   $0x86
  jmp alltraps
801057f5:	e9 12 f7 ff ff       	jmp    80104f0c <alltraps>

801057fa <vector135>:
.globl vector135
vector135:
  pushl $0
801057fa:	6a 00                	push   $0x0
  pushl $135
801057fc:	68 87 00 00 00       	push   $0x87
  jmp alltraps
80105801:	e9 06 f7 ff ff       	jmp    80104f0c <alltraps>

80105806 <vector136>:
.globl vector136
vector136:
  pushl $0
80105806:	6a 00                	push   $0x0
  pushl $136
80105808:	68 88 00 00 00       	push   $0x88
  jmp alltraps
8010580d:	e9 fa f6 ff ff       	jmp    80104f0c <alltraps>

80105812 <vector137>:
.globl vector137
vector137:
  pushl $0
80105812:	6a 00                	push   $0x0
  pushl $137
80105814:	68 89 00 00 00       	push   $0x89
  jmp alltraps
80105819:	e9 ee f6 ff ff       	jmp    80104f0c <alltraps>

8010581e <vector138>:
.globl vector138
vector138:
  pushl $0
8010581e:	6a 00                	push   $0x0
  pushl $138
80105820:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
80105825:	e9 e2 f6 ff ff       	jmp    80104f0c <alltraps>

8010582a <vector139>:
.globl vector139
vector139:
  pushl $0
8010582a:	6a 00                	push   $0x0
  pushl $139
8010582c:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
80105831:	e9 d6 f6 ff ff       	jmp    80104f0c <alltraps>

80105836 <vector140>:
.globl vector140
vector140:
  pushl $0
80105836:	6a 00                	push   $0x0
  pushl $140
80105838:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
8010583d:	e9 ca f6 ff ff       	jmp    80104f0c <alltraps>

80105842 <vector141>:
.globl vector141
vector141:
  pushl $0
80105842:	6a 00                	push   $0x0
  pushl $141
80105844:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
80105849:	e9 be f6 ff ff       	jmp    80104f0c <alltraps>

8010584e <vector142>:
.globl vector142
vector142:
  pushl $0
8010584e:	6a 00                	push   $0x0
  pushl $142
80105850:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
80105855:	e9 b2 f6 ff ff       	jmp    80104f0c <alltraps>

8010585a <vector143>:
.globl vector143
vector143:
  pushl $0
8010585a:	6a 00                	push   $0x0
  pushl $143
8010585c:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
80105861:	e9 a6 f6 ff ff       	jmp    80104f0c <alltraps>

80105866 <vector144>:
.globl vector144
vector144:
  pushl $0
80105866:	6a 00                	push   $0x0
  pushl $144
80105868:	68 90 00 00 00       	push   $0x90
  jmp alltraps
8010586d:	e9 9a f6 ff ff       	jmp    80104f0c <alltraps>

80105872 <vector145>:
.globl vector145
vector145:
  pushl $0
80105872:	6a 00                	push   $0x0
  pushl $145
80105874:	68 91 00 00 00       	push   $0x91
  jmp alltraps
80105879:	e9 8e f6 ff ff       	jmp    80104f0c <alltraps>

8010587e <vector146>:
.globl vector146
vector146:
  pushl $0
8010587e:	6a 00                	push   $0x0
  pushl $146
80105880:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80105885:	e9 82 f6 ff ff       	jmp    80104f0c <alltraps>

8010588a <vector147>:
.globl vector147
vector147:
  pushl $0
8010588a:	6a 00                	push   $0x0
  pushl $147
8010588c:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80105891:	e9 76 f6 ff ff       	jmp    80104f0c <alltraps>

80105896 <vector148>:
.globl vector148
vector148:
  pushl $0
80105896:	6a 00                	push   $0x0
  pushl $148
80105898:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010589d:	e9 6a f6 ff ff       	jmp    80104f0c <alltraps>

801058a2 <vector149>:
.globl vector149
vector149:
  pushl $0
801058a2:	6a 00                	push   $0x0
  pushl $149
801058a4:	68 95 00 00 00       	push   $0x95
  jmp alltraps
801058a9:	e9 5e f6 ff ff       	jmp    80104f0c <alltraps>

801058ae <vector150>:
.globl vector150
vector150:
  pushl $0
801058ae:	6a 00                	push   $0x0
  pushl $150
801058b0:	68 96 00 00 00       	push   $0x96
  jmp alltraps
801058b5:	e9 52 f6 ff ff       	jmp    80104f0c <alltraps>

801058ba <vector151>:
.globl vector151
vector151:
  pushl $0
801058ba:	6a 00                	push   $0x0
  pushl $151
801058bc:	68 97 00 00 00       	push   $0x97
  jmp alltraps
801058c1:	e9 46 f6 ff ff       	jmp    80104f0c <alltraps>

801058c6 <vector152>:
.globl vector152
vector152:
  pushl $0
801058c6:	6a 00                	push   $0x0
  pushl $152
801058c8:	68 98 00 00 00       	push   $0x98
  jmp alltraps
801058cd:	e9 3a f6 ff ff       	jmp    80104f0c <alltraps>

801058d2 <vector153>:
.globl vector153
vector153:
  pushl $0
801058d2:	6a 00                	push   $0x0
  pushl $153
801058d4:	68 99 00 00 00       	push   $0x99
  jmp alltraps
801058d9:	e9 2e f6 ff ff       	jmp    80104f0c <alltraps>

801058de <vector154>:
.globl vector154
vector154:
  pushl $0
801058de:	6a 00                	push   $0x0
  pushl $154
801058e0:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
801058e5:	e9 22 f6 ff ff       	jmp    80104f0c <alltraps>

801058ea <vector155>:
.globl vector155
vector155:
  pushl $0
801058ea:	6a 00                	push   $0x0
  pushl $155
801058ec:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
801058f1:	e9 16 f6 ff ff       	jmp    80104f0c <alltraps>

801058f6 <vector156>:
.globl vector156
vector156:
  pushl $0
801058f6:	6a 00                	push   $0x0
  pushl $156
801058f8:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
801058fd:	e9 0a f6 ff ff       	jmp    80104f0c <alltraps>

80105902 <vector157>:
.globl vector157
vector157:
  pushl $0
80105902:	6a 00                	push   $0x0
  pushl $157
80105904:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
80105909:	e9 fe f5 ff ff       	jmp    80104f0c <alltraps>

8010590e <vector158>:
.globl vector158
vector158:
  pushl $0
8010590e:	6a 00                	push   $0x0
  pushl $158
80105910:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
80105915:	e9 f2 f5 ff ff       	jmp    80104f0c <alltraps>

8010591a <vector159>:
.globl vector159
vector159:
  pushl $0
8010591a:	6a 00                	push   $0x0
  pushl $159
8010591c:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
80105921:	e9 e6 f5 ff ff       	jmp    80104f0c <alltraps>

80105926 <vector160>:
.globl vector160
vector160:
  pushl $0
80105926:	6a 00                	push   $0x0
  pushl $160
80105928:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
8010592d:	e9 da f5 ff ff       	jmp    80104f0c <alltraps>

80105932 <vector161>:
.globl vector161
vector161:
  pushl $0
80105932:	6a 00                	push   $0x0
  pushl $161
80105934:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
80105939:	e9 ce f5 ff ff       	jmp    80104f0c <alltraps>

8010593e <vector162>:
.globl vector162
vector162:
  pushl $0
8010593e:	6a 00                	push   $0x0
  pushl $162
80105940:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
80105945:	e9 c2 f5 ff ff       	jmp    80104f0c <alltraps>

8010594a <vector163>:
.globl vector163
vector163:
  pushl $0
8010594a:	6a 00                	push   $0x0
  pushl $163
8010594c:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
80105951:	e9 b6 f5 ff ff       	jmp    80104f0c <alltraps>

80105956 <vector164>:
.globl vector164
vector164:
  pushl $0
80105956:	6a 00                	push   $0x0
  pushl $164
80105958:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
8010595d:	e9 aa f5 ff ff       	jmp    80104f0c <alltraps>

80105962 <vector165>:
.globl vector165
vector165:
  pushl $0
80105962:	6a 00                	push   $0x0
  pushl $165
80105964:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
80105969:	e9 9e f5 ff ff       	jmp    80104f0c <alltraps>

8010596e <vector166>:
.globl vector166
vector166:
  pushl $0
8010596e:	6a 00                	push   $0x0
  pushl $166
80105970:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
80105975:	e9 92 f5 ff ff       	jmp    80104f0c <alltraps>

8010597a <vector167>:
.globl vector167
vector167:
  pushl $0
8010597a:	6a 00                	push   $0x0
  pushl $167
8010597c:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80105981:	e9 86 f5 ff ff       	jmp    80104f0c <alltraps>

80105986 <vector168>:
.globl vector168
vector168:
  pushl $0
80105986:	6a 00                	push   $0x0
  pushl $168
80105988:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
8010598d:	e9 7a f5 ff ff       	jmp    80104f0c <alltraps>

80105992 <vector169>:
.globl vector169
vector169:
  pushl $0
80105992:	6a 00                	push   $0x0
  pushl $169
80105994:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
80105999:	e9 6e f5 ff ff       	jmp    80104f0c <alltraps>

8010599e <vector170>:
.globl vector170
vector170:
  pushl $0
8010599e:	6a 00                	push   $0x0
  pushl $170
801059a0:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
801059a5:	e9 62 f5 ff ff       	jmp    80104f0c <alltraps>

801059aa <vector171>:
.globl vector171
vector171:
  pushl $0
801059aa:	6a 00                	push   $0x0
  pushl $171
801059ac:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
801059b1:	e9 56 f5 ff ff       	jmp    80104f0c <alltraps>

801059b6 <vector172>:
.globl vector172
vector172:
  pushl $0
801059b6:	6a 00                	push   $0x0
  pushl $172
801059b8:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
801059bd:	e9 4a f5 ff ff       	jmp    80104f0c <alltraps>

801059c2 <vector173>:
.globl vector173
vector173:
  pushl $0
801059c2:	6a 00                	push   $0x0
  pushl $173
801059c4:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
801059c9:	e9 3e f5 ff ff       	jmp    80104f0c <alltraps>

801059ce <vector174>:
.globl vector174
vector174:
  pushl $0
801059ce:	6a 00                	push   $0x0
  pushl $174
801059d0:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
801059d5:	e9 32 f5 ff ff       	jmp    80104f0c <alltraps>

801059da <vector175>:
.globl vector175
vector175:
  pushl $0
801059da:	6a 00                	push   $0x0
  pushl $175
801059dc:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
801059e1:	e9 26 f5 ff ff       	jmp    80104f0c <alltraps>

801059e6 <vector176>:
.globl vector176
vector176:
  pushl $0
801059e6:	6a 00                	push   $0x0
  pushl $176
801059e8:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
801059ed:	e9 1a f5 ff ff       	jmp    80104f0c <alltraps>

801059f2 <vector177>:
.globl vector177
vector177:
  pushl $0
801059f2:	6a 00                	push   $0x0
  pushl $177
801059f4:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
801059f9:	e9 0e f5 ff ff       	jmp    80104f0c <alltraps>

801059fe <vector178>:
.globl vector178
vector178:
  pushl $0
801059fe:	6a 00                	push   $0x0
  pushl $178
80105a00:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80105a05:	e9 02 f5 ff ff       	jmp    80104f0c <alltraps>

80105a0a <vector179>:
.globl vector179
vector179:
  pushl $0
80105a0a:	6a 00                	push   $0x0
  pushl $179
80105a0c:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80105a11:	e9 f6 f4 ff ff       	jmp    80104f0c <alltraps>

80105a16 <vector180>:
.globl vector180
vector180:
  pushl $0
80105a16:	6a 00                	push   $0x0
  pushl $180
80105a18:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
80105a1d:	e9 ea f4 ff ff       	jmp    80104f0c <alltraps>

80105a22 <vector181>:
.globl vector181
vector181:
  pushl $0
80105a22:	6a 00                	push   $0x0
  pushl $181
80105a24:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
80105a29:	e9 de f4 ff ff       	jmp    80104f0c <alltraps>

80105a2e <vector182>:
.globl vector182
vector182:
  pushl $0
80105a2e:	6a 00                	push   $0x0
  pushl $182
80105a30:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
80105a35:	e9 d2 f4 ff ff       	jmp    80104f0c <alltraps>

80105a3a <vector183>:
.globl vector183
vector183:
  pushl $0
80105a3a:	6a 00                	push   $0x0
  pushl $183
80105a3c:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
80105a41:	e9 c6 f4 ff ff       	jmp    80104f0c <alltraps>

80105a46 <vector184>:
.globl vector184
vector184:
  pushl $0
80105a46:	6a 00                	push   $0x0
  pushl $184
80105a48:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
80105a4d:	e9 ba f4 ff ff       	jmp    80104f0c <alltraps>

80105a52 <vector185>:
.globl vector185
vector185:
  pushl $0
80105a52:	6a 00                	push   $0x0
  pushl $185
80105a54:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
80105a59:	e9 ae f4 ff ff       	jmp    80104f0c <alltraps>

80105a5e <vector186>:
.globl vector186
vector186:
  pushl $0
80105a5e:	6a 00                	push   $0x0
  pushl $186
80105a60:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
80105a65:	e9 a2 f4 ff ff       	jmp    80104f0c <alltraps>

80105a6a <vector187>:
.globl vector187
vector187:
  pushl $0
80105a6a:	6a 00                	push   $0x0
  pushl $187
80105a6c:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
80105a71:	e9 96 f4 ff ff       	jmp    80104f0c <alltraps>

80105a76 <vector188>:
.globl vector188
vector188:
  pushl $0
80105a76:	6a 00                	push   $0x0
  pushl $188
80105a78:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
80105a7d:	e9 8a f4 ff ff       	jmp    80104f0c <alltraps>

80105a82 <vector189>:
.globl vector189
vector189:
  pushl $0
80105a82:	6a 00                	push   $0x0
  pushl $189
80105a84:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
80105a89:	e9 7e f4 ff ff       	jmp    80104f0c <alltraps>

80105a8e <vector190>:
.globl vector190
vector190:
  pushl $0
80105a8e:	6a 00                	push   $0x0
  pushl $190
80105a90:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80105a95:	e9 72 f4 ff ff       	jmp    80104f0c <alltraps>

80105a9a <vector191>:
.globl vector191
vector191:
  pushl $0
80105a9a:	6a 00                	push   $0x0
  pushl $191
80105a9c:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80105aa1:	e9 66 f4 ff ff       	jmp    80104f0c <alltraps>

80105aa6 <vector192>:
.globl vector192
vector192:
  pushl $0
80105aa6:	6a 00                	push   $0x0
  pushl $192
80105aa8:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
80105aad:	e9 5a f4 ff ff       	jmp    80104f0c <alltraps>

80105ab2 <vector193>:
.globl vector193
vector193:
  pushl $0
80105ab2:	6a 00                	push   $0x0
  pushl $193
80105ab4:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
80105ab9:	e9 4e f4 ff ff       	jmp    80104f0c <alltraps>

80105abe <vector194>:
.globl vector194
vector194:
  pushl $0
80105abe:	6a 00                	push   $0x0
  pushl $194
80105ac0:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80105ac5:	e9 42 f4 ff ff       	jmp    80104f0c <alltraps>

80105aca <vector195>:
.globl vector195
vector195:
  pushl $0
80105aca:	6a 00                	push   $0x0
  pushl $195
80105acc:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80105ad1:	e9 36 f4 ff ff       	jmp    80104f0c <alltraps>

80105ad6 <vector196>:
.globl vector196
vector196:
  pushl $0
80105ad6:	6a 00                	push   $0x0
  pushl $196
80105ad8:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
80105add:	e9 2a f4 ff ff       	jmp    80104f0c <alltraps>

80105ae2 <vector197>:
.globl vector197
vector197:
  pushl $0
80105ae2:	6a 00                	push   $0x0
  pushl $197
80105ae4:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
80105ae9:	e9 1e f4 ff ff       	jmp    80104f0c <alltraps>

80105aee <vector198>:
.globl vector198
vector198:
  pushl $0
80105aee:	6a 00                	push   $0x0
  pushl $198
80105af0:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80105af5:	e9 12 f4 ff ff       	jmp    80104f0c <alltraps>

80105afa <vector199>:
.globl vector199
vector199:
  pushl $0
80105afa:	6a 00                	push   $0x0
  pushl $199
80105afc:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80105b01:	e9 06 f4 ff ff       	jmp    80104f0c <alltraps>

80105b06 <vector200>:
.globl vector200
vector200:
  pushl $0
80105b06:	6a 00                	push   $0x0
  pushl $200
80105b08:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
80105b0d:	e9 fa f3 ff ff       	jmp    80104f0c <alltraps>

80105b12 <vector201>:
.globl vector201
vector201:
  pushl $0
80105b12:	6a 00                	push   $0x0
  pushl $201
80105b14:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
80105b19:	e9 ee f3 ff ff       	jmp    80104f0c <alltraps>

80105b1e <vector202>:
.globl vector202
vector202:
  pushl $0
80105b1e:	6a 00                	push   $0x0
  pushl $202
80105b20:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
80105b25:	e9 e2 f3 ff ff       	jmp    80104f0c <alltraps>

80105b2a <vector203>:
.globl vector203
vector203:
  pushl $0
80105b2a:	6a 00                	push   $0x0
  pushl $203
80105b2c:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
80105b31:	e9 d6 f3 ff ff       	jmp    80104f0c <alltraps>

80105b36 <vector204>:
.globl vector204
vector204:
  pushl $0
80105b36:	6a 00                	push   $0x0
  pushl $204
80105b38:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
80105b3d:	e9 ca f3 ff ff       	jmp    80104f0c <alltraps>

80105b42 <vector205>:
.globl vector205
vector205:
  pushl $0
80105b42:	6a 00                	push   $0x0
  pushl $205
80105b44:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
80105b49:	e9 be f3 ff ff       	jmp    80104f0c <alltraps>

80105b4e <vector206>:
.globl vector206
vector206:
  pushl $0
80105b4e:	6a 00                	push   $0x0
  pushl $206
80105b50:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
80105b55:	e9 b2 f3 ff ff       	jmp    80104f0c <alltraps>

80105b5a <vector207>:
.globl vector207
vector207:
  pushl $0
80105b5a:	6a 00                	push   $0x0
  pushl $207
80105b5c:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
80105b61:	e9 a6 f3 ff ff       	jmp    80104f0c <alltraps>

80105b66 <vector208>:
.globl vector208
vector208:
  pushl $0
80105b66:	6a 00                	push   $0x0
  pushl $208
80105b68:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
80105b6d:	e9 9a f3 ff ff       	jmp    80104f0c <alltraps>

80105b72 <vector209>:
.globl vector209
vector209:
  pushl $0
80105b72:	6a 00                	push   $0x0
  pushl $209
80105b74:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
80105b79:	e9 8e f3 ff ff       	jmp    80104f0c <alltraps>

80105b7e <vector210>:
.globl vector210
vector210:
  pushl $0
80105b7e:	6a 00                	push   $0x0
  pushl $210
80105b80:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80105b85:	e9 82 f3 ff ff       	jmp    80104f0c <alltraps>

80105b8a <vector211>:
.globl vector211
vector211:
  pushl $0
80105b8a:	6a 00                	push   $0x0
  pushl $211
80105b8c:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80105b91:	e9 76 f3 ff ff       	jmp    80104f0c <alltraps>

80105b96 <vector212>:
.globl vector212
vector212:
  pushl $0
80105b96:	6a 00                	push   $0x0
  pushl $212
80105b98:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
80105b9d:	e9 6a f3 ff ff       	jmp    80104f0c <alltraps>

80105ba2 <vector213>:
.globl vector213
vector213:
  pushl $0
80105ba2:	6a 00                	push   $0x0
  pushl $213
80105ba4:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
80105ba9:	e9 5e f3 ff ff       	jmp    80104f0c <alltraps>

80105bae <vector214>:
.globl vector214
vector214:
  pushl $0
80105bae:	6a 00                	push   $0x0
  pushl $214
80105bb0:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80105bb5:	e9 52 f3 ff ff       	jmp    80104f0c <alltraps>

80105bba <vector215>:
.globl vector215
vector215:
  pushl $0
80105bba:	6a 00                	push   $0x0
  pushl $215
80105bbc:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80105bc1:	e9 46 f3 ff ff       	jmp    80104f0c <alltraps>

80105bc6 <vector216>:
.globl vector216
vector216:
  pushl $0
80105bc6:	6a 00                	push   $0x0
  pushl $216
80105bc8:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
80105bcd:	e9 3a f3 ff ff       	jmp    80104f0c <alltraps>

80105bd2 <vector217>:
.globl vector217
vector217:
  pushl $0
80105bd2:	6a 00                	push   $0x0
  pushl $217
80105bd4:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
80105bd9:	e9 2e f3 ff ff       	jmp    80104f0c <alltraps>

80105bde <vector218>:
.globl vector218
vector218:
  pushl $0
80105bde:	6a 00                	push   $0x0
  pushl $218
80105be0:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80105be5:	e9 22 f3 ff ff       	jmp    80104f0c <alltraps>

80105bea <vector219>:
.globl vector219
vector219:
  pushl $0
80105bea:	6a 00                	push   $0x0
  pushl $219
80105bec:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80105bf1:	e9 16 f3 ff ff       	jmp    80104f0c <alltraps>

80105bf6 <vector220>:
.globl vector220
vector220:
  pushl $0
80105bf6:	6a 00                	push   $0x0
  pushl $220
80105bf8:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
80105bfd:	e9 0a f3 ff ff       	jmp    80104f0c <alltraps>

80105c02 <vector221>:
.globl vector221
vector221:
  pushl $0
80105c02:	6a 00                	push   $0x0
  pushl $221
80105c04:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
80105c09:	e9 fe f2 ff ff       	jmp    80104f0c <alltraps>

80105c0e <vector222>:
.globl vector222
vector222:
  pushl $0
80105c0e:	6a 00                	push   $0x0
  pushl $222
80105c10:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80105c15:	e9 f2 f2 ff ff       	jmp    80104f0c <alltraps>

80105c1a <vector223>:
.globl vector223
vector223:
  pushl $0
80105c1a:	6a 00                	push   $0x0
  pushl $223
80105c1c:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
80105c21:	e9 e6 f2 ff ff       	jmp    80104f0c <alltraps>

80105c26 <vector224>:
.globl vector224
vector224:
  pushl $0
80105c26:	6a 00                	push   $0x0
  pushl $224
80105c28:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
80105c2d:	e9 da f2 ff ff       	jmp    80104f0c <alltraps>

80105c32 <vector225>:
.globl vector225
vector225:
  pushl $0
80105c32:	6a 00                	push   $0x0
  pushl $225
80105c34:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
80105c39:	e9 ce f2 ff ff       	jmp    80104f0c <alltraps>

80105c3e <vector226>:
.globl vector226
vector226:
  pushl $0
80105c3e:	6a 00                	push   $0x0
  pushl $226
80105c40:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
80105c45:	e9 c2 f2 ff ff       	jmp    80104f0c <alltraps>

80105c4a <vector227>:
.globl vector227
vector227:
  pushl $0
80105c4a:	6a 00                	push   $0x0
  pushl $227
80105c4c:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
80105c51:	e9 b6 f2 ff ff       	jmp    80104f0c <alltraps>

80105c56 <vector228>:
.globl vector228
vector228:
  pushl $0
80105c56:	6a 00                	push   $0x0
  pushl $228
80105c58:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
80105c5d:	e9 aa f2 ff ff       	jmp    80104f0c <alltraps>

80105c62 <vector229>:
.globl vector229
vector229:
  pushl $0
80105c62:	6a 00                	push   $0x0
  pushl $229
80105c64:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
80105c69:	e9 9e f2 ff ff       	jmp    80104f0c <alltraps>

80105c6e <vector230>:
.globl vector230
vector230:
  pushl $0
80105c6e:	6a 00                	push   $0x0
  pushl $230
80105c70:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
80105c75:	e9 92 f2 ff ff       	jmp    80104f0c <alltraps>

80105c7a <vector231>:
.globl vector231
vector231:
  pushl $0
80105c7a:	6a 00                	push   $0x0
  pushl $231
80105c7c:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80105c81:	e9 86 f2 ff ff       	jmp    80104f0c <alltraps>

80105c86 <vector232>:
.globl vector232
vector232:
  pushl $0
80105c86:	6a 00                	push   $0x0
  pushl $232
80105c88:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80105c8d:	e9 7a f2 ff ff       	jmp    80104f0c <alltraps>

80105c92 <vector233>:
.globl vector233
vector233:
  pushl $0
80105c92:	6a 00                	push   $0x0
  pushl $233
80105c94:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80105c99:	e9 6e f2 ff ff       	jmp    80104f0c <alltraps>

80105c9e <vector234>:
.globl vector234
vector234:
  pushl $0
80105c9e:	6a 00                	push   $0x0
  pushl $234
80105ca0:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80105ca5:	e9 62 f2 ff ff       	jmp    80104f0c <alltraps>

80105caa <vector235>:
.globl vector235
vector235:
  pushl $0
80105caa:	6a 00                	push   $0x0
  pushl $235
80105cac:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80105cb1:	e9 56 f2 ff ff       	jmp    80104f0c <alltraps>

80105cb6 <vector236>:
.globl vector236
vector236:
  pushl $0
80105cb6:	6a 00                	push   $0x0
  pushl $236
80105cb8:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80105cbd:	e9 4a f2 ff ff       	jmp    80104f0c <alltraps>

80105cc2 <vector237>:
.globl vector237
vector237:
  pushl $0
80105cc2:	6a 00                	push   $0x0
  pushl $237
80105cc4:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80105cc9:	e9 3e f2 ff ff       	jmp    80104f0c <alltraps>

80105cce <vector238>:
.globl vector238
vector238:
  pushl $0
80105cce:	6a 00                	push   $0x0
  pushl $238
80105cd0:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80105cd5:	e9 32 f2 ff ff       	jmp    80104f0c <alltraps>

80105cda <vector239>:
.globl vector239
vector239:
  pushl $0
80105cda:	6a 00                	push   $0x0
  pushl $239
80105cdc:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80105ce1:	e9 26 f2 ff ff       	jmp    80104f0c <alltraps>

80105ce6 <vector240>:
.globl vector240
vector240:
  pushl $0
80105ce6:	6a 00                	push   $0x0
  pushl $240
80105ce8:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80105ced:	e9 1a f2 ff ff       	jmp    80104f0c <alltraps>

80105cf2 <vector241>:
.globl vector241
vector241:
  pushl $0
80105cf2:	6a 00                	push   $0x0
  pushl $241
80105cf4:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80105cf9:	e9 0e f2 ff ff       	jmp    80104f0c <alltraps>

80105cfe <vector242>:
.globl vector242
vector242:
  pushl $0
80105cfe:	6a 00                	push   $0x0
  pushl $242
80105d00:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80105d05:	e9 02 f2 ff ff       	jmp    80104f0c <alltraps>

80105d0a <vector243>:
.globl vector243
vector243:
  pushl $0
80105d0a:	6a 00                	push   $0x0
  pushl $243
80105d0c:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80105d11:	e9 f6 f1 ff ff       	jmp    80104f0c <alltraps>

80105d16 <vector244>:
.globl vector244
vector244:
  pushl $0
80105d16:	6a 00                	push   $0x0
  pushl $244
80105d18:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80105d1d:	e9 ea f1 ff ff       	jmp    80104f0c <alltraps>

80105d22 <vector245>:
.globl vector245
vector245:
  pushl $0
80105d22:	6a 00                	push   $0x0
  pushl $245
80105d24:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80105d29:	e9 de f1 ff ff       	jmp    80104f0c <alltraps>

80105d2e <vector246>:
.globl vector246
vector246:
  pushl $0
80105d2e:	6a 00                	push   $0x0
  pushl $246
80105d30:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80105d35:	e9 d2 f1 ff ff       	jmp    80104f0c <alltraps>

80105d3a <vector247>:
.globl vector247
vector247:
  pushl $0
80105d3a:	6a 00                	push   $0x0
  pushl $247
80105d3c:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80105d41:	e9 c6 f1 ff ff       	jmp    80104f0c <alltraps>

80105d46 <vector248>:
.globl vector248
vector248:
  pushl $0
80105d46:	6a 00                	push   $0x0
  pushl $248
80105d48:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80105d4d:	e9 ba f1 ff ff       	jmp    80104f0c <alltraps>

80105d52 <vector249>:
.globl vector249
vector249:
  pushl $0
80105d52:	6a 00                	push   $0x0
  pushl $249
80105d54:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80105d59:	e9 ae f1 ff ff       	jmp    80104f0c <alltraps>

80105d5e <vector250>:
.globl vector250
vector250:
  pushl $0
80105d5e:	6a 00                	push   $0x0
  pushl $250
80105d60:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80105d65:	e9 a2 f1 ff ff       	jmp    80104f0c <alltraps>

80105d6a <vector251>:
.globl vector251
vector251:
  pushl $0
80105d6a:	6a 00                	push   $0x0
  pushl $251
80105d6c:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80105d71:	e9 96 f1 ff ff       	jmp    80104f0c <alltraps>

80105d76 <vector252>:
.globl vector252
vector252:
  pushl $0
80105d76:	6a 00                	push   $0x0
  pushl $252
80105d78:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80105d7d:	e9 8a f1 ff ff       	jmp    80104f0c <alltraps>

80105d82 <vector253>:
.globl vector253
vector253:
  pushl $0
80105d82:	6a 00                	push   $0x0
  pushl $253
80105d84:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80105d89:	e9 7e f1 ff ff       	jmp    80104f0c <alltraps>

80105d8e <vector254>:
.globl vector254
vector254:
  pushl $0
80105d8e:	6a 00                	push   $0x0
  pushl $254
80105d90:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80105d95:	e9 72 f1 ff ff       	jmp    80104f0c <alltraps>

80105d9a <vector255>:
.globl vector255
vector255:
  pushl $0
80105d9a:	6a 00                	push   $0x0
  pushl $255
80105d9c:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80105da1:	e9 66 f1 ff ff       	jmp    80104f0c <alltraps>

80105da6 <walkpgdir>:
// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
80105da6:	55                   	push   %ebp
80105da7:	89 e5                	mov    %esp,%ebp
80105da9:	57                   	push   %edi
80105daa:	56                   	push   %esi
80105dab:	53                   	push   %ebx
80105dac:	83 ec 0c             	sub    $0xc,%esp
80105daf:	89 d6                	mov    %edx,%esi
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
80105db1:	c1 ea 16             	shr    $0x16,%edx
80105db4:	8d 3c 90             	lea    (%eax,%edx,4),%edi
  if(*pde & PTE_P){
80105db7:	8b 1f                	mov    (%edi),%ebx
80105db9:	f6 c3 01             	test   $0x1,%bl
80105dbc:	74 21                	je     80105ddf <walkpgdir+0x39>
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80105dbe:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80105dc4:	81 c3 00 00 00 80    	add    $0x80000000,%ebx
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
80105dca:	c1 ee 0a             	shr    $0xa,%esi
80105dcd:	81 e6 fc 0f 00 00    	and    $0xffc,%esi
80105dd3:	01 f3                	add    %esi,%ebx
}
80105dd5:	89 d8                	mov    %ebx,%eax
80105dd7:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105dda:	5b                   	pop    %ebx
80105ddb:	5e                   	pop    %esi
80105ddc:	5f                   	pop    %edi
80105ddd:	5d                   	pop    %ebp
80105dde:	c3                   	ret    
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80105ddf:	85 c9                	test   %ecx,%ecx
80105de1:	74 2b                	je     80105e0e <walkpgdir+0x68>
80105de3:	e8 76 c3 ff ff       	call   8010215e <kalloc>
80105de8:	89 c3                	mov    %eax,%ebx
80105dea:	85 c0                	test   %eax,%eax
80105dec:	74 e7                	je     80105dd5 <walkpgdir+0x2f>
    memset(pgtab, 0, PGSIZE);
80105dee:	83 ec 04             	sub    $0x4,%esp
80105df1:	68 00 10 00 00       	push   $0x1000
80105df6:	6a 00                	push   $0x0
80105df8:	50                   	push   %eax
80105df9:	e8 7c e0 ff ff       	call   80103e7a <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80105dfe:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80105e04:	83 c8 07             	or     $0x7,%eax
80105e07:	89 07                	mov    %eax,(%edi)
80105e09:	83 c4 10             	add    $0x10,%esp
80105e0c:	eb bc                	jmp    80105dca <walkpgdir+0x24>
      return 0;
80105e0e:	bb 00 00 00 00       	mov    $0x0,%ebx
80105e13:	eb c0                	jmp    80105dd5 <walkpgdir+0x2f>

80105e15 <mappages>:
// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
80105e15:	55                   	push   %ebp
80105e16:	89 e5                	mov    %esp,%ebp
80105e18:	57                   	push   %edi
80105e19:	56                   	push   %esi
80105e1a:	53                   	push   %ebx
80105e1b:	83 ec 1c             	sub    $0x1c,%esp
80105e1e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  char *a, *last;
  pte_t *pte;

  a = (char*)PGROUNDDOWN((uint)va);
80105e21:	89 d0                	mov    %edx,%eax
80105e23:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80105e28:	89 c3                	mov    %eax,%ebx
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80105e2a:	8d 54 0a ff          	lea    -0x1(%edx,%ecx,1),%edx
80105e2e:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80105e34:	89 55 e0             	mov    %edx,-0x20(%ebp)
80105e37:	8b 7d 08             	mov    0x8(%ebp),%edi
80105e3a:	29 c7                	sub    %eax,%edi
  for(;;){
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
      return -1;
    if(*pte & PTE_P)
      panic("remap");
    *pte = pa | perm | PTE_P;
80105e3c:	8b 45 0c             	mov    0xc(%ebp),%eax
80105e3f:	83 c8 01             	or     $0x1,%eax
80105e42:	89 45 dc             	mov    %eax,-0x24(%ebp)
80105e45:	8d 34 3b             	lea    (%ebx,%edi,1),%esi
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80105e48:	b9 01 00 00 00       	mov    $0x1,%ecx
80105e4d:	89 da                	mov    %ebx,%edx
80105e4f:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80105e52:	e8 4f ff ff ff       	call   80105da6 <walkpgdir>
80105e57:	85 c0                	test   %eax,%eax
80105e59:	74 24                	je     80105e7f <mappages+0x6a>
    if(*pte & PTE_P)
80105e5b:	f6 00 01             	testb  $0x1,(%eax)
80105e5e:	75 12                	jne    80105e72 <mappages+0x5d>
    *pte = pa | perm | PTE_P;
80105e60:	0b 75 dc             	or     -0x24(%ebp),%esi
80105e63:	89 30                	mov    %esi,(%eax)
    if(a == last)
80105e65:	3b 5d e0             	cmp    -0x20(%ebp),%ebx
80105e68:	74 22                	je     80105e8c <mappages+0x77>
      break;
    a += PGSIZE;
80105e6a:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80105e70:	eb d3                	jmp    80105e45 <mappages+0x30>
      panic("remap");
80105e72:	83 ec 0c             	sub    $0xc,%esp
80105e75:	68 f0 88 10 80       	push   $0x801088f0
80105e7a:	e8 c5 a4 ff ff       	call   80100344 <panic>
      return -1;
80105e7f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    pa += PGSIZE;
  }
  return 0;
}
80105e84:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105e87:	5b                   	pop    %ebx
80105e88:	5e                   	pop    %esi
80105e89:	5f                   	pop    %edi
80105e8a:	5d                   	pop    %ebp
80105e8b:	c3                   	ret    
  return 0;
80105e8c:	b8 00 00 00 00       	mov    $0x0,%eax
80105e91:	eb f1                	jmp    80105e84 <mappages+0x6f>

80105e93 <seginit>:
{
80105e93:	55                   	push   %ebp
80105e94:	89 e5                	mov    %esp,%ebp
80105e96:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
80105e99:	e8 94 d4 ff ff       	call   80103332 <cpuid>
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
80105e9e:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80105ea4:	66 c7 80 f8 b7 1d 80 	movw   $0xffff,-0x7fe24808(%eax)
80105eab:	ff ff 
80105ead:	66 c7 80 fa b7 1d 80 	movw   $0x0,-0x7fe24806(%eax)
80105eb4:	00 00 
80105eb6:	c6 80 fc b7 1d 80 00 	movb   $0x0,-0x7fe24804(%eax)
80105ebd:	c6 80 fd b7 1d 80 9a 	movb   $0x9a,-0x7fe24803(%eax)
80105ec4:	c6 80 fe b7 1d 80 cf 	movb   $0xcf,-0x7fe24802(%eax)
80105ecb:	c6 80 ff b7 1d 80 00 	movb   $0x0,-0x7fe24801(%eax)
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80105ed2:	66 c7 80 00 b8 1d 80 	movw   $0xffff,-0x7fe24800(%eax)
80105ed9:	ff ff 
80105edb:	66 c7 80 02 b8 1d 80 	movw   $0x0,-0x7fe247fe(%eax)
80105ee2:	00 00 
80105ee4:	c6 80 04 b8 1d 80 00 	movb   $0x0,-0x7fe247fc(%eax)
80105eeb:	c6 80 05 b8 1d 80 92 	movb   $0x92,-0x7fe247fb(%eax)
80105ef2:	c6 80 06 b8 1d 80 cf 	movb   $0xcf,-0x7fe247fa(%eax)
80105ef9:	c6 80 07 b8 1d 80 00 	movb   $0x0,-0x7fe247f9(%eax)
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80105f00:	66 c7 80 08 b8 1d 80 	movw   $0xffff,-0x7fe247f8(%eax)
80105f07:	ff ff 
80105f09:	66 c7 80 0a b8 1d 80 	movw   $0x0,-0x7fe247f6(%eax)
80105f10:	00 00 
80105f12:	c6 80 0c b8 1d 80 00 	movb   $0x0,-0x7fe247f4(%eax)
80105f19:	c6 80 0d b8 1d 80 fa 	movb   $0xfa,-0x7fe247f3(%eax)
80105f20:	c6 80 0e b8 1d 80 cf 	movb   $0xcf,-0x7fe247f2(%eax)
80105f27:	c6 80 0f b8 1d 80 00 	movb   $0x0,-0x7fe247f1(%eax)
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80105f2e:	66 c7 80 10 b8 1d 80 	movw   $0xffff,-0x7fe247f0(%eax)
80105f35:	ff ff 
80105f37:	66 c7 80 12 b8 1d 80 	movw   $0x0,-0x7fe247ee(%eax)
80105f3e:	00 00 
80105f40:	c6 80 14 b8 1d 80 00 	movb   $0x0,-0x7fe247ec(%eax)
80105f47:	c6 80 15 b8 1d 80 f2 	movb   $0xf2,-0x7fe247eb(%eax)
80105f4e:	c6 80 16 b8 1d 80 cf 	movb   $0xcf,-0x7fe247ea(%eax)
80105f55:	c6 80 17 b8 1d 80 00 	movb   $0x0,-0x7fe247e9(%eax)
  lgdt(c->gdt, sizeof(c->gdt));
80105f5c:	05 f0 b7 1d 80       	add    $0x801db7f0,%eax
  pd[0] = size-1;
80105f61:	66 c7 45 f2 2f 00    	movw   $0x2f,-0xe(%ebp)
  pd[1] = (uint)p;
80105f67:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80105f6b:	c1 e8 10             	shr    $0x10,%eax
80105f6e:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
80105f72:	8d 45 f2             	lea    -0xe(%ebp),%eax
80105f75:	0f 01 10             	lgdtl  (%eax)
}
80105f78:	c9                   	leave  
80105f79:	c3                   	ret    

80105f7a <switchkvm>:

// Switch h/w page table register to the kernel-only page table,
// for when no process is running.
void
switchkvm(void)
{
80105f7a:	55                   	push   %ebp
80105f7b:	89 e5                	mov    %esp,%ebp
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80105f7d:	a1 e4 cd 1d 80       	mov    0x801dcde4,%eax
80105f82:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
80105f87:	0f 22 d8             	mov    %eax,%cr3
}
80105f8a:	5d                   	pop    %ebp
80105f8b:	c3                   	ret    

80105f8c <switchuvm>:

// Switch TSS and h/w page table to correspond to process p.
void
switchuvm(struct proc *p)
{
80105f8c:	55                   	push   %ebp
80105f8d:	89 e5                	mov    %esp,%ebp
80105f8f:	57                   	push   %edi
80105f90:	56                   	push   %esi
80105f91:	53                   	push   %ebx
80105f92:	83 ec 1c             	sub    $0x1c,%esp
80105f95:	8b 75 08             	mov    0x8(%ebp),%esi
  if(p == 0)
80105f98:	85 f6                	test   %esi,%esi
80105f9a:	0f 84 c3 00 00 00    	je     80106063 <switchuvm+0xd7>
    panic("switchuvm: no process");
  if(p->kstack == 0)
80105fa0:	83 7e 08 00          	cmpl   $0x0,0x8(%esi)
80105fa4:	0f 84 c6 00 00 00    	je     80106070 <switchuvm+0xe4>
    panic("switchuvm: no kstack");
  if(p->pgdir == 0)
80105faa:	83 7e 04 00          	cmpl   $0x0,0x4(%esi)
80105fae:	0f 84 c9 00 00 00    	je     8010607d <switchuvm+0xf1>
    panic("switchuvm: no pgdir");

  pushcli();
80105fb4:	e8 42 dd ff ff       	call   80103cfb <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80105fb9:	e8 fd d2 ff ff       	call   801032bb <mycpu>
80105fbe:	89 c3                	mov    %eax,%ebx
80105fc0:	e8 f6 d2 ff ff       	call   801032bb <mycpu>
80105fc5:	89 c7                	mov    %eax,%edi
80105fc7:	e8 ef d2 ff ff       	call   801032bb <mycpu>
80105fcc:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80105fcf:	e8 e7 d2 ff ff       	call   801032bb <mycpu>
80105fd4:	66 c7 83 98 00 00 00 	movw   $0x67,0x98(%ebx)
80105fdb:	67 00 
80105fdd:	83 c7 08             	add    $0x8,%edi
80105fe0:	66 89 bb 9a 00 00 00 	mov    %di,0x9a(%ebx)
80105fe7:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80105fea:	83 c2 08             	add    $0x8,%edx
80105fed:	c1 ea 10             	shr    $0x10,%edx
80105ff0:	88 93 9c 00 00 00    	mov    %dl,0x9c(%ebx)
80105ff6:	c6 83 9d 00 00 00 99 	movb   $0x99,0x9d(%ebx)
80105ffd:	c6 83 9e 00 00 00 40 	movb   $0x40,0x9e(%ebx)
80106004:	83 c0 08             	add    $0x8,%eax
80106007:	c1 e8 18             	shr    $0x18,%eax
8010600a:	88 83 9f 00 00 00    	mov    %al,0x9f(%ebx)
                                sizeof(mycpu()->ts)-1, 0);
  mycpu()->gdt[SEG_TSS].s = 0;
80106010:	e8 a6 d2 ff ff       	call   801032bb <mycpu>
80106015:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
8010601c:	e8 9a d2 ff ff       	call   801032bb <mycpu>
80106021:	66 c7 40 10 10 00    	movw   $0x10,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80106027:	8b 5e 08             	mov    0x8(%esi),%ebx
8010602a:	e8 8c d2 ff ff       	call   801032bb <mycpu>
8010602f:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106035:	89 58 0c             	mov    %ebx,0xc(%eax)
  // setting IOPL=0 in eflags *and* iomb beyond the tss segment limit
  // forbids I/O instructions (e.g., inb and outb) from user space
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106038:	e8 7e d2 ff ff       	call   801032bb <mycpu>
8010603d:	66 c7 40 6e ff ff    	movw   $0xffff,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
80106043:	b8 28 00 00 00       	mov    $0x28,%eax
80106048:	0f 00 d8             	ltr    %ax
  ltr(SEG_TSS << 3);
  lcr3(V2P(p->pgdir));  // switch to process's address space
8010604b:	8b 46 04             	mov    0x4(%esi),%eax
8010604e:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
80106053:	0f 22 d8             	mov    %eax,%cr3
  popcli();
80106056:	e8 dd dc ff ff       	call   80103d38 <popcli>
}
8010605b:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010605e:	5b                   	pop    %ebx
8010605f:	5e                   	pop    %esi
80106060:	5f                   	pop    %edi
80106061:	5d                   	pop    %ebp
80106062:	c3                   	ret    
    panic("switchuvm: no process");
80106063:	83 ec 0c             	sub    $0xc,%esp
80106066:	68 f6 88 10 80       	push   $0x801088f6
8010606b:	e8 d4 a2 ff ff       	call   80100344 <panic>
    panic("switchuvm: no kstack");
80106070:	83 ec 0c             	sub    $0xc,%esp
80106073:	68 0c 89 10 80       	push   $0x8010890c
80106078:	e8 c7 a2 ff ff       	call   80100344 <panic>
    panic("switchuvm: no pgdir");
8010607d:	83 ec 0c             	sub    $0xc,%esp
80106080:	68 21 89 10 80       	push   $0x80108921
80106085:	e8 ba a2 ff ff       	call   80100344 <panic>

8010608a <inituvm>:

// Load the initcode into address 0 of pgdir.
// sz must be less than a page.
void
inituvm(pde_t *pgdir, char *init, uint sz)
{
8010608a:	55                   	push   %ebp
8010608b:	89 e5                	mov    %esp,%ebp
8010608d:	56                   	push   %esi
8010608e:	53                   	push   %ebx
8010608f:	8b 75 10             	mov    0x10(%ebp),%esi
  char *mem;

  if(sz >= PGSIZE)
80106092:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
80106098:	77 4c                	ja     801060e6 <inituvm+0x5c>
    panic("inituvm: more than a page");
  mem = kalloc();
8010609a:	e8 bf c0 ff ff       	call   8010215e <kalloc>
8010609f:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
801060a1:	83 ec 04             	sub    $0x4,%esp
801060a4:	68 00 10 00 00       	push   $0x1000
801060a9:	6a 00                	push   $0x0
801060ab:	50                   	push   %eax
801060ac:	e8 c9 dd ff ff       	call   80103e7a <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
801060b1:	83 c4 08             	add    $0x8,%esp
801060b4:	6a 06                	push   $0x6
801060b6:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801060bc:	50                   	push   %eax
801060bd:	b9 00 10 00 00       	mov    $0x1000,%ecx
801060c2:	ba 00 00 00 00       	mov    $0x0,%edx
801060c7:	8b 45 08             	mov    0x8(%ebp),%eax
801060ca:	e8 46 fd ff ff       	call   80105e15 <mappages>
  memmove(mem, init, sz);
801060cf:	83 c4 0c             	add    $0xc,%esp
801060d2:	56                   	push   %esi
801060d3:	ff 75 0c             	pushl  0xc(%ebp)
801060d6:	53                   	push   %ebx
801060d7:	e8 33 de ff ff       	call   80103f0f <memmove>
}
801060dc:	83 c4 10             	add    $0x10,%esp
801060df:	8d 65 f8             	lea    -0x8(%ebp),%esp
801060e2:	5b                   	pop    %ebx
801060e3:	5e                   	pop    %esi
801060e4:	5d                   	pop    %ebp
801060e5:	c3                   	ret    
    panic("inituvm: more than a page");
801060e6:	83 ec 0c             	sub    $0xc,%esp
801060e9:	68 35 89 10 80       	push   $0x80108935
801060ee:	e8 51 a2 ff ff       	call   80100344 <panic>

801060f3 <loaduvm>:

// Load a program segment into pgdir.  addr must be page-aligned
// and the pages from addr to addr+sz must already be mapped.
int
loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz)
{
801060f3:	55                   	push   %ebp
801060f4:	89 e5                	mov    %esp,%ebp
801060f6:	57                   	push   %edi
801060f7:	56                   	push   %esi
801060f8:	53                   	push   %ebx
801060f9:	83 ec 1c             	sub    $0x1c,%esp
801060fc:	8b 45 0c             	mov    0xc(%ebp),%eax
  uint i, pa, n;
  pte_t *pte;

  if((uint) addr % PGSIZE != 0)
801060ff:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106102:	a9 ff 0f 00 00       	test   $0xfff,%eax
80106107:	75 71                	jne    8010617a <loaduvm+0x87>
    panic("loaduvm: addr must be page aligned");
  for(i = 0; i < sz; i += PGSIZE){
80106109:	8b 75 18             	mov    0x18(%ebp),%esi
8010610c:	bb 00 00 00 00       	mov    $0x0,%ebx
    else
      n = PGSIZE;
    if(readi(ip, P2V(pa), offset+i, n) != n)
      return -1;
  }
  return 0;
80106111:	b8 00 00 00 00       	mov    $0x0,%eax
  for(i = 0; i < sz; i += PGSIZE){
80106116:	85 f6                	test   %esi,%esi
80106118:	74 7f                	je     80106199 <loaduvm+0xa6>
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
8010611a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010611d:	8d 14 18             	lea    (%eax,%ebx,1),%edx
80106120:	b9 00 00 00 00       	mov    $0x0,%ecx
80106125:	8b 45 08             	mov    0x8(%ebp),%eax
80106128:	e8 79 fc ff ff       	call   80105da6 <walkpgdir>
8010612d:	85 c0                	test   %eax,%eax
8010612f:	74 56                	je     80106187 <loaduvm+0x94>
    pa = PTE_ADDR(*pte);
80106131:	8b 00                	mov    (%eax),%eax
80106133:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      n = sz - i;
80106138:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
8010613e:	bf 00 10 00 00       	mov    $0x1000,%edi
80106143:	0f 46 fe             	cmovbe %esi,%edi
    if(readi(ip, P2V(pa), offset+i, n) != n)
80106146:	57                   	push   %edi
80106147:	89 da                	mov    %ebx,%edx
80106149:	03 55 14             	add    0x14(%ebp),%edx
8010614c:	52                   	push   %edx
8010614d:	05 00 00 00 80       	add    $0x80000000,%eax
80106152:	50                   	push   %eax
80106153:	ff 75 10             	pushl  0x10(%ebp)
80106156:	e8 1f b6 ff ff       	call   8010177a <readi>
8010615b:	83 c4 10             	add    $0x10,%esp
8010615e:	39 f8                	cmp    %edi,%eax
80106160:	75 32                	jne    80106194 <loaduvm+0xa1>
  for(i = 0; i < sz; i += PGSIZE){
80106162:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106168:	81 ee 00 10 00 00    	sub    $0x1000,%esi
8010616e:	39 5d 18             	cmp    %ebx,0x18(%ebp)
80106171:	77 a7                	ja     8010611a <loaduvm+0x27>
  return 0;
80106173:	b8 00 00 00 00       	mov    $0x0,%eax
80106178:	eb 1f                	jmp    80106199 <loaduvm+0xa6>
    panic("loaduvm: addr must be page aligned");
8010617a:	83 ec 0c             	sub    $0xc,%esp
8010617d:	68 f0 89 10 80       	push   $0x801089f0
80106182:	e8 bd a1 ff ff       	call   80100344 <panic>
      panic("loaduvm: address should exist");
80106187:	83 ec 0c             	sub    $0xc,%esp
8010618a:	68 4f 89 10 80       	push   $0x8010894f
8010618f:	e8 b0 a1 ff ff       	call   80100344 <panic>
      return -1;
80106194:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106199:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010619c:	5b                   	pop    %ebx
8010619d:	5e                   	pop    %esi
8010619e:	5f                   	pop    %edi
8010619f:	5d                   	pop    %ebp
801061a0:	c3                   	ret    

801061a1 <deallocuvm>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
801061a1:	55                   	push   %ebp
801061a2:	89 e5                	mov    %esp,%ebp
801061a4:	57                   	push   %edi
801061a5:	56                   	push   %esi
801061a6:	53                   	push   %ebx
801061a7:	83 ec 0c             	sub    $0xc,%esp
801061aa:	8b 7d 0c             	mov    0xc(%ebp),%edi
  pte_t *pte;
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;
801061ad:	89 f8                	mov    %edi,%eax
  if(newsz >= oldsz)
801061af:	39 7d 10             	cmp    %edi,0x10(%ebp)
801061b2:	73 16                	jae    801061ca <deallocuvm+0x29>

  a = PGROUNDUP(newsz);
801061b4:	8b 45 10             	mov    0x10(%ebp),%eax
801061b7:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801061bd:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; a  < oldsz; a += PGSIZE){
801061c3:	39 df                	cmp    %ebx,%edi
801061c5:	77 21                	ja     801061e8 <deallocuvm+0x47>
      char *v = P2V(pa);
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
801061c7:	8b 45 10             	mov    0x10(%ebp),%eax
}
801061ca:	8d 65 f4             	lea    -0xc(%ebp),%esp
801061cd:	5b                   	pop    %ebx
801061ce:	5e                   	pop    %esi
801061cf:	5f                   	pop    %edi
801061d0:	5d                   	pop    %ebp
801061d1:	c3                   	ret    
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
801061d2:	81 e3 00 00 c0 ff    	and    $0xffc00000,%ebx
801061d8:	81 c3 00 f0 3f 00    	add    $0x3ff000,%ebx
  for(; a  < oldsz; a += PGSIZE){
801061de:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801061e4:	39 df                	cmp    %ebx,%edi
801061e6:	76 df                	jbe    801061c7 <deallocuvm+0x26>
    pte = walkpgdir(pgdir, (char*)a, 0);
801061e8:	b9 00 00 00 00       	mov    $0x0,%ecx
801061ed:	89 da                	mov    %ebx,%edx
801061ef:	8b 45 08             	mov    0x8(%ebp),%eax
801061f2:	e8 af fb ff ff       	call   80105da6 <walkpgdir>
801061f7:	89 c6                	mov    %eax,%esi
    if(!pte)
801061f9:	85 c0                	test   %eax,%eax
801061fb:	74 d5                	je     801061d2 <deallocuvm+0x31>
    else if((*pte & PTE_P) != 0){
801061fd:	8b 00                	mov    (%eax),%eax
801061ff:	a8 01                	test   $0x1,%al
80106201:	74 db                	je     801061de <deallocuvm+0x3d>
      if(pa == 0)
80106203:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106208:	74 19                	je     80106223 <deallocuvm+0x82>
      kfree(v);
8010620a:	83 ec 0c             	sub    $0xc,%esp
      char *v = P2V(pa);
8010620d:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
80106212:	50                   	push   %eax
80106213:	e8 21 be ff ff       	call   80102039 <kfree>
      *pte = 0;
80106218:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
8010621e:	83 c4 10             	add    $0x10,%esp
80106221:	eb bb                	jmp    801061de <deallocuvm+0x3d>
        panic("kfree");
80106223:	83 ec 0c             	sub    $0xc,%esp
80106226:	68 62 82 10 80       	push   $0x80108262
8010622b:	e8 14 a1 ff ff       	call   80100344 <panic>

80106230 <allocuvm>:
{
80106230:	55                   	push   %ebp
80106231:	89 e5                	mov    %esp,%ebp
80106233:	57                   	push   %edi
80106234:	56                   	push   %esi
80106235:	53                   	push   %ebx
80106236:	83 ec 1c             	sub    $0x1c,%esp
80106239:	8b 7d 10             	mov    0x10(%ebp),%edi
  if(newsz >= KERNBASE)
8010623c:	89 7d e4             	mov    %edi,-0x1c(%ebp)
8010623f:	85 ff                	test   %edi,%edi
80106241:	0f 88 c5 00 00 00    	js     8010630c <allocuvm+0xdc>
  if(newsz < oldsz)
80106247:	3b 7d 0c             	cmp    0xc(%ebp),%edi
8010624a:	72 60                	jb     801062ac <allocuvm+0x7c>
  a = PGROUNDUP(oldsz);
8010624c:	8b 45 0c             	mov    0xc(%ebp),%eax
8010624f:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80106255:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; a < newsz; a += PGSIZE){
8010625b:	39 df                	cmp    %ebx,%edi
8010625d:	0f 86 b0 00 00 00    	jbe    80106313 <allocuvm+0xe3>
    mem = kalloc();
80106263:	e8 f6 be ff ff       	call   8010215e <kalloc>
80106268:	89 c6                	mov    %eax,%esi
    if(mem == 0){
8010626a:	85 c0                	test   %eax,%eax
8010626c:	74 46                	je     801062b4 <allocuvm+0x84>
    memset(mem, 0, PGSIZE);
8010626e:	83 ec 04             	sub    $0x4,%esp
80106271:	68 00 10 00 00       	push   $0x1000
80106276:	6a 00                	push   $0x0
80106278:	50                   	push   %eax
80106279:	e8 fc db ff ff       	call   80103e7a <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
8010627e:	83 c4 08             	add    $0x8,%esp
80106281:	6a 06                	push   $0x6
80106283:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
80106289:	50                   	push   %eax
8010628a:	b9 00 10 00 00       	mov    $0x1000,%ecx
8010628f:	89 da                	mov    %ebx,%edx
80106291:	8b 45 08             	mov    0x8(%ebp),%eax
80106294:	e8 7c fb ff ff       	call   80105e15 <mappages>
80106299:	83 c4 10             	add    $0x10,%esp
8010629c:	85 c0                	test   %eax,%eax
8010629e:	78 3c                	js     801062dc <allocuvm+0xac>
  for(; a < newsz; a += PGSIZE){
801062a0:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801062a6:	39 df                	cmp    %ebx,%edi
801062a8:	77 b9                	ja     80106263 <allocuvm+0x33>
801062aa:	eb 67                	jmp    80106313 <allocuvm+0xe3>
    return oldsz;
801062ac:	8b 45 0c             	mov    0xc(%ebp),%eax
801062af:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801062b2:	eb 5f                	jmp    80106313 <allocuvm+0xe3>
      cprintf("allocuvm out of memory\n");
801062b4:	83 ec 0c             	sub    $0xc,%esp
801062b7:	68 6d 89 10 80       	push   $0x8010896d
801062bc:	e8 20 a3 ff ff       	call   801005e1 <cprintf>
      deallocuvm(pgdir, newsz, oldsz);
801062c1:	83 c4 0c             	add    $0xc,%esp
801062c4:	ff 75 0c             	pushl  0xc(%ebp)
801062c7:	57                   	push   %edi
801062c8:	ff 75 08             	pushl  0x8(%ebp)
801062cb:	e8 d1 fe ff ff       	call   801061a1 <deallocuvm>
      return 0;
801062d0:	83 c4 10             	add    $0x10,%esp
801062d3:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
801062da:	eb 37                	jmp    80106313 <allocuvm+0xe3>
      cprintf("allocuvm out of memory (2)\n");
801062dc:	83 ec 0c             	sub    $0xc,%esp
801062df:	68 85 89 10 80       	push   $0x80108985
801062e4:	e8 f8 a2 ff ff       	call   801005e1 <cprintf>
      deallocuvm(pgdir, newsz, oldsz);
801062e9:	83 c4 0c             	add    $0xc,%esp
801062ec:	ff 75 0c             	pushl  0xc(%ebp)
801062ef:	57                   	push   %edi
801062f0:	ff 75 08             	pushl  0x8(%ebp)
801062f3:	e8 a9 fe ff ff       	call   801061a1 <deallocuvm>
      kfree(mem);
801062f8:	89 34 24             	mov    %esi,(%esp)
801062fb:	e8 39 bd ff ff       	call   80102039 <kfree>
      return 0;
80106300:	83 c4 10             	add    $0x10,%esp
80106303:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
8010630a:	eb 07                	jmp    80106313 <allocuvm+0xe3>
    return 0;
8010630c:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
}
80106313:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80106316:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106319:	5b                   	pop    %ebx
8010631a:	5e                   	pop    %esi
8010631b:	5f                   	pop    %edi
8010631c:	5d                   	pop    %ebp
8010631d:	c3                   	ret    

8010631e <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
8010631e:	55                   	push   %ebp
8010631f:	89 e5                	mov    %esp,%ebp
80106321:	57                   	push   %edi
80106322:	56                   	push   %esi
80106323:	53                   	push   %ebx
80106324:	83 ec 0c             	sub    $0xc,%esp
80106327:	8b 7d 08             	mov    0x8(%ebp),%edi
  uint i;

  if(pgdir == 0)
8010632a:	85 ff                	test   %edi,%edi
8010632c:	74 1d                	je     8010634b <freevm+0x2d>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
8010632e:	83 ec 04             	sub    $0x4,%esp
80106331:	6a 00                	push   $0x0
80106333:	68 00 00 00 80       	push   $0x80000000
80106338:	57                   	push   %edi
80106339:	e8 63 fe ff ff       	call   801061a1 <deallocuvm>
8010633e:	89 fb                	mov    %edi,%ebx
80106340:	8d b7 00 10 00 00    	lea    0x1000(%edi),%esi
80106346:	83 c4 10             	add    $0x10,%esp
80106349:	eb 14                	jmp    8010635f <freevm+0x41>
    panic("freevm: no pgdir");
8010634b:	83 ec 0c             	sub    $0xc,%esp
8010634e:	68 a1 89 10 80       	push   $0x801089a1
80106353:	e8 ec 9f ff ff       	call   80100344 <panic>
80106358:	83 c3 04             	add    $0x4,%ebx
  for(i = 0; i < NPDENTRIES; i++){
8010635b:	39 f3                	cmp    %esi,%ebx
8010635d:	74 1e                	je     8010637d <freevm+0x5f>
    if(pgdir[i] & PTE_P){
8010635f:	8b 03                	mov    (%ebx),%eax
80106361:	a8 01                	test   $0x1,%al
80106363:	74 f3                	je     80106358 <freevm+0x3a>
      char * v = P2V(PTE_ADDR(pgdir[i]));
      kfree(v);
80106365:	83 ec 0c             	sub    $0xc,%esp
      char * v = P2V(PTE_ADDR(pgdir[i]));
80106368:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010636d:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
80106372:	50                   	push   %eax
80106373:	e8 c1 bc ff ff       	call   80102039 <kfree>
80106378:	83 c4 10             	add    $0x10,%esp
8010637b:	eb db                	jmp    80106358 <freevm+0x3a>
    }
  }
  kfree((char*)pgdir);
8010637d:	83 ec 0c             	sub    $0xc,%esp
80106380:	57                   	push   %edi
80106381:	e8 b3 bc ff ff       	call   80102039 <kfree>
}
80106386:	83 c4 10             	add    $0x10,%esp
80106389:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010638c:	5b                   	pop    %ebx
8010638d:	5e                   	pop    %esi
8010638e:	5f                   	pop    %edi
8010638f:	5d                   	pop    %ebp
80106390:	c3                   	ret    

80106391 <setupkvm>:
{
80106391:	55                   	push   %ebp
80106392:	89 e5                	mov    %esp,%ebp
80106394:	56                   	push   %esi
80106395:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
80106396:	e8 c3 bd ff ff       	call   8010215e <kalloc>
8010639b:	89 c6                	mov    %eax,%esi
8010639d:	85 c0                	test   %eax,%eax
8010639f:	74 42                	je     801063e3 <setupkvm+0x52>
  memset(pgdir, 0, PGSIZE);
801063a1:	83 ec 04             	sub    $0x4,%esp
801063a4:	68 00 10 00 00       	push   $0x1000
801063a9:	6a 00                	push   $0x0
801063ab:	50                   	push   %eax
801063ac:	e8 c9 da ff ff       	call   80103e7a <memset>
801063b1:	83 c4 10             	add    $0x10,%esp
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801063b4:	bb 20 b4 10 80       	mov    $0x8010b420,%ebx
                (uint)k->phys_start, k->perm) < 0) {
801063b9:	8b 43 04             	mov    0x4(%ebx),%eax
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
801063bc:	8b 4b 08             	mov    0x8(%ebx),%ecx
801063bf:	29 c1                	sub    %eax,%ecx
801063c1:	83 ec 08             	sub    $0x8,%esp
801063c4:	ff 73 0c             	pushl  0xc(%ebx)
801063c7:	50                   	push   %eax
801063c8:	8b 13                	mov    (%ebx),%edx
801063ca:	89 f0                	mov    %esi,%eax
801063cc:	e8 44 fa ff ff       	call   80105e15 <mappages>
801063d1:	83 c4 10             	add    $0x10,%esp
801063d4:	85 c0                	test   %eax,%eax
801063d6:	78 14                	js     801063ec <setupkvm+0x5b>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801063d8:	83 c3 10             	add    $0x10,%ebx
801063db:	81 fb 60 b4 10 80    	cmp    $0x8010b460,%ebx
801063e1:	75 d6                	jne    801063b9 <setupkvm+0x28>
}
801063e3:	89 f0                	mov    %esi,%eax
801063e5:	8d 65 f8             	lea    -0x8(%ebp),%esp
801063e8:	5b                   	pop    %ebx
801063e9:	5e                   	pop    %esi
801063ea:	5d                   	pop    %ebp
801063eb:	c3                   	ret    
      freevm(pgdir);
801063ec:	83 ec 0c             	sub    $0xc,%esp
801063ef:	56                   	push   %esi
801063f0:	e8 29 ff ff ff       	call   8010631e <freevm>
      return 0;
801063f5:	83 c4 10             	add    $0x10,%esp
801063f8:	be 00 00 00 00       	mov    $0x0,%esi
801063fd:	eb e4                	jmp    801063e3 <setupkvm+0x52>

801063ff <kvmalloc>:
{
801063ff:	55                   	push   %ebp
80106400:	89 e5                	mov    %esp,%ebp
80106402:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80106405:	e8 87 ff ff ff       	call   80106391 <setupkvm>
8010640a:	a3 e4 cd 1d 80       	mov    %eax,0x801dcde4
  switchkvm();
8010640f:	e8 66 fb ff ff       	call   80105f7a <switchkvm>
}
80106414:	c9                   	leave  
80106415:	c3                   	ret    

80106416 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80106416:	55                   	push   %ebp
80106417:	89 e5                	mov    %esp,%ebp
80106419:	83 ec 08             	sub    $0x8,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
8010641c:	b9 00 00 00 00       	mov    $0x0,%ecx
80106421:	8b 55 0c             	mov    0xc(%ebp),%edx
80106424:	8b 45 08             	mov    0x8(%ebp),%eax
80106427:	e8 7a f9 ff ff       	call   80105da6 <walkpgdir>
  if(pte == 0)
8010642c:	85 c0                	test   %eax,%eax
8010642e:	74 05                	je     80106435 <clearpteu+0x1f>
    panic("clearpteu");
  *pte &= ~PTE_U;
80106430:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
80106433:	c9                   	leave  
80106434:	c3                   	ret    
    panic("clearpteu");
80106435:	83 ec 0c             	sub    $0xc,%esp
80106438:	68 b2 89 10 80       	push   $0x801089b2
8010643d:	e8 02 9f ff ff       	call   80100344 <panic>

80106442 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
80106442:	55                   	push   %ebp
80106443:	89 e5                	mov    %esp,%ebp
80106445:	57                   	push   %edi
80106446:	56                   	push   %esi
80106447:	53                   	push   %ebx
80106448:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
8010644b:	e8 41 ff ff ff       	call   80106391 <setupkvm>
80106450:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106453:	85 c0                	test   %eax,%eax
80106455:	0f 84 c7 00 00 00    	je     80106522 <copyuvm+0xe0>
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
8010645b:	83 7d 0c 00          	cmpl   $0x0,0xc(%ebp)
8010645f:	0f 84 bd 00 00 00    	je     80106522 <copyuvm+0xe0>
80106465:	bf 00 00 00 00       	mov    $0x0,%edi
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
8010646a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
8010646d:	b9 00 00 00 00       	mov    $0x0,%ecx
80106472:	89 fa                	mov    %edi,%edx
80106474:	8b 45 08             	mov    0x8(%ebp),%eax
80106477:	e8 2a f9 ff ff       	call   80105da6 <walkpgdir>
8010647c:	85 c0                	test   %eax,%eax
8010647e:	74 67                	je     801064e7 <copyuvm+0xa5>
      panic("copyuvm: pte should exist");
    if(!(*pte & PTE_P))
80106480:	8b 00                	mov    (%eax),%eax
80106482:	a8 01                	test   $0x1,%al
80106484:	74 6e                	je     801064f4 <copyuvm+0xb2>
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
80106486:	89 c6                	mov    %eax,%esi
80106488:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
    flags = PTE_FLAGS(*pte);
8010648e:	25 ff 0f 00 00       	and    $0xfff,%eax
80106493:	89 45 e0             	mov    %eax,-0x20(%ebp)
    if((mem = kalloc()) == 0)
80106496:	e8 c3 bc ff ff       	call   8010215e <kalloc>
8010649b:	89 c3                	mov    %eax,%ebx
8010649d:	85 c0                	test   %eax,%eax
8010649f:	74 6c                	je     8010650d <copyuvm+0xcb>
      goto bad;
    memmove(mem, (char*)P2V(pa), PGSIZE);
801064a1:	83 ec 04             	sub    $0x4,%esp
801064a4:	68 00 10 00 00       	push   $0x1000
801064a9:	81 c6 00 00 00 80    	add    $0x80000000,%esi
801064af:	56                   	push   %esi
801064b0:	50                   	push   %eax
801064b1:	e8 59 da ff ff       	call   80103f0f <memmove>
    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0) {
801064b6:	83 c4 08             	add    $0x8,%esp
801064b9:	ff 75 e0             	pushl  -0x20(%ebp)
801064bc:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801064c2:	50                   	push   %eax
801064c3:	b9 00 10 00 00       	mov    $0x1000,%ecx
801064c8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801064cb:	8b 45 dc             	mov    -0x24(%ebp),%eax
801064ce:	e8 42 f9 ff ff       	call   80105e15 <mappages>
801064d3:	83 c4 10             	add    $0x10,%esp
801064d6:	85 c0                	test   %eax,%eax
801064d8:	78 27                	js     80106501 <copyuvm+0xbf>
  for(i = 0; i < sz; i += PGSIZE){
801064da:	81 c7 00 10 00 00    	add    $0x1000,%edi
801064e0:	39 7d 0c             	cmp    %edi,0xc(%ebp)
801064e3:	77 85                	ja     8010646a <copyuvm+0x28>
801064e5:	eb 3b                	jmp    80106522 <copyuvm+0xe0>
      panic("copyuvm: pte should exist");
801064e7:	83 ec 0c             	sub    $0xc,%esp
801064ea:	68 bc 89 10 80       	push   $0x801089bc
801064ef:	e8 50 9e ff ff       	call   80100344 <panic>
      panic("copyuvm: page not present");
801064f4:	83 ec 0c             	sub    $0xc,%esp
801064f7:	68 d6 89 10 80       	push   $0x801089d6
801064fc:	e8 43 9e ff ff       	call   80100344 <panic>
      kfree(mem);
80106501:	83 ec 0c             	sub    $0xc,%esp
80106504:	53                   	push   %ebx
80106505:	e8 2f bb ff ff       	call   80102039 <kfree>
      goto bad;
8010650a:	83 c4 10             	add    $0x10,%esp
    }
  }
  return d;

bad:
  freevm(d);
8010650d:	83 ec 0c             	sub    $0xc,%esp
80106510:	ff 75 dc             	pushl  -0x24(%ebp)
80106513:	e8 06 fe ff ff       	call   8010631e <freevm>
  return 0;
80106518:	83 c4 10             	add    $0x10,%esp
8010651b:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
}
80106522:	8b 45 dc             	mov    -0x24(%ebp),%eax
80106525:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106528:	5b                   	pop    %ebx
80106529:	5e                   	pop    %esi
8010652a:	5f                   	pop    %edi
8010652b:	5d                   	pop    %ebp
8010652c:	c3                   	ret    

8010652d <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
8010652d:	55                   	push   %ebp
8010652e:	89 e5                	mov    %esp,%ebp
80106530:	83 ec 08             	sub    $0x8,%esp
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
80106533:	b9 00 00 00 00       	mov    $0x0,%ecx
80106538:	8b 55 0c             	mov    0xc(%ebp),%edx
8010653b:	8b 45 08             	mov    0x8(%ebp),%eax
8010653e:	e8 63 f8 ff ff       	call   80105da6 <walkpgdir>
  if((*pte & PTE_P) == 0)
80106543:	8b 00                	mov    (%eax),%eax
    return 0;
  if((*pte & PTE_U) == 0)
80106545:	89 c2                	mov    %eax,%edx
80106547:	83 e2 05             	and    $0x5,%edx
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
8010654a:	25 00 f0 ff ff       	and    $0xfffff000,%eax
8010654f:	05 00 00 00 80       	add    $0x80000000,%eax
80106554:	83 fa 05             	cmp    $0x5,%edx
80106557:	ba 00 00 00 00       	mov    $0x0,%edx
8010655c:	0f 45 c2             	cmovne %edx,%eax
}
8010655f:	c9                   	leave  
80106560:	c3                   	ret    

80106561 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
80106561:	55                   	push   %ebp
80106562:	89 e5                	mov    %esp,%ebp
80106564:	57                   	push   %edi
80106565:	56                   	push   %esi
80106566:	53                   	push   %ebx
80106567:	83 ec 0c             	sub    $0xc,%esp
8010656a:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
8010656d:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
80106571:	74 55                	je     801065c8 <copyout+0x67>
    va0 = (uint)PGROUNDDOWN(va);
80106573:	89 df                	mov    %ebx,%edi
80106575:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
    pa0 = uva2ka(pgdir, (char*)va0);
8010657b:	83 ec 08             	sub    $0x8,%esp
8010657e:	57                   	push   %edi
8010657f:	ff 75 08             	pushl  0x8(%ebp)
80106582:	e8 a6 ff ff ff       	call   8010652d <uva2ka>
    if(pa0 == 0)
80106587:	83 c4 10             	add    $0x10,%esp
8010658a:	85 c0                	test   %eax,%eax
8010658c:	74 41                	je     801065cf <copyout+0x6e>
      return -1;
    n = PGSIZE - (va - va0);
8010658e:	89 fe                	mov    %edi,%esi
80106590:	29 de                	sub    %ebx,%esi
80106592:	81 c6 00 10 00 00    	add    $0x1000,%esi
80106598:	3b 75 14             	cmp    0x14(%ebp),%esi
8010659b:	0f 47 75 14          	cmova  0x14(%ebp),%esi
    if(n > len)
      n = len;
    memmove(pa0 + (va - va0), buf, n);
8010659f:	83 ec 04             	sub    $0x4,%esp
801065a2:	56                   	push   %esi
801065a3:	ff 75 10             	pushl  0x10(%ebp)
801065a6:	29 fb                	sub    %edi,%ebx
801065a8:	01 d8                	add    %ebx,%eax
801065aa:	50                   	push   %eax
801065ab:	e8 5f d9 ff ff       	call   80103f0f <memmove>
    len -= n;
    buf += n;
801065b0:	01 75 10             	add    %esi,0x10(%ebp)
    va = va0 + PGSIZE;
801065b3:	8d 9f 00 10 00 00    	lea    0x1000(%edi),%ebx
  while(len > 0){
801065b9:	83 c4 10             	add    $0x10,%esp
801065bc:	29 75 14             	sub    %esi,0x14(%ebp)
801065bf:	75 b2                	jne    80106573 <copyout+0x12>
  }
  return 0;
801065c1:	b8 00 00 00 00       	mov    $0x0,%eax
801065c6:	eb 0c                	jmp    801065d4 <copyout+0x73>
801065c8:	b8 00 00 00 00       	mov    $0x0,%eax
801065cd:	eb 05                	jmp    801065d4 <copyout+0x73>
      return -1;
801065cf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801065d4:	8d 65 f4             	lea    -0xc(%ebp),%esp
801065d7:	5b                   	pop    %ebx
801065d8:	5e                   	pop    %esi
801065d9:	5f                   	pop    %edi
801065da:	5d                   	pop    %ebp
801065db:	c3                   	ret    

801065dc <get_bit>:
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"


bool get_bit(char num, int i){
801065dc:	55                   	push   %ebp
801065dd:	89 e5                	mov    %esp,%ebp
	return ((num & (1 << i)) != 0);
801065df:	0f be 45 08          	movsbl 0x8(%ebp),%eax
801065e3:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801065e6:	d3 f8                	sar    %cl,%eax
801065e8:	83 e0 01             	and    $0x1,%eax
}
801065eb:	5d                   	pop    %ebp
801065ec:	c3                   	ret    

801065ed <set_bit>:
char set_bit(char num, int i){
801065ed:	55                   	push   %ebp
801065ee:	89 e5                	mov    %esp,%ebp
	return num | (1 << i);
801065f0:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801065f3:	b8 01 00 00 00       	mov    $0x1,%eax
801065f8:	d3 e0                	shl    %cl,%eax
801065fa:	0a 45 08             	or     0x8(%ebp),%al
}
801065fd:	5d                   	pop    %ebp
801065fe:	c3                   	ret    

801065ff <clear_bit>:
char clear_bit(char num, int i){
801065ff:	55                   	push   %ebp
80106600:	89 e5                	mov    %esp,%ebp
	return num & (~(1 << i));
80106602:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80106605:	b8 fe ff ff ff       	mov    $0xfffffffe,%eax
8010660a:	d3 c0                	rol    %cl,%eax
8010660c:	22 45 08             	and    0x8(%ebp),%al
}
8010660f:	5d                   	pop    %ebp
80106610:	c3                   	ret    

80106611 <nextPower>:

unsigned int nextPower(unsigned int n)
{
80106611:	55                   	push   %ebp
80106612:	89 e5                	mov    %esp,%ebp
	unsigned count  = 0;
	if(n <= 16 && n > 0)
80106614:	8b 45 08             	mov    0x8(%ebp),%eax
80106617:	8d 50 ff             	lea    -0x1(%eax),%edx
		return 0;
8010661a:	b8 00 00 00 00       	mov    $0x0,%eax
	if(n <= 16 && n > 0)
8010661f:	83 fa 0f             	cmp    $0xf,%edx
80106622:	76 0e                	jbe    80106632 <nextPower+0x21>
	n--;
	while(n > 0)
80106624:	85 d2                	test   %edx,%edx
80106626:	74 0c                	je     80106634 <nextPower+0x23>
	{
		n>>=1;
		count ++;
80106628:	83 c0 01             	add    $0x1,%eax
	while(n > 0)
8010662b:	d1 ea                	shr    %edx
8010662d:	75 f9                	jne    80106628 <nextPower+0x17>
	}
	return count - 4;
8010662f:	83 e8 04             	sub    $0x4,%eax
}
80106632:	5d                   	pop    %ebp
80106633:	c3                   	ret    
	unsigned count  = 0;
80106634:	89 d0                	mov    %edx,%eax
80106636:	eb f7                	jmp    8010662f <nextPower+0x1e>

80106638 <bitmap_set>:
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;


void bitmap_set(char *bitmap, int bit_index){
80106638:	55                   	push   %ebp
80106639:	89 e5                	mov    %esp,%ebp
8010663b:	8b 4d 0c             	mov    0xc(%ebp),%ecx
	int byte_idx = bit_index / 8;
8010663e:	8d 41 07             	lea    0x7(%ecx),%eax
80106641:	85 c9                	test   %ecx,%ecx
80106643:	0f 49 c1             	cmovns %ecx,%eax
80106646:	c1 f8 03             	sar    $0x3,%eax
	int bit_idx = bit_index % 8;
	bitmap[byte_idx] = set_bit(bitmap[byte_idx], bit_idx);
80106649:	03 45 08             	add    0x8(%ebp),%eax
	int bit_idx = bit_index % 8;
8010664c:	89 ca                	mov    %ecx,%edx
8010664e:	c1 fa 1f             	sar    $0x1f,%edx
80106651:	c1 ea 1d             	shr    $0x1d,%edx
80106654:	01 d1                	add    %edx,%ecx
80106656:	83 e1 07             	and    $0x7,%ecx
80106659:	29 d1                	sub    %edx,%ecx
	return num | (1 << i);
8010665b:	ba 01 00 00 00       	mov    $0x1,%edx
80106660:	d3 e2                	shl    %cl,%edx
80106662:	08 10                	or     %dl,(%eax)
}
80106664:	5d                   	pop    %ebp
80106665:	c3                   	ret    

80106666 <bitmap_clear>:

void bitmap_clear(char *bitmap, int bit_index) {
80106666:	55                   	push   %ebp
80106667:	89 e5                	mov    %esp,%ebp
80106669:	8b 4d 0c             	mov    0xc(%ebp),%ecx
    int byte_idx = bit_index / 8;
8010666c:	8d 41 07             	lea    0x7(%ecx),%eax
8010666f:	85 c9                	test   %ecx,%ecx
80106671:	0f 49 c1             	cmovns %ecx,%eax
80106674:	c1 f8 03             	sar    $0x3,%eax
    int bit_idx = bit_index % 8;
    bitmap[byte_idx] = clear_bit(bitmap[byte_idx], bit_idx);
80106677:	03 45 08             	add    0x8(%ebp),%eax
    int bit_idx = bit_index % 8;
8010667a:	89 ca                	mov    %ecx,%edx
8010667c:	c1 fa 1f             	sar    $0x1f,%edx
8010667f:	c1 ea 1d             	shr    $0x1d,%edx
80106682:	01 d1                	add    %edx,%ecx
80106684:	83 e1 07             	and    $0x7,%ecx
80106687:	29 d1                	sub    %edx,%ecx
	return num & (~(1 << i));
80106689:	ba fe ff ff ff       	mov    $0xfffffffe,%edx
8010668e:	d3 c2                	rol    %cl,%edx
80106690:	20 10                	and    %dl,(%eax)
}
80106692:	5d                   	pop    %ebp
80106693:	c3                   	ret    

80106694 <bitmap_test>:

bool bitmap_test(char *bitmap, int bit_index) {
80106694:	55                   	push   %ebp
80106695:	89 e5                	mov    %esp,%ebp
80106697:	8b 4d 0c             	mov    0xc(%ebp),%ecx
    int byte_idx = bit_index / 8;
8010669a:	8d 41 07             	lea    0x7(%ecx),%eax
8010669d:	85 c9                	test   %ecx,%ecx
8010669f:	0f 49 c1             	cmovns %ecx,%eax
801066a2:	c1 f8 03             	sar    $0x3,%eax
    int bit_idx = bit_index % 8;
    return get_bit(bitmap[byte_idx], bit_idx);
801066a5:	8b 55 08             	mov    0x8(%ebp),%edx
801066a8:	0f be 04 02          	movsbl (%edx,%eax,1),%eax
    int bit_idx = bit_index % 8;
801066ac:	89 ca                	mov    %ecx,%edx
801066ae:	c1 fa 1f             	sar    $0x1f,%edx
801066b1:	c1 ea 1d             	shr    $0x1d,%edx
801066b4:	01 d1                	add    %edx,%ecx
801066b6:	83 e1 07             	and    $0x7,%ecx
801066b9:	29 d1                	sub    %edx,%ecx
	return ((num & (1 << i)) != 0);
801066bb:	d3 f8                	sar    %cl,%eax
801066bd:	83 e0 01             	and    $0x1,%eax
}
801066c0:	5d                   	pop    %ebp
801066c1:	c3                   	ret    

801066c2 <cover_page>:



void cover_page(struct slab *s)
{
801066c2:	55                   	push   %ebp
801066c3:	89 e5                	mov    %esp,%ebp
801066c5:	57                   	push   %edi
801066c6:	56                   	push   %esi
801066c7:	53                   	push   %ebx
801066c8:	83 ec 3c             	sub    $0x3c,%esp
801066cb:	8b 7d 08             	mov    0x8(%ebp),%edi
	int write_idx = 0;
	int objs = s->num_objects_per_page;
801066ce:	8b 47 10             	mov    0x10(%edi),%eax
801066d1:	89 45 c0             	mov    %eax,-0x40(%ebp)
	for(int m = 0 ; m < s->num_pages ; m++)
801066d4:	8b 47 04             	mov    0x4(%edi),%eax
801066d7:	85 c0                	test   %eax,%eax
801066d9:	0f 8e 19 01 00 00    	jle    801067f8 <cover_page+0x136>
	{
		if(s->page[m] == 0)
801066df:	83 7f 18 00          	cmpl   $0x0,0x18(%edi)
801066e3:	0f 84 50 01 00 00    	je     80106839 <cover_page+0x177>
	for(int m = 0 ; m < s->num_pages ; m++)
801066e9:	ba 00 00 00 00       	mov    $0x0,%edx
801066ee:	83 c2 01             	add    $0x1,%edx
801066f1:	39 c2                	cmp    %eax,%edx
801066f3:	74 0c                	je     80106701 <cover_page+0x3f>
		if(s->page[m] == 0)
801066f5:	83 7c 97 18 00       	cmpl   $0x0,0x18(%edi,%edx,4)
801066fa:	75 f2                	jne    801066ee <cover_page+0x2c>
801066fc:	89 55 d0             	mov    %edx,-0x30(%ebp)
801066ff:	eb 07                	jmp    80106708 <cover_page+0x46>
	int write_idx = 0;
80106701:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
80106708:	8b 5d c0             	mov    -0x40(%ebp),%ebx
8010670b:	89 5d c8             	mov    %ebx,-0x38(%ebp)
8010670e:	8b 45 d0             	mov    -0x30(%ebp),%eax
80106711:	89 c6                	mov    %eax,%esi
80106713:	0f af f3             	imul   %ebx,%esi
80106716:	89 75 cc             	mov    %esi,-0x34(%ebp)
	for(int m = 0 ; m < s->num_pages ; m++)
80106719:	89 45 dc             	mov    %eax,-0x24(%ebp)
8010671c:	89 fe                	mov    %edi,%esi
8010671e:	eb 6f                	jmp    8010678f <cover_page+0xcd>
				{
					bitmap_set(s->bitmap, str_bit);
				}
				else
				{
					bitmap_clear(s->bitmap, str_bit);
80106720:	ff 75 e0             	pushl  -0x20(%ebp)
80106723:	53                   	push   %ebx
80106724:	e8 3d ff ff ff       	call   80106666 <bitmap_clear>
80106729:	83 c4 08             	add    $0x8,%esp
				}
				bitmap_clear(s->bitmap, del_bit);
8010672c:	ff 75 e4             	pushl  -0x1c(%ebp)
8010672f:	ff 76 14             	pushl  0x14(%esi)
80106732:	e8 2f ff ff ff       	call   80106666 <bitmap_clear>
80106737:	83 c7 01             	add    $0x1,%edi
			for(int i = 0 ; i < objs ; i++){
8010673a:	83 c4 08             	add    $0x8,%esp
8010673d:	3b 7d d8             	cmp    -0x28(%ebp),%edi
80106740:	74 2a                	je     8010676c <cover_page+0xaa>
				int del_bit = read_idx * objs + i;
80106742:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106745:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80106748:	01 f8                	add    %edi,%eax
8010674a:	89 45 e0             	mov    %eax,-0x20(%ebp)
				if(bitmap_test(s->bitmap, del_bit))
8010674d:	8b 5e 14             	mov    0x14(%esi),%ebx
80106750:	57                   	push   %edi
80106751:	53                   	push   %ebx
80106752:	e8 3d ff ff ff       	call   80106694 <bitmap_test>
80106757:	83 c4 08             	add    $0x8,%esp
8010675a:	84 c0                	test   %al,%al
8010675c:	74 c2                	je     80106720 <cover_page+0x5e>
					bitmap_set(s->bitmap, str_bit);
8010675e:	ff 75 e0             	pushl  -0x20(%ebp)
80106761:	53                   	push   %ebx
80106762:	e8 d1 fe ff ff       	call   80106638 <bitmap_set>
80106767:	83 c4 08             	add    $0x8,%esp
8010676a:	eb c0                	jmp    8010672c <cover_page+0x6a>
			}
			s->page[read_idx] = 0;
8010676c:	8b 45 c4             	mov    -0x3c(%ebp),%eax
8010676f:	c7 44 86 18 00 00 00 	movl   $0x0,0x18(%esi,%eax,4)
80106776:	00 
		}		
		write_idx ++;
80106777:	83 45 d0 01          	addl   $0x1,-0x30(%ebp)
	for(int read_idx = r ; read_idx < s->num_pages ; read_idx++)
8010677b:	83 45 dc 01          	addl   $0x1,-0x24(%ebp)
8010677f:	8b 45 dc             	mov    -0x24(%ebp),%eax
80106782:	8b 56 04             	mov    0x4(%esi),%edx
80106785:	8b 4d c8             	mov    -0x38(%ebp),%ecx
80106788:	01 4d cc             	add    %ecx,-0x34(%ebp)
8010678b:	39 c2                	cmp    %eax,%edx
8010678d:	7e 3a                	jle    801067c9 <cover_page+0x107>
8010678f:	8b 4d dc             	mov    -0x24(%ebp),%ecx
80106792:	89 4d c4             	mov    %ecx,-0x3c(%ebp)
		if(s->page[read_idx] == 0)
80106795:	8b 44 8e 18          	mov    0x18(%esi,%ecx,4),%eax
80106799:	85 c0                	test   %eax,%eax
8010679b:	74 de                	je     8010677b <cover_page+0xb9>
		if(write_idx!=read_idx)
8010679d:	8b 55 d0             	mov    -0x30(%ebp),%edx
801067a0:	39 ca                	cmp    %ecx,%edx
801067a2:	74 d3                	je     80106777 <cover_page+0xb5>
			s->page[write_idx] = s->page[read_idx];	
801067a4:	89 44 96 18          	mov    %eax,0x18(%esi,%edx,4)
			for(int i = 0 ; i < objs ; i++){
801067a8:	8b 45 c0             	mov    -0x40(%ebp),%eax
801067ab:	85 c0                	test   %eax,%eax
801067ad:	7e bd                	jle    8010676c <cover_page+0xaa>
				int str_bit = write_idx * objs + i;
801067af:	0f af c2             	imul   %edx,%eax
801067b2:	8b 5d cc             	mov    -0x34(%ebp),%ebx
801067b5:	89 da                	mov    %ebx,%edx
801067b7:	03 55 c8             	add    -0x38(%ebp),%edx
801067ba:	89 55 d8             	mov    %edx,-0x28(%ebp)
801067bd:	89 df                	mov    %ebx,%edi
801067bf:	29 d8                	sub    %ebx,%eax
801067c1:	89 45 d4             	mov    %eax,-0x2c(%ebp)
801067c4:	e9 79 ff ff ff       	jmp    80106742 <cover_page+0x80>
801067c9:	89 f7                	mov    %esi,%edi
	}
	
	int ans = 0;
	for(int i = 0 ; i < s->num_pages ; i++)
801067cb:	85 d2                	test   %edx,%edx
801067cd:	7e 37                	jle    80106806 <cover_page+0x144>
801067cf:	8d 46 18             	lea    0x18(%esi),%eax
801067d2:	8d 0c 90             	lea    (%eax,%edx,4),%ecx
	int ans = 0;
801067d5:	ba 00 00 00 00       	mov    $0x0,%edx
		if(s->page[i] != 0)
		{
			ans ++;	
801067da:	83 38 01             	cmpl   $0x1,(%eax)
801067dd:	83 da ff             	sbb    $0xffffffff,%edx
801067e0:	83 c0 04             	add    $0x4,%eax
	for(int i = 0 ; i < s->num_pages ; i++)
801067e3:	39 c8                	cmp    %ecx,%eax
801067e5:	75 f3                	jne    801067da <cover_page+0x118>
		}

	s->num_pages =ans;
801067e7:	89 57 04             	mov    %edx,0x4(%edi)
	if(write_idx == 0)
801067ea:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
801067ee:	74 1d                	je     8010680d <cover_page+0x14b>
		s->page[0] = kalloc();
		memset(s->page[0], 0, PGSIZE);
		s->num_pages += 1;
		s->num_free_objects +=PGSIZE / s->size;
	}
}
801067f0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801067f3:	5b                   	pop    %ebx
801067f4:	5e                   	pop    %esi
801067f5:	5f                   	pop    %edi
801067f6:	5d                   	pop    %ebp
801067f7:	c3                   	ret    
	int write_idx = 0;
801067f8:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
	int ans = 0;
801067ff:	ba 00 00 00 00       	mov    $0x0,%edx
80106804:	eb e1                	jmp    801067e7 <cover_page+0x125>
80106806:	ba 00 00 00 00       	mov    $0x0,%edx
8010680b:	eb da                	jmp    801067e7 <cover_page+0x125>
		s->page[0] = kalloc();
8010680d:	e8 4c b9 ff ff       	call   8010215e <kalloc>
80106812:	89 47 18             	mov    %eax,0x18(%edi)
		memset(s->page[0], 0, PGSIZE);
80106815:	83 ec 04             	sub    $0x4,%esp
80106818:	68 00 10 00 00       	push   $0x1000
8010681d:	6a 00                	push   $0x0
8010681f:	50                   	push   %eax
80106820:	e8 55 d6 ff ff       	call   80103e7a <memset>
		s->num_pages += 1;
80106825:	83 47 04 01          	addl   $0x1,0x4(%edi)
		s->num_free_objects +=PGSIZE / s->size;
80106829:	b8 00 10 00 00       	mov    $0x1000,%eax
8010682e:	99                   	cltd   
8010682f:	f7 3f                	idivl  (%edi)
80106831:	01 47 08             	add    %eax,0x8(%edi)
80106834:	83 c4 10             	add    $0x10,%esp
}
80106837:	eb b7                	jmp    801067f0 <cover_page+0x12e>
	for(int m = 0 ; m < s->num_pages ; m++)
80106839:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
80106840:	e9 c3 fe ff ff       	jmp    80106708 <cover_page+0x46>

80106845 <slabinit>:

void slabinit(){
80106845:	55                   	push   %ebp
80106846:	89 e5                	mov    %esp,%ebp
80106848:	57                   	push   %edi
80106849:	56                   	push   %esi
8010684a:	53                   	push   %ebx
8010684b:	83 ec 44             	sub    $0x44,%esp
	initlock(&stable.lock, "slab lock");
8010684e:	68 13 8a 10 80       	push   $0x80108a13
80106853:	68 00 ce 1d 80       	push   $0x801dce00
80106858:	e8 27 d4 ff ff       	call   80103c84 <initlock>
	acquire(&stable.lock);
8010685d:	c7 04 24 00 ce 1d 80 	movl   $0x801dce00,(%esp)
80106864:	e8 63 d5 ff ff       	call   80103dcc <acquire>
	int slab_size[8] = {16, 32, 64, 128, 256, 512, 1024, 2048};
80106869:	c7 45 c8 10 00 00 00 	movl   $0x10,-0x38(%ebp)
80106870:	c7 45 cc 20 00 00 00 	movl   $0x20,-0x34(%ebp)
80106877:	c7 45 d0 40 00 00 00 	movl   $0x40,-0x30(%ebp)
8010687e:	c7 45 d4 80 00 00 00 	movl   $0x80,-0x2c(%ebp)
80106885:	c7 45 d8 00 01 00 00 	movl   $0x100,-0x28(%ebp)
8010688c:	c7 45 dc 00 02 00 00 	movl   $0x200,-0x24(%ebp)
80106893:	c7 45 e0 00 04 00 00 	movl   $0x400,-0x20(%ebp)
8010689a:	c7 45 e4 00 08 00 00 	movl   $0x800,-0x1c(%ebp)
801068a1:	8d 75 c8             	lea    -0x38(%ebp),%esi
801068a4:	bb 4c ce 1d 80       	mov    $0x801dce4c,%ebx
801068a9:	83 c4 10             	add    $0x10,%esp
	
	struct slab *s;

	for(int i = 0 ; i <NSLAB ; i++){
		s = &stable.slab[i];
		s->size = slab_size[i];
801068ac:	8b 0e                	mov    (%esi),%ecx
801068ae:	89 5d c4             	mov    %ebx,-0x3c(%ebp)
801068b1:	89 4b e8             	mov    %ecx,-0x18(%ebx)
		s->num_pages = 1;
801068b4:	c7 43 ec 01 00 00 00 	movl   $0x1,-0x14(%ebx)
		s->num_free_objects = PGSIZE / slab_size[i];
801068bb:	b8 00 10 00 00       	mov    $0x1000,%eax
801068c0:	99                   	cltd   
801068c1:	f7 f9                	idiv   %ecx
801068c3:	89 c7                	mov    %eax,%edi
801068c5:	89 43 f0             	mov    %eax,-0x10(%ebx)
		s->num_used_objects = 0;
801068c8:	c7 43 f4 00 00 00 00 	movl   $0x0,-0xc(%ebx)

		if((s->bitmap = (char *)kalloc())==0)
801068cf:	e8 8a b8 ff ff       	call   8010215e <kalloc>
801068d4:	89 43 fc             	mov    %eax,-0x4(%ebx)
801068d7:	85 c0                	test   %eax,%eax
801068d9:	74 73                	je     8010694e <slabinit+0x109>
			panic("slabinit: no mem");
		memset(s->bitmap, 0, PGSIZE);
801068db:	83 ec 04             	sub    $0x4,%esp
801068de:	68 00 10 00 00       	push   $0x1000
801068e3:	6a 00                	push   $0x0
801068e5:	50                   	push   %eax
801068e6:	e8 8f d5 ff ff       	call   80103e7a <memset>
		
		s->num_objects_per_page = PGSIZE / slab_size[i];
801068eb:	89 7b f8             	mov    %edi,-0x8(%ebx)
801068ee:	8d 93 90 01 00 00    	lea    0x190(%ebx),%edx
801068f4:	83 c4 10             	add    $0x10,%esp
801068f7:	89 d8                	mov    %ebx,%eax
		for(int j = 0 ; j < MAX_PAGES_PER_SLAB ; j++)
			s->page[j] = 0;
801068f9:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
801068ff:	83 c0 04             	add    $0x4,%eax
		for(int j = 0 ; j < MAX_PAGES_PER_SLAB ; j++)
80106902:	39 d0                	cmp    %edx,%eax
80106904:	75 f3                	jne    801068f9 <slabinit+0xb4>

		s->page[0] = kalloc();
80106906:	e8 53 b8 ff ff       	call   8010215e <kalloc>
8010690b:	8b 4d c4             	mov    -0x3c(%ebp),%ecx
8010690e:	89 01                	mov    %eax,(%ecx)

	        if (s->page[0] == 0)
80106910:	85 c0                	test   %eax,%eax
80106912:	74 47                	je     8010695b <slabinit+0x116>
			panic("slabinit: no page mem");
		
		s->large_count = 0; 	//2048보다 큰 데이터인지 구분
80106914:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80106917:	c7 80 90 01 00 00 00 	movl   $0x0,0x190(%eax)
8010691e:	00 00 00 
80106921:	83 c6 04             	add    $0x4,%esi
80106924:	81 c3 ac 01 00 00    	add    $0x1ac,%ebx
	for(int i = 0 ; i <NSLAB ; i++){
8010692a:	81 fb ac db 1d 80    	cmp    $0x801ddbac,%ebx
80106930:	0f 85 76 ff ff ff    	jne    801068ac <slabinit+0x67>
	}
	release(&stable.lock);
80106936:	83 ec 0c             	sub    $0xc,%esp
80106939:	68 00 ce 1d 80       	push   $0x801dce00
8010693e:	e8 f0 d4 ff ff       	call   80103e33 <release>
}
80106943:	83 c4 10             	add    $0x10,%esp
80106946:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106949:	5b                   	pop    %ebx
8010694a:	5e                   	pop    %esi
8010694b:	5f                   	pop    %edi
8010694c:	5d                   	pop    %ebp
8010694d:	c3                   	ret    
			panic("slabinit: no mem");
8010694e:	83 ec 0c             	sub    $0xc,%esp
80106951:	68 1d 8a 10 80       	push   $0x80108a1d
80106956:	e8 e9 99 ff ff       	call   80100344 <panic>
			panic("slabinit: no page mem");
8010695b:	83 ec 0c             	sub    $0xc,%esp
8010695e:	68 2e 8a 10 80       	push   $0x80108a2e
80106963:	e8 dc 99 ff ff       	call   80100344 <panic>

80106968 <kmalloc>:


char *kmalloc(int size){
80106968:	55                   	push   %ebp
80106969:	89 e5                	mov    %esp,%ebp
8010696b:	57                   	push   %edi
8010696c:	56                   	push   %esi
8010696d:	53                   	push   %ebx
8010696e:	83 ec 2c             	sub    $0x2c,%esp
80106971:	8b 5d 08             	mov    0x8(%ebp),%ebx
	if(size <= 0 || size > PGSIZE * MAX_PAGES_PER_SLAB)
80106974:	8d 43 ff             	lea    -0x1(%ebx),%eax
80106977:	3d ff 3f 06 00       	cmp    $0x63fff,%eax
8010697c:	0f 87 76 03 00 00    	ja     80106cf8 <kmalloc+0x390>
		return 0;
	
	acquire(&stable.lock);
80106982:	83 ec 0c             	sub    $0xc,%esp
80106985:	68 00 ce 1d 80       	push   $0x801dce00
8010698a:	e8 3d d4 ff ff       	call   80103dcc <acquire>
	if(size > MAX_OBJ_SIZE)
8010698f:	83 c4 10             	add    $0x10,%esp
80106992:	81 fb 00 08 00 00    	cmp    $0x800,%ebx
80106998:	0f 8e 46 01 00 00    	jle    80106ae4 <kmalloc+0x17c>
	{
		int obj_need = (size + MAX_OBJ_SIZE - 1) / MAX_OBJ_SIZE;
8010699e:	8d 83 fe 0f 00 00    	lea    0xffe(%ebx),%eax
801069a4:	81 c3 ff 07 00 00    	add    $0x7ff,%ebx
801069aa:	0f 48 d8             	cmovs  %eax,%ebx
801069ad:	c1 fb 0b             	sar    $0xb,%ebx
801069b0:	89 5d dc             	mov    %ebx,-0x24(%ebp)
		struct slab *s = &stable.slab[NSLAB - 1];
		s->large_count = obj_need;
801069b3:	89 1d 90 db 1d 80    	mov    %ebx,0x801ddb90
		int allocate = 0;
		char * first_addr = 0;

		for(int i = 0 ; allocate < obj_need ; i++){
801069b9:	85 db                	test   %ebx,%ebx
801069bb:	0f 8e 01 01 00 00    	jle    80106ac2 <kmalloc+0x15a>
801069c1:	bb 00 00 00 00       	mov    $0x0,%ebx
		char * first_addr = 0;
801069c6:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
		int allocate = 0;
801069cd:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
			int check_page = i / s->num_objects_per_page;
801069d4:	bf 00 ce 1d 80       	mov    $0x801dce00,%edi
801069d9:	eb 68                	jmp    80106a43 <kmalloc+0xdb>

			if(s->page[check_page] == 0){
				s->page[check_page] = kalloc();
801069db:	e8 7e b7 ff ff       	call   8010215e <kalloc>
801069e0:	8b 4d e0             	mov    -0x20(%ebp),%ecx
801069e3:	89 84 8f 00 0c 00 00 	mov    %eax,0xc00(%edi,%ecx,4)
				if(s->page[check_page] == 0)
801069ea:	85 c0                	test   %eax,%eax
801069ec:	74 28                	je     80106a16 <kmalloc+0xae>
				{
					release(&stable.lock);
					return 0;
				}
				s->num_pages++;
801069ee:	83 87 ec 0b 00 00 01 	addl   $0x1,0xbec(%edi)
				s->num_free_objects += s->num_objects_per_page;
801069f5:	8b 97 f8 0b 00 00    	mov    0xbf8(%edi),%edx
801069fb:	01 97 f0 0b 00 00    	add    %edx,0xbf0(%edi)
				memset(s->page[check_page], 0, PGSIZE);
80106a01:	83 ec 04             	sub    $0x4,%esp
80106a04:	68 00 10 00 00       	push   $0x1000
80106a09:	6a 00                	push   $0x0
80106a0b:	50                   	push   %eax
80106a0c:	e8 69 d4 ff ff       	call   80103e7a <memset>
80106a11:	83 c4 10             	add    $0x10,%esp
80106a14:	eb 43                	jmp    80106a59 <kmalloc+0xf1>
80106a16:	89 c6                	mov    %eax,%esi
					release(&stable.lock);
80106a18:	83 ec 0c             	sub    $0xc,%esp
80106a1b:	68 00 ce 1d 80       	push   $0x801dce00
80106a20:	e8 0e d4 ff ff       	call   80103e33 <release>
					return 0;
80106a25:	83 c4 10             	add    $0x10,%esp
80106a28:	89 75 d0             	mov    %esi,-0x30(%ebp)
80106a2b:	e9 a9 00 00 00       	jmp    80106ad9 <kmalloc+0x171>
			s->num_free_objects--;
			s->num_used_objects++;
			char *addr = (char *)s->page[check_page] + offset;
			if(allocate == 0)
				first_addr = addr;
			allocate++;
80106a30:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
		for(int i = 0 ; allocate < obj_need ; i++){
80106a34:	83 c3 01             	add    $0x1,%ebx
80106a37:	8b 4d dc             	mov    -0x24(%ebp),%ecx
80106a3a:	39 4d e4             	cmp    %ecx,-0x1c(%ebp)
80106a3d:	0f 8d 86 00 00 00    	jge    80106ac9 <kmalloc+0x161>
			int check_page = i / s->num_objects_per_page;
80106a43:	89 d8                	mov    %ebx,%eax
80106a45:	99                   	cltd   
80106a46:	f7 bf f8 0b 00 00    	idivl  0xbf8(%edi)
80106a4c:	89 45 e0             	mov    %eax,-0x20(%ebp)
			if(s->page[check_page] == 0){
80106a4f:	83 bc 87 00 0c 00 00 	cmpl   $0x0,0xc00(%edi,%eax,4)
80106a56:	00 
80106a57:	74 82                	je     801069db <kmalloc+0x73>
			if(bitmap_test(s->bitmap, i))
80106a59:	8b b7 fc 0b 00 00    	mov    0xbfc(%edi),%esi
80106a5f:	83 ec 08             	sub    $0x8,%esp
80106a62:	53                   	push   %ebx
80106a63:	56                   	push   %esi
80106a64:	e8 2b fc ff ff       	call   80106694 <bitmap_test>
80106a69:	83 c4 10             	add    $0x10,%esp
80106a6c:	84 c0                	test   %al,%al
80106a6e:	75 c4                	jne    80106a34 <kmalloc+0xcc>
			int offset = (i % s->num_objects_per_page) * s->size;
80106a70:	8b 87 f8 0b 00 00    	mov    0xbf8(%edi),%eax
80106a76:	89 45 d8             	mov    %eax,-0x28(%ebp)
80106a79:	8b 97 e8 0b 00 00    	mov    0xbe8(%edi),%edx
80106a7f:	89 55 d4             	mov    %edx,-0x2c(%ebp)
			bitmap_set(s->bitmap, i);
80106a82:	83 ec 08             	sub    $0x8,%esp
80106a85:	53                   	push   %ebx
80106a86:	56                   	push   %esi
80106a87:	e8 ac fb ff ff       	call   80106638 <bitmap_set>
			s->num_free_objects--;
80106a8c:	83 af f0 0b 00 00 01 	subl   $0x1,0xbf0(%edi)
			s->num_used_objects++;
80106a93:	83 87 f4 0b 00 00 01 	addl   $0x1,0xbf4(%edi)
			char *addr = (char *)s->page[check_page] + offset;
80106a9a:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106a9d:	8b 8c 87 00 0c 00 00 	mov    0xc00(%edi,%eax,4),%ecx
			if(allocate == 0)
80106aa4:	83 c4 10             	add    $0x10,%esp
80106aa7:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
80106aab:	75 83                	jne    80106a30 <kmalloc+0xc8>
			int offset = (i % s->num_objects_per_page) * s->size;
80106aad:	89 d8                	mov    %ebx,%eax
80106aaf:	99                   	cltd   
80106ab0:	f7 7d d8             	idivl  -0x28(%ebp)
80106ab3:	0f af 55 d4          	imul   -0x2c(%ebp),%edx
			char *addr = (char *)s->page[check_page] + offset;
80106ab7:	8d 04 11             	lea    (%ecx,%edx,1),%eax
80106aba:	89 45 d0             	mov    %eax,-0x30(%ebp)
80106abd:	e9 6e ff ff ff       	jmp    80106a30 <kmalloc+0xc8>
		char * first_addr = 0;
80106ac2:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
				
		if(allocate < obj_need){
			release(&stable.lock);
			return 0;
		}
		release(&stable.lock);		
80106ac9:	83 ec 0c             	sub    $0xc,%esp
80106acc:	68 00 ce 1d 80       	push   $0x801dce00
80106ad1:	e8 5d d3 ff ff       	call   80103e33 <release>
		return first_addr;
80106ad6:	83 c4 10             	add    $0x10,%esp
		release(&stable.lock);
		return addr;
	}
	release(&stable.lock);
	return 0;
}
80106ad9:	8b 45 d0             	mov    -0x30(%ebp),%eax
80106adc:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106adf:	5b                   	pop    %ebx
80106ae0:	5e                   	pop    %esi
80106ae1:	5f                   	pop    %edi
80106ae2:	5d                   	pop    %ebp
80106ae3:	c3                   	ret    
	int slab_num = nextPower(size);
80106ae4:	83 ec 0c             	sub    $0xc,%esp
80106ae7:	53                   	push   %ebx
80106ae8:	e8 24 fb ff ff       	call   80106611 <nextPower>
80106aed:	83 c4 10             	add    $0x10,%esp
80106af0:	89 c6                	mov    %eax,%esi
	if(s->bitmap == 0){
80106af2:	69 c0 ac 01 00 00    	imul   $0x1ac,%eax,%eax
80106af8:	83 b8 48 ce 1d 80 00 	cmpl   $0x0,-0x7fe231b8(%eax)
80106aff:	0f 84 be 00 00 00    	je     80106bc3 <kmalloc+0x25b>
	if(s->num_free_objects == 0 || s->page[0] == 0)
80106b05:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106b0b:	83 b8 3c ce 1d 80 00 	cmpl   $0x0,-0x7fe231c4(%eax)
80106b12:	74 09                	je     80106b1d <kmalloc+0x1b5>
80106b14:	83 b8 4c ce 1d 80 00 	cmpl   $0x0,-0x7fe231b4(%eax)
80106b1b:	75 65                	jne    80106b82 <kmalloc+0x21a>
		if(s->num_pages < MAX_PAGES_PER_SLAB)
80106b1d:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106b23:	8b 98 38 ce 1d 80    	mov    -0x7fe231c8(%eax),%ebx
80106b29:	83 fb 63             	cmp    $0x63,%ebx
80106b2c:	0f 8f ef 00 00 00    	jg     80106c21 <kmalloc+0x2b9>
			s->page[s->num_pages] = kalloc();
80106b32:	e8 27 b6 ff ff       	call   8010215e <kalloc>
80106b37:	6b ce 6b             	imul   $0x6b,%esi,%ecx
80106b3a:	8d 54 0b 10          	lea    0x10(%ebx,%ecx,1),%edx
80106b3e:	89 04 95 0c ce 1d 80 	mov    %eax,-0x7fe231f4(,%edx,4)
			if(s->page[s->num_pages] == 0)
80106b45:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106b4b:	8b 90 38 ce 1d 80    	mov    -0x7fe231c8(%eax),%edx
80106b51:	8d 44 0a 10          	lea    0x10(%edx,%ecx,1),%eax
80106b55:	8b 04 85 0c ce 1d 80 	mov    -0x7fe231f4(,%eax,4),%eax
80106b5c:	89 45 d0             	mov    %eax,-0x30(%ebp)
80106b5f:	85 c0                	test   %eax,%eax
80106b61:	0f 84 a5 00 00 00    	je     80106c0c <kmalloc+0x2a4>
			s->num_pages++;
80106b67:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106b6d:	83 c2 01             	add    $0x1,%edx
80106b70:	89 90 38 ce 1d 80    	mov    %edx,-0x7fe231c8(%eax)
			s->num_free_objects = s->num_objects_per_page;
80106b76:	8b 90 44 ce 1d 80    	mov    -0x7fe231bc(%eax),%edx
80106b7c:	89 90 3c ce 1d 80    	mov    %edx,-0x7fe231c4(%eax)
	int check_total = s->num_pages * s->num_objects_per_page;
80106b82:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106b88:	8b 98 44 ce 1d 80    	mov    -0x7fe231bc(%eax),%ebx
80106b8e:	89 d9                	mov    %ebx,%ecx
80106b90:	0f af 88 38 ce 1d 80 	imul   -0x7fe231c8(%eax),%ecx
80106b97:	89 4d d8             	mov    %ecx,-0x28(%ebp)
	for(int obj = 0 ; obj < check_total ; obj++)
80106b9a:	85 c9                	test   %ecx,%ecx
80106b9c:	0f 8e 3a 01 00 00    	jle    80106cdc <kmalloc+0x374>
80106ba2:	bf 00 00 00 00       	mov    $0x0,%edi
		if(s->page[check_page] == 0)
80106ba7:	6b c6 6b             	imul   $0x6b,%esi,%eax
80106baa:	89 45 e4             	mov    %eax,-0x1c(%ebp)
		if(bitmap_test(s->bitmap, obj))
80106bad:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106bb3:	05 00 ce 1d 80       	add    $0x801dce00,%eax
80106bb8:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106bbb:	89 75 d4             	mov    %esi,-0x2c(%ebp)
80106bbe:	e9 8a 00 00 00       	jmp    80106c4d <kmalloc+0x2e5>
		s->bitmap = (char *) kalloc();
80106bc3:	e8 96 b5 ff ff       	call   8010215e <kalloc>
80106bc8:	89 c2                	mov    %eax,%edx
80106bca:	89 45 d0             	mov    %eax,-0x30(%ebp)
80106bcd:	69 c6 ac 01 00 00    	imul   $0x1ac,%esi,%eax
80106bd3:	89 90 48 ce 1d 80    	mov    %edx,-0x7fe231b8(%eax)
		if(s->bitmap == 0)
80106bd9:	85 d2                	test   %edx,%edx
80106bdb:	74 1a                	je     80106bf7 <kmalloc+0x28f>
		memset(s->bitmap, 0, PGSIZE);
80106bdd:	83 ec 04             	sub    $0x4,%esp
80106be0:	68 00 10 00 00       	push   $0x1000
80106be5:	6a 00                	push   $0x0
80106be7:	ff 75 d0             	pushl  -0x30(%ebp)
80106bea:	e8 8b d2 ff ff       	call   80103e7a <memset>
80106bef:	83 c4 10             	add    $0x10,%esp
80106bf2:	e9 0e ff ff ff       	jmp    80106b05 <kmalloc+0x19d>
			release(&stable.lock);
80106bf7:	83 ec 0c             	sub    $0xc,%esp
80106bfa:	68 00 ce 1d 80       	push   $0x801dce00
80106bff:	e8 2f d2 ff ff       	call   80103e33 <release>
			return 0;
80106c04:	83 c4 10             	add    $0x10,%esp
80106c07:	e9 cd fe ff ff       	jmp    80106ad9 <kmalloc+0x171>
				release(&stable.lock);
80106c0c:	83 ec 0c             	sub    $0xc,%esp
80106c0f:	68 00 ce 1d 80       	push   $0x801dce00
80106c14:	e8 1a d2 ff ff       	call   80103e33 <release>
				return 0;
80106c19:	83 c4 10             	add    $0x10,%esp
80106c1c:	e9 b8 fe ff ff       	jmp    80106ad9 <kmalloc+0x171>
			release(&stable.lock);
80106c21:	83 ec 0c             	sub    $0xc,%esp
80106c24:	68 00 ce 1d 80       	push   $0x801dce00
80106c29:	e8 05 d2 ff ff       	call   80103e33 <release>
			return 0;
80106c2e:	83 c4 10             	add    $0x10,%esp
80106c31:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
80106c38:	e9 9c fe ff ff       	jmp    80106ad9 <kmalloc+0x171>
			obj = obj + s->num_objects_per_page - 1;
80106c3d:	8d 7c 3b ff          	lea    -0x1(%ebx,%edi,1),%edi
	for(int obj = 0 ; obj < check_total ; obj++)
80106c41:	83 c7 01             	add    $0x1,%edi
80106c44:	39 7d d8             	cmp    %edi,-0x28(%ebp)
80106c47:	0f 8e 8f 00 00 00    	jle    80106cdc <kmalloc+0x374>
		int check_page = obj / s->num_objects_per_page;
80106c4d:	89 f8                	mov    %edi,%eax
80106c4f:	99                   	cltd   
80106c50:	f7 fb                	idiv   %ebx
80106c52:	89 45 e0             	mov    %eax,-0x20(%ebp)
		if(s->page[check_page] == 0)
80106c55:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80106c58:	8d 44 08 10          	lea    0x10(%eax,%ecx,1),%eax
80106c5c:	b9 00 ce 1d 80       	mov    $0x801dce00,%ecx
80106c61:	83 7c 81 0c 00       	cmpl   $0x0,0xc(%ecx,%eax,4)
80106c66:	74 d5                	je     80106c3d <kmalloc+0x2d5>
		if(bitmap_test(s->bitmap, obj))
80106c68:	8b 45 dc             	mov    -0x24(%ebp),%eax
80106c6b:	8b 70 48             	mov    0x48(%eax),%esi
80106c6e:	83 ec 08             	sub    $0x8,%esp
80106c71:	57                   	push   %edi
80106c72:	56                   	push   %esi
80106c73:	e8 1c fa ff ff       	call   80106694 <bitmap_test>
80106c78:	83 c4 10             	add    $0x10,%esp
80106c7b:	84 c0                	test   %al,%al
80106c7d:	75 c2                	jne    80106c41 <kmalloc+0x2d9>
80106c7f:	89 f1                	mov    %esi,%ecx
80106c81:	8b 75 d4             	mov    -0x2c(%ebp),%esi
		int offset = (obj % s->num_objects_per_page) * s->size;
80106c84:	89 f8                	mov    %edi,%eax
80106c86:	99                   	cltd   
80106c87:	f7 fb                	idiv   %ebx
80106c89:	69 de ac 01 00 00    	imul   $0x1ac,%esi,%ebx
80106c8f:	0f af 93 34 ce 1d 80 	imul   -0x7fe231cc(%ebx),%edx
80106c96:	81 c3 00 ce 1d 80    	add    $0x801dce00,%ebx
80106c9c:	89 55 e4             	mov    %edx,-0x1c(%ebp)
		bitmap_set(s->bitmap, obj);
80106c9f:	83 ec 08             	sub    $0x8,%esp
80106ca2:	57                   	push   %edi
80106ca3:	51                   	push   %ecx
80106ca4:	e8 8f f9 ff ff       	call   80106638 <bitmap_set>
		s->num_free_objects--;
80106ca9:	83 6b 3c 01          	subl   $0x1,0x3c(%ebx)
		s->num_used_objects++;
80106cad:	83 43 40 01          	addl   $0x1,0x40(%ebx)
		char *addr = (char *)s->page[check_page] + offset;
80106cb1:	6b c6 6b             	imul   $0x6b,%esi,%eax
80106cb4:	8b 75 e0             	mov    -0x20(%ebp),%esi
80106cb7:	8d 44 06 10          	lea    0x10(%esi,%eax,1),%eax
80106cbb:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80106cbe:	03 14 85 0c ce 1d 80 	add    -0x7fe231f4(,%eax,4),%edx
80106cc5:	89 55 d0             	mov    %edx,-0x30(%ebp)
		release(&stable.lock);
80106cc8:	c7 04 24 00 ce 1d 80 	movl   $0x801dce00,(%esp)
80106ccf:	e8 5f d1 ff ff       	call   80103e33 <release>
		return addr;
80106cd4:	83 c4 10             	add    $0x10,%esp
80106cd7:	e9 fd fd ff ff       	jmp    80106ad9 <kmalloc+0x171>
	release(&stable.lock);
80106cdc:	83 ec 0c             	sub    $0xc,%esp
80106cdf:	68 00 ce 1d 80       	push   $0x801dce00
80106ce4:	e8 4a d1 ff ff       	call   80103e33 <release>
	return 0;
80106ce9:	83 c4 10             	add    $0x10,%esp
80106cec:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
80106cf3:	e9 e1 fd ff ff       	jmp    80106ad9 <kmalloc+0x171>
		return 0;
80106cf8:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
80106cff:	e9 d5 fd ff ff       	jmp    80106ad9 <kmalloc+0x171>

80106d04 <kmfree>:

void kmfree(char *addr, int size){
80106d04:	55                   	push   %ebp
80106d05:	89 e5                	mov    %esp,%ebp
80106d07:	57                   	push   %edi
80106d08:	56                   	push   %esi
80106d09:	53                   	push   %ebx
80106d0a:	83 ec 1c             	sub    $0x1c,%esp
80106d0d:	8b 75 08             	mov    0x8(%ebp),%esi
80106d10:	8b 5d 0c             	mov    0xc(%ebp),%ebx
	if(size <= 0 || size > PGSIZE * MAX_PAGES_PER_SLAB)
80106d13:	8d 43 ff             	lea    -0x1(%ebx),%eax
80106d16:	3d ff 3f 06 00       	cmp    $0x63fff,%eax
80106d1b:	76 08                	jbe    80106d25 <kmfree+0x21>
		}
	}
	cover_page(s);
	release(&stable.lock);
	return ;
}
80106d1d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106d20:	5b                   	pop    %ebx
80106d21:	5e                   	pop    %esi
80106d22:	5f                   	pop    %edi
80106d23:	5d                   	pop    %ebp
80106d24:	c3                   	ret    
	acquire(&stable.lock);
80106d25:	83 ec 0c             	sub    $0xc,%esp
80106d28:	68 00 ce 1d 80       	push   $0x801dce00
80106d2d:	e8 9a d0 ff ff       	call   80103dcc <acquire>
	if(size > MAX_OBJ_SIZE)
80106d32:	83 c4 10             	add    $0x10,%esp
80106d35:	81 fb 00 08 00 00    	cmp    $0x800,%ebx
80106d3b:	0f 8e e5 01 00 00    	jle    80106f26 <kmfree+0x222>
		for(int i = 0 ; i < s->large_count ; i++)
80106d41:	83 3d 90 db 1d 80 00 	cmpl   $0x0,0x801ddb90
80106d48:	0f 8e cb 00 00 00    	jle    80106e19 <kmfree+0x115>
80106d4e:	c7 45 d8 00 00 00 00 	movl   $0x0,-0x28(%ebp)
			char *cur_addr = s->page[i/2] + ((i%2) * s->size);
80106d55:	bf 00 ce 1d 80       	mov    $0x801dce00,%edi
80106d5a:	eb 52                	jmp    80106dae <kmfree+0xaa>
					obj = obj + s->num_objects_per_page - 1;
80106d5c:	8d 5c 1e ff          	lea    -0x1(%esi,%ebx,1),%ebx
			for(int obj = 0 ; obj < total_obj ; obj++)
80106d60:	83 c3 01             	add    $0x1,%ebx
80106d63:	39 5d e4             	cmp    %ebx,-0x1c(%ebp)
80106d66:	7e 37                	jle    80106d9f <kmfree+0x9b>
				int check_page = obj / s->num_objects_per_page;
80106d68:	89 d8                	mov    %ebx,%eax
80106d6a:	99                   	cltd   
80106d6b:	f7 fe                	idiv   %esi
				if(s->page[check_page] == 0)
80106d6d:	8b 8c 87 00 0c 00 00 	mov    0xc00(%edi,%eax,4),%ecx
80106d74:	85 c9                	test   %ecx,%ecx
80106d76:	74 e4                	je     80106d5c <kmfree+0x58>
				int offset = (obj % s->num_objects_per_page) * s->size;
80106d78:	89 d8                	mov    %ebx,%eax
80106d7a:	99                   	cltd   
80106d7b:	f7 fe                	idiv   %esi
80106d7d:	0f af 55 e0          	imul   -0x20(%ebp),%edx
				char *obj_addr = (char *)s->page[check_page]+ offset;
80106d81:	01 d1                	add    %edx,%ecx
				if(cur_addr == obj_addr)
80106d83:	39 4d dc             	cmp    %ecx,-0x24(%ebp)
80106d86:	75 d8                	jne    80106d60 <kmfree+0x5c>
					if(bitmap_test(s->bitmap, obj))
80106d88:	8b b7 fc 0b 00 00    	mov    0xbfc(%edi),%esi
80106d8e:	83 ec 08             	sub    $0x8,%esp
80106d91:	53                   	push   %ebx
80106d92:	56                   	push   %esi
80106d93:	e8 fc f8 ff ff       	call   80106694 <bitmap_test>
80106d98:	83 c4 10             	add    $0x10,%esp
80106d9b:	84 c0                	test   %al,%al
80106d9d:	75 5d                	jne    80106dfc <kmfree+0xf8>
		for(int i = 0 ; i < s->large_count ; i++)
80106d9f:	83 45 d8 01          	addl   $0x1,-0x28(%ebp)
80106da3:	8b 45 d8             	mov    -0x28(%ebp),%eax
80106da6:	39 87 90 0d 00 00    	cmp    %eax,0xd90(%edi)
80106dac:	7e 6b                	jle    80106e19 <kmfree+0x115>
			char *cur_addr = s->page[i/2] + ((i%2) * s->size);
80106dae:	8b b7 e8 0b 00 00    	mov    0xbe8(%edi),%esi
80106db4:	89 75 e0             	mov    %esi,-0x20(%ebp)
80106db7:	8b 45 d8             	mov    -0x28(%ebp),%eax
80106dba:	89 c2                	mov    %eax,%edx
80106dbc:	c1 ea 1f             	shr    $0x1f,%edx
80106dbf:	01 c2                	add    %eax,%edx
80106dc1:	d1 fa                	sar    %edx
80106dc3:	89 c1                	mov    %eax,%ecx
80106dc5:	c1 e9 1f             	shr    $0x1f,%ecx
80106dc8:	01 c8                	add    %ecx,%eax
80106dca:	83 e0 01             	and    $0x1,%eax
80106dcd:	29 c8                	sub    %ecx,%eax
80106dcf:	0f af c6             	imul   %esi,%eax
80106dd2:	03 84 97 00 0c 00 00 	add    0xc00(%edi,%edx,4),%eax
80106dd9:	89 45 dc             	mov    %eax,-0x24(%ebp)
			int total_obj = (s->num_pages) * s->num_objects_per_page;
80106ddc:	8b b7 f8 0b 00 00    	mov    0xbf8(%edi),%esi
80106de2:	89 f0                	mov    %esi,%eax
80106de4:	0f af 87 ec 0b 00 00 	imul   0xbec(%edi),%eax
80106deb:	89 45 e4             	mov    %eax,-0x1c(%ebp)
			for(int obj = 0 ; obj < total_obj ; obj++)
80106dee:	85 c0                	test   %eax,%eax
80106df0:	7e ad                	jle    80106d9f <kmfree+0x9b>
80106df2:	bb 00 00 00 00       	mov    $0x0,%ebx
80106df7:	e9 6c ff ff ff       	jmp    80106d68 <kmfree+0x64>
						bitmap_clear(s->bitmap, obj);
80106dfc:	83 ec 08             	sub    $0x8,%esp
80106dff:	53                   	push   %ebx
80106e00:	56                   	push   %esi
80106e01:	e8 60 f8 ff ff       	call   80106666 <bitmap_clear>
						s->num_used_objects--;
80106e06:	83 af f4 0b 00 00 01 	subl   $0x1,0xbf4(%edi)
						s->num_free_objects++;
80106e0d:	83 87 f0 0b 00 00 01 	addl   $0x1,0xbf0(%edi)
80106e14:	83 c4 10             	add    $0x10,%esp
80106e17:	eb 86                	jmp    80106d9f <kmfree+0x9b>
		for(int i = 0 ; i < s->num_pages ; i++)
80106e19:	83 3d ec d9 1d 80 00 	cmpl   $0x0,0x801dd9ec
80106e20:	0f 8e d5 00 00 00    	jle    80106efb <kmfree+0x1f7>
80106e26:	bf 00 00 00 00       	mov    $0x0,%edi
80106e2b:	eb 42                	jmp    80106e6f <kmfree+0x16b>
80106e2d:	8b 7d d8             	mov    -0x28(%ebp),%edi
				if(!page_use && i >= 0)
80106e30:	85 ff                	test   %edi,%edi
80106e32:	78 2c                	js     80106e60 <kmfree+0x15c>
					kfree(s->page[i]);
80106e34:	83 ec 0c             	sub    $0xc,%esp
80106e37:	ff 75 e4             	pushl  -0x1c(%ebp)
80106e3a:	e8 fa b1 ff ff       	call   80102039 <kfree>
					s->page[i] = 0;
80106e3f:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106e42:	c7 04 85 00 da 1d 80 	movl   $0x0,-0x7fe22600(,%eax,4)
80106e49:	00 00 00 00 
					s->num_free_objects -= s->num_objects_per_page;
80106e4d:	a1 f0 d9 1d 80       	mov    0x801dd9f0,%eax
80106e52:	2b 05 f8 d9 1d 80    	sub    0x801dd9f8,%eax
80106e58:	a3 f0 d9 1d 80       	mov    %eax,0x801dd9f0
80106e5d:	83 c4 10             	add    $0x10,%esp
		for(int i = 0 ; i < s->num_pages ; i++)
80106e60:	83 c7 01             	add    $0x1,%edi
80106e63:	39 3d ec d9 1d 80    	cmp    %edi,0x801dd9ec
80106e69:	0f 8e 8c 00 00 00    	jle    80106efb <kmfree+0x1f7>
80106e6f:	89 7d e0             	mov    %edi,-0x20(%ebp)
			if(s->page[i]){
80106e72:	8b 04 bd 00 da 1d 80 	mov    -0x7fe22600(,%edi,4),%eax
80106e79:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106e7c:	85 c0                	test   %eax,%eax
80106e7e:	74 e0                	je     80106e60 <kmfree+0x15c>
				for(int j = 0 ; j<s->num_objects_per_page ; j++)
80106e80:	8b 35 f8 d9 1d 80    	mov    0x801dd9f8,%esi
80106e86:	85 f6                	test   %esi,%esi
80106e88:	7e a6                	jle    80106e30 <kmfree+0x12c>
					int obj_idx = i * s->num_objects_per_page +j;
80106e8a:	89 f0                	mov    %esi,%eax
80106e8c:	0f af c7             	imul   %edi,%eax
					if(get_bit(s->bitmap[obj_num], bit_num))
80106e8f:	8b 1d fc d9 1d 80    	mov    0x801dd9fc,%ebx
					int obj_num = obj_idx / 8;
80106e95:	8d 50 07             	lea    0x7(%eax),%edx
80106e98:	85 c0                	test   %eax,%eax
80106e9a:	0f 49 d0             	cmovns %eax,%edx
80106e9d:	c1 fa 03             	sar    $0x3,%edx
					if(get_bit(s->bitmap[obj_num], bit_num))
80106ea0:	89 5d dc             	mov    %ebx,-0x24(%ebp)
80106ea3:	0f be 1c 13          	movsbl (%ebx,%edx,1),%ebx
					int bit_num = obj_idx % 8;
80106ea7:	89 c1                	mov    %eax,%ecx
80106ea9:	c1 f9 1f             	sar    $0x1f,%ecx
80106eac:	c1 e9 1d             	shr    $0x1d,%ecx
80106eaf:	8d 14 08             	lea    (%eax,%ecx,1),%edx
80106eb2:	83 e2 07             	and    $0x7,%edx
80106eb5:	29 ca                	sub    %ecx,%edx
					if(get_bit(s->bitmap[obj_num], bit_num))
80106eb7:	0f a3 d3             	bt     %edx,%ebx
80106eba:	72 a4                	jb     80106e60 <kmfree+0x15c>
80106ebc:	8d 48 01             	lea    0x1(%eax),%ecx
80106ebf:	01 c6                	add    %eax,%esi
80106ec1:	89 7d d8             	mov    %edi,-0x28(%ebp)
80106ec4:	8b 7d dc             	mov    -0x24(%ebp),%edi
				for(int j = 0 ; j<s->num_objects_per_page ; j++)
80106ec7:	39 ce                	cmp    %ecx,%esi
80106ec9:	0f 84 5e ff ff ff    	je     80106e2d <kmfree+0x129>
					int obj_idx = i * s->num_objects_per_page +j;
80106ecf:	89 c8                	mov    %ecx,%eax
80106ed1:	83 c1 01             	add    $0x1,%ecx
					int obj_num = obj_idx / 8;
80106ed4:	8d 50 07             	lea    0x7(%eax),%edx
80106ed7:	85 c0                	test   %eax,%eax
80106ed9:	0f 49 d0             	cmovns %eax,%edx
80106edc:	c1 fa 03             	sar    $0x3,%edx
					if(get_bit(s->bitmap[obj_num], bit_num))
80106edf:	0f be 1c 17          	movsbl (%edi,%edx,1),%ebx
					int bit_num = obj_idx % 8;
80106ee3:	99                   	cltd   
80106ee4:	c1 ea 1d             	shr    $0x1d,%edx
80106ee7:	01 d0                	add    %edx,%eax
80106ee9:	83 e0 07             	and    $0x7,%eax
80106eec:	29 d0                	sub    %edx,%eax
					if(get_bit(s->bitmap[obj_num], bit_num))
80106eee:	0f a3 c3             	bt     %eax,%ebx
80106ef1:	73 d4                	jae    80106ec7 <kmfree+0x1c3>
80106ef3:	8b 7d d8             	mov    -0x28(%ebp),%edi
80106ef6:	e9 65 ff ff ff       	jmp    80106e60 <kmfree+0x15c>
		cover_page(s);
80106efb:	83 ec 0c             	sub    $0xc,%esp
80106efe:	68 e8 d9 1d 80       	push   $0x801dd9e8
80106f03:	e8 ba f7 ff ff       	call   801066c2 <cover_page>
		s->large_count = 0;
80106f08:	c7 05 90 db 1d 80 00 	movl   $0x0,0x801ddb90
80106f0f:	00 00 00 
		release(&stable.lock);
80106f12:	c7 04 24 00 ce 1d 80 	movl   $0x801dce00,(%esp)
80106f19:	e8 15 cf ff ff       	call   80103e33 <release>
		return ;
80106f1e:	83 c4 10             	add    $0x10,%esp
80106f21:	e9 f7 fd ff ff       	jmp    80106d1d <kmfree+0x19>
	int slab_num = nextPower(size);
80106f26:	83 ec 0c             	sub    $0xc,%esp
80106f29:	53                   	push   %ebx
80106f2a:	e8 e2 f6 ff ff       	call   80106611 <nextPower>
80106f2f:	83 c4 10             	add    $0x10,%esp
80106f32:	89 c7                	mov    %eax,%edi
80106f34:	89 45 e0             	mov    %eax,-0x20(%ebp)
	for(int i = 0  ; i < s->num_pages ; i++)
80106f37:	69 c0 ac 01 00 00    	imul   $0x1ac,%eax,%eax
80106f3d:	8b 90 38 ce 1d 80    	mov    -0x7fe231c8(%eax),%edx
80106f43:	85 d2                	test   %edx,%edx
80106f45:	0f 8e b9 00 00 00    	jle    80107004 <kmfree+0x300>
80106f4b:	89 c1                	mov    %eax,%ecx
80106f4d:	89 45 d8             	mov    %eax,-0x28(%ebp)
80106f50:	bb 00 00 00 00       	mov    $0x0,%ebx
80106f55:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80106f58:	eb 0b                	jmp    80106f65 <kmfree+0x261>
80106f5a:	83 c3 01             	add    $0x1,%ebx
80106f5d:	39 d3                	cmp    %edx,%ebx
80106f5f:	0f 84 9f 00 00 00    	je     80107004 <kmfree+0x300>
		if(addr >= (char *)s->page[i] && addr < (char*)s->page[i] + PGSIZE)
80106f65:	8b 84 99 4c ce 1d 80 	mov    -0x7fe231b4(%ecx,%ebx,4),%eax
80106f6c:	39 f0                	cmp    %esi,%eax
80106f6e:	77 ea                	ja     80106f5a <kmfree+0x256>
80106f70:	8d b8 00 10 00 00    	lea    0x1000(%eax),%edi
80106f76:	39 fe                	cmp    %edi,%esi
80106f78:	73 e0                	jae    80106f5a <kmfree+0x256>
80106f7a:	8b 7d e4             	mov    -0x1c(%ebp),%edi
			obj_idx = (addr - (char *)s->page[i]) / s->size;
80106f7d:	29 c6                	sub    %eax,%esi
80106f7f:	89 f0                	mov    %esi,%eax
80106f81:	69 cf ac 01 00 00    	imul   $0x1ac,%edi,%ecx
80106f87:	99                   	cltd   
80106f88:	f7 b9 34 ce 1d 80    	idivl  -0x7fe231cc(%ecx)
	if(page_idx == -1 || obj_idx == -1)
80106f8e:	83 fb ff             	cmp    $0xffffffff,%ebx
80106f91:	74 71                	je     80107004 <kmfree+0x300>
80106f93:	83 f8 ff             	cmp    $0xffffffff,%eax
80106f96:	74 6c                	je     80107004 <kmfree+0x300>
	int obj_num = page_idx * s->num_objects_per_page + obj_idx;
80106f98:	69 d7 ac 01 00 00    	imul   $0x1ac,%edi,%edx
80106f9e:	0f af 9a 44 ce 1d 80 	imul   -0x7fe231bc(%edx),%ebx
80106fa5:	01 c3                	add    %eax,%ebx
	if(!bitmap_test(s->bitmap, obj_num))
80106fa7:	8b b2 48 ce 1d 80    	mov    -0x7fe231b8(%edx),%esi
80106fad:	83 ec 08             	sub    $0x8,%esp
80106fb0:	53                   	push   %ebx
80106fb1:	56                   	push   %esi
80106fb2:	e8 dd f6 ff ff       	call   80106694 <bitmap_test>
80106fb7:	83 c4 10             	add    $0x10,%esp
80106fba:	84 c0                	test   %al,%al
80106fbc:	74 5b                	je     80107019 <kmfree+0x315>
	bitmap_clear(s->bitmap, obj_num);
80106fbe:	83 ec 08             	sub    $0x8,%esp
80106fc1:	53                   	push   %ebx
80106fc2:	56                   	push   %esi
80106fc3:	e8 9e f6 ff ff       	call   80106666 <bitmap_clear>
	s->num_used_objects--;
80106fc8:	69 c7 ac 01 00 00    	imul   $0x1ac,%edi,%eax
80106fce:	05 00 ce 1d 80       	add    $0x801dce00,%eax
80106fd3:	83 68 40 01          	subl   $0x1,0x40(%eax)
	s->num_free_objects++;
80106fd7:	83 40 3c 01          	addl   $0x1,0x3c(%eax)
	for(int i = 0 ; i < s->num_pages ; i++)
80106fdb:	8b 40 38             	mov    0x38(%eax),%eax
80106fde:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106fe1:	83 c4 10             	add    $0x10,%esp
80106fe4:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
80106feb:	85 c0                	test   %eax,%eax
80106fed:	0f 8e b6 00 00 00    	jle    801070a9 <kmfree+0x3a5>
		for(int j = 0 ; j<s->num_objects_per_page ; j++)
80106ff3:	69 45 e0 ac 01 00 00 	imul   $0x1ac,-0x20(%ebp),%eax
80106ffa:	05 00 ce 1d 80       	add    $0x801dce00,%eax
80106fff:	89 45 e0             	mov    %eax,-0x20(%ebp)
80107002:	eb 3e                	jmp    80107042 <kmfree+0x33e>
		release(&stable.lock);
80107004:	83 ec 0c             	sub    $0xc,%esp
80107007:	68 00 ce 1d 80       	push   $0x801dce00
8010700c:	e8 22 ce ff ff       	call   80103e33 <release>
		return ;
80107011:	83 c4 10             	add    $0x10,%esp
80107014:	e9 04 fd ff ff       	jmp    80106d1d <kmfree+0x19>
		release(&stable.lock);
80107019:	83 ec 0c             	sub    $0xc,%esp
8010701c:	68 00 ce 1d 80       	push   $0x801dce00
80107021:	e8 0d ce ff ff       	call   80103e33 <release>
		return ;
80107026:	83 c4 10             	add    $0x10,%esp
80107029:	e9 ef fc ff ff       	jmp    80106d1d <kmfree+0x19>
	for(int i = 0 ; i < s->num_pages ; i++)
8010702e:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
80107032:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80107035:	8b 7d e0             	mov    -0x20(%ebp),%edi
80107038:	8b 7f 38             	mov    0x38(%edi),%edi
8010703b:	89 7d dc             	mov    %edi,-0x24(%ebp)
8010703e:	39 c7                	cmp    %eax,%edi
80107040:	7e 67                	jle    801070a9 <kmfree+0x3a5>
		for(int j = 0 ; j<s->num_objects_per_page ; j++)
80107042:	8b 45 e0             	mov    -0x20(%ebp),%eax
80107045:	8b 70 44             	mov    0x44(%eax),%esi
80107048:	85 f6                	test   %esi,%esi
8010704a:	7e 26                	jle    80107072 <kmfree+0x36e>
			if(bitmap_test(s->bitmap, bit)){
8010704c:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010704f:	8b 78 48             	mov    0x48(%eax),%edi
			int bit = i * s->num_objects_per_page + j;
80107052:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80107055:	0f af de             	imul   %esi,%ebx
80107058:	01 de                	add    %ebx,%esi
			if(bitmap_test(s->bitmap, bit)){
8010705a:	83 ec 08             	sub    $0x8,%esp
8010705d:	53                   	push   %ebx
8010705e:	57                   	push   %edi
8010705f:	e8 30 f6 ff ff       	call   80106694 <bitmap_test>
80107064:	83 c4 10             	add    $0x10,%esp
80107067:	84 c0                	test   %al,%al
80107069:	75 c3                	jne    8010702e <kmfree+0x32a>
8010706b:	83 c3 01             	add    $0x1,%ebx
		for(int j = 0 ; j<s->num_objects_per_page ; j++)
8010706e:	39 de                	cmp    %ebx,%esi
80107070:	75 e8                	jne    8010705a <kmfree+0x356>
		if(empty == 1 && s->num_pages > 1)
80107072:	83 7d dc 01          	cmpl   $0x1,-0x24(%ebp)
80107076:	7e b6                	jle    8010702e <kmfree+0x32a>
			kfree(s->page[i]);
80107078:	83 ec 0c             	sub    $0xc,%esp
8010707b:	8b 7d d8             	mov    -0x28(%ebp),%edi
8010707e:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80107081:	ff b4 b7 4c ce 1d 80 	pushl  -0x7fe231b4(%edi,%esi,4)
80107088:	e8 ac af ff ff       	call   80102039 <kfree>
			s->page[i]  = 0;
8010708d:	c7 84 b7 4c ce 1d 80 	movl   $0x0,-0x7fe231b4(%edi,%esi,4)
80107094:	00 00 00 00 
			s->num_free_objects -= s-> num_objects_per_page; 
80107098:	8b 7d e0             	mov    -0x20(%ebp),%edi
8010709b:	8b 47 3c             	mov    0x3c(%edi),%eax
8010709e:	2b 47 44             	sub    0x44(%edi),%eax
801070a1:	89 47 3c             	mov    %eax,0x3c(%edi)
			continue;
801070a4:	83 c4 10             	add    $0x10,%esp
801070a7:	eb 85                	jmp    8010702e <kmfree+0x32a>
	cover_page(s);
801070a9:	83 ec 0c             	sub    $0xc,%esp
	struct slab *s = &stable.slab[slab_num];
801070ac:	8b 45 d8             	mov    -0x28(%ebp),%eax
801070af:	05 34 ce 1d 80       	add    $0x801dce34,%eax
	cover_page(s);
801070b4:	50                   	push   %eax
801070b5:	e8 08 f6 ff ff       	call   801066c2 <cover_page>
	release(&stable.lock);
801070ba:	c7 04 24 00 ce 1d 80 	movl   $0x801dce00,(%esp)
801070c1:	e8 6d cd ff ff       	call   80103e33 <release>
	return ;
801070c6:	83 c4 10             	add    $0x10,%esp
801070c9:	e9 4f fc ff ff       	jmp    80106d1d <kmfree+0x19>

801070ce <slabdump>:

/* Helper functions */
void slabdump(){
801070ce:	55                   	push   %ebp
801070cf:	89 e5                	mov    %esp,%ebp
801070d1:	53                   	push   %ebx
801070d2:	83 ec 10             	sub    $0x10,%esp
	cprintf("__slabdump__\n");
801070d5:	68 44 8a 10 80       	push   $0x80108a44
801070da:	e8 02 95 ff ff       	call   801005e1 <cprintf>

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");
801070df:	c7 04 24 64 8a 10 80 	movl   $0x80108a64,(%esp)
801070e6:	e8 f6 94 ff ff       	call   801005e1 <cprintf>
801070eb:	83 c4 10             	add    $0x10,%esp

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
801070ee:	bb 34 ce 1d 80       	mov    $0x801dce34,%ebx
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
801070f3:	83 ec 0c             	sub    $0xc,%esp
801070f6:	ff 73 08             	pushl  0x8(%ebx)
801070f9:	ff 73 0c             	pushl  0xc(%ebx)
801070fc:	ff 73 04             	pushl  0x4(%ebx)
801070ff:	ff 33                	pushl  (%ebx)
80107101:	68 52 8a 10 80       	push   $0x80108a52
80107106:	e8 d6 94 ff ff       	call   801005e1 <cprintf>
	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
8010710b:	81 c3 ac 01 00 00    	add    $0x1ac,%ebx
80107111:	83 c4 20             	add    $0x20,%esp
80107114:	81 fb 94 db 1d 80    	cmp    $0x801ddb94,%ebx
8010711a:	72 d7                	jb     801070f3 <slabdump+0x25>
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}
8010711c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010711f:	c9                   	leave  
80107120:	c3                   	ret    

80107121 <numobj_slab>:

int numobj_slab(int slabid)
{
80107121:	55                   	push   %ebp
80107122:	89 e5                	mov    %esp,%ebp
	return stable.slab[slabid].num_used_objects;
80107124:	69 45 08 ac 01 00 00 	imul   $0x1ac,0x8(%ebp),%eax
8010712b:	8b 80 40 ce 1d 80    	mov    -0x7fe231c0(%eax),%eax
}
80107131:	5d                   	pop    %ebp
80107132:	c3                   	ret    

80107133 <numpage_slab>:

int numpage_slab(int slabid)
{
80107133:	55                   	push   %ebp
80107134:	89 e5                	mov    %esp,%ebp
	return stable.slab[slabid].num_pages;
80107136:	69 45 08 ac 01 00 00 	imul   $0x1ac,0x8(%ebp),%eax
8010713d:	8b 80 38 ce 1d 80    	mov    -0x7fe231c8(%eax),%eax
}
80107143:	5d                   	pop    %ebp
80107144:	c3                   	ret    

80107145 <slabtest>:
Note that, you can edit the test function only for the debugging purpose. 
*/

int* t[NSLAB][MAXSLABTEST] = {};

void slabtest(){
80107145:	55                   	push   %ebp
80107146:	89 e5                	mov    %esp,%ebp
80107148:	57                   	push   %edi
80107149:	56                   	push   %esi
8010714a:	53                   	push   %ebx
8010714b:	83 ec 48             	sub    $0x48,%esp
	int counter = 1;
8010714e:	c7 45 e4 01 00 00 00 	movl   $0x1,-0x1c(%ebp)
	 * to locate the VMA (virtual memory address) of an multiple of 4 bytes. 
	 * You can check the VMA of .stab by executing 'objdump -h kernel' in your xv6 source dir.
	 * If the VMA is not aligned to the multiple of 4B, then adjust (add/del chars) 
	 * the literal string in the cprintf function
	 */
	cprintf("==== SLAB TEST ====\n");
80107155:	68 9b 8a 10 80       	push   $0x80108a9b
8010715a:	e8 82 94 ff ff       	call   801005e1 <cprintf>
	 *	You may debug your result with 
	 * cprintf();
	 * slabdump();
	 */
	/* TEST1: Single slab alloc */
	cprintf("==== TEST1 =====\n");
8010715f:	c7 04 24 b0 8a 10 80 	movl   $0x80108ab0,(%esp)
80107166:	e8 76 94 ff ff       	call   801005e1 <cprintf>
	start = counter;
8010716b:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
	t[0][0] = (int*) kmalloc (TESTSIZE); 
8010716e:	c7 04 24 00 08 00 00 	movl   $0x800,(%esp)
80107175:	e8 ee f7 ff ff       	call   80106968 <kmalloc>
8010717a:	a3 c0 b5 10 80       	mov    %eax,0x8010b5c0
	*(t[0][0]) = counter;
8010717f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107182:	89 10                	mov    %edx,(%eax)
	counter++;
80107184:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 1) ? "OK\n":"WRONG\n");
80107188:	83 c4 10             	add    $0x10,%esp
8010718b:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107190:	8b 15 c0 b5 10 80    	mov    0x8010b5c0,%edx
80107196:	39 1a                	cmp    %ebx,(%edx)
80107198:	0f 84 1a 01 00 00    	je     801072b8 <slabtest+0x173>
8010719e:	83 ec 0c             	sub    $0xc,%esp
801071a1:	50                   	push   %eax
801071a2:	e8 3a 94 ff ff       	call   801005e1 <cprintf>
	kmfree ((char*) t[0][0], TESTSIZE);
801071a7:	83 c4 08             	add    $0x8,%esp
801071aa:	68 00 08 00 00       	push   $0x800
801071af:	ff 35 c0 b5 10 80    	pushl  0x8010b5c0
801071b5:	e8 4a fb ff ff       	call   80106d04 <kmfree>
	/* TEST2: Single slab alloc: the size not equal to a power of 2. */
	cprintf("==== TEST2 =====\n");
801071ba:	c7 04 24 c2 8a 10 80 	movl   $0x80108ac2,(%esp)
801071c1:	e8 1b 94 ff ff       	call   801005e1 <cprintf>
	start = counter;
801071c6:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
	t[0][0] = (int*) kmalloc (TESTSIZE-10); 
801071c9:	c7 04 24 f6 07 00 00 	movl   $0x7f6,(%esp)
801071d0:	e8 93 f7 ff ff       	call   80106968 <kmalloc>
801071d5:	a3 c0 b5 10 80       	mov    %eax,0x8010b5c0
	*(t[0][0]) = counter;
801071da:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801071dd:	89 10                	mov    %edx,(%eax)
	counter++;
801071df:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)

	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 1) ? "OK\n":"WRONG\n");
801071e3:	83 c4 10             	add    $0x10,%esp
801071e6:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801071eb:	8b 15 c0 b5 10 80    	mov    0x8010b5c0,%edx
801071f1:	39 1a                	cmp    %ebx,(%edx)
801071f3:	0f 84 e1 00 00 00    	je     801072da <slabtest+0x195>
801071f9:	83 ec 0c             	sub    $0xc,%esp
801071fc:	50                   	push   %eax
801071fd:	e8 df 93 ff ff       	call   801005e1 <cprintf>
	kmfree ((char*) t[0][0], TESTSIZE);
80107202:	83 c4 08             	add    $0x8,%esp
80107205:	68 00 08 00 00       	push   $0x800
8010720a:	ff 35 c0 b5 10 80    	pushl  0x8010b5c0
80107210:	e8 ef fa ff ff       	call   80106d04 <kmfree>

	/* TEST3: Multiple slabs alloc */
	cprintf("==== TEST3 =====\n");
80107215:	c7 04 24 d4 8a 10 80 	movl   $0x80108ad4,(%esp)
8010721c:	e8 c0 93 ff ff       	call   801005e1 <cprintf>
	start = counter;
80107221:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80107224:	83 c4 10             	add    $0x10,%esp
80107227:	c7 45 c4 c0 b5 10 80 	movl   $0x8010b5c0,-0x3c(%ebp)
8010722e:	c7 45 d4 04 00 00 00 	movl   $0x4,-0x2c(%ebp)
	{
		slabsize = 1 << (i+4); 
		t[i][0]	= (int*) kmalloc (slabsize); 
		for (int j=0; j<slabsize/sizeof(int); j++)
		{
			memmove (t[i][0]+j, &counter, sizeof(int));
80107235:	89 75 d0             	mov    %esi,-0x30(%ebp)
		slabsize = 1 << (i+4); 
80107238:	bb 01 00 00 00       	mov    $0x1,%ebx
8010723d:	0f b6 4d d4          	movzbl -0x2c(%ebp),%ecx
80107241:	d3 e3                	shl    %cl,%ebx
		t[i][0]	= (int*) kmalloc (slabsize); 
80107243:	83 ec 0c             	sub    $0xc,%esp
80107246:	53                   	push   %ebx
80107247:	e8 1c f7 ff ff       	call   80106968 <kmalloc>
8010724c:	8b 55 c4             	mov    -0x3c(%ebp),%edx
8010724f:	89 d7                	mov    %edx,%edi
80107251:	89 02                	mov    %eax,(%edx)
		for (int j=0; j<slabsize/sizeof(int); j++)
80107253:	c1 eb 02             	shr    $0x2,%ebx
80107256:	83 c4 10             	add    $0x10,%esp
80107259:	85 db                	test   %ebx,%ebx
8010725b:	74 29                	je     80107286 <slabtest+0x141>
8010725d:	89 de                	mov    %ebx,%esi
8010725f:	bb 00 00 00 00       	mov    $0x0,%ebx
			memmove (t[i][0]+j, &counter, sizeof(int));
80107264:	83 ec 04             	sub    $0x4,%esp
80107267:	6a 04                	push   $0x4
80107269:	8d 45 e4             	lea    -0x1c(%ebp),%eax
8010726c:	50                   	push   %eax
8010726d:	8b 07                	mov    (%edi),%eax
8010726f:	8d 04 98             	lea    (%eax,%ebx,4),%eax
80107272:	50                   	push   %eax
80107273:	e8 97 cc ff ff       	call   80103f0f <memmove>
			counter++;
80107278:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
		for (int j=0; j<slabsize/sizeof(int); j++)
8010727c:	83 c3 01             	add    $0x1,%ebx
8010727f:	83 c4 10             	add    $0x10,%esp
80107282:	39 f3                	cmp    %esi,%ebx
80107284:	75 de                	jne    80107264 <slabtest+0x11f>
80107286:	83 45 d4 01          	addl   $0x1,-0x2c(%ebp)
8010728a:	81 45 c4 00 90 01 00 	addl   $0x19000,-0x3c(%ebp)
80107291:	8b 45 c4             	mov    -0x3c(%ebp),%eax
	for (int i=0; i<NSLAB; i++)
80107294:	3d c0 35 1d 80       	cmp    $0x801d35c0,%eax
80107299:	75 9d                	jne    80107238 <slabtest+0xf3>
8010729b:	8b 75 d0             	mov    -0x30(%ebp),%esi
8010729e:	c7 45 d0 c0 b5 10 80 	movl   $0x8010b5c0,-0x30(%ebp)
801072a5:	bb 04 00 00 00       	mov    $0x4,%ebx
		}
	}
	// CHECK 
	pass = 1;
801072aa:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
		slabsize = 1 << (i+4); 
		for (int j=0; j < slabsize/sizeof(int); j++)
		{
			if ( *(t[i][0]+j) != start )
			{
				pass = 0;
801072b1:	bf 00 00 00 00       	mov    $0x0,%edi
801072b6:	eb 56                	jmp    8010730e <slabtest+0x1c9>
	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 1) ? "OK\n":"WRONG\n");
801072b8:	83 ec 0c             	sub    $0xc,%esp
801072bb:	6a 07                	push   $0x7
801072bd:	e8 5f fe ff ff       	call   80107121 <numobj_slab>
801072c2:	83 c4 10             	add    $0x10,%esp
801072c5:	83 f8 01             	cmp    $0x1,%eax
801072c8:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
801072cd:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
801072d2:	0f 45 c2             	cmovne %edx,%eax
801072d5:	e9 c4 fe ff ff       	jmp    8010719e <slabtest+0x59>
	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 1) ? "OK\n":"WRONG\n");
801072da:	83 ec 0c             	sub    $0xc,%esp
801072dd:	6a 07                	push   $0x7
801072df:	e8 3d fe ff ff       	call   80107121 <numobj_slab>
801072e4:	83 c4 10             	add    $0x10,%esp
801072e7:	83 f8 01             	cmp    $0x1,%eax
801072ea:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
801072ef:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
801072f4:	0f 45 c2             	cmovne %edx,%eax
801072f7:	e9 fd fe ff ff       	jmp    801071f9 <slabtest+0xb4>
				pass = 0;
801072fc:	89 7d d4             	mov    %edi,-0x2c(%ebp)
801072ff:	83 c3 01             	add    $0x1,%ebx
80107302:	81 45 d0 00 90 01 00 	addl   $0x19000,-0x30(%ebp)
	for (int i=0; i<NSLAB; i++)
80107309:	83 fb 0c             	cmp    $0xc,%ebx
8010730c:	74 32                	je     80107340 <slabtest+0x1fb>
		slabsize = 1 << (i+4); 
8010730e:	ba 01 00 00 00       	mov    $0x1,%edx
80107313:	89 d9                	mov    %ebx,%ecx
80107315:	d3 e2                	shl    %cl,%edx
		for (int j=0; j < slabsize/sizeof(int); j++)
80107317:	c1 ea 02             	shr    $0x2,%edx
8010731a:	85 d2                	test   %edx,%edx
8010731c:	74 e1                	je     801072ff <slabtest+0x1ba>
			if ( *(t[i][0]+j) != start )
8010731e:	8b 45 d0             	mov    -0x30(%ebp),%eax
80107321:	8b 08                	mov    (%eax),%ecx
80107323:	39 31                	cmp    %esi,(%ecx)
80107325:	75 d5                	jne    801072fc <slabtest+0x1b7>
		for (int j=0; j < slabsize/sizeof(int); j++)
80107327:	b8 00 00 00 00       	mov    $0x0,%eax
				break;
			}
			start++;
8010732c:	83 c6 01             	add    $0x1,%esi
		for (int j=0; j < slabsize/sizeof(int); j++)
8010732f:	83 c0 01             	add    $0x1,%eax
80107332:	39 d0                	cmp    %edx,%eax
80107334:	74 c9                	je     801072ff <slabtest+0x1ba>
			if ( *(t[i][0]+j) != start )
80107336:	39 34 81             	cmp    %esi,(%ecx,%eax,4)
80107339:	74 f1                	je     8010732c <slabtest+0x1e7>
				pass = 0;
8010733b:	89 7d d4             	mov    %edi,-0x2c(%ebp)
8010733e:	eb bf                	jmp    801072ff <slabtest+0x1ba>
80107340:	be c0 b5 10 80       	mov    $0x8010b5c0,%esi
80107345:	bb 04 00 00 00       	mov    $0x4,%ebx
		}
	}
	for (int i=0; i<NSLAB; i++)
	{
		slabsize = 1 << (i+4); 
8010734a:	bf 01 00 00 00       	mov    $0x1,%edi
		kmfree((char*) t[i][0], slabsize);
8010734f:	83 ec 08             	sub    $0x8,%esp
		slabsize = 1 << (i+4); 
80107352:	89 f8                	mov    %edi,%eax
80107354:	89 d9                	mov    %ebx,%ecx
80107356:	d3 e0                	shl    %cl,%eax
		kmfree((char*) t[i][0], slabsize);
80107358:	50                   	push   %eax
80107359:	ff 36                	pushl  (%esi)
8010735b:	e8 a4 f9 ff ff       	call   80106d04 <kmfree>
80107360:	83 c3 01             	add    $0x1,%ebx
80107363:	81 c6 00 90 01 00    	add    $0x19000,%esi
	for (int i=0; i<NSLAB; i++)
80107369:	83 c4 10             	add    $0x10,%esp
8010736c:	83 fb 0c             	cmp    $0xc,%ebx
8010736f:	75 de                	jne    8010734f <slabtest+0x20a>
	}
	for (int i=0; i<NSLAB; i++){
80107371:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107376:	83 ec 0c             	sub    $0xc,%esp
80107379:	53                   	push   %ebx
8010737a:	e8 b4 fd ff ff       	call   80107133 <numpage_slab>
8010737f:	83 c4 10             	add    $0x10,%esp
80107382:	83 f8 01             	cmp    $0x1,%eax
80107385:	75 57                	jne    801073de <slabtest+0x299>
80107387:	83 ec 0c             	sub    $0xc,%esp
8010738a:	53                   	push   %ebx
8010738b:	e8 91 fd ff ff       	call   80107121 <numobj_slab>
80107390:	83 c4 10             	add    $0x10,%esp
80107393:	85 c0                	test   %eax,%eax
80107395:	75 4e                	jne    801073e5 <slabtest+0x2a0>
	for (int i=0; i<NSLAB; i++){
80107397:	83 c3 01             	add    $0x1,%ebx
8010739a:	83 fb 08             	cmp    $0x8,%ebx
8010739d:	75 d7                	jne    80107376 <slabtest+0x231>
        		pass = 0;
        		break;
        	}
        }
	cprintf( pass ? "OK\n" : "WRONG\n");	           
8010739f:	83 7d d4 00          	cmpl   $0x0,-0x2c(%ebp)
801073a3:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
801073a8:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
801073ad:	0f 44 c2             	cmove  %edx,%eax
801073b0:	83 ec 0c             	sub    $0xc,%esp
801073b3:	50                   	push   %eax
801073b4:	e8 28 92 ff ff       	call   801005e1 <cprintf>
	
	/* TEST4: Multiple slabs alloc2 */
	cprintf("==== TEST4 =====\n");
801073b9:	c7 04 24 e6 8a 10 80 	movl   $0x80108ae6,(%esp)
801073c0:	e8 1c 92 ff ff       	call   801005e1 <cprintf>
	start = counter;
801073c5:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801073c8:	83 c4 10             	add    $0x10,%esp
801073cb:	c7 45 d0 e0 b8 10 80 	movl   $0x8010b8e0,-0x30(%ebp)
801073d2:	c7 45 c0 04 00 00 00 	movl   $0x4,-0x40(%ebp)
		for (int j=0; j<MAXTEST; j++)
		{
			t[i][j]	= (int*) kmalloc (slabsize); 
			for (int k=0; k<slabsize/sizeof(int); k++)
			{
				memmove (t[i][j]+k, &counter, sizeof(int));
801073d9:	89 7d bc             	mov    %edi,-0x44(%ebp)
801073dc:	eb 73                	jmp    80107451 <slabtest+0x30c>
	cprintf( pass ? "OK\n" : "WRONG\n");	           
801073de:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801073e3:	eb cb                	jmp    801073b0 <slabtest+0x26b>
801073e5:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801073ea:	eb c4                	jmp    801073b0 <slabtest+0x26b>
801073ec:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
801073f0:	8b 45 d4             	mov    -0x2c(%ebp),%eax
		for (int j=0; j<MAXTEST; j++)
801073f3:	3b 45 d0             	cmp    -0x30(%ebp),%eax
801073f6:	74 44                	je     8010743c <slabtest+0x2f7>
			t[i][j]	= (int*) kmalloc (slabsize); 
801073f8:	83 ec 0c             	sub    $0xc,%esp
801073fb:	ff 75 cc             	pushl  -0x34(%ebp)
801073fe:	e8 65 f5 ff ff       	call   80106968 <kmalloc>
80107403:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
80107406:	89 ce                	mov    %ecx,%esi
80107408:	89 01                	mov    %eax,(%ecx)
			for (int k=0; k<slabsize/sizeof(int); k++)
8010740a:	83 c4 10             	add    $0x10,%esp
8010740d:	83 7d c8 00          	cmpl   $0x0,-0x38(%ebp)
80107411:	74 d9                	je     801073ec <slabtest+0x2a7>
80107413:	bb 00 00 00 00       	mov    $0x0,%ebx
				memmove (t[i][j]+k, &counter, sizeof(int));
80107418:	83 ec 04             	sub    $0x4,%esp
8010741b:	6a 04                	push   $0x4
8010741d:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80107420:	50                   	push   %eax
80107421:	8b 06                	mov    (%esi),%eax
80107423:	8d 04 98             	lea    (%eax,%ebx,4),%eax
80107426:	50                   	push   %eax
80107427:	e8 e3 ca ff ff       	call   80103f0f <memmove>
				counter++;
8010742c:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
			for (int k=0; k<slabsize/sizeof(int); k++)
80107430:	83 c3 01             	add    $0x1,%ebx
80107433:	83 c4 10             	add    $0x10,%esp
80107436:	39 fb                	cmp    %edi,%ebx
80107438:	75 de                	jne    80107418 <slabtest+0x2d3>
8010743a:	eb b0                	jmp    801073ec <slabtest+0x2a7>
8010743c:	83 45 c0 01          	addl   $0x1,-0x40(%ebp)
80107440:	81 45 d0 00 90 01 00 	addl   $0x19000,-0x30(%ebp)
80107447:	8b 45 d0             	mov    -0x30(%ebp),%eax
	for (int i=0; i<NSLAB; i++)
8010744a:	3d e0 38 1d 80       	cmp    $0x801d38e0,%eax
8010744f:	74 23                	je     80107474 <slabtest+0x32f>
		slabsize = 1 << (i+4); 
80107451:	b8 01 00 00 00       	mov    $0x1,%eax
80107456:	0f b6 4d c0          	movzbl -0x40(%ebp),%ecx
8010745a:	d3 e0                	shl    %cl,%eax
8010745c:	89 45 cc             	mov    %eax,-0x34(%ebp)
			for (int k=0; k<slabsize/sizeof(int); k++)
8010745f:	c1 e8 02             	shr    $0x2,%eax
80107462:	89 c7                	mov    %eax,%edi
80107464:	89 45 c8             	mov    %eax,-0x38(%ebp)
80107467:	8b 45 d0             	mov    -0x30(%ebp),%eax
8010746a:	2d 20 03 00 00       	sub    $0x320,%eax
8010746f:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80107472:	eb 84                	jmp    801073f8 <slabtest+0x2b3>
80107474:	8b 7d bc             	mov    -0x44(%ebp),%edi
80107477:	c7 45 d4 e0 b8 10 80 	movl   $0x8010b8e0,-0x2c(%ebp)
8010747e:	c7 45 c8 04 00 00 00 	movl   $0x4,-0x38(%ebp)
			}
		}
	}
	// CHECK
	pass = 1;
80107485:	c7 45 cc 01 00 00 00 	movl   $0x1,-0x34(%ebp)
8010748c:	eb 49                	jmp    801074d7 <slabtest+0x392>
			for (int k=0; k<slabsize/sizeof(int); k++)
			{

				if (*(t[i][j]+k) != start)
				{
					pass = 0;
8010748e:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%ebp)
80107495:	83 c3 04             	add    $0x4,%ebx
		for (int j=0; j<MAXTEST; j++)
80107498:	3b 5d d4             	cmp    -0x2c(%ebp),%ebx
8010749b:	74 27                	je     801074c4 <slabtest+0x37f>
			for (int k=0; k<slabsize/sizeof(int); k++)
8010749d:	85 f6                	test   %esi,%esi
8010749f:	74 f4                	je     80107495 <slabtest+0x350>
				if (*(t[i][j]+k) != start)
801074a1:	8b 13                	mov    (%ebx),%edx
801074a3:	39 3a                	cmp    %edi,(%edx)
801074a5:	75 e7                	jne    8010748e <slabtest+0x349>
			for (int k=0; k<slabsize/sizeof(int); k++)
801074a7:	b8 00 00 00 00       	mov    $0x0,%eax
					break;
				}
				start++;
801074ac:	83 c7 01             	add    $0x1,%edi
			for (int k=0; k<slabsize/sizeof(int); k++)
801074af:	83 c0 01             	add    $0x1,%eax
801074b2:	39 c8                	cmp    %ecx,%eax
801074b4:	74 df                	je     80107495 <slabtest+0x350>
				if (*(t[i][j]+k) != start)
801074b6:	39 3c 82             	cmp    %edi,(%edx,%eax,4)
801074b9:	74 f1                	je     801074ac <slabtest+0x367>
					pass = 0;
801074bb:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%ebp)
801074c2:	eb d1                	jmp    80107495 <slabtest+0x350>
801074c4:	83 45 c8 01          	addl   $0x1,-0x38(%ebp)
801074c8:	81 45 d4 00 90 01 00 	addl   $0x19000,-0x2c(%ebp)
801074cf:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for (int i=0; i<NSLAB; i++)
801074d2:	3b 45 d0             	cmp    -0x30(%ebp),%eax
801074d5:	74 1d                	je     801074f4 <slabtest+0x3af>
		slabsize = 1 << (i+4); 
801074d7:	b8 01 00 00 00       	mov    $0x1,%eax
801074dc:	0f b6 4d c8          	movzbl -0x38(%ebp),%ecx
801074e0:	d3 e0                	shl    %cl,%eax
			for (int k=0; k<slabsize/sizeof(int); k++)
801074e2:	c1 e8 02             	shr    $0x2,%eax
801074e5:	89 c6                	mov    %eax,%esi
801074e7:	8b 45 d4             	mov    -0x2c(%ebp),%eax
801074ea:	8d 98 e0 fc ff ff    	lea    -0x320(%eax),%ebx
801074f0:	89 f1                	mov    %esi,%ecx
801074f2:	eb a9                	jmp    8010749d <slabtest+0x358>
801074f4:	c7 45 c8 c0 b5 10 80 	movl   $0x8010b5c0,-0x38(%ebp)
801074fb:	c7 45 d4 04 00 00 00 	movl   $0x4,-0x2c(%ebp)
			}
		}
	}
	for (int i=0; i<NSLAB; i++)
	{
		slabsize = 1 << (i+4); 
80107502:	bf 01 00 00 00       	mov    $0x1,%edi
80107507:	0f b6 4d d4          	movzbl -0x2c(%ebp),%ecx
8010750b:	d3 e7                	shl    %cl,%edi
8010750d:	8b 5d c8             	mov    -0x38(%ebp),%ebx
80107510:	8d b3 20 03 00 00    	lea    0x320(%ebx),%esi
		for (int j=0; j<MAXTEST; j++)
			kmfree((char*) t[i][j], slabsize);
80107516:	83 ec 08             	sub    $0x8,%esp
80107519:	57                   	push   %edi
8010751a:	ff 33                	pushl  (%ebx)
8010751c:	e8 e3 f7 ff ff       	call   80106d04 <kmfree>
80107521:	83 c3 04             	add    $0x4,%ebx
		for (int j=0; j<MAXTEST; j++)
80107524:	83 c4 10             	add    $0x10,%esp
80107527:	39 f3                	cmp    %esi,%ebx
80107529:	75 eb                	jne    80107516 <slabtest+0x3d1>
8010752b:	83 45 d4 01          	addl   $0x1,-0x2c(%ebp)
8010752f:	81 45 c8 00 90 01 00 	addl   $0x19000,-0x38(%ebp)
80107536:	8b 45 c8             	mov    -0x38(%ebp),%eax
	for (int i=0; i<NSLAB; i++)
80107539:	3b 45 c4             	cmp    -0x3c(%ebp),%eax
8010753c:	75 c4                	jne    80107502 <slabtest+0x3bd>
	}
	// DO NOT de-alloc first page. Allocate one page for slab cache.
	for (int i=0; i<NSLAB; i++){
8010753e:	bb 00 00 00 00       	mov    $0x0,%ebx
		if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107543:	83 ec 0c             	sub    $0xc,%esp
80107546:	53                   	push   %ebx
80107547:	e8 e7 fb ff ff       	call   80107133 <numpage_slab>
8010754c:	83 c4 10             	add    $0x10,%esp
8010754f:	83 f8 01             	cmp    $0x1,%eax
80107552:	0f 85 62 01 00 00    	jne    801076ba <slabtest+0x575>
80107558:	83 ec 0c             	sub    $0xc,%esp
8010755b:	53                   	push   %ebx
8010755c:	e8 c0 fb ff ff       	call   80107121 <numobj_slab>
80107561:	83 c4 10             	add    $0x10,%esp
80107564:	85 c0                	test   %eax,%eax
80107566:	0f 85 58 01 00 00    	jne    801076c4 <slabtest+0x57f>
	for (int i=0; i<NSLAB; i++){
8010756c:	83 c3 01             	add    $0x1,%ebx
8010756f:	83 fb 08             	cmp    $0x8,%ebx
80107572:	75 cf                	jne    80107543 <slabtest+0x3fe>
			pass = 0;
			break;
		}
	}
	cprintf( pass ? "OK\n" : "WRONG\n");	
80107574:	83 7d cc 00          	cmpl   $0x0,-0x34(%ebp)
80107578:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
8010757d:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107582:	0f 44 c2             	cmove  %edx,%eax
80107585:	83 ec 0c             	sub    $0xc,%esp
80107588:	50                   	push   %eax
80107589:	e8 53 90 ff ff       	call   801005e1 <cprintf>

	/* TEST5: alloc more than the page limit (100 pages) */
	cprintf("==== TEST5 =====\n");
8010758e:	c7 04 24 f8 8a 10 80 	movl   $0x80108af8,(%esp)
80107595:	e8 47 90 ff ff       	call   801005e1 <cprintf>
8010759a:	83 c4 10             	add    $0x10,%esp
8010759d:	c7 45 d4 c0 b5 10 80 	movl   $0x8010b5c0,-0x2c(%ebp)
	start = counter;
	for (int j=0; j<MAXTEST; j++)
	{
		t[0][j]	= (int*) kmalloc (TESTSIZE);
		for (int k=0; k<TESTSIZE/sizeof(int); k++){
                        memmove (t[0][j]+k, &counter, sizeof(int));
801075a4:	8d 7d e4             	lea    -0x1c(%ebp),%edi
		t[0][j]	= (int*) kmalloc (TESTSIZE);
801075a7:	83 ec 0c             	sub    $0xc,%esp
801075aa:	68 00 08 00 00       	push   $0x800
801075af:	e8 b4 f3 ff ff       	call   80106968 <kmalloc>
801075b4:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
801075b7:	89 ce                	mov    %ecx,%esi
801075b9:	89 01                	mov    %eax,(%ecx)
801075bb:	83 c4 10             	add    $0x10,%esp
801075be:	bb 00 00 00 00       	mov    $0x0,%ebx
                        memmove (t[0][j]+k, &counter, sizeof(int));
801075c3:	83 ec 04             	sub    $0x4,%esp
801075c6:	6a 04                	push   $0x4
801075c8:	57                   	push   %edi
801075c9:	89 d8                	mov    %ebx,%eax
801075cb:	03 06                	add    (%esi),%eax
801075cd:	50                   	push   %eax
801075ce:	e8 3c c9 ff ff       	call   80103f0f <memmove>
                        counter++;
801075d3:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
801075d7:	83 c3 04             	add    $0x4,%ebx
		for (int k=0; k<TESTSIZE/sizeof(int); k++){
801075da:	83 c4 10             	add    $0x10,%esp
801075dd:	81 fb 00 08 00 00    	cmp    $0x800,%ebx
801075e3:	75 de                	jne    801075c3 <slabtest+0x47e>
801075e5:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
801075e9:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for (int j=0; j<MAXTEST; j++)
801075ec:	3d e0 b8 10 80       	cmp    $0x8010b8e0,%eax
801075f1:	75 b4                	jne    801075a7 <slabtest+0x462>
                }
        }
        tmp = (int*) kmalloc (TESTSIZE);
801075f3:	83 ec 0c             	sub    $0xc,%esp
801075f6:	68 00 08 00 00       	push   $0x800
801075fb:	e8 68 f3 ff ff       	call   80106968 <kmalloc>
        cprintf( (!tmp && numobj_slab (TESTSLABID) == MAXTEST) ? "OK\n" : "WRONG\n");
80107600:	83 c4 10             	add    $0x10,%esp
80107603:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107608:	85 c0                	test   %eax,%eax
8010760a:	0f 84 be 00 00 00    	je     801076ce <slabtest+0x589>
80107610:	83 ec 0c             	sub    $0xc,%esp
80107613:	52                   	push   %edx
80107614:	e8 c8 8f ff ff       	call   801005e1 <cprintf>
	/* TEST6: realloc slabs after free */
	cprintf("==== TEST6 =====\n");
80107619:	c7 04 24 0a 8b 10 80 	movl   $0x80108b0a,(%esp)
80107620:	e8 bc 8f ff ff       	call   801005e1 <cprintf>
80107625:	83 c4 10             	add    $0x10,%esp
80107628:	bb c0 b5 10 80       	mov    $0x8010b5c0,%ebx
	for (int j=0; j<MAXTEST; j++)
	{
		kmfree((char*) t[0][j], TESTSIZE);
8010762d:	83 ec 08             	sub    $0x8,%esp
80107630:	68 00 08 00 00       	push   $0x800
80107635:	ff 33                	pushl  (%ebx)
80107637:	e8 c8 f6 ff ff       	call   80106d04 <kmfree>
8010763c:	83 c3 04             	add    $0x4,%ebx
	for (int j=0; j<MAXTEST; j++)
8010763f:	83 c4 10             	add    $0x10,%esp
80107642:	81 fb e0 b8 10 80    	cmp    $0x8010b8e0,%ebx
80107648:	75 e3                	jne    8010762d <slabtest+0x4e8>
	}

	start = counter;
8010764a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
8010764d:	89 45 d0             	mov    %eax,-0x30(%ebp)
80107650:	c7 45 d4 c0 b5 10 80 	movl   $0x8010b5c0,-0x2c(%ebp)
	for (int j=0; j<MAXTEST; j++)
	{
		t[0][j]	= (int*) kmalloc (TESTSIZE); 
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
		{
			memmove (t[0][j]+k, &counter, sizeof(int));
80107657:	8d 7d e4             	lea    -0x1c(%ebp),%edi
		t[0][j]	= (int*) kmalloc (TESTSIZE); 
8010765a:	83 ec 0c             	sub    $0xc,%esp
8010765d:	68 00 08 00 00       	push   $0x800
80107662:	e8 01 f3 ff ff       	call   80106968 <kmalloc>
80107667:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
8010766a:	89 ce                	mov    %ecx,%esi
8010766c:	89 01                	mov    %eax,(%ecx)
8010766e:	83 c4 10             	add    $0x10,%esp
80107671:	bb 00 00 00 00       	mov    $0x0,%ebx
			memmove (t[0][j]+k, &counter, sizeof(int));
80107676:	83 ec 04             	sub    $0x4,%esp
80107679:	6a 04                	push   $0x4
8010767b:	57                   	push   %edi
8010767c:	89 d8                	mov    %ebx,%eax
8010767e:	03 06                	add    (%esi),%eax
80107680:	50                   	push   %eax
80107681:	e8 89 c8 ff ff       	call   80103f0f <memmove>
			counter++;
80107686:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
8010768a:	83 c3 04             	add    $0x4,%ebx
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
8010768d:	83 c4 10             	add    $0x10,%esp
80107690:	81 fb 00 08 00 00    	cmp    $0x800,%ebx
80107696:	75 de                	jne    80107676 <slabtest+0x531>
80107698:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
8010769c:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for (int j=0; j<MAXTEST; j++)
8010769f:	3d e0 b8 10 80       	cmp    $0x8010b8e0,%eax
801076a4:	75 b4                	jne    8010765a <slabtest+0x515>
801076a6:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
		}
	}

	// CHECK 
	pass = 1;
801076ab:	be 01 00 00 00       	mov    $0x1,%esi
		{
			
			//cprintf("%d, %d, %d, %d, %p\n", j, k, *(t[0][j]+k), start, t[0][j]+k);                //YOU MAY USE THIS
			if (*(t[0][j]+k) != start)
			{
				pass = 0;
801076b0:	bb 00 00 00 00       	mov    $0x0,%ebx
801076b5:	8b 55 d0             	mov    -0x30(%ebp),%edx
801076b8:	eb 45                	jmp    801076ff <slabtest+0x5ba>
	cprintf( pass ? "OK\n" : "WRONG\n");	
801076ba:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801076bf:	e9 c1 fe ff ff       	jmp    80107585 <slabtest+0x440>
801076c4:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801076c9:	e9 b7 fe ff ff       	jmp    80107585 <slabtest+0x440>
        cprintf( (!tmp && numobj_slab (TESTSLABID) == MAXTEST) ? "OK\n" : "WRONG\n");
801076ce:	83 ec 0c             	sub    $0xc,%esp
801076d1:	6a 07                	push   $0x7
801076d3:	e8 49 fa ff ff       	call   80107121 <numobj_slab>
801076d8:	83 c4 10             	add    $0x10,%esp
801076db:	3d c8 00 00 00       	cmp    $0xc8,%eax
801076e0:	ba 90 8a 10 80       	mov    $0x80108a90,%edx
801076e5:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801076ea:	0f 45 d0             	cmovne %eax,%edx
801076ed:	e9 1e ff ff ff       	jmp    80107610 <slabtest+0x4cb>
				pass = 0;
801076f2:	89 de                	mov    %ebx,%esi
801076f4:	83 c1 04             	add    $0x4,%ecx
	for (int j=0; j<MAXTEST; j++)
801076f7:	81 f9 e0 b8 10 80    	cmp    $0x8010b8e0,%ecx
801076fd:	74 26                	je     80107725 <slabtest+0x5e0>
			if (*(t[0][j]+k) != start)
801076ff:	8b 39                	mov    (%ecx),%edi
80107701:	39 17                	cmp    %edx,(%edi)
80107703:	75 1c                	jne    80107721 <slabtest+0x5dc>
				break;
			}
			start++;
80107705:	83 c2 01             	add    $0x1,%edx
80107708:	8d 47 04             	lea    0x4(%edi),%eax
8010770b:	81 c7 00 08 00 00    	add    $0x800,%edi
			if (*(t[0][j]+k) != start)
80107711:	39 10                	cmp    %edx,(%eax)
80107713:	75 dd                	jne    801076f2 <slabtest+0x5ad>
			start++;
80107715:	83 c2 01             	add    $0x1,%edx
80107718:	83 c0 04             	add    $0x4,%eax
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
8010771b:	39 f8                	cmp    %edi,%eax
8010771d:	75 f2                	jne    80107711 <slabtest+0x5cc>
8010771f:	eb d3                	jmp    801076f4 <slabtest+0x5af>
				pass = 0;
80107721:	89 de                	mov    %ebx,%esi
80107723:	eb cf                	jmp    801076f4 <slabtest+0x5af>
80107725:	bb c0 b5 10 80       	mov    $0x8010b5c0,%ebx
		}
	}
	//cprintf( pass ? "OK\n" : "WRONG\n");	
	for (int j=0; j<MAXTEST; j++)
		kmfree((char*) t[0][j], TESTSIZE);
8010772a:	83 ec 08             	sub    $0x8,%esp
8010772d:	68 00 08 00 00       	push   $0x800
80107732:	ff 33                	pushl  (%ebx)
80107734:	e8 cb f5 ff ff       	call   80106d04 <kmfree>
80107739:	83 c3 04             	add    $0x4,%ebx
	for (int j=0; j<MAXTEST; j++)
8010773c:	83 c4 10             	add    $0x10,%esp
8010773f:	81 fb e0 b8 10 80    	cmp    $0x8010b8e0,%ebx
80107745:	75 e3                	jne    8010772a <slabtest+0x5e5>

	for (int i=0; i<NSLAB; i++){
80107747:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
8010774c:	83 ec 0c             	sub    $0xc,%esp
8010774f:	53                   	push   %ebx
80107750:	e8 de f9 ff ff       	call   80107133 <numpage_slab>
80107755:	83 c4 10             	add    $0x10,%esp
80107758:	83 f8 01             	cmp    $0x1,%eax
8010775b:	75 5d                	jne    801077ba <slabtest+0x675>
8010775d:	83 ec 0c             	sub    $0xc,%esp
80107760:	53                   	push   %ebx
80107761:	e8 bb f9 ff ff       	call   80107121 <numobj_slab>
80107766:	83 c4 10             	add    $0x10,%esp
80107769:	85 c0                	test   %eax,%eax
8010776b:	75 54                	jne    801077c1 <slabtest+0x67c>
	for (int i=0; i<NSLAB; i++){
8010776d:	83 c3 01             	add    $0x1,%ebx
80107770:	83 fb 08             	cmp    $0x8,%ebx
80107773:	75 d7                	jne    8010774c <slabtest+0x607>
        		pass = 0;
        		break;
        	}
        }
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107775:	85 f6                	test   %esi,%esi
80107777:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
8010777c:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107781:	0f 44 c2             	cmove  %edx,%eax
80107784:	83 ec 0c             	sub    $0xc,%esp
80107787:	50                   	push   %eax
80107788:	e8 54 8e ff ff       	call   801005e1 <cprintf>

	/* TEST7: de-alloc empty slab pages */
	cprintf("==== TEST7 =====\n"); 	
8010778d:	c7 04 24 1c 8b 10 80 	movl   $0x80108b1c,(%esp)
80107794:	e8 48 8e ff ff       	call   801005e1 <cprintf>
80107799:	83 c4 10             	add    $0x10,%esp
8010779c:	c7 45 d4 c0 b5 10 80 	movl   $0x8010b5c0,-0x2c(%ebp)
801077a3:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
    	max_numslab = 0;
    	pass = 1;

	for (int i=0; i<NSLAB; i++)
801077aa:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%ebp)
    	pass = 1;
801077b1:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
801077b8:	eb 33                	jmp    801077ed <slabtest+0x6a8>
        cprintf( pass ? "OK\n" : "WRONG\n");	
801077ba:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801077bf:	eb c3                	jmp    80107784 <slabtest+0x63f>
801077c1:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
801077c6:	eb bc                	jmp    80107784 <slabtest+0x63f>
        	//cprintf("%d, %d\n", page_num_before, page_num_after);                //YOU MAY USE THIS
        	// CHECK 
        	if ( (page_num_before == MAX_PAGES_PER_SLAB) && (page_num_after == MAX_PAGES_PER_SLAB/2) )
        	    continue;
        	else
        	    pass = 0;
801077c8:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
	for (int i=0; i<NSLAB; i++)
801077cf:	83 45 cc 01          	addl   $0x1,-0x34(%ebp)
801077d3:	8b 45 cc             	mov    -0x34(%ebp),%eax
801077d6:	81 45 d4 00 90 01 00 	addl   $0x19000,-0x2c(%ebp)
801077dd:	81 45 d0 00 64 00 00 	addl   $0x6400,-0x30(%ebp)
801077e4:	83 f8 08             	cmp    $0x8,%eax
801077e7:	0f 84 a5 00 00 00    	je     80107892 <slabtest+0x74d>
		slabsize = 1 << (i+4); 
801077ed:	8b 45 cc             	mov    -0x34(%ebp),%eax
801077f0:	8d 48 04             	lea    0x4(%eax),%ecx
801077f3:	be 01 00 00 00       	mov    $0x1,%esi
801077f8:	d3 e6                	shl    %cl,%esi
		max_numslab = PGSIZE / slabsize * MAX_PAGES_PER_SLAB;
801077fa:	b8 00 10 00 00       	mov    $0x1000,%eax
801077ff:	99                   	cltd   
80107800:	f7 fe                	idiv   %esi
80107802:	6b c0 64             	imul   $0x64,%eax,%eax
80107805:	89 45 c0             	mov    %eax,-0x40(%ebp)
		for (int j=0; j<max_numslab; j++)
80107808:	85 c0                	test   %eax,%eax
8010780a:	7e 23                	jle    8010782f <slabtest+0x6ea>
8010780c:	03 45 d0             	add    -0x30(%ebp),%eax
8010780f:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
80107814:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
80107817:	8b 5d d4             	mov    -0x2c(%ebp),%ebx
			t[i][j] = (int*) kmalloc (slabsize);
8010781a:	83 ec 0c             	sub    $0xc,%esp
8010781d:	56                   	push   %esi
8010781e:	e8 45 f1 ff ff       	call   80106968 <kmalloc>
80107823:	89 03                	mov    %eax,(%ebx)
80107825:	83 c3 04             	add    $0x4,%ebx
		for (int j=0; j<max_numslab; j++)
80107828:	83 c4 10             	add    $0x10,%esp
8010782b:	39 fb                	cmp    %edi,%ebx
8010782d:	75 eb                	jne    8010781a <slabtest+0x6d5>
		page_num_before = numpage_slab(i);
8010782f:	83 ec 0c             	sub    $0xc,%esp
80107832:	ff 75 cc             	pushl  -0x34(%ebp)
80107835:	e8 f9 f8 ff ff       	call   80107133 <numpage_slab>
8010783a:	89 45 bc             	mov    %eax,-0x44(%ebp)
		for(int j=0; j<max_numslab/2; j++)
8010783d:	8b 45 c0             	mov    -0x40(%ebp),%eax
80107840:	d1 f8                	sar    %eax
80107842:	83 c4 10             	add    $0x10,%esp
80107845:	85 c0                	test   %eax,%eax
80107847:	7e 23                	jle    8010786c <slabtest+0x727>
80107849:	03 45 d0             	add    -0x30(%ebp),%eax
8010784c:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
80107851:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
80107854:	8b 5d d4             	mov    -0x2c(%ebp),%ebx
			kmfree((char*) t[i][j], slabsize);
80107857:	83 ec 08             	sub    $0x8,%esp
8010785a:	56                   	push   %esi
8010785b:	ff 33                	pushl  (%ebx)
8010785d:	e8 a2 f4 ff ff       	call   80106d04 <kmfree>
80107862:	83 c3 04             	add    $0x4,%ebx
		for(int j=0; j<max_numslab/2; j++)
80107865:	83 c4 10             	add    $0x10,%esp
80107868:	39 fb                	cmp    %edi,%ebx
8010786a:	75 eb                	jne    80107857 <slabtest+0x712>
		page_num_after = numpage_slab(i);
8010786c:	83 ec 0c             	sub    $0xc,%esp
8010786f:	ff 75 cc             	pushl  -0x34(%ebp)
80107872:	e8 bc f8 ff ff       	call   80107133 <numpage_slab>
        	if ( (page_num_before == MAX_PAGES_PER_SLAB) && (page_num_after == MAX_PAGES_PER_SLAB/2) )
80107877:	83 c4 10             	add    $0x10,%esp
8010787a:	83 7d bc 64          	cmpl   $0x64,-0x44(%ebp)
8010787e:	0f 85 44 ff ff ff    	jne    801077c8 <slabtest+0x683>
80107884:	83 f8 32             	cmp    $0x32,%eax
80107887:	0f 85 3b ff ff ff    	jne    801077c8 <slabtest+0x683>
8010788d:	e9 3d ff ff ff       	jmp    801077cf <slabtest+0x68a>
80107892:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
80107899:	c7 45 d0 04 00 00 00 	movl   $0x4,-0x30(%ebp)
	}

	for(int i=0; i<NSLAB; i++)
    	{
		slabsize = 1 << (i+4); 
801078a0:	be 01 00 00 00       	mov    $0x1,%esi
801078a5:	0f b6 4d d0          	movzbl -0x30(%ebp),%ecx
801078a9:	d3 e6                	shl    %cl,%esi
		max_numslab = PGSIZE / slabsize * MAX_PAGES_PER_SLAB;
801078ab:	b8 00 10 00 00       	mov    $0x1000,%eax
801078b0:	99                   	cltd   
801078b1:	f7 fe                	idiv   %esi
801078b3:	6b c0 64             	imul   $0x64,%eax,%eax
		for(int j=max_numslab/2; j<max_numslab; j++)
801078b6:	89 c2                	mov    %eax,%edx
801078b8:	d1 fa                	sar    %edx
801078ba:	39 d0                	cmp    %edx,%eax
801078bc:	7e 2b                	jle    801078e9 <slabtest+0x7a4>
801078be:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
801078c1:	01 ca                	add    %ecx,%edx
801078c3:	8d 1c 95 c0 b5 10 80 	lea    -0x7fef4a40(,%edx,4),%ebx
801078ca:	01 c8                	add    %ecx,%eax
801078cc:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
801078d1:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
        	{
			kmfree((char*) t[i][j], slabsize);
801078d4:	83 ec 08             	sub    $0x8,%esp
801078d7:	56                   	push   %esi
801078d8:	ff 33                	pushl  (%ebx)
801078da:	e8 25 f4 ff ff       	call   80106d04 <kmfree>
801078df:	83 c3 04             	add    $0x4,%ebx
		for(int j=max_numslab/2; j<max_numslab; j++)
801078e2:	83 c4 10             	add    $0x10,%esp
801078e5:	39 df                	cmp    %ebx,%edi
801078e7:	75 eb                	jne    801078d4 <slabtest+0x78f>
801078e9:	83 45 d0 01          	addl   $0x1,-0x30(%ebp)
801078ed:	81 45 d4 00 64 00 00 	addl   $0x6400,-0x2c(%ebp)
801078f4:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for(int i=0; i<NSLAB; i++)
801078f7:	3d 00 20 03 00       	cmp    $0x32000,%eax
801078fc:	75 a2                	jne    801078a0 <slabtest+0x75b>
		}
	} 
	
	// DO NOT de-alloc first page. Allocate one page for slab cache.
	for (int i=0; i<NSLAB; i++){
801078fe:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107903:	83 ec 0c             	sub    $0xc,%esp
80107906:	53                   	push   %ebx
80107907:	e8 27 f8 ff ff       	call   80107133 <numpage_slab>
8010790c:	83 c4 10             	add    $0x10,%esp
8010790f:	83 f8 01             	cmp    $0x1,%eax
80107912:	0f 85 00 01 00 00    	jne    80107a18 <slabtest+0x8d3>
80107918:	83 ec 0c             	sub    $0xc,%esp
8010791b:	53                   	push   %ebx
8010791c:	e8 00 f8 ff ff       	call   80107121 <numobj_slab>
80107921:	83 c4 10             	add    $0x10,%esp
80107924:	85 c0                	test   %eax,%eax
80107926:	0f 85 f6 00 00 00    	jne    80107a22 <slabtest+0x8dd>
	for (int i=0; i<NSLAB; i++){
8010792c:	83 c3 01             	add    $0x1,%ebx
8010792f:	83 fb 08             	cmp    $0x8,%ebx
80107932:	75 cf                	jne    80107903 <slabtest+0x7be>
        		pass = 0;
        		break;
        	}
        }
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107934:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
80107938:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
8010793d:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107942:	0f 44 c2             	cmove  %edx,%eax
80107945:	83 ec 0c             	sub    $0xc,%esp
80107948:	50                   	push   %eax
80107949:	e8 93 8c ff ff       	call   801005e1 <cprintf>

    	/* TEST8: re-alloc empty slab pages */  
	cprintf("==== TEST8 =====\n"); 
8010794e:	c7 04 24 2e 8b 10 80 	movl   $0x80108b2e,(%esp)
80107955:	e8 87 8c ff ff       	call   801005e1 <cprintf>
8010795a:	83 c4 10             	add    $0x10,%esp
8010795d:	bb c0 b5 10 80       	mov    $0x8010b5c0,%ebx
	max_numslab = PGSIZE / TESTSIZE * MAX_PAGES_PER_SLAB;
    	pass = 1;

	for(int j=0; j<max_numslab; j++)
		t[0][j] = (int*) kmalloc (TESTSIZE);
80107962:	83 ec 0c             	sub    $0xc,%esp
80107965:	68 00 08 00 00       	push   $0x800
8010796a:	e8 f9 ef ff ff       	call   80106968 <kmalloc>
8010796f:	89 03                	mov    %eax,(%ebx)
80107971:	83 c3 04             	add    $0x4,%ebx
	for(int j=0; j<max_numslab; j++)
80107974:	83 c4 10             	add    $0x10,%esp
80107977:	81 fb e0 b8 10 80    	cmp    $0x8010b8e0,%ebx
8010797d:	75 e3                	jne    80107962 <slabtest+0x81d>
8010797f:	bb 50 b7 10 80       	mov    $0x8010b750,%ebx
80107984:	be c0 b5 10 80       	mov    $0x8010b5c0,%esi
	
	for(int j=0; j<max_numslab/2; j++)
		kmfree((char*) t[0][j], TESTSIZE);
80107989:	83 ec 08             	sub    $0x8,%esp
8010798c:	68 00 08 00 00       	push   $0x800
80107991:	ff 36                	pushl  (%esi)
80107993:	e8 6c f3 ff ff       	call   80106d04 <kmfree>
80107998:	83 c6 04             	add    $0x4,%esi
	for(int j=0; j<max_numslab/2; j++)
8010799b:	83 c4 10             	add    $0x10,%esp
8010799e:	39 f3                	cmp    %esi,%ebx
801079a0:	75 e7                	jne    80107989 <slabtest+0x844>
801079a2:	89 75 d0             	mov    %esi,-0x30(%ebp)

    	start = counter;
801079a5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
801079a8:	89 45 c4             	mov    %eax,-0x3c(%ebp)
801079ab:	c7 45 d4 c0 b5 10 80 	movl   $0x8010b5c0,-0x2c(%ebp)
	for(int j=0; j<max_numslab/2; j++)
    	{
		t[0][j] = (int*) kmalloc (TESTSIZE);
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
        	{
			memmove (t[0][j]+k, &counter, sizeof(int));
801079b2:	8d 7d e4             	lea    -0x1c(%ebp),%edi
		t[0][j] = (int*) kmalloc (TESTSIZE);
801079b5:	83 ec 0c             	sub    $0xc,%esp
801079b8:	68 00 08 00 00       	push   $0x800
801079bd:	e8 a6 ef ff ff       	call   80106968 <kmalloc>
801079c2:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
801079c5:	89 ce                	mov    %ecx,%esi
801079c7:	89 01                	mov    %eax,(%ecx)
801079c9:	83 c4 10             	add    $0x10,%esp
801079cc:	bb 00 00 00 00       	mov    $0x0,%ebx
			memmove (t[0][j]+k, &counter, sizeof(int));
801079d1:	83 ec 04             	sub    $0x4,%esp
801079d4:	6a 04                	push   $0x4
801079d6:	57                   	push   %edi
801079d7:	89 d8                	mov    %ebx,%eax
801079d9:	03 06                	add    (%esi),%eax
801079db:	50                   	push   %eax
801079dc:	e8 2e c5 ff ff       	call   80103f0f <memmove>
			counter++;
801079e1:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
801079e5:	83 c3 04             	add    $0x4,%ebx
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
801079e8:	83 c4 10             	add    $0x10,%esp
801079eb:	81 fb 00 08 00 00    	cmp    $0x800,%ebx
801079f1:	75 de                	jne    801079d1 <slabtest+0x88c>
801079f3:	83 45 d4 04          	addl   $0x4,-0x2c(%ebp)
801079f7:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for(int j=0; j<max_numslab/2; j++)
801079fa:	39 45 d0             	cmp    %eax,-0x30(%ebp)
801079fd:	75 b6                	jne    801079b5 <slabtest+0x870>
801079ff:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
    	pass = 1;
80107a04:	be 01 00 00 00       	mov    $0x1,%esi
    	{
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
        	{
			if (*(t[0][j]+k) != start)
            		{
				pass = 0;
80107a09:	bb 00 00 00 00       	mov    $0x0,%ebx
80107a0e:	89 75 d0             	mov    %esi,-0x30(%ebp)
80107a11:	8b 55 c4             	mov    -0x3c(%ebp),%edx
80107a14:	89 c6                	mov    %eax,%esi
80107a16:	eb 1e                	jmp    80107a36 <slabtest+0x8f1>
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107a18:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107a1d:	e9 23 ff ff ff       	jmp    80107945 <slabtest+0x800>
80107a22:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107a27:	e9 19 ff ff ff       	jmp    80107945 <slabtest+0x800>
				pass = 0;
80107a2c:	89 5d d0             	mov    %ebx,-0x30(%ebp)
80107a2f:	83 c1 04             	add    $0x4,%ecx
	for (int j=0; j<max_numslab/2; j++)
80107a32:	39 f1                	cmp    %esi,%ecx
80107a34:	74 27                	je     80107a5d <slabtest+0x918>
			if (*(t[0][j]+k) != start)
80107a36:	8b 39                	mov    (%ecx),%edi
80107a38:	39 17                	cmp    %edx,(%edi)
80107a3a:	75 1c                	jne    80107a58 <slabtest+0x913>
				break;
			}
			start++;
80107a3c:	83 c2 01             	add    $0x1,%edx
80107a3f:	8d 47 04             	lea    0x4(%edi),%eax
80107a42:	81 c7 00 08 00 00    	add    $0x800,%edi
			if (*(t[0][j]+k) != start)
80107a48:	39 10                	cmp    %edx,(%eax)
80107a4a:	75 e0                	jne    80107a2c <slabtest+0x8e7>
			start++;
80107a4c:	83 c2 01             	add    $0x1,%edx
80107a4f:	83 c0 04             	add    $0x4,%eax
		for (int k=0; k<TESTSIZE/sizeof(int); k++)
80107a52:	39 f8                	cmp    %edi,%eax
80107a54:	75 f2                	jne    80107a48 <slabtest+0x903>
80107a56:	eb d7                	jmp    80107a2f <slabtest+0x8ea>
				pass = 0;
80107a58:	89 5d d0             	mov    %ebx,-0x30(%ebp)
80107a5b:	eb d2                	jmp    80107a2f <slabtest+0x8ea>
80107a5d:	8b 75 d0             	mov    -0x30(%ebp),%esi
80107a60:	bb c0 b5 10 80       	mov    $0x8010b5c0,%ebx
		}
	}

	for(int j=0;j<max_numslab;j++)
		kmfree((char*) t[0][j], TESTSIZE);
80107a65:	83 ec 08             	sub    $0x8,%esp
80107a68:	68 00 08 00 00       	push   $0x800
80107a6d:	ff 33                	pushl  (%ebx)
80107a6f:	e8 90 f2 ff ff       	call   80106d04 <kmfree>
80107a74:	83 c3 04             	add    $0x4,%ebx
	for(int j=0;j<max_numslab;j++)
80107a77:	83 c4 10             	add    $0x10,%esp
80107a7a:	81 fb e0 b8 10 80    	cmp    $0x8010b8e0,%ebx
80107a80:	75 e3                	jne    80107a65 <slabtest+0x920>

	// DO NOT de-alloc first page. Allocate one page for slab cache.
        for (int i=0; i<NSLAB; i++){
80107a82:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107a87:	83 ec 0c             	sub    $0xc,%esp
80107a8a:	53                   	push   %ebx
80107a8b:	e8 a3 f6 ff ff       	call   80107133 <numpage_slab>
80107a90:	83 c4 10             	add    $0x10,%esp
80107a93:	83 f8 01             	cmp    $0x1,%eax
80107a96:	0f 85 cc 01 00 00    	jne    80107c68 <slabtest+0xb23>
80107a9c:	83 ec 0c             	sub    $0xc,%esp
80107a9f:	53                   	push   %ebx
80107aa0:	e8 7c f6 ff ff       	call   80107121 <numobj_slab>
80107aa5:	83 c4 10             	add    $0x10,%esp
80107aa8:	85 c0                	test   %eax,%eax
80107aaa:	0f 85 c2 01 00 00    	jne    80107c72 <slabtest+0xb2d>
        for (int i=0; i<NSLAB; i++){
80107ab0:	83 c3 01             	add    $0x1,%ebx
80107ab3:	83 fb 08             	cmp    $0x8,%ebx
80107ab6:	75 cf                	jne    80107a87 <slabtest+0x942>
        		pass = 0;
        		break;
        	}
        }
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107ab8:	85 f6                	test   %esi,%esi
80107aba:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
80107abf:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107ac4:	0f 44 c2             	cmove  %edx,%eax
80107ac7:	83 ec 0c             	sub    $0xc,%esp
80107aca:	50                   	push   %eax
80107acb:	e8 11 8b ff ff       	call   801005e1 <cprintf>

	/* TEST9: free some slabs already freed */
	cprintf("==== TEST9  ====\n");  
80107ad0:	c7 04 24 40 8b 10 80 	movl   $0x80108b40,(%esp)
80107ad7:	e8 05 8b ff ff       	call   801005e1 <cprintf>
80107adc:	83 c4 10             	add    $0x10,%esp
80107adf:	bf 00 00 00 00       	mov    $0x0,%edi
	pass =1;

	for(int i=0; i<NSLAB; i++)
80107ae4:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
	pass =1;
80107aeb:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
80107af2:	b8 c0 b5 10 80       	mov    $0x8010b5c0,%eax
80107af7:	83 c0 40             	add    $0x40,%eax
80107afa:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    	{
		int numobjs = 0;
		slabsize = 1 << (i+4); 
80107afd:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80107b00:	8d 48 04             	lea    0x4(%eax),%ecx
80107b03:	be 01 00 00 00       	mov    $0x1,%esi
80107b08:	d3 e6                	shl    %cl,%esi
80107b0a:	8d 9f c0 b5 10 80    	lea    -0x7fef4a40(%edi),%ebx
80107b10:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80107b13:	01 f8                	add    %edi,%eax
80107b15:	89 7d c0             	mov    %edi,-0x40(%ebp)
80107b18:	89 c7                	mov    %eax,%edi

		for (int j=0; j<16; j++)
			t[i][j] = (int*)kmalloc(slabsize);
80107b1a:	83 ec 0c             	sub    $0xc,%esp
80107b1d:	56                   	push   %esi
80107b1e:	e8 45 ee ff ff       	call   80106968 <kmalloc>
80107b23:	89 03                	mov    %eax,(%ebx)
80107b25:	83 c3 04             	add    $0x4,%ebx
		for (int j=0; j<16; j++)
80107b28:	83 c4 10             	add    $0x10,%esp
80107b2b:	39 df                	cmp    %ebx,%edi
80107b2d:	75 eb                	jne    80107b1a <slabtest+0x9d5>
80107b2f:	8b 7d c0             	mov    -0x40(%ebp),%edi
		
		for (int j=8; j<16; j++)
80107b32:	8b 5d cc             	mov    -0x34(%ebp),%ebx
			kmfree((char*) t[i][j], slabsize);
80107b35:	83 ec 08             	sub    $0x8,%esp
80107b38:	56                   	push   %esi
80107b39:	ff b4 9f c0 b5 10 80 	pushl  -0x7fef4a40(%edi,%ebx,4)
80107b40:	e8 bf f1 ff ff       	call   80106d04 <kmfree>
		for (int j=8; j<16; j++)
80107b45:	83 c3 01             	add    $0x1,%ebx
80107b48:	83 c4 10             	add    $0x10,%esp
80107b4b:	83 fb 10             	cmp    $0x10,%ebx
80107b4e:	75 e5                	jne    80107b35 <slabtest+0x9f0>
		
		numobjs = numobj_slab(i);
80107b50:	83 ec 0c             	sub    $0xc,%esp
80107b53:	ff 75 d4             	pushl  -0x2c(%ebp)
80107b56:	e8 c6 f5 ff ff       	call   80107121 <numobj_slab>
80107b5b:	89 c3                	mov    %eax,%ebx

		for (int j=10; j<12; j++)
			kmfree((char*) t[i][j], slabsize);
80107b5d:	83 c4 08             	add    $0x8,%esp
80107b60:	56                   	push   %esi
80107b61:	ff b7 e8 b5 10 80    	pushl  -0x7fef4a18(%edi)
80107b67:	e8 98 f1 ff ff       	call   80106d04 <kmfree>
80107b6c:	83 c4 08             	add    $0x8,%esp
80107b6f:	56                   	push   %esi
80107b70:	ff b7 ec b5 10 80    	pushl  -0x7fef4a14(%edi)
80107b76:	e8 89 f1 ff ff       	call   80106d04 <kmfree>

		if (numobjs != numobj_slab(i))
80107b7b:	8b 75 d4             	mov    -0x2c(%ebp),%esi
80107b7e:	89 34 24             	mov    %esi,(%esp)
80107b81:	e8 9b f5 ff ff       	call   80107121 <numobj_slab>
80107b86:	83 c4 10             	add    $0x10,%esp
            		pass = 0;
80107b89:	39 d8                	cmp    %ebx,%eax
80107b8b:	b8 00 00 00 00       	mov    $0x0,%eax
80107b90:	0f 44 45 d0          	cmove  -0x30(%ebp),%eax
80107b94:	89 45 d0             	mov    %eax,-0x30(%ebp)
	for(int i=0; i<NSLAB; i++)
80107b97:	83 c6 01             	add    $0x1,%esi
80107b9a:	89 75 d4             	mov    %esi,-0x2c(%ebp)
80107b9d:	81 c7 00 90 01 00    	add    $0x19000,%edi
80107ba3:	83 fe 08             	cmp    $0x8,%esi
80107ba6:	0f 85 51 ff ff ff    	jne    80107afd <slabtest+0x9b8>
80107bac:	c7 45 d4 c0 b5 10 80 	movl   $0x8010b5c0,-0x2c(%ebp)
80107bb3:	c7 45 cc 04 00 00 00 	movl   $0x4,-0x34(%ebp)
	}
	for(int i=0; i<NSLAB; i++){
		slabsize = 1 << (i + 4);
80107bba:	bf 01 00 00 00       	mov    $0x1,%edi
80107bbf:	0f b6 4d cc          	movzbl -0x34(%ebp),%ecx
80107bc3:	d3 e7                	shl    %cl,%edi
80107bc5:	8b 5d d4             	mov    -0x2c(%ebp),%ebx
80107bc8:	8d 73 40             	lea    0x40(%ebx),%esi
		for(int j=0; j<16; j++) 
			kmfree((char*) t[i][j], slabsize);
80107bcb:	83 ec 08             	sub    $0x8,%esp
80107bce:	57                   	push   %edi
80107bcf:	ff 33                	pushl  (%ebx)
80107bd1:	e8 2e f1 ff ff       	call   80106d04 <kmfree>
80107bd6:	83 c3 04             	add    $0x4,%ebx
		for(int j=0; j<16; j++) 
80107bd9:	83 c4 10             	add    $0x10,%esp
80107bdc:	39 f3                	cmp    %esi,%ebx
80107bde:	75 eb                	jne    80107bcb <slabtest+0xa86>
80107be0:	83 45 cc 01          	addl   $0x1,-0x34(%ebp)
80107be4:	81 45 d4 00 90 01 00 	addl   $0x19000,-0x2c(%ebp)
80107beb:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for(int i=0; i<NSLAB; i++){
80107bee:	3b 45 c8             	cmp    -0x38(%ebp),%eax
80107bf1:	75 c7                	jne    80107bba <slabtest+0xa75>
	}
	// DO NOT de-alloc first page. Allocate one page for slab cache.
        for (int i=0; i<NSLAB; i++){
80107bf3:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107bf8:	83 ec 0c             	sub    $0xc,%esp
80107bfb:	53                   	push   %ebx
80107bfc:	e8 32 f5 ff ff       	call   80107133 <numpage_slab>
80107c01:	83 c4 10             	add    $0x10,%esp
80107c04:	83 f8 01             	cmp    $0x1,%eax
80107c07:	75 73                	jne    80107c7c <slabtest+0xb37>
80107c09:	83 ec 0c             	sub    $0xc,%esp
80107c0c:	53                   	push   %ebx
80107c0d:	e8 0f f5 ff ff       	call   80107121 <numobj_slab>
80107c12:	83 c4 10             	add    $0x10,%esp
80107c15:	85 c0                	test   %eax,%eax
80107c17:	75 6a                	jne    80107c83 <slabtest+0xb3e>
        for (int i=0; i<NSLAB; i++){
80107c19:	83 c3 01             	add    $0x1,%ebx
80107c1c:	83 fb 08             	cmp    $0x8,%ebx
80107c1f:	75 d7                	jne    80107bf8 <slabtest+0xab3>
        		pass = 0;
        		break;
		}
        }
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107c21:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
80107c25:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
80107c2a:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107c2f:	0f 44 c2             	cmove  %edx,%eax
80107c32:	83 ec 0c             	sub    $0xc,%esp
80107c35:	50                   	push   %eax
80107c36:	e8 a6 89 ff ff       	call   801005e1 <cprintf>


	/* TEST10: de-alloc empty slab pages */
	cprintf("===== TEST10 =====\n"); 	
80107c3b:	c7 04 24 52 8b 10 80 	movl   $0x80108b52,(%esp)
80107c42:	e8 9a 89 ff ff       	call   801005e1 <cprintf>
80107c47:	83 c4 10             	add    $0x10,%esp
80107c4a:	c7 45 c4 c0 b5 10 80 	movl   $0x8010b5c0,-0x3c(%ebp)
80107c51:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%ebp)
    	max_numslab = 0;
    	pass = 1;

	for (int i=0; i<NSLAB; i++)
80107c58:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
    	pass = 1;
80107c5f:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
80107c66:	eb 47                	jmp    80107caf <slabtest+0xb6a>
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107c68:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107c6d:	e9 55 fe ff ff       	jmp    80107ac7 <slabtest+0x982>
80107c72:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107c77:	e9 4b fe ff ff       	jmp    80107ac7 <slabtest+0x982>
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107c7c:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107c81:	eb af                	jmp    80107c32 <slabtest+0xaed>
80107c83:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107c88:	eb a8                	jmp    80107c32 <slabtest+0xaed>
        	// CHECK 
        	if ( (page_num_before == MAX_PAGES_PER_SLAB)
			       	&& (page_num_after == MAX_PAGES_PER_SLAB/2) )
        	    continue;
        	else
        	    pass = 0;
80107c8a:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
	for (int i=0; i<NSLAB; i++)
80107c91:	83 45 d4 01          	addl   $0x1,-0x2c(%ebp)
80107c95:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80107c98:	81 45 c4 00 90 01 00 	addl   $0x19000,-0x3c(%ebp)
80107c9f:	81 45 cc 00 64 00 00 	addl   $0x6400,-0x34(%ebp)
80107ca6:	83 f8 08             	cmp    $0x8,%eax
80107ca9:	0f 84 ec 00 00 00    	je     80107d9b <slabtest+0xc56>
		slabsize = 1 << (i+4); 
80107caf:	8b 45 d4             	mov    -0x2c(%ebp),%eax
80107cb2:	8d 48 04             	lea    0x4(%eax),%ecx
80107cb5:	be 01 00 00 00       	mov    $0x1,%esi
80107cba:	d3 e6                	shl    %cl,%esi
		max_numslab = PGSIZE / slabsize * MAX_PAGES_PER_SLAB;
80107cbc:	b8 00 10 00 00       	mov    $0x1000,%eax
80107cc1:	99                   	cltd   
80107cc2:	f7 fe                	idiv   %esi
80107cc4:	6b f8 64             	imul   $0x64,%eax,%edi
		for (int j=0; j<max_numslab; j++)
80107cc7:	85 ff                	test   %edi,%edi
80107cc9:	7e 29                	jle    80107cf4 <slabtest+0xbaf>
80107ccb:	8b 45 cc             	mov    -0x34(%ebp),%eax
80107cce:	01 f8                	add    %edi,%eax
80107cd0:	ba c0 b5 10 80       	mov    $0x8010b5c0,%edx
80107cd5:	8d 04 82             	lea    (%edx,%eax,4),%eax
80107cd8:	89 45 c8             	mov    %eax,-0x38(%ebp)
80107cdb:	8b 5d c4             	mov    -0x3c(%ebp),%ebx
			t[i][j] = (int*) kmalloc (slabsize);
80107cde:	83 ec 0c             	sub    $0xc,%esp
80107ce1:	56                   	push   %esi
80107ce2:	e8 81 ec ff ff       	call   80106968 <kmalloc>
80107ce7:	89 03                	mov    %eax,(%ebx)
80107ce9:	83 c3 04             	add    $0x4,%ebx
		for (int j=0; j<max_numslab; j++)
80107cec:	83 c4 10             	add    $0x10,%esp
80107cef:	3b 5d c8             	cmp    -0x38(%ebp),%ebx
80107cf2:	75 ea                	jne    80107cde <slabtest+0xb99>
		page_num_before = numpage_slab(i);
80107cf4:	83 ec 0c             	sub    $0xc,%esp
80107cf7:	ff 75 d4             	pushl  -0x2c(%ebp)
80107cfa:	e8 34 f4 ff ff       	call   80107133 <numpage_slab>
80107cff:	89 45 c0             	mov    %eax,-0x40(%ebp)
		for(int j=0; j<max_numslab/4; j++)
80107d02:	8d 47 03             	lea    0x3(%edi),%eax
80107d05:	83 c4 10             	add    $0x10,%esp
80107d08:	85 ff                	test   %edi,%edi
80107d0a:	0f 49 c7             	cmovns %edi,%eax
80107d0d:	c1 f8 02             	sar    $0x2,%eax
80107d10:	89 45 bc             	mov    %eax,-0x44(%ebp)
80107d13:	85 c0                	test   %eax,%eax
80107d15:	7e 27                	jle    80107d3e <slabtest+0xbf9>
80107d17:	03 45 cc             	add    -0x34(%ebp),%eax
80107d1a:	ba c0 b5 10 80       	mov    $0x8010b5c0,%edx
80107d1f:	8d 04 82             	lea    (%edx,%eax,4),%eax
80107d22:	89 45 c8             	mov    %eax,-0x38(%ebp)
80107d25:	8b 5d c4             	mov    -0x3c(%ebp),%ebx
			kmfree((char*) t[i][j], slabsize);
80107d28:	83 ec 08             	sub    $0x8,%esp
80107d2b:	56                   	push   %esi
80107d2c:	ff 33                	pushl  (%ebx)
80107d2e:	e8 d1 ef ff ff       	call   80106d04 <kmfree>
80107d33:	83 c3 04             	add    $0x4,%ebx
		for(int j=0; j<max_numslab/4; j++)
80107d36:	83 c4 10             	add    $0x10,%esp
80107d39:	3b 5d c8             	cmp    -0x38(%ebp),%ebx
80107d3c:	75 ea                	jne    80107d28 <slabtest+0xbe3>
		for(int j=max_numslab/2 ; j<max_numslab/4*3 ; j++)
80107d3e:	d1 ff                	sar    %edi
80107d40:	8b 45 bc             	mov    -0x44(%ebp),%eax
80107d43:	8d 04 40             	lea    (%eax,%eax,2),%eax
80107d46:	39 c7                	cmp    %eax,%edi
80107d48:	7d 2b                	jge    80107d75 <slabtest+0xc30>
80107d4a:	8b 55 cc             	mov    -0x34(%ebp),%edx
80107d4d:	01 d7                	add    %edx,%edi
80107d4f:	8d 1c bd c0 b5 10 80 	lea    -0x7fef4a40(,%edi,4),%ebx
80107d56:	01 d0                	add    %edx,%eax
80107d58:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
80107d5d:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
			kmfree((char*)t[i][j], slabsize);
80107d60:	83 ec 08             	sub    $0x8,%esp
80107d63:	56                   	push   %esi
80107d64:	ff 33                	pushl  (%ebx)
80107d66:	e8 99 ef ff ff       	call   80106d04 <kmfree>
80107d6b:	83 c3 04             	add    $0x4,%ebx
		for(int j=max_numslab/2 ; j<max_numslab/4*3 ; j++)
80107d6e:	83 c4 10             	add    $0x10,%esp
80107d71:	39 fb                	cmp    %edi,%ebx
80107d73:	75 eb                	jne    80107d60 <slabtest+0xc1b>
		page_num_after = numpage_slab(i);
80107d75:	83 ec 0c             	sub    $0xc,%esp
80107d78:	ff 75 d4             	pushl  -0x2c(%ebp)
80107d7b:	e8 b3 f3 ff ff       	call   80107133 <numpage_slab>
        	if ( (page_num_before == MAX_PAGES_PER_SLAB)
80107d80:	83 c4 10             	add    $0x10,%esp
80107d83:	83 7d c0 64          	cmpl   $0x64,-0x40(%ebp)
80107d87:	0f 85 fd fe ff ff    	jne    80107c8a <slabtest+0xb45>
80107d8d:	83 f8 32             	cmp    $0x32,%eax
80107d90:	0f 85 f4 fe ff ff    	jne    80107c8a <slabtest+0xb45>
80107d96:	e9 f6 fe ff ff       	jmp    80107c91 <slabtest+0xb4c>
	}
	slabdump();
80107d9b:	e8 2e f3 ff ff       	call   801070ce <slabdump>
80107da0:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
80107da7:	c7 45 c8 04 00 00 00 	movl   $0x4,-0x38(%ebp)

	for(int i=0; i<NSLAB; i++)
    	{
		slabsize = 1 << (i+4); 
80107dae:	bf 01 00 00 00       	mov    $0x1,%edi
80107db3:	0f b6 4d c8          	movzbl -0x38(%ebp),%ecx
80107db7:	d3 e7                	shl    %cl,%edi
		max_numslab = PGSIZE / slabsize * MAX_PAGES_PER_SLAB;
80107db9:	b8 00 10 00 00       	mov    $0x1000,%eax
80107dbe:	99                   	cltd   
80107dbf:	f7 ff                	idiv   %edi
80107dc1:	6b f0 64             	imul   $0x64,%eax,%esi
		for(int j=max_numslab/4; j<max_numslab/2; j++)
80107dc4:	8d 46 03             	lea    0x3(%esi),%eax
80107dc7:	85 f6                	test   %esi,%esi
80107dc9:	0f 49 c6             	cmovns %esi,%eax
80107dcc:	c1 f8 02             	sar    $0x2,%eax
80107dcf:	89 c2                	mov    %eax,%edx
80107dd1:	89 45 c4             	mov    %eax,-0x3c(%ebp)
80107dd4:	89 f0                	mov    %esi,%eax
80107dd6:	d1 f8                	sar    %eax
80107dd8:	39 c2                	cmp    %eax,%edx
80107dda:	7d 2f                	jge    80107e0b <slabtest+0xcc6>
80107ddc:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
80107ddf:	01 ca                	add    %ecx,%edx
80107de1:	8d 1c 95 c0 b5 10 80 	lea    -0x7fef4a40(,%edx,4),%ebx
80107de8:	01 c8                	add    %ecx,%eax
80107dea:	b9 c0 b5 10 80       	mov    $0x8010b5c0,%ecx
80107def:	8d 04 81             	lea    (%ecx,%eax,4),%eax
80107df2:	89 45 cc             	mov    %eax,-0x34(%ebp)
        	{
			kmfree((char*) t[i][j], slabsize);
80107df5:	83 ec 08             	sub    $0x8,%esp
80107df8:	57                   	push   %edi
80107df9:	ff 33                	pushl  (%ebx)
80107dfb:	e8 04 ef ff ff       	call   80106d04 <kmfree>
80107e00:	83 c3 04             	add    $0x4,%ebx
		for(int j=max_numslab/4; j<max_numslab/2; j++)
80107e03:	83 c4 10             	add    $0x10,%esp
80107e06:	39 5d cc             	cmp    %ebx,-0x34(%ebp)
80107e09:	75 ea                	jne    80107df5 <slabtest+0xcb0>
		}
		for(int j=max_numslab/4*3 ; j<max_numslab ; j++)
80107e0b:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80107e0e:	8d 04 40             	lea    (%eax,%eax,2),%eax
80107e11:	39 c6                	cmp    %eax,%esi
80107e13:	7e 2b                	jle    80107e40 <slabtest+0xcfb>
80107e15:	8b 55 d4             	mov    -0x2c(%ebp),%edx
80107e18:	01 d0                	add    %edx,%eax
80107e1a:	8d 1c 85 c0 b5 10 80 	lea    -0x7fef4a40(,%eax,4),%ebx
80107e21:	01 d6                	add    %edx,%esi
80107e23:	b8 c0 b5 10 80       	mov    $0x8010b5c0,%eax
80107e28:	8d 34 b0             	lea    (%eax,%esi,4),%esi
			kmfree((char *)t[i][j], slabsize);
80107e2b:	83 ec 08             	sub    $0x8,%esp
80107e2e:	57                   	push   %edi
80107e2f:	ff 33                	pushl  (%ebx)
80107e31:	e8 ce ee ff ff       	call   80106d04 <kmfree>
80107e36:	83 c3 04             	add    $0x4,%ebx
		for(int j=max_numslab/4*3 ; j<max_numslab ; j++)
80107e39:	83 c4 10             	add    $0x10,%esp
80107e3c:	39 de                	cmp    %ebx,%esi
80107e3e:	75 eb                	jne    80107e2b <slabtest+0xce6>
80107e40:	83 45 c8 01          	addl   $0x1,-0x38(%ebp)
80107e44:	81 45 d4 00 64 00 00 	addl   $0x6400,-0x2c(%ebp)
80107e4b:	8b 45 d4             	mov    -0x2c(%ebp),%eax
	for(int i=0; i<NSLAB; i++)
80107e4e:	3d 00 20 03 00       	cmp    $0x32000,%eax
80107e53:	0f 85 55 ff ff ff    	jne    80107dae <slabtest+0xc69>
	} 
	
	// DO NOT de-alloc first page. Allocate one page for slab cache.
	for (int i=0; i<NSLAB; i++){
80107e59:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
        		pass = 0;
80107e5e:	be 00 00 00 00       	mov    $0x0,%esi
80107e63:	8b 7d d0             	mov    -0x30(%ebp),%edi
80107e66:	eb 19                	jmp    80107e81 <slabtest+0xd3c>
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107e68:	83 ec 0c             	sub    $0xc,%esp
80107e6b:	53                   	push   %ebx
80107e6c:	e8 b0 f2 ff ff       	call   80107121 <numobj_slab>
80107e71:	83 c4 10             	add    $0x10,%esp
        		pass = 0;
80107e74:	85 c0                	test   %eax,%eax
80107e76:	0f 45 fe             	cmovne %esi,%edi
	for (int i=0; i<NSLAB; i++){
80107e79:	83 c3 01             	add    $0x1,%ebx
80107e7c:	83 fb 08             	cmp    $0x8,%ebx
80107e7f:	74 18                	je     80107e99 <slabtest+0xd54>
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107e81:	83 ec 0c             	sub    $0xc,%esp
80107e84:	53                   	push   %ebx
80107e85:	e8 a9 f2 ff ff       	call   80107133 <numpage_slab>
80107e8a:	83 c4 10             	add    $0x10,%esp
80107e8d:	83 f8 01             	cmp    $0x1,%eax
80107e90:	74 d6                	je     80107e68 <slabtest+0xd23>
        		pass = 0;
80107e92:	bf 00 00 00 00       	mov    $0x0,%edi
80107e97:	eb e0                	jmp    80107e79 <slabtest+0xd34>
80107e99:	89 7d d0             	mov    %edi,-0x30(%ebp)
               }
	}
	slabdump();
80107e9c:	e8 2d f2 ff ff       	call   801070ce <slabdump>
        cprintf( pass ? "OK\n" : "WRONG\n");	
80107ea1:	85 ff                	test   %edi,%edi
80107ea3:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
80107ea8:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107ead:	0f 44 c2             	cmove  %edx,%eax
80107eb0:	83 ec 0c             	sub    $0xc,%esp
80107eb3:	50                   	push   %eax
80107eb4:	e8 28 87 ff ff       	call   801005e1 <cprintf>


	//new_test
	cprintf("===== TEST11 =====\n");
80107eb9:	c7 04 24 66 8b 10 80 	movl   $0x80108b66,(%esp)
80107ec0:	e8 1c 87 ff ff       	call   801005e1 <cprintf>
	start = counter;
80107ec5:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
	t[0][0] = (int*) kmalloc (8000); 
80107ec8:	c7 04 24 40 1f 00 00 	movl   $0x1f40,(%esp)
80107ecf:	e8 94 ea ff ff       	call   80106968 <kmalloc>
80107ed4:	a3 c0 b5 10 80       	mov    %eax,0x8010b5c0
	*(t[0][0]) = counter;
80107ed9:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107edc:	89 10                	mov    %edx,(%eax)
	t[0][1] = (int *)kmalloc(2020);
80107ede:	c7 04 24 e4 07 00 00 	movl   $0x7e4,(%esp)
80107ee5:	e8 7e ea ff ff       	call   80106968 <kmalloc>
80107eea:	a3 c4 b5 10 80       	mov    %eax,0x8010b5c4
	*(t[0][1]) = counter;
80107eef:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107ef2:	89 10                	mov    %edx,(%eax)
	counter++;
80107ef4:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
	slabdump();	
80107ef8:	e8 d1 f1 ff ff       	call   801070ce <slabdump>
	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 3) ? "OK\n":"WRONG\n");
80107efd:	83 c4 10             	add    $0x10,%esp
80107f00:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107f05:	8b 15 c0 b5 10 80    	mov    0x8010b5c0,%edx
80107f0b:	39 1a                	cmp    %ebx,(%edx)
80107f0d:	0f 84 93 00 00 00    	je     80107fa6 <slabtest+0xe61>
80107f13:	83 ec 0c             	sub    $0xc,%esp
80107f16:	50                   	push   %eax
80107f17:	e8 c5 86 ff ff       	call   801005e1 <cprintf>
	kmfree((char *)t[0][0], 8000);
80107f1c:	83 c4 08             	add    $0x8,%esp
80107f1f:	68 40 1f 00 00       	push   $0x1f40
80107f24:	ff 35 c0 b5 10 80    	pushl  0x8010b5c0
80107f2a:	e8 d5 ed ff ff       	call   80106d04 <kmfree>
	kmfree((char *)t[0][1], 2020);
80107f2f:	83 c4 08             	add    $0x8,%esp
80107f32:	68 e4 07 00 00       	push   $0x7e4
80107f37:	ff 35 c4 b5 10 80    	pushl  0x8010b5c4
80107f3d:	e8 c2 ed ff ff       	call   80106d04 <kmfree>
80107f42:	83 c4 10             	add    $0x10,%esp
	for (int i=0; i<NSLAB; i++){
80107f45:	bb 00 00 00 00       	mov    $0x0,%ebx
        	if (numpage_slab(i) !=1 || numobj_slab(i) !=0){
80107f4a:	83 ec 0c             	sub    $0xc,%esp
80107f4d:	53                   	push   %ebx
80107f4e:	e8 e0 f1 ff ff       	call   80107133 <numpage_slab>
80107f53:	83 c4 10             	add    $0x10,%esp
80107f56:	83 f8 01             	cmp    $0x1,%eax
80107f59:	75 6d                	jne    80107fc8 <slabtest+0xe83>
80107f5b:	83 ec 0c             	sub    $0xc,%esp
80107f5e:	53                   	push   %ebx
80107f5f:	e8 bd f1 ff ff       	call   80107121 <numobj_slab>
80107f64:	83 c4 10             	add    $0x10,%esp
80107f67:	85 c0                	test   %eax,%eax
80107f69:	75 5d                	jne    80107fc8 <slabtest+0xe83>
	for (int i=0; i<NSLAB; i++){
80107f6b:	83 c3 01             	add    $0x1,%ebx
80107f6e:	83 fb 08             	cmp    $0x8,%ebx
80107f71:	75 d7                	jne    80107f4a <slabtest+0xe05>
        		pass = 0;
        		break;
        	}
        }
	slabdump();
80107f73:	e8 56 f1 ff ff       	call   801070ce <slabdump>
	cprintf( pass ? "OK\n" : "WRONG\n");	           
80107f78:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
80107f7c:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
80107f81:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107f86:	0f 44 c2             	cmove  %edx,%eax
80107f89:	83 ec 0c             	sub    $0xc,%esp
80107f8c:	50                   	push   %eax
80107f8d:	e8 4f 86 ff ff       	call   801005e1 <cprintf>
	
	cprintf("===== TEST END =====\n");
80107f92:	c7 04 24 7a 8b 10 80 	movl   $0x80108b7a,(%esp)
80107f99:	e8 43 86 ff ff       	call   801005e1 <cprintf>
}
80107f9e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107fa1:	5b                   	pop    %ebx
80107fa2:	5e                   	pop    %esi
80107fa3:	5f                   	pop    %edi
80107fa4:	5d                   	pop    %ebp
80107fa5:	c3                   	ret    
	cprintf( (*(t[0][0]) == start && numobj_slab(TESTSLABID) == 3) ? "OK\n":"WRONG\n");
80107fa6:	83 ec 0c             	sub    $0xc,%esp
80107fa9:	6a 07                	push   $0x7
80107fab:	e8 71 f1 ff ff       	call   80107121 <numobj_slab>
80107fb0:	83 c4 10             	add    $0x10,%esp
80107fb3:	83 f8 03             	cmp    $0x3,%eax
80107fb6:	b8 90 8a 10 80       	mov    $0x80108a90,%eax
80107fbb:	ba 94 8a 10 80       	mov    $0x80108a94,%edx
80107fc0:	0f 45 c2             	cmovne %edx,%eax
80107fc3:	e9 4b ff ff ff       	jmp    80107f13 <slabtest+0xdce>
	slabdump();
80107fc8:	e8 01 f1 ff ff       	call   801070ce <slabdump>
	cprintf( pass ? "OK\n" : "WRONG\n");	           
80107fcd:	b8 94 8a 10 80       	mov    $0x80108a94,%eax
80107fd2:	eb b5                	jmp    80107f89 <slabtest+0xe44>

80107fd4 <sys_slabtest>:
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

int sys_slabtest(){
80107fd4:	55                   	push   %ebp
80107fd5:	89 e5                	mov    %esp,%ebp
80107fd7:	83 ec 08             	sub    $0x8,%esp
	slabtest();
80107fda:	e8 66 f1 ff ff       	call   80107145 <slabtest>
	return 0;
}
80107fdf:	b8 00 00 00 00       	mov    $0x0,%eax
80107fe4:	c9                   	leave  
80107fe5:	c3                   	ret    
