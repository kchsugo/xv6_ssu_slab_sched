
user/_echo:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
  14:	8b 01                	mov    (%ecx),%eax
  16:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  19:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  for(i = 1; i < argc; i++)
  1c:	83 f8 01             	cmp    $0x1,%eax
  1f:	7e 41                	jle    62 <main+0x62>
  21:	8d 5f 04             	lea    0x4(%edi),%ebx
  24:	8d 74 87 fc          	lea    -0x4(%edi,%eax,4),%esi
    printf(1, "%s%s", argv[i], i+1 < argc ? " " : "\n");
  28:	39 f3                	cmp    %esi,%ebx
  2a:	74 1b                	je     47 <main+0x47>
  2c:	68 78 06 00 00       	push   $0x678
  31:	ff 33                	pushl  (%ebx)
  33:	68 7a 06 00 00       	push   $0x67a
  38:	6a 01                	push   $0x1
  3a:	e8 22 03 00 00       	call   361 <printf>
  3f:	83 c3 04             	add    $0x4,%ebx
  42:	83 c4 10             	add    $0x10,%esp
  45:	eb e1                	jmp    28 <main+0x28>
  47:	68 7f 06 00 00       	push   $0x67f
  4c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  4f:	ff 74 87 fc          	pushl  -0x4(%edi,%eax,4)
  53:	68 7a 06 00 00       	push   $0x67a
  58:	6a 01                	push   $0x1
  5a:	e8 02 03 00 00       	call   361 <printf>
  5f:	83 c4 10             	add    $0x10,%esp
  exit();
  62:	e8 c0 01 00 00       	call   227 <exit>

00000067 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  67:	55                   	push   %ebp
  68:	89 e5                	mov    %esp,%ebp
  6a:	53                   	push   %ebx
  6b:	8b 45 08             	mov    0x8(%ebp),%eax
  6e:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  71:	89 c2                	mov    %eax,%edx
  73:	83 c1 01             	add    $0x1,%ecx
  76:	83 c2 01             	add    $0x1,%edx
  79:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
  7d:	88 5a ff             	mov    %bl,-0x1(%edx)
  80:	84 db                	test   %bl,%bl
  82:	75 ef                	jne    73 <strcpy+0xc>
    ;
  return os;
}
  84:	5b                   	pop    %ebx
  85:	5d                   	pop    %ebp
  86:	c3                   	ret    

00000087 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  87:	55                   	push   %ebp
  88:	89 e5                	mov    %esp,%ebp
  8a:	8b 4d 08             	mov    0x8(%ebp),%ecx
  8d:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
  90:	0f b6 01             	movzbl (%ecx),%eax
  93:	84 c0                	test   %al,%al
  95:	74 15                	je     ac <strcmp+0x25>
  97:	3a 02                	cmp    (%edx),%al
  99:	75 11                	jne    ac <strcmp+0x25>
    p++, q++;
  9b:	83 c1 01             	add    $0x1,%ecx
  9e:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
  a1:	0f b6 01             	movzbl (%ecx),%eax
  a4:	84 c0                	test   %al,%al
  a6:	74 04                	je     ac <strcmp+0x25>
  a8:	3a 02                	cmp    (%edx),%al
  aa:	74 ef                	je     9b <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
  ac:	0f b6 c0             	movzbl %al,%eax
  af:	0f b6 12             	movzbl (%edx),%edx
  b2:	29 d0                	sub    %edx,%eax
}
  b4:	5d                   	pop    %ebp
  b5:	c3                   	ret    

000000b6 <strlen>:

uint
strlen(const char *s)
{
  b6:	55                   	push   %ebp
  b7:	89 e5                	mov    %esp,%ebp
  b9:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
  bc:	80 39 00             	cmpb   $0x0,(%ecx)
  bf:	74 12                	je     d3 <strlen+0x1d>
  c1:	ba 00 00 00 00       	mov    $0x0,%edx
  c6:	83 c2 01             	add    $0x1,%edx
  c9:	89 d0                	mov    %edx,%eax
  cb:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
  cf:	75 f5                	jne    c6 <strlen+0x10>
    ;
  return n;
}
  d1:	5d                   	pop    %ebp
  d2:	c3                   	ret    
  for(n = 0; s[n]; n++)
  d3:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
  d8:	eb f7                	jmp    d1 <strlen+0x1b>

000000da <memset>:

void*
memset(void *dst, int c, uint n)
{
  da:	55                   	push   %ebp
  db:	89 e5                	mov    %esp,%ebp
  dd:	57                   	push   %edi
  de:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
  e1:	89 d7                	mov    %edx,%edi
  e3:	8b 4d 10             	mov    0x10(%ebp),%ecx
  e6:	8b 45 0c             	mov    0xc(%ebp),%eax
  e9:	fc                   	cld    
  ea:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
  ec:	89 d0                	mov    %edx,%eax
  ee:	5f                   	pop    %edi
  ef:	5d                   	pop    %ebp
  f0:	c3                   	ret    

000000f1 <strchr>:

char*
strchr(const char *s, char c)
{
  f1:	55                   	push   %ebp
  f2:	89 e5                	mov    %esp,%ebp
  f4:	53                   	push   %ebx
  f5:	8b 45 08             	mov    0x8(%ebp),%eax
  f8:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
  fb:	0f b6 10             	movzbl (%eax),%edx
  fe:	84 d2                	test   %dl,%dl
 100:	74 1e                	je     120 <strchr+0x2f>
 102:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 104:	38 d3                	cmp    %dl,%bl
 106:	74 15                	je     11d <strchr+0x2c>
  for(; *s; s++)
 108:	83 c0 01             	add    $0x1,%eax
 10b:	0f b6 10             	movzbl (%eax),%edx
 10e:	84 d2                	test   %dl,%dl
 110:	74 06                	je     118 <strchr+0x27>
    if(*s == c)
 112:	38 ca                	cmp    %cl,%dl
 114:	75 f2                	jne    108 <strchr+0x17>
 116:	eb 05                	jmp    11d <strchr+0x2c>
      return (char*)s;
  return 0;
 118:	b8 00 00 00 00       	mov    $0x0,%eax
}
 11d:	5b                   	pop    %ebx
 11e:	5d                   	pop    %ebp
 11f:	c3                   	ret    
  return 0;
 120:	b8 00 00 00 00       	mov    $0x0,%eax
 125:	eb f6                	jmp    11d <strchr+0x2c>

00000127 <gets>:

char*
gets(char *buf, int max)
{
 127:	55                   	push   %ebp
 128:	89 e5                	mov    %esp,%ebp
 12a:	57                   	push   %edi
 12b:	56                   	push   %esi
 12c:	53                   	push   %ebx
 12d:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 130:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 135:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 138:	8d 5e 01             	lea    0x1(%esi),%ebx
 13b:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 13e:	7d 2b                	jge    16b <gets+0x44>
    cc = read(0, &c, 1);
 140:	83 ec 04             	sub    $0x4,%esp
 143:	6a 01                	push   $0x1
 145:	57                   	push   %edi
 146:	6a 00                	push   $0x0
 148:	e8 f2 00 00 00       	call   23f <read>
    if(cc < 1)
 14d:	83 c4 10             	add    $0x10,%esp
 150:	85 c0                	test   %eax,%eax
 152:	7e 17                	jle    16b <gets+0x44>
      break;
    buf[i++] = c;
 154:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 158:	8b 55 08             	mov    0x8(%ebp),%edx
 15b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 15f:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 161:	3c 0a                	cmp    $0xa,%al
 163:	74 04                	je     169 <gets+0x42>
 165:	3c 0d                	cmp    $0xd,%al
 167:	75 cf                	jne    138 <gets+0x11>
  for(i=0; i+1 < max; ){
 169:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 16b:	8b 45 08             	mov    0x8(%ebp),%eax
 16e:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 172:	8d 65 f4             	lea    -0xc(%ebp),%esp
 175:	5b                   	pop    %ebx
 176:	5e                   	pop    %esi
 177:	5f                   	pop    %edi
 178:	5d                   	pop    %ebp
 179:	c3                   	ret    

0000017a <stat>:

int
stat(const char *n, struct stat *st)
{
 17a:	55                   	push   %ebp
 17b:	89 e5                	mov    %esp,%ebp
 17d:	56                   	push   %esi
 17e:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 17f:	83 ec 08             	sub    $0x8,%esp
 182:	6a 00                	push   $0x0
 184:	ff 75 08             	pushl  0x8(%ebp)
 187:	e8 db 00 00 00       	call   267 <open>
  if(fd < 0)
 18c:	83 c4 10             	add    $0x10,%esp
 18f:	85 c0                	test   %eax,%eax
 191:	78 24                	js     1b7 <stat+0x3d>
 193:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 195:	83 ec 08             	sub    $0x8,%esp
 198:	ff 75 0c             	pushl  0xc(%ebp)
 19b:	50                   	push   %eax
 19c:	e8 de 00 00 00       	call   27f <fstat>
 1a1:	89 c6                	mov    %eax,%esi
  close(fd);
 1a3:	89 1c 24             	mov    %ebx,(%esp)
 1a6:	e8 a4 00 00 00       	call   24f <close>
  return r;
 1ab:	83 c4 10             	add    $0x10,%esp
}
 1ae:	89 f0                	mov    %esi,%eax
 1b0:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1b3:	5b                   	pop    %ebx
 1b4:	5e                   	pop    %esi
 1b5:	5d                   	pop    %ebp
 1b6:	c3                   	ret    
    return -1;
 1b7:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1bc:	eb f0                	jmp    1ae <stat+0x34>

000001be <atoi>:

int
atoi(const char *s)
{
 1be:	55                   	push   %ebp
 1bf:	89 e5                	mov    %esp,%ebp
 1c1:	53                   	push   %ebx
 1c2:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1c5:	0f b6 11             	movzbl (%ecx),%edx
 1c8:	8d 42 d0             	lea    -0x30(%edx),%eax
 1cb:	3c 09                	cmp    $0x9,%al
 1cd:	77 20                	ja     1ef <atoi+0x31>
  n = 0;
 1cf:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 1d4:	83 c1 01             	add    $0x1,%ecx
 1d7:	8d 04 80             	lea    (%eax,%eax,4),%eax
 1da:	0f be d2             	movsbl %dl,%edx
 1dd:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 1e1:	0f b6 11             	movzbl (%ecx),%edx
 1e4:	8d 5a d0             	lea    -0x30(%edx),%ebx
 1e7:	80 fb 09             	cmp    $0x9,%bl
 1ea:	76 e8                	jbe    1d4 <atoi+0x16>
  return n;
}
 1ec:	5b                   	pop    %ebx
 1ed:	5d                   	pop    %ebp
 1ee:	c3                   	ret    
  n = 0;
 1ef:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 1f4:	eb f6                	jmp    1ec <atoi+0x2e>

000001f6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1f6:	55                   	push   %ebp
 1f7:	89 e5                	mov    %esp,%ebp
 1f9:	56                   	push   %esi
 1fa:	53                   	push   %ebx
 1fb:	8b 45 08             	mov    0x8(%ebp),%eax
 1fe:	8b 75 0c             	mov    0xc(%ebp),%esi
 201:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 204:	85 db                	test   %ebx,%ebx
 206:	7e 13                	jle    21b <memmove+0x25>
 208:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 20d:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 211:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 214:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 217:	39 d3                	cmp    %edx,%ebx
 219:	75 f2                	jne    20d <memmove+0x17>
  return vdst;
}
 21b:	5b                   	pop    %ebx
 21c:	5e                   	pop    %esi
 21d:	5d                   	pop    %ebp
 21e:	c3                   	ret    

0000021f <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 21f:	b8 01 00 00 00       	mov    $0x1,%eax
 224:	cd 40                	int    $0x40
 226:	c3                   	ret    

00000227 <exit>:
SYSCALL(exit)
 227:	b8 02 00 00 00       	mov    $0x2,%eax
 22c:	cd 40                	int    $0x40
 22e:	c3                   	ret    

0000022f <wait>:
SYSCALL(wait)
 22f:	b8 03 00 00 00       	mov    $0x3,%eax
 234:	cd 40                	int    $0x40
 236:	c3                   	ret    

00000237 <pipe>:
SYSCALL(pipe)
 237:	b8 04 00 00 00       	mov    $0x4,%eax
 23c:	cd 40                	int    $0x40
 23e:	c3                   	ret    

0000023f <read>:
SYSCALL(read)
 23f:	b8 05 00 00 00       	mov    $0x5,%eax
 244:	cd 40                	int    $0x40
 246:	c3                   	ret    

00000247 <write>:
SYSCALL(write)
 247:	b8 10 00 00 00       	mov    $0x10,%eax
 24c:	cd 40                	int    $0x40
 24e:	c3                   	ret    

0000024f <close>:
SYSCALL(close)
 24f:	b8 15 00 00 00       	mov    $0x15,%eax
 254:	cd 40                	int    $0x40
 256:	c3                   	ret    

00000257 <kill>:
SYSCALL(kill)
 257:	b8 06 00 00 00       	mov    $0x6,%eax
 25c:	cd 40                	int    $0x40
 25e:	c3                   	ret    

0000025f <exec>:
SYSCALL(exec)
 25f:	b8 07 00 00 00       	mov    $0x7,%eax
 264:	cd 40                	int    $0x40
 266:	c3                   	ret    

00000267 <open>:
SYSCALL(open)
 267:	b8 0f 00 00 00       	mov    $0xf,%eax
 26c:	cd 40                	int    $0x40
 26e:	c3                   	ret    

0000026f <mknod>:
SYSCALL(mknod)
 26f:	b8 11 00 00 00       	mov    $0x11,%eax
 274:	cd 40                	int    $0x40
 276:	c3                   	ret    

00000277 <unlink>:
SYSCALL(unlink)
 277:	b8 12 00 00 00       	mov    $0x12,%eax
 27c:	cd 40                	int    $0x40
 27e:	c3                   	ret    

0000027f <fstat>:
SYSCALL(fstat)
 27f:	b8 08 00 00 00       	mov    $0x8,%eax
 284:	cd 40                	int    $0x40
 286:	c3                   	ret    

00000287 <link>:
SYSCALL(link)
 287:	b8 13 00 00 00       	mov    $0x13,%eax
 28c:	cd 40                	int    $0x40
 28e:	c3                   	ret    

0000028f <mkdir>:
SYSCALL(mkdir)
 28f:	b8 14 00 00 00       	mov    $0x14,%eax
 294:	cd 40                	int    $0x40
 296:	c3                   	ret    

00000297 <chdir>:
SYSCALL(chdir)
 297:	b8 09 00 00 00       	mov    $0x9,%eax
 29c:	cd 40                	int    $0x40
 29e:	c3                   	ret    

0000029f <dup>:
SYSCALL(dup)
 29f:	b8 0a 00 00 00       	mov    $0xa,%eax
 2a4:	cd 40                	int    $0x40
 2a6:	c3                   	ret    

000002a7 <getpid>:
SYSCALL(getpid)
 2a7:	b8 0b 00 00 00       	mov    $0xb,%eax
 2ac:	cd 40                	int    $0x40
 2ae:	c3                   	ret    

000002af <sbrk>:
SYSCALL(sbrk)
 2af:	b8 0c 00 00 00       	mov    $0xc,%eax
 2b4:	cd 40                	int    $0x40
 2b6:	c3                   	ret    

000002b7 <sleep>:
SYSCALL(sleep)
 2b7:	b8 0d 00 00 00       	mov    $0xd,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <uptime>:
SYSCALL(uptime)
 2bf:	b8 0e 00 00 00       	mov    $0xe,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <slabtest>:
SYSCALL(slabtest)
 2c7:	b8 16 00 00 00       	mov    $0x16,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <ps>:
SYSCALL(ps)
 2cf:	b8 17 00 00 00       	mov    $0x17,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 2d7:	55                   	push   %ebp
 2d8:	89 e5                	mov    %esp,%ebp
 2da:	57                   	push   %edi
 2db:	56                   	push   %esi
 2dc:	53                   	push   %ebx
 2dd:	83 ec 3c             	sub    $0x3c,%esp
 2e0:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 2e2:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 2e6:	74 14                	je     2fc <printint+0x25>
 2e8:	85 d2                	test   %edx,%edx
 2ea:	79 10                	jns    2fc <printint+0x25>
    neg = 1;
    x = -xx;
 2ec:	f7 da                	neg    %edx
    neg = 1;
 2ee:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 2f5:	bf 00 00 00 00       	mov    $0x0,%edi
 2fa:	eb 0b                	jmp    307 <printint+0x30>
  neg = 0;
 2fc:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 303:	eb f0                	jmp    2f5 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 305:	89 df                	mov    %ebx,%edi
 307:	8d 5f 01             	lea    0x1(%edi),%ebx
 30a:	89 d0                	mov    %edx,%eax
 30c:	ba 00 00 00 00       	mov    $0x0,%edx
 311:	f7 f1                	div    %ecx
 313:	0f b6 92 88 06 00 00 	movzbl 0x688(%edx),%edx
 31a:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 31e:	89 c2                	mov    %eax,%edx
 320:	85 c0                	test   %eax,%eax
 322:	75 e1                	jne    305 <printint+0x2e>
  if(neg)
 324:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 328:	74 08                	je     332 <printint+0x5b>
    buf[i++] = '-';
 32a:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 32f:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 332:	83 eb 01             	sub    $0x1,%ebx
 335:	78 22                	js     359 <printint+0x82>
  write(fd, &c, 1);
 337:	8d 7d d7             	lea    -0x29(%ebp),%edi
 33a:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 33f:	88 45 d7             	mov    %al,-0x29(%ebp)
 342:	83 ec 04             	sub    $0x4,%esp
 345:	6a 01                	push   $0x1
 347:	57                   	push   %edi
 348:	56                   	push   %esi
 349:	e8 f9 fe ff ff       	call   247 <write>
  while(--i >= 0)
 34e:	83 eb 01             	sub    $0x1,%ebx
 351:	83 c4 10             	add    $0x10,%esp
 354:	83 fb ff             	cmp    $0xffffffff,%ebx
 357:	75 e1                	jne    33a <printint+0x63>
    putc(fd, buf[i]);
}
 359:	8d 65 f4             	lea    -0xc(%ebp),%esp
 35c:	5b                   	pop    %ebx
 35d:	5e                   	pop    %esi
 35e:	5f                   	pop    %edi
 35f:	5d                   	pop    %ebp
 360:	c3                   	ret    

00000361 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 361:	55                   	push   %ebp
 362:	89 e5                	mov    %esp,%ebp
 364:	57                   	push   %edi
 365:	56                   	push   %esi
 366:	53                   	push   %ebx
 367:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 36a:	8b 75 0c             	mov    0xc(%ebp),%esi
 36d:	0f b6 1e             	movzbl (%esi),%ebx
 370:	84 db                	test   %bl,%bl
 372:	0f 84 b1 01 00 00    	je     529 <printf+0x1c8>
 378:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 37b:	8d 45 10             	lea    0x10(%ebp),%eax
 37e:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 381:	bf 00 00 00 00       	mov    $0x0,%edi
 386:	eb 2d                	jmp    3b5 <printf+0x54>
 388:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 38b:	83 ec 04             	sub    $0x4,%esp
 38e:	6a 01                	push   $0x1
 390:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 393:	50                   	push   %eax
 394:	ff 75 08             	pushl  0x8(%ebp)
 397:	e8 ab fe ff ff       	call   247 <write>
 39c:	83 c4 10             	add    $0x10,%esp
 39f:	eb 05                	jmp    3a6 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 3a1:	83 ff 25             	cmp    $0x25,%edi
 3a4:	74 22                	je     3c8 <printf+0x67>
 3a6:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 3a9:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 3ad:	84 db                	test   %bl,%bl
 3af:	0f 84 74 01 00 00    	je     529 <printf+0x1c8>
    c = fmt[i] & 0xff;
 3b5:	0f be d3             	movsbl %bl,%edx
 3b8:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 3bb:	85 ff                	test   %edi,%edi
 3bd:	75 e2                	jne    3a1 <printf+0x40>
      if(c == '%'){
 3bf:	83 f8 25             	cmp    $0x25,%eax
 3c2:	75 c4                	jne    388 <printf+0x27>
        state = '%';
 3c4:	89 c7                	mov    %eax,%edi
 3c6:	eb de                	jmp    3a6 <printf+0x45>
      if(c == 'd'){
 3c8:	83 f8 64             	cmp    $0x64,%eax
 3cb:	74 59                	je     426 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 3cd:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 3d3:	83 fa 70             	cmp    $0x70,%edx
 3d6:	74 7a                	je     452 <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 3d8:	83 f8 73             	cmp    $0x73,%eax
 3db:	0f 84 9d 00 00 00    	je     47e <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 3e1:	83 f8 63             	cmp    $0x63,%eax
 3e4:	0f 84 f2 00 00 00    	je     4dc <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 3ea:	83 f8 25             	cmp    $0x25,%eax
 3ed:	0f 84 15 01 00 00    	je     508 <printf+0x1a7>
 3f3:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 3f7:	83 ec 04             	sub    $0x4,%esp
 3fa:	6a 01                	push   $0x1
 3fc:	8d 45 e7             	lea    -0x19(%ebp),%eax
 3ff:	50                   	push   %eax
 400:	ff 75 08             	pushl  0x8(%ebp)
 403:	e8 3f fe ff ff       	call   247 <write>
 408:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 40b:	83 c4 0c             	add    $0xc,%esp
 40e:	6a 01                	push   $0x1
 410:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 413:	50                   	push   %eax
 414:	ff 75 08             	pushl  0x8(%ebp)
 417:	e8 2b fe ff ff       	call   247 <write>
 41c:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 41f:	bf 00 00 00 00       	mov    $0x0,%edi
 424:	eb 80                	jmp    3a6 <printf+0x45>
        printint(fd, *ap, 10, 1);
 426:	83 ec 0c             	sub    $0xc,%esp
 429:	6a 01                	push   $0x1
 42b:	b9 0a 00 00 00       	mov    $0xa,%ecx
 430:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 433:	8b 17                	mov    (%edi),%edx
 435:	8b 45 08             	mov    0x8(%ebp),%eax
 438:	e8 9a fe ff ff       	call   2d7 <printint>
        ap++;
 43d:	89 f8                	mov    %edi,%eax
 43f:	83 c0 04             	add    $0x4,%eax
 442:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 445:	83 c4 10             	add    $0x10,%esp
      state = 0;
 448:	bf 00 00 00 00       	mov    $0x0,%edi
 44d:	e9 54 ff ff ff       	jmp    3a6 <printf+0x45>
        printint(fd, *ap, 16, 0);
 452:	83 ec 0c             	sub    $0xc,%esp
 455:	6a 00                	push   $0x0
 457:	b9 10 00 00 00       	mov    $0x10,%ecx
 45c:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 45f:	8b 17                	mov    (%edi),%edx
 461:	8b 45 08             	mov    0x8(%ebp),%eax
 464:	e8 6e fe ff ff       	call   2d7 <printint>
        ap++;
 469:	89 f8                	mov    %edi,%eax
 46b:	83 c0 04             	add    $0x4,%eax
 46e:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 471:	83 c4 10             	add    $0x10,%esp
      state = 0;
 474:	bf 00 00 00 00       	mov    $0x0,%edi
 479:	e9 28 ff ff ff       	jmp    3a6 <printf+0x45>
        s = (char*)*ap;
 47e:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 481:	8b 01                	mov    (%ecx),%eax
        ap++;
 483:	83 c1 04             	add    $0x4,%ecx
 486:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 489:	85 c0                	test   %eax,%eax
 48b:	74 13                	je     4a0 <printf+0x13f>
        s = (char*)*ap;
 48d:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 48f:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 492:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 497:	84 c0                	test   %al,%al
 499:	75 0f                	jne    4aa <printf+0x149>
 49b:	e9 06 ff ff ff       	jmp    3a6 <printf+0x45>
          s = "(null)";
 4a0:	bb 81 06 00 00       	mov    $0x681,%ebx
        while(*s != 0){
 4a5:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 4aa:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 4ad:	89 75 d0             	mov    %esi,-0x30(%ebp)
 4b0:	8b 75 08             	mov    0x8(%ebp),%esi
 4b3:	88 45 e3             	mov    %al,-0x1d(%ebp)
 4b6:	83 ec 04             	sub    $0x4,%esp
 4b9:	6a 01                	push   $0x1
 4bb:	57                   	push   %edi
 4bc:	56                   	push   %esi
 4bd:	e8 85 fd ff ff       	call   247 <write>
          s++;
 4c2:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 4c5:	0f b6 03             	movzbl (%ebx),%eax
 4c8:	83 c4 10             	add    $0x10,%esp
 4cb:	84 c0                	test   %al,%al
 4cd:	75 e4                	jne    4b3 <printf+0x152>
 4cf:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 4d2:	bf 00 00 00 00       	mov    $0x0,%edi
 4d7:	e9 ca fe ff ff       	jmp    3a6 <printf+0x45>
        putc(fd, *ap);
 4dc:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4df:	8b 07                	mov    (%edi),%eax
 4e1:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 4e4:	83 ec 04             	sub    $0x4,%esp
 4e7:	6a 01                	push   $0x1
 4e9:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 4ec:	50                   	push   %eax
 4ed:	ff 75 08             	pushl  0x8(%ebp)
 4f0:	e8 52 fd ff ff       	call   247 <write>
        ap++;
 4f5:	83 c7 04             	add    $0x4,%edi
 4f8:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4fb:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4fe:	bf 00 00 00 00       	mov    $0x0,%edi
 503:	e9 9e fe ff ff       	jmp    3a6 <printf+0x45>
 508:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 50b:	83 ec 04             	sub    $0x4,%esp
 50e:	6a 01                	push   $0x1
 510:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 513:	50                   	push   %eax
 514:	ff 75 08             	pushl  0x8(%ebp)
 517:	e8 2b fd ff ff       	call   247 <write>
 51c:	83 c4 10             	add    $0x10,%esp
      state = 0;
 51f:	bf 00 00 00 00       	mov    $0x0,%edi
 524:	e9 7d fe ff ff       	jmp    3a6 <printf+0x45>
    }
  }
}
 529:	8d 65 f4             	lea    -0xc(%ebp),%esp
 52c:	5b                   	pop    %ebx
 52d:	5e                   	pop    %esi
 52e:	5f                   	pop    %edi
 52f:	5d                   	pop    %ebp
 530:	c3                   	ret    

00000531 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 531:	55                   	push   %ebp
 532:	89 e5                	mov    %esp,%ebp
 534:	57                   	push   %edi
 535:	56                   	push   %esi
 536:	53                   	push   %ebx
 537:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 53a:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 53d:	a1 fc 08 00 00       	mov    0x8fc,%eax
 542:	eb 0c                	jmp    550 <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 544:	8b 10                	mov    (%eax),%edx
 546:	39 c2                	cmp    %eax,%edx
 548:	77 04                	ja     54e <free+0x1d>
 54a:	39 ca                	cmp    %ecx,%edx
 54c:	77 10                	ja     55e <free+0x2d>
{
 54e:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 550:	39 c8                	cmp    %ecx,%eax
 552:	73 f0                	jae    544 <free+0x13>
 554:	8b 10                	mov    (%eax),%edx
 556:	39 ca                	cmp    %ecx,%edx
 558:	77 04                	ja     55e <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 55a:	39 c2                	cmp    %eax,%edx
 55c:	77 f0                	ja     54e <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 55e:	8b 73 fc             	mov    -0x4(%ebx),%esi
 561:	8b 10                	mov    (%eax),%edx
 563:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 566:	39 fa                	cmp    %edi,%edx
 568:	74 19                	je     583 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 56a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 56d:	8b 50 04             	mov    0x4(%eax),%edx
 570:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 573:	39 f1                	cmp    %esi,%ecx
 575:	74 1b                	je     592 <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 577:	89 08                	mov    %ecx,(%eax)
  freep = p;
 579:	a3 fc 08 00 00       	mov    %eax,0x8fc
}
 57e:	5b                   	pop    %ebx
 57f:	5e                   	pop    %esi
 580:	5f                   	pop    %edi
 581:	5d                   	pop    %ebp
 582:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 583:	03 72 04             	add    0x4(%edx),%esi
 586:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 589:	8b 10                	mov    (%eax),%edx
 58b:	8b 12                	mov    (%edx),%edx
 58d:	89 53 f8             	mov    %edx,-0x8(%ebx)
 590:	eb db                	jmp    56d <free+0x3c>
    p->s.size += bp->s.size;
 592:	03 53 fc             	add    -0x4(%ebx),%edx
 595:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 598:	8b 53 f8             	mov    -0x8(%ebx),%edx
 59b:	89 10                	mov    %edx,(%eax)
 59d:	eb da                	jmp    579 <free+0x48>

0000059f <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 59f:	55                   	push   %ebp
 5a0:	89 e5                	mov    %esp,%ebp
 5a2:	57                   	push   %edi
 5a3:	56                   	push   %esi
 5a4:	53                   	push   %ebx
 5a5:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 5a8:	8b 45 08             	mov    0x8(%ebp),%eax
 5ab:	8d 58 07             	lea    0x7(%eax),%ebx
 5ae:	c1 eb 03             	shr    $0x3,%ebx
 5b1:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 5b4:	8b 15 fc 08 00 00    	mov    0x8fc,%edx
 5ba:	85 d2                	test   %edx,%edx
 5bc:	74 20                	je     5de <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 5be:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 5c0:	8b 48 04             	mov    0x4(%eax),%ecx
 5c3:	39 cb                	cmp    %ecx,%ebx
 5c5:	76 3c                	jbe    603 <malloc+0x64>
 5c7:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 5cd:	be 00 10 00 00       	mov    $0x1000,%esi
 5d2:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 5d5:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 5dc:	eb 70                	jmp    64e <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 5de:	c7 05 fc 08 00 00 00 	movl   $0x900,0x8fc
 5e5:	09 00 00 
 5e8:	c7 05 00 09 00 00 00 	movl   $0x900,0x900
 5ef:	09 00 00 
    base.s.size = 0;
 5f2:	c7 05 04 09 00 00 00 	movl   $0x0,0x904
 5f9:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 5fc:	ba 00 09 00 00       	mov    $0x900,%edx
 601:	eb bb                	jmp    5be <malloc+0x1f>
      if(p->s.size == nunits)
 603:	39 cb                	cmp    %ecx,%ebx
 605:	74 1c                	je     623 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 607:	29 d9                	sub    %ebx,%ecx
 609:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 60c:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 60f:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 612:	89 15 fc 08 00 00    	mov    %edx,0x8fc
      return (void*)(p + 1);
 618:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 61b:	8d 65 f4             	lea    -0xc(%ebp),%esp
 61e:	5b                   	pop    %ebx
 61f:	5e                   	pop    %esi
 620:	5f                   	pop    %edi
 621:	5d                   	pop    %ebp
 622:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 623:	8b 08                	mov    (%eax),%ecx
 625:	89 0a                	mov    %ecx,(%edx)
 627:	eb e9                	jmp    612 <malloc+0x73>
  hp->s.size = nu;
 629:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 62c:	83 ec 0c             	sub    $0xc,%esp
 62f:	83 c0 08             	add    $0x8,%eax
 632:	50                   	push   %eax
 633:	e8 f9 fe ff ff       	call   531 <free>
  return freep;
 638:	8b 15 fc 08 00 00    	mov    0x8fc,%edx
      if((p = morecore(nunits)) == 0)
 63e:	83 c4 10             	add    $0x10,%esp
 641:	85 d2                	test   %edx,%edx
 643:	74 2b                	je     670 <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 645:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 647:	8b 48 04             	mov    0x4(%eax),%ecx
 64a:	39 d9                	cmp    %ebx,%ecx
 64c:	73 b5                	jae    603 <malloc+0x64>
 64e:	89 c2                	mov    %eax,%edx
    if(p == freep)
 650:	39 05 fc 08 00 00    	cmp    %eax,0x8fc
 656:	75 ed                	jne    645 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 658:	83 ec 0c             	sub    $0xc,%esp
 65b:	57                   	push   %edi
 65c:	e8 4e fc ff ff       	call   2af <sbrk>
  if(p == (char*)-1)
 661:	83 c4 10             	add    $0x10,%esp
 664:	83 f8 ff             	cmp    $0xffffffff,%eax
 667:	75 c0                	jne    629 <malloc+0x8a>
        return 0;
 669:	b8 00 00 00 00       	mov    $0x0,%eax
 66e:	eb ab                	jmp    61b <malloc+0x7c>
 670:	b8 00 00 00 00       	mov    $0x0,%eax
 675:	eb a4                	jmp    61b <malloc+0x7c>
