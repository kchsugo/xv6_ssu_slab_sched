
user/_ln:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
   f:	8b 59 04             	mov    0x4(%ecx),%ebx
  if(argc != 3){
  12:	83 39 03             	cmpl   $0x3,(%ecx)
  15:	74 14                	je     2b <main+0x2b>
    printf(2, "Usage: ln old new\n");
  17:	83 ec 08             	sub    $0x8,%esp
  1a:	68 6c 06 00 00       	push   $0x66c
  1f:	6a 02                	push   $0x2
  21:	e8 30 03 00 00       	call   356 <printf>
    exit();
  26:	e8 f1 01 00 00       	call   21c <exit>
  }
  if(link(argv[1], argv[2]) < 0)
  2b:	83 ec 08             	sub    $0x8,%esp
  2e:	ff 73 08             	pushl  0x8(%ebx)
  31:	ff 73 04             	pushl  0x4(%ebx)
  34:	e8 43 02 00 00       	call   27c <link>
  39:	83 c4 10             	add    $0x10,%esp
  3c:	85 c0                	test   %eax,%eax
  3e:	78 05                	js     45 <main+0x45>
    printf(2, "link %s %s: failed\n", argv[1], argv[2]);
  exit();
  40:	e8 d7 01 00 00       	call   21c <exit>
    printf(2, "link %s %s: failed\n", argv[1], argv[2]);
  45:	ff 73 08             	pushl  0x8(%ebx)
  48:	ff 73 04             	pushl  0x4(%ebx)
  4b:	68 7f 06 00 00       	push   $0x67f
  50:	6a 02                	push   $0x2
  52:	e8 ff 02 00 00       	call   356 <printf>
  57:	83 c4 10             	add    $0x10,%esp
  5a:	eb e4                	jmp    40 <main+0x40>

0000005c <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  5c:	55                   	push   %ebp
  5d:	89 e5                	mov    %esp,%ebp
  5f:	53                   	push   %ebx
  60:	8b 45 08             	mov    0x8(%ebp),%eax
  63:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  66:	89 c2                	mov    %eax,%edx
  68:	83 c1 01             	add    $0x1,%ecx
  6b:	83 c2 01             	add    $0x1,%edx
  6e:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
  72:	88 5a ff             	mov    %bl,-0x1(%edx)
  75:	84 db                	test   %bl,%bl
  77:	75 ef                	jne    68 <strcpy+0xc>
    ;
  return os;
}
  79:	5b                   	pop    %ebx
  7a:	5d                   	pop    %ebp
  7b:	c3                   	ret    

0000007c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  7c:	55                   	push   %ebp
  7d:	89 e5                	mov    %esp,%ebp
  7f:	8b 4d 08             	mov    0x8(%ebp),%ecx
  82:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
  85:	0f b6 01             	movzbl (%ecx),%eax
  88:	84 c0                	test   %al,%al
  8a:	74 15                	je     a1 <strcmp+0x25>
  8c:	3a 02                	cmp    (%edx),%al
  8e:	75 11                	jne    a1 <strcmp+0x25>
    p++, q++;
  90:	83 c1 01             	add    $0x1,%ecx
  93:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
  96:	0f b6 01             	movzbl (%ecx),%eax
  99:	84 c0                	test   %al,%al
  9b:	74 04                	je     a1 <strcmp+0x25>
  9d:	3a 02                	cmp    (%edx),%al
  9f:	74 ef                	je     90 <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
  a1:	0f b6 c0             	movzbl %al,%eax
  a4:	0f b6 12             	movzbl (%edx),%edx
  a7:	29 d0                	sub    %edx,%eax
}
  a9:	5d                   	pop    %ebp
  aa:	c3                   	ret    

000000ab <strlen>:

uint
strlen(const char *s)
{
  ab:	55                   	push   %ebp
  ac:	89 e5                	mov    %esp,%ebp
  ae:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
  b1:	80 39 00             	cmpb   $0x0,(%ecx)
  b4:	74 12                	je     c8 <strlen+0x1d>
  b6:	ba 00 00 00 00       	mov    $0x0,%edx
  bb:	83 c2 01             	add    $0x1,%edx
  be:	89 d0                	mov    %edx,%eax
  c0:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
  c4:	75 f5                	jne    bb <strlen+0x10>
    ;
  return n;
}
  c6:	5d                   	pop    %ebp
  c7:	c3                   	ret    
  for(n = 0; s[n]; n++)
  c8:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
  cd:	eb f7                	jmp    c6 <strlen+0x1b>

000000cf <memset>:

void*
memset(void *dst, int c, uint n)
{
  cf:	55                   	push   %ebp
  d0:	89 e5                	mov    %esp,%ebp
  d2:	57                   	push   %edi
  d3:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
  d6:	89 d7                	mov    %edx,%edi
  d8:	8b 4d 10             	mov    0x10(%ebp),%ecx
  db:	8b 45 0c             	mov    0xc(%ebp),%eax
  de:	fc                   	cld    
  df:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
  e1:	89 d0                	mov    %edx,%eax
  e3:	5f                   	pop    %edi
  e4:	5d                   	pop    %ebp
  e5:	c3                   	ret    

000000e6 <strchr>:

char*
strchr(const char *s, char c)
{
  e6:	55                   	push   %ebp
  e7:	89 e5                	mov    %esp,%ebp
  e9:	53                   	push   %ebx
  ea:	8b 45 08             	mov    0x8(%ebp),%eax
  ed:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
  f0:	0f b6 10             	movzbl (%eax),%edx
  f3:	84 d2                	test   %dl,%dl
  f5:	74 1e                	je     115 <strchr+0x2f>
  f7:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
  f9:	38 d3                	cmp    %dl,%bl
  fb:	74 15                	je     112 <strchr+0x2c>
  for(; *s; s++)
  fd:	83 c0 01             	add    $0x1,%eax
 100:	0f b6 10             	movzbl (%eax),%edx
 103:	84 d2                	test   %dl,%dl
 105:	74 06                	je     10d <strchr+0x27>
    if(*s == c)
 107:	38 ca                	cmp    %cl,%dl
 109:	75 f2                	jne    fd <strchr+0x17>
 10b:	eb 05                	jmp    112 <strchr+0x2c>
      return (char*)s;
  return 0;
 10d:	b8 00 00 00 00       	mov    $0x0,%eax
}
 112:	5b                   	pop    %ebx
 113:	5d                   	pop    %ebp
 114:	c3                   	ret    
  return 0;
 115:	b8 00 00 00 00       	mov    $0x0,%eax
 11a:	eb f6                	jmp    112 <strchr+0x2c>

0000011c <gets>:

char*
gets(char *buf, int max)
{
 11c:	55                   	push   %ebp
 11d:	89 e5                	mov    %esp,%ebp
 11f:	57                   	push   %edi
 120:	56                   	push   %esi
 121:	53                   	push   %ebx
 122:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 125:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 12a:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 12d:	8d 5e 01             	lea    0x1(%esi),%ebx
 130:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 133:	7d 2b                	jge    160 <gets+0x44>
    cc = read(0, &c, 1);
 135:	83 ec 04             	sub    $0x4,%esp
 138:	6a 01                	push   $0x1
 13a:	57                   	push   %edi
 13b:	6a 00                	push   $0x0
 13d:	e8 f2 00 00 00       	call   234 <read>
    if(cc < 1)
 142:	83 c4 10             	add    $0x10,%esp
 145:	85 c0                	test   %eax,%eax
 147:	7e 17                	jle    160 <gets+0x44>
      break;
    buf[i++] = c;
 149:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 14d:	8b 55 08             	mov    0x8(%ebp),%edx
 150:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 154:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 156:	3c 0a                	cmp    $0xa,%al
 158:	74 04                	je     15e <gets+0x42>
 15a:	3c 0d                	cmp    $0xd,%al
 15c:	75 cf                	jne    12d <gets+0x11>
  for(i=0; i+1 < max; ){
 15e:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 160:	8b 45 08             	mov    0x8(%ebp),%eax
 163:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 167:	8d 65 f4             	lea    -0xc(%ebp),%esp
 16a:	5b                   	pop    %ebx
 16b:	5e                   	pop    %esi
 16c:	5f                   	pop    %edi
 16d:	5d                   	pop    %ebp
 16e:	c3                   	ret    

0000016f <stat>:

int
stat(const char *n, struct stat *st)
{
 16f:	55                   	push   %ebp
 170:	89 e5                	mov    %esp,%ebp
 172:	56                   	push   %esi
 173:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 174:	83 ec 08             	sub    $0x8,%esp
 177:	6a 00                	push   $0x0
 179:	ff 75 08             	pushl  0x8(%ebp)
 17c:	e8 db 00 00 00       	call   25c <open>
  if(fd < 0)
 181:	83 c4 10             	add    $0x10,%esp
 184:	85 c0                	test   %eax,%eax
 186:	78 24                	js     1ac <stat+0x3d>
 188:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 18a:	83 ec 08             	sub    $0x8,%esp
 18d:	ff 75 0c             	pushl  0xc(%ebp)
 190:	50                   	push   %eax
 191:	e8 de 00 00 00       	call   274 <fstat>
 196:	89 c6                	mov    %eax,%esi
  close(fd);
 198:	89 1c 24             	mov    %ebx,(%esp)
 19b:	e8 a4 00 00 00       	call   244 <close>
  return r;
 1a0:	83 c4 10             	add    $0x10,%esp
}
 1a3:	89 f0                	mov    %esi,%eax
 1a5:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1a8:	5b                   	pop    %ebx
 1a9:	5e                   	pop    %esi
 1aa:	5d                   	pop    %ebp
 1ab:	c3                   	ret    
    return -1;
 1ac:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1b1:	eb f0                	jmp    1a3 <stat+0x34>

000001b3 <atoi>:

int
atoi(const char *s)
{
 1b3:	55                   	push   %ebp
 1b4:	89 e5                	mov    %esp,%ebp
 1b6:	53                   	push   %ebx
 1b7:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1ba:	0f b6 11             	movzbl (%ecx),%edx
 1bd:	8d 42 d0             	lea    -0x30(%edx),%eax
 1c0:	3c 09                	cmp    $0x9,%al
 1c2:	77 20                	ja     1e4 <atoi+0x31>
  n = 0;
 1c4:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 1c9:	83 c1 01             	add    $0x1,%ecx
 1cc:	8d 04 80             	lea    (%eax,%eax,4),%eax
 1cf:	0f be d2             	movsbl %dl,%edx
 1d2:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 1d6:	0f b6 11             	movzbl (%ecx),%edx
 1d9:	8d 5a d0             	lea    -0x30(%edx),%ebx
 1dc:	80 fb 09             	cmp    $0x9,%bl
 1df:	76 e8                	jbe    1c9 <atoi+0x16>
  return n;
}
 1e1:	5b                   	pop    %ebx
 1e2:	5d                   	pop    %ebp
 1e3:	c3                   	ret    
  n = 0;
 1e4:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 1e9:	eb f6                	jmp    1e1 <atoi+0x2e>

000001eb <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1eb:	55                   	push   %ebp
 1ec:	89 e5                	mov    %esp,%ebp
 1ee:	56                   	push   %esi
 1ef:	53                   	push   %ebx
 1f0:	8b 45 08             	mov    0x8(%ebp),%eax
 1f3:	8b 75 0c             	mov    0xc(%ebp),%esi
 1f6:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 1f9:	85 db                	test   %ebx,%ebx
 1fb:	7e 13                	jle    210 <memmove+0x25>
 1fd:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 202:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 206:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 209:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 20c:	39 d3                	cmp    %edx,%ebx
 20e:	75 f2                	jne    202 <memmove+0x17>
  return vdst;
}
 210:	5b                   	pop    %ebx
 211:	5e                   	pop    %esi
 212:	5d                   	pop    %ebp
 213:	c3                   	ret    

00000214 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 214:	b8 01 00 00 00       	mov    $0x1,%eax
 219:	cd 40                	int    $0x40
 21b:	c3                   	ret    

0000021c <exit>:
SYSCALL(exit)
 21c:	b8 02 00 00 00       	mov    $0x2,%eax
 221:	cd 40                	int    $0x40
 223:	c3                   	ret    

00000224 <wait>:
SYSCALL(wait)
 224:	b8 03 00 00 00       	mov    $0x3,%eax
 229:	cd 40                	int    $0x40
 22b:	c3                   	ret    

0000022c <pipe>:
SYSCALL(pipe)
 22c:	b8 04 00 00 00       	mov    $0x4,%eax
 231:	cd 40                	int    $0x40
 233:	c3                   	ret    

00000234 <read>:
SYSCALL(read)
 234:	b8 05 00 00 00       	mov    $0x5,%eax
 239:	cd 40                	int    $0x40
 23b:	c3                   	ret    

0000023c <write>:
SYSCALL(write)
 23c:	b8 10 00 00 00       	mov    $0x10,%eax
 241:	cd 40                	int    $0x40
 243:	c3                   	ret    

00000244 <close>:
SYSCALL(close)
 244:	b8 15 00 00 00       	mov    $0x15,%eax
 249:	cd 40                	int    $0x40
 24b:	c3                   	ret    

0000024c <kill>:
SYSCALL(kill)
 24c:	b8 06 00 00 00       	mov    $0x6,%eax
 251:	cd 40                	int    $0x40
 253:	c3                   	ret    

00000254 <exec>:
SYSCALL(exec)
 254:	b8 07 00 00 00       	mov    $0x7,%eax
 259:	cd 40                	int    $0x40
 25b:	c3                   	ret    

0000025c <open>:
SYSCALL(open)
 25c:	b8 0f 00 00 00       	mov    $0xf,%eax
 261:	cd 40                	int    $0x40
 263:	c3                   	ret    

00000264 <mknod>:
SYSCALL(mknod)
 264:	b8 11 00 00 00       	mov    $0x11,%eax
 269:	cd 40                	int    $0x40
 26b:	c3                   	ret    

0000026c <unlink>:
SYSCALL(unlink)
 26c:	b8 12 00 00 00       	mov    $0x12,%eax
 271:	cd 40                	int    $0x40
 273:	c3                   	ret    

00000274 <fstat>:
SYSCALL(fstat)
 274:	b8 08 00 00 00       	mov    $0x8,%eax
 279:	cd 40                	int    $0x40
 27b:	c3                   	ret    

0000027c <link>:
SYSCALL(link)
 27c:	b8 13 00 00 00       	mov    $0x13,%eax
 281:	cd 40                	int    $0x40
 283:	c3                   	ret    

00000284 <mkdir>:
SYSCALL(mkdir)
 284:	b8 14 00 00 00       	mov    $0x14,%eax
 289:	cd 40                	int    $0x40
 28b:	c3                   	ret    

0000028c <chdir>:
SYSCALL(chdir)
 28c:	b8 09 00 00 00       	mov    $0x9,%eax
 291:	cd 40                	int    $0x40
 293:	c3                   	ret    

00000294 <dup>:
SYSCALL(dup)
 294:	b8 0a 00 00 00       	mov    $0xa,%eax
 299:	cd 40                	int    $0x40
 29b:	c3                   	ret    

0000029c <getpid>:
SYSCALL(getpid)
 29c:	b8 0b 00 00 00       	mov    $0xb,%eax
 2a1:	cd 40                	int    $0x40
 2a3:	c3                   	ret    

000002a4 <sbrk>:
SYSCALL(sbrk)
 2a4:	b8 0c 00 00 00       	mov    $0xc,%eax
 2a9:	cd 40                	int    $0x40
 2ab:	c3                   	ret    

000002ac <sleep>:
SYSCALL(sleep)
 2ac:	b8 0d 00 00 00       	mov    $0xd,%eax
 2b1:	cd 40                	int    $0x40
 2b3:	c3                   	ret    

000002b4 <uptime>:
SYSCALL(uptime)
 2b4:	b8 0e 00 00 00       	mov    $0xe,%eax
 2b9:	cd 40                	int    $0x40
 2bb:	c3                   	ret    

000002bc <slabtest>:
SYSCALL(slabtest)
 2bc:	b8 16 00 00 00       	mov    $0x16,%eax
 2c1:	cd 40                	int    $0x40
 2c3:	c3                   	ret    

000002c4 <ps>:
SYSCALL(ps)
 2c4:	b8 17 00 00 00       	mov    $0x17,%eax
 2c9:	cd 40                	int    $0x40
 2cb:	c3                   	ret    

000002cc <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 2cc:	55                   	push   %ebp
 2cd:	89 e5                	mov    %esp,%ebp
 2cf:	57                   	push   %edi
 2d0:	56                   	push   %esi
 2d1:	53                   	push   %ebx
 2d2:	83 ec 3c             	sub    $0x3c,%esp
 2d5:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 2d7:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 2db:	74 14                	je     2f1 <printint+0x25>
 2dd:	85 d2                	test   %edx,%edx
 2df:	79 10                	jns    2f1 <printint+0x25>
    neg = 1;
    x = -xx;
 2e1:	f7 da                	neg    %edx
    neg = 1;
 2e3:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 2ea:	bf 00 00 00 00       	mov    $0x0,%edi
 2ef:	eb 0b                	jmp    2fc <printint+0x30>
  neg = 0;
 2f1:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 2f8:	eb f0                	jmp    2ea <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 2fa:	89 df                	mov    %ebx,%edi
 2fc:	8d 5f 01             	lea    0x1(%edi),%ebx
 2ff:	89 d0                	mov    %edx,%eax
 301:	ba 00 00 00 00       	mov    $0x0,%edx
 306:	f7 f1                	div    %ecx
 308:	0f b6 92 9c 06 00 00 	movzbl 0x69c(%edx),%edx
 30f:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 313:	89 c2                	mov    %eax,%edx
 315:	85 c0                	test   %eax,%eax
 317:	75 e1                	jne    2fa <printint+0x2e>
  if(neg)
 319:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 31d:	74 08                	je     327 <printint+0x5b>
    buf[i++] = '-';
 31f:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 324:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 327:	83 eb 01             	sub    $0x1,%ebx
 32a:	78 22                	js     34e <printint+0x82>
  write(fd, &c, 1);
 32c:	8d 7d d7             	lea    -0x29(%ebp),%edi
 32f:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 334:	88 45 d7             	mov    %al,-0x29(%ebp)
 337:	83 ec 04             	sub    $0x4,%esp
 33a:	6a 01                	push   $0x1
 33c:	57                   	push   %edi
 33d:	56                   	push   %esi
 33e:	e8 f9 fe ff ff       	call   23c <write>
  while(--i >= 0)
 343:	83 eb 01             	sub    $0x1,%ebx
 346:	83 c4 10             	add    $0x10,%esp
 349:	83 fb ff             	cmp    $0xffffffff,%ebx
 34c:	75 e1                	jne    32f <printint+0x63>
    putc(fd, buf[i]);
}
 34e:	8d 65 f4             	lea    -0xc(%ebp),%esp
 351:	5b                   	pop    %ebx
 352:	5e                   	pop    %esi
 353:	5f                   	pop    %edi
 354:	5d                   	pop    %ebp
 355:	c3                   	ret    

00000356 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 356:	55                   	push   %ebp
 357:	89 e5                	mov    %esp,%ebp
 359:	57                   	push   %edi
 35a:	56                   	push   %esi
 35b:	53                   	push   %ebx
 35c:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 35f:	8b 75 0c             	mov    0xc(%ebp),%esi
 362:	0f b6 1e             	movzbl (%esi),%ebx
 365:	84 db                	test   %bl,%bl
 367:	0f 84 b1 01 00 00    	je     51e <printf+0x1c8>
 36d:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 370:	8d 45 10             	lea    0x10(%ebp),%eax
 373:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 376:	bf 00 00 00 00       	mov    $0x0,%edi
 37b:	eb 2d                	jmp    3aa <printf+0x54>
 37d:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 380:	83 ec 04             	sub    $0x4,%esp
 383:	6a 01                	push   $0x1
 385:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 388:	50                   	push   %eax
 389:	ff 75 08             	pushl  0x8(%ebp)
 38c:	e8 ab fe ff ff       	call   23c <write>
 391:	83 c4 10             	add    $0x10,%esp
 394:	eb 05                	jmp    39b <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 396:	83 ff 25             	cmp    $0x25,%edi
 399:	74 22                	je     3bd <printf+0x67>
 39b:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 39e:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 3a2:	84 db                	test   %bl,%bl
 3a4:	0f 84 74 01 00 00    	je     51e <printf+0x1c8>
    c = fmt[i] & 0xff;
 3aa:	0f be d3             	movsbl %bl,%edx
 3ad:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 3b0:	85 ff                	test   %edi,%edi
 3b2:	75 e2                	jne    396 <printf+0x40>
      if(c == '%'){
 3b4:	83 f8 25             	cmp    $0x25,%eax
 3b7:	75 c4                	jne    37d <printf+0x27>
        state = '%';
 3b9:	89 c7                	mov    %eax,%edi
 3bb:	eb de                	jmp    39b <printf+0x45>
      if(c == 'd'){
 3bd:	83 f8 64             	cmp    $0x64,%eax
 3c0:	74 59                	je     41b <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 3c2:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 3c8:	83 fa 70             	cmp    $0x70,%edx
 3cb:	74 7a                	je     447 <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 3cd:	83 f8 73             	cmp    $0x73,%eax
 3d0:	0f 84 9d 00 00 00    	je     473 <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 3d6:	83 f8 63             	cmp    $0x63,%eax
 3d9:	0f 84 f2 00 00 00    	je     4d1 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 3df:	83 f8 25             	cmp    $0x25,%eax
 3e2:	0f 84 15 01 00 00    	je     4fd <printf+0x1a7>
 3e8:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 3ec:	83 ec 04             	sub    $0x4,%esp
 3ef:	6a 01                	push   $0x1
 3f1:	8d 45 e7             	lea    -0x19(%ebp),%eax
 3f4:	50                   	push   %eax
 3f5:	ff 75 08             	pushl  0x8(%ebp)
 3f8:	e8 3f fe ff ff       	call   23c <write>
 3fd:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 400:	83 c4 0c             	add    $0xc,%esp
 403:	6a 01                	push   $0x1
 405:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 408:	50                   	push   %eax
 409:	ff 75 08             	pushl  0x8(%ebp)
 40c:	e8 2b fe ff ff       	call   23c <write>
 411:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 414:	bf 00 00 00 00       	mov    $0x0,%edi
 419:	eb 80                	jmp    39b <printf+0x45>
        printint(fd, *ap, 10, 1);
 41b:	83 ec 0c             	sub    $0xc,%esp
 41e:	6a 01                	push   $0x1
 420:	b9 0a 00 00 00       	mov    $0xa,%ecx
 425:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 428:	8b 17                	mov    (%edi),%edx
 42a:	8b 45 08             	mov    0x8(%ebp),%eax
 42d:	e8 9a fe ff ff       	call   2cc <printint>
        ap++;
 432:	89 f8                	mov    %edi,%eax
 434:	83 c0 04             	add    $0x4,%eax
 437:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 43a:	83 c4 10             	add    $0x10,%esp
      state = 0;
 43d:	bf 00 00 00 00       	mov    $0x0,%edi
 442:	e9 54 ff ff ff       	jmp    39b <printf+0x45>
        printint(fd, *ap, 16, 0);
 447:	83 ec 0c             	sub    $0xc,%esp
 44a:	6a 00                	push   $0x0
 44c:	b9 10 00 00 00       	mov    $0x10,%ecx
 451:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 454:	8b 17                	mov    (%edi),%edx
 456:	8b 45 08             	mov    0x8(%ebp),%eax
 459:	e8 6e fe ff ff       	call   2cc <printint>
        ap++;
 45e:	89 f8                	mov    %edi,%eax
 460:	83 c0 04             	add    $0x4,%eax
 463:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 466:	83 c4 10             	add    $0x10,%esp
      state = 0;
 469:	bf 00 00 00 00       	mov    $0x0,%edi
 46e:	e9 28 ff ff ff       	jmp    39b <printf+0x45>
        s = (char*)*ap;
 473:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 476:	8b 01                	mov    (%ecx),%eax
        ap++;
 478:	83 c1 04             	add    $0x4,%ecx
 47b:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 47e:	85 c0                	test   %eax,%eax
 480:	74 13                	je     495 <printf+0x13f>
        s = (char*)*ap;
 482:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 484:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 487:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 48c:	84 c0                	test   %al,%al
 48e:	75 0f                	jne    49f <printf+0x149>
 490:	e9 06 ff ff ff       	jmp    39b <printf+0x45>
          s = "(null)";
 495:	bb 93 06 00 00       	mov    $0x693,%ebx
        while(*s != 0){
 49a:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 49f:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 4a2:	89 75 d0             	mov    %esi,-0x30(%ebp)
 4a5:	8b 75 08             	mov    0x8(%ebp),%esi
 4a8:	88 45 e3             	mov    %al,-0x1d(%ebp)
 4ab:	83 ec 04             	sub    $0x4,%esp
 4ae:	6a 01                	push   $0x1
 4b0:	57                   	push   %edi
 4b1:	56                   	push   %esi
 4b2:	e8 85 fd ff ff       	call   23c <write>
          s++;
 4b7:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 4ba:	0f b6 03             	movzbl (%ebx),%eax
 4bd:	83 c4 10             	add    $0x10,%esp
 4c0:	84 c0                	test   %al,%al
 4c2:	75 e4                	jne    4a8 <printf+0x152>
 4c4:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 4c7:	bf 00 00 00 00       	mov    $0x0,%edi
 4cc:	e9 ca fe ff ff       	jmp    39b <printf+0x45>
        putc(fd, *ap);
 4d1:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4d4:	8b 07                	mov    (%edi),%eax
 4d6:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 4d9:	83 ec 04             	sub    $0x4,%esp
 4dc:	6a 01                	push   $0x1
 4de:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 4e1:	50                   	push   %eax
 4e2:	ff 75 08             	pushl  0x8(%ebp)
 4e5:	e8 52 fd ff ff       	call   23c <write>
        ap++;
 4ea:	83 c7 04             	add    $0x4,%edi
 4ed:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4f0:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4f3:	bf 00 00 00 00       	mov    $0x0,%edi
 4f8:	e9 9e fe ff ff       	jmp    39b <printf+0x45>
 4fd:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 500:	83 ec 04             	sub    $0x4,%esp
 503:	6a 01                	push   $0x1
 505:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 508:	50                   	push   %eax
 509:	ff 75 08             	pushl  0x8(%ebp)
 50c:	e8 2b fd ff ff       	call   23c <write>
 511:	83 c4 10             	add    $0x10,%esp
      state = 0;
 514:	bf 00 00 00 00       	mov    $0x0,%edi
 519:	e9 7d fe ff ff       	jmp    39b <printf+0x45>
    }
  }
}
 51e:	8d 65 f4             	lea    -0xc(%ebp),%esp
 521:	5b                   	pop    %ebx
 522:	5e                   	pop    %esi
 523:	5f                   	pop    %edi
 524:	5d                   	pop    %ebp
 525:	c3                   	ret    

00000526 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 526:	55                   	push   %ebp
 527:	89 e5                	mov    %esp,%ebp
 529:	57                   	push   %edi
 52a:	56                   	push   %esi
 52b:	53                   	push   %ebx
 52c:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 52f:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 532:	a1 08 09 00 00       	mov    0x908,%eax
 537:	eb 0c                	jmp    545 <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 539:	8b 10                	mov    (%eax),%edx
 53b:	39 c2                	cmp    %eax,%edx
 53d:	77 04                	ja     543 <free+0x1d>
 53f:	39 ca                	cmp    %ecx,%edx
 541:	77 10                	ja     553 <free+0x2d>
{
 543:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 545:	39 c8                	cmp    %ecx,%eax
 547:	73 f0                	jae    539 <free+0x13>
 549:	8b 10                	mov    (%eax),%edx
 54b:	39 ca                	cmp    %ecx,%edx
 54d:	77 04                	ja     553 <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 54f:	39 c2                	cmp    %eax,%edx
 551:	77 f0                	ja     543 <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 553:	8b 73 fc             	mov    -0x4(%ebx),%esi
 556:	8b 10                	mov    (%eax),%edx
 558:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 55b:	39 fa                	cmp    %edi,%edx
 55d:	74 19                	je     578 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 55f:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 562:	8b 50 04             	mov    0x4(%eax),%edx
 565:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 568:	39 f1                	cmp    %esi,%ecx
 56a:	74 1b                	je     587 <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 56c:	89 08                	mov    %ecx,(%eax)
  freep = p;
 56e:	a3 08 09 00 00       	mov    %eax,0x908
}
 573:	5b                   	pop    %ebx
 574:	5e                   	pop    %esi
 575:	5f                   	pop    %edi
 576:	5d                   	pop    %ebp
 577:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 578:	03 72 04             	add    0x4(%edx),%esi
 57b:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 57e:	8b 10                	mov    (%eax),%edx
 580:	8b 12                	mov    (%edx),%edx
 582:	89 53 f8             	mov    %edx,-0x8(%ebx)
 585:	eb db                	jmp    562 <free+0x3c>
    p->s.size += bp->s.size;
 587:	03 53 fc             	add    -0x4(%ebx),%edx
 58a:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 58d:	8b 53 f8             	mov    -0x8(%ebx),%edx
 590:	89 10                	mov    %edx,(%eax)
 592:	eb da                	jmp    56e <free+0x48>

00000594 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 594:	55                   	push   %ebp
 595:	89 e5                	mov    %esp,%ebp
 597:	57                   	push   %edi
 598:	56                   	push   %esi
 599:	53                   	push   %ebx
 59a:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 59d:	8b 45 08             	mov    0x8(%ebp),%eax
 5a0:	8d 58 07             	lea    0x7(%eax),%ebx
 5a3:	c1 eb 03             	shr    $0x3,%ebx
 5a6:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 5a9:	8b 15 08 09 00 00    	mov    0x908,%edx
 5af:	85 d2                	test   %edx,%edx
 5b1:	74 20                	je     5d3 <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 5b3:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 5b5:	8b 48 04             	mov    0x4(%eax),%ecx
 5b8:	39 cb                	cmp    %ecx,%ebx
 5ba:	76 3c                	jbe    5f8 <malloc+0x64>
 5bc:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 5c2:	be 00 10 00 00       	mov    $0x1000,%esi
 5c7:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 5ca:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 5d1:	eb 70                	jmp    643 <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 5d3:	c7 05 08 09 00 00 0c 	movl   $0x90c,0x908
 5da:	09 00 00 
 5dd:	c7 05 0c 09 00 00 0c 	movl   $0x90c,0x90c
 5e4:	09 00 00 
    base.s.size = 0;
 5e7:	c7 05 10 09 00 00 00 	movl   $0x0,0x910
 5ee:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 5f1:	ba 0c 09 00 00       	mov    $0x90c,%edx
 5f6:	eb bb                	jmp    5b3 <malloc+0x1f>
      if(p->s.size == nunits)
 5f8:	39 cb                	cmp    %ecx,%ebx
 5fa:	74 1c                	je     618 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 5fc:	29 d9                	sub    %ebx,%ecx
 5fe:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 601:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 604:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 607:	89 15 08 09 00 00    	mov    %edx,0x908
      return (void*)(p + 1);
 60d:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 610:	8d 65 f4             	lea    -0xc(%ebp),%esp
 613:	5b                   	pop    %ebx
 614:	5e                   	pop    %esi
 615:	5f                   	pop    %edi
 616:	5d                   	pop    %ebp
 617:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 618:	8b 08                	mov    (%eax),%ecx
 61a:	89 0a                	mov    %ecx,(%edx)
 61c:	eb e9                	jmp    607 <malloc+0x73>
  hp->s.size = nu;
 61e:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 621:	83 ec 0c             	sub    $0xc,%esp
 624:	83 c0 08             	add    $0x8,%eax
 627:	50                   	push   %eax
 628:	e8 f9 fe ff ff       	call   526 <free>
  return freep;
 62d:	8b 15 08 09 00 00    	mov    0x908,%edx
      if((p = morecore(nunits)) == 0)
 633:	83 c4 10             	add    $0x10,%esp
 636:	85 d2                	test   %edx,%edx
 638:	74 2b                	je     665 <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 63a:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 63c:	8b 48 04             	mov    0x4(%eax),%ecx
 63f:	39 d9                	cmp    %ebx,%ecx
 641:	73 b5                	jae    5f8 <malloc+0x64>
 643:	89 c2                	mov    %eax,%edx
    if(p == freep)
 645:	39 05 08 09 00 00    	cmp    %eax,0x908
 64b:	75 ed                	jne    63a <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 64d:	83 ec 0c             	sub    $0xc,%esp
 650:	57                   	push   %edi
 651:	e8 4e fc ff ff       	call   2a4 <sbrk>
  if(p == (char*)-1)
 656:	83 c4 10             	add    $0x10,%esp
 659:	83 f8 ff             	cmp    $0xffffffff,%eax
 65c:	75 c0                	jne    61e <malloc+0x8a>
        return 0;
 65e:	b8 00 00 00 00       	mov    $0x0,%eax
 663:	eb ab                	jmp    610 <malloc+0x7c>
 665:	b8 00 00 00 00       	mov    $0x0,%eax
 66a:	eb a4                	jmp    610 <malloc+0x7c>
