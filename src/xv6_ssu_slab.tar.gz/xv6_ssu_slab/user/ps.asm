
user/_ps:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	83 ec 04             	sub    $0x4,%esp
	ps();
  11:	e8 7c 02 00 00       	call   292 <ps>
	printf(1, "ps\n");
  16:	83 ec 08             	sub    $0x8,%esp
  19:	68 3c 06 00 00       	push   $0x63c
  1e:	6a 01                	push   $0x1
  20:	e8 ff 02 00 00       	call   324 <printf>
    exit();
  25:	e8 c0 01 00 00       	call   1ea <exit>

0000002a <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  2a:	55                   	push   %ebp
  2b:	89 e5                	mov    %esp,%ebp
  2d:	53                   	push   %ebx
  2e:	8b 45 08             	mov    0x8(%ebp),%eax
  31:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  34:	89 c2                	mov    %eax,%edx
  36:	83 c1 01             	add    $0x1,%ecx
  39:	83 c2 01             	add    $0x1,%edx
  3c:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
  40:	88 5a ff             	mov    %bl,-0x1(%edx)
  43:	84 db                	test   %bl,%bl
  45:	75 ef                	jne    36 <strcpy+0xc>
    ;
  return os;
}
  47:	5b                   	pop    %ebx
  48:	5d                   	pop    %ebp
  49:	c3                   	ret    

0000004a <strcmp>:

int
strcmp(const char *p, const char *q)
{
  4a:	55                   	push   %ebp
  4b:	89 e5                	mov    %esp,%ebp
  4d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  50:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
  53:	0f b6 01             	movzbl (%ecx),%eax
  56:	84 c0                	test   %al,%al
  58:	74 15                	je     6f <strcmp+0x25>
  5a:	3a 02                	cmp    (%edx),%al
  5c:	75 11                	jne    6f <strcmp+0x25>
    p++, q++;
  5e:	83 c1 01             	add    $0x1,%ecx
  61:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
  64:	0f b6 01             	movzbl (%ecx),%eax
  67:	84 c0                	test   %al,%al
  69:	74 04                	je     6f <strcmp+0x25>
  6b:	3a 02                	cmp    (%edx),%al
  6d:	74 ef                	je     5e <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
  6f:	0f b6 c0             	movzbl %al,%eax
  72:	0f b6 12             	movzbl (%edx),%edx
  75:	29 d0                	sub    %edx,%eax
}
  77:	5d                   	pop    %ebp
  78:	c3                   	ret    

00000079 <strlen>:

uint
strlen(const char *s)
{
  79:	55                   	push   %ebp
  7a:	89 e5                	mov    %esp,%ebp
  7c:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
  7f:	80 39 00             	cmpb   $0x0,(%ecx)
  82:	74 12                	je     96 <strlen+0x1d>
  84:	ba 00 00 00 00       	mov    $0x0,%edx
  89:	83 c2 01             	add    $0x1,%edx
  8c:	89 d0                	mov    %edx,%eax
  8e:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
  92:	75 f5                	jne    89 <strlen+0x10>
    ;
  return n;
}
  94:	5d                   	pop    %ebp
  95:	c3                   	ret    
  for(n = 0; s[n]; n++)
  96:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
  9b:	eb f7                	jmp    94 <strlen+0x1b>

0000009d <memset>:

void*
memset(void *dst, int c, uint n)
{
  9d:	55                   	push   %ebp
  9e:	89 e5                	mov    %esp,%ebp
  a0:	57                   	push   %edi
  a1:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
  a4:	89 d7                	mov    %edx,%edi
  a6:	8b 4d 10             	mov    0x10(%ebp),%ecx
  a9:	8b 45 0c             	mov    0xc(%ebp),%eax
  ac:	fc                   	cld    
  ad:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
  af:	89 d0                	mov    %edx,%eax
  b1:	5f                   	pop    %edi
  b2:	5d                   	pop    %ebp
  b3:	c3                   	ret    

000000b4 <strchr>:

char*
strchr(const char *s, char c)
{
  b4:	55                   	push   %ebp
  b5:	89 e5                	mov    %esp,%ebp
  b7:	53                   	push   %ebx
  b8:	8b 45 08             	mov    0x8(%ebp),%eax
  bb:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
  be:	0f b6 10             	movzbl (%eax),%edx
  c1:	84 d2                	test   %dl,%dl
  c3:	74 1e                	je     e3 <strchr+0x2f>
  c5:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
  c7:	38 d3                	cmp    %dl,%bl
  c9:	74 15                	je     e0 <strchr+0x2c>
  for(; *s; s++)
  cb:	83 c0 01             	add    $0x1,%eax
  ce:	0f b6 10             	movzbl (%eax),%edx
  d1:	84 d2                	test   %dl,%dl
  d3:	74 06                	je     db <strchr+0x27>
    if(*s == c)
  d5:	38 ca                	cmp    %cl,%dl
  d7:	75 f2                	jne    cb <strchr+0x17>
  d9:	eb 05                	jmp    e0 <strchr+0x2c>
      return (char*)s;
  return 0;
  db:	b8 00 00 00 00       	mov    $0x0,%eax
}
  e0:	5b                   	pop    %ebx
  e1:	5d                   	pop    %ebp
  e2:	c3                   	ret    
  return 0;
  e3:	b8 00 00 00 00       	mov    $0x0,%eax
  e8:	eb f6                	jmp    e0 <strchr+0x2c>

000000ea <gets>:

char*
gets(char *buf, int max)
{
  ea:	55                   	push   %ebp
  eb:	89 e5                	mov    %esp,%ebp
  ed:	57                   	push   %edi
  ee:	56                   	push   %esi
  ef:	53                   	push   %ebx
  f0:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
  f3:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
  f8:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
  fb:	8d 5e 01             	lea    0x1(%esi),%ebx
  fe:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 101:	7d 2b                	jge    12e <gets+0x44>
    cc = read(0, &c, 1);
 103:	83 ec 04             	sub    $0x4,%esp
 106:	6a 01                	push   $0x1
 108:	57                   	push   %edi
 109:	6a 00                	push   $0x0
 10b:	e8 f2 00 00 00       	call   202 <read>
    if(cc < 1)
 110:	83 c4 10             	add    $0x10,%esp
 113:	85 c0                	test   %eax,%eax
 115:	7e 17                	jle    12e <gets+0x44>
      break;
    buf[i++] = c;
 117:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 11b:	8b 55 08             	mov    0x8(%ebp),%edx
 11e:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 122:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 124:	3c 0a                	cmp    $0xa,%al
 126:	74 04                	je     12c <gets+0x42>
 128:	3c 0d                	cmp    $0xd,%al
 12a:	75 cf                	jne    fb <gets+0x11>
  for(i=0; i+1 < max; ){
 12c:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 12e:	8b 45 08             	mov    0x8(%ebp),%eax
 131:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 135:	8d 65 f4             	lea    -0xc(%ebp),%esp
 138:	5b                   	pop    %ebx
 139:	5e                   	pop    %esi
 13a:	5f                   	pop    %edi
 13b:	5d                   	pop    %ebp
 13c:	c3                   	ret    

0000013d <stat>:

int
stat(const char *n, struct stat *st)
{
 13d:	55                   	push   %ebp
 13e:	89 e5                	mov    %esp,%ebp
 140:	56                   	push   %esi
 141:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 142:	83 ec 08             	sub    $0x8,%esp
 145:	6a 00                	push   $0x0
 147:	ff 75 08             	pushl  0x8(%ebp)
 14a:	e8 db 00 00 00       	call   22a <open>
  if(fd < 0)
 14f:	83 c4 10             	add    $0x10,%esp
 152:	85 c0                	test   %eax,%eax
 154:	78 24                	js     17a <stat+0x3d>
 156:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 158:	83 ec 08             	sub    $0x8,%esp
 15b:	ff 75 0c             	pushl  0xc(%ebp)
 15e:	50                   	push   %eax
 15f:	e8 de 00 00 00       	call   242 <fstat>
 164:	89 c6                	mov    %eax,%esi
  close(fd);
 166:	89 1c 24             	mov    %ebx,(%esp)
 169:	e8 a4 00 00 00       	call   212 <close>
  return r;
 16e:	83 c4 10             	add    $0x10,%esp
}
 171:	89 f0                	mov    %esi,%eax
 173:	8d 65 f8             	lea    -0x8(%ebp),%esp
 176:	5b                   	pop    %ebx
 177:	5e                   	pop    %esi
 178:	5d                   	pop    %ebp
 179:	c3                   	ret    
    return -1;
 17a:	be ff ff ff ff       	mov    $0xffffffff,%esi
 17f:	eb f0                	jmp    171 <stat+0x34>

00000181 <atoi>:

int
atoi(const char *s)
{
 181:	55                   	push   %ebp
 182:	89 e5                	mov    %esp,%ebp
 184:	53                   	push   %ebx
 185:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 188:	0f b6 11             	movzbl (%ecx),%edx
 18b:	8d 42 d0             	lea    -0x30(%edx),%eax
 18e:	3c 09                	cmp    $0x9,%al
 190:	77 20                	ja     1b2 <atoi+0x31>
  n = 0;
 192:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 197:	83 c1 01             	add    $0x1,%ecx
 19a:	8d 04 80             	lea    (%eax,%eax,4),%eax
 19d:	0f be d2             	movsbl %dl,%edx
 1a0:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 1a4:	0f b6 11             	movzbl (%ecx),%edx
 1a7:	8d 5a d0             	lea    -0x30(%edx),%ebx
 1aa:	80 fb 09             	cmp    $0x9,%bl
 1ad:	76 e8                	jbe    197 <atoi+0x16>
  return n;
}
 1af:	5b                   	pop    %ebx
 1b0:	5d                   	pop    %ebp
 1b1:	c3                   	ret    
  n = 0;
 1b2:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 1b7:	eb f6                	jmp    1af <atoi+0x2e>

000001b9 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1b9:	55                   	push   %ebp
 1ba:	89 e5                	mov    %esp,%ebp
 1bc:	56                   	push   %esi
 1bd:	53                   	push   %ebx
 1be:	8b 45 08             	mov    0x8(%ebp),%eax
 1c1:	8b 75 0c             	mov    0xc(%ebp),%esi
 1c4:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 1c7:	85 db                	test   %ebx,%ebx
 1c9:	7e 13                	jle    1de <memmove+0x25>
 1cb:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 1d0:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 1d4:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 1d7:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 1da:	39 d3                	cmp    %edx,%ebx
 1dc:	75 f2                	jne    1d0 <memmove+0x17>
  return vdst;
}
 1de:	5b                   	pop    %ebx
 1df:	5e                   	pop    %esi
 1e0:	5d                   	pop    %ebp
 1e1:	c3                   	ret    

000001e2 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 1e2:	b8 01 00 00 00       	mov    $0x1,%eax
 1e7:	cd 40                	int    $0x40
 1e9:	c3                   	ret    

000001ea <exit>:
SYSCALL(exit)
 1ea:	b8 02 00 00 00       	mov    $0x2,%eax
 1ef:	cd 40                	int    $0x40
 1f1:	c3                   	ret    

000001f2 <wait>:
SYSCALL(wait)
 1f2:	b8 03 00 00 00       	mov    $0x3,%eax
 1f7:	cd 40                	int    $0x40
 1f9:	c3                   	ret    

000001fa <pipe>:
SYSCALL(pipe)
 1fa:	b8 04 00 00 00       	mov    $0x4,%eax
 1ff:	cd 40                	int    $0x40
 201:	c3                   	ret    

00000202 <read>:
SYSCALL(read)
 202:	b8 05 00 00 00       	mov    $0x5,%eax
 207:	cd 40                	int    $0x40
 209:	c3                   	ret    

0000020a <write>:
SYSCALL(write)
 20a:	b8 10 00 00 00       	mov    $0x10,%eax
 20f:	cd 40                	int    $0x40
 211:	c3                   	ret    

00000212 <close>:
SYSCALL(close)
 212:	b8 15 00 00 00       	mov    $0x15,%eax
 217:	cd 40                	int    $0x40
 219:	c3                   	ret    

0000021a <kill>:
SYSCALL(kill)
 21a:	b8 06 00 00 00       	mov    $0x6,%eax
 21f:	cd 40                	int    $0x40
 221:	c3                   	ret    

00000222 <exec>:
SYSCALL(exec)
 222:	b8 07 00 00 00       	mov    $0x7,%eax
 227:	cd 40                	int    $0x40
 229:	c3                   	ret    

0000022a <open>:
SYSCALL(open)
 22a:	b8 0f 00 00 00       	mov    $0xf,%eax
 22f:	cd 40                	int    $0x40
 231:	c3                   	ret    

00000232 <mknod>:
SYSCALL(mknod)
 232:	b8 11 00 00 00       	mov    $0x11,%eax
 237:	cd 40                	int    $0x40
 239:	c3                   	ret    

0000023a <unlink>:
SYSCALL(unlink)
 23a:	b8 12 00 00 00       	mov    $0x12,%eax
 23f:	cd 40                	int    $0x40
 241:	c3                   	ret    

00000242 <fstat>:
SYSCALL(fstat)
 242:	b8 08 00 00 00       	mov    $0x8,%eax
 247:	cd 40                	int    $0x40
 249:	c3                   	ret    

0000024a <link>:
SYSCALL(link)
 24a:	b8 13 00 00 00       	mov    $0x13,%eax
 24f:	cd 40                	int    $0x40
 251:	c3                   	ret    

00000252 <mkdir>:
SYSCALL(mkdir)
 252:	b8 14 00 00 00       	mov    $0x14,%eax
 257:	cd 40                	int    $0x40
 259:	c3                   	ret    

0000025a <chdir>:
SYSCALL(chdir)
 25a:	b8 09 00 00 00       	mov    $0x9,%eax
 25f:	cd 40                	int    $0x40
 261:	c3                   	ret    

00000262 <dup>:
SYSCALL(dup)
 262:	b8 0a 00 00 00       	mov    $0xa,%eax
 267:	cd 40                	int    $0x40
 269:	c3                   	ret    

0000026a <getpid>:
SYSCALL(getpid)
 26a:	b8 0b 00 00 00       	mov    $0xb,%eax
 26f:	cd 40                	int    $0x40
 271:	c3                   	ret    

00000272 <sbrk>:
SYSCALL(sbrk)
 272:	b8 0c 00 00 00       	mov    $0xc,%eax
 277:	cd 40                	int    $0x40
 279:	c3                   	ret    

0000027a <sleep>:
SYSCALL(sleep)
 27a:	b8 0d 00 00 00       	mov    $0xd,%eax
 27f:	cd 40                	int    $0x40
 281:	c3                   	ret    

00000282 <uptime>:
SYSCALL(uptime)
 282:	b8 0e 00 00 00       	mov    $0xe,%eax
 287:	cd 40                	int    $0x40
 289:	c3                   	ret    

0000028a <slabtest>:
SYSCALL(slabtest)
 28a:	b8 16 00 00 00       	mov    $0x16,%eax
 28f:	cd 40                	int    $0x40
 291:	c3                   	ret    

00000292 <ps>:
SYSCALL(ps)
 292:	b8 17 00 00 00       	mov    $0x17,%eax
 297:	cd 40                	int    $0x40
 299:	c3                   	ret    

0000029a <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 29a:	55                   	push   %ebp
 29b:	89 e5                	mov    %esp,%ebp
 29d:	57                   	push   %edi
 29e:	56                   	push   %esi
 29f:	53                   	push   %ebx
 2a0:	83 ec 3c             	sub    $0x3c,%esp
 2a3:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 2a5:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 2a9:	74 14                	je     2bf <printint+0x25>
 2ab:	85 d2                	test   %edx,%edx
 2ad:	79 10                	jns    2bf <printint+0x25>
    neg = 1;
    x = -xx;
 2af:	f7 da                	neg    %edx
    neg = 1;
 2b1:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 2b8:	bf 00 00 00 00       	mov    $0x0,%edi
 2bd:	eb 0b                	jmp    2ca <printint+0x30>
  neg = 0;
 2bf:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 2c6:	eb f0                	jmp    2b8 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 2c8:	89 df                	mov    %ebx,%edi
 2ca:	8d 5f 01             	lea    0x1(%edi),%ebx
 2cd:	89 d0                	mov    %edx,%eax
 2cf:	ba 00 00 00 00       	mov    $0x0,%edx
 2d4:	f7 f1                	div    %ecx
 2d6:	0f b6 92 48 06 00 00 	movzbl 0x648(%edx),%edx
 2dd:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 2e1:	89 c2                	mov    %eax,%edx
 2e3:	85 c0                	test   %eax,%eax
 2e5:	75 e1                	jne    2c8 <printint+0x2e>
  if(neg)
 2e7:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 2eb:	74 08                	je     2f5 <printint+0x5b>
    buf[i++] = '-';
 2ed:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 2f2:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 2f5:	83 eb 01             	sub    $0x1,%ebx
 2f8:	78 22                	js     31c <printint+0x82>
  write(fd, &c, 1);
 2fa:	8d 7d d7             	lea    -0x29(%ebp),%edi
 2fd:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 302:	88 45 d7             	mov    %al,-0x29(%ebp)
 305:	83 ec 04             	sub    $0x4,%esp
 308:	6a 01                	push   $0x1
 30a:	57                   	push   %edi
 30b:	56                   	push   %esi
 30c:	e8 f9 fe ff ff       	call   20a <write>
  while(--i >= 0)
 311:	83 eb 01             	sub    $0x1,%ebx
 314:	83 c4 10             	add    $0x10,%esp
 317:	83 fb ff             	cmp    $0xffffffff,%ebx
 31a:	75 e1                	jne    2fd <printint+0x63>
    putc(fd, buf[i]);
}
 31c:	8d 65 f4             	lea    -0xc(%ebp),%esp
 31f:	5b                   	pop    %ebx
 320:	5e                   	pop    %esi
 321:	5f                   	pop    %edi
 322:	5d                   	pop    %ebp
 323:	c3                   	ret    

00000324 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 324:	55                   	push   %ebp
 325:	89 e5                	mov    %esp,%ebp
 327:	57                   	push   %edi
 328:	56                   	push   %esi
 329:	53                   	push   %ebx
 32a:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 32d:	8b 75 0c             	mov    0xc(%ebp),%esi
 330:	0f b6 1e             	movzbl (%esi),%ebx
 333:	84 db                	test   %bl,%bl
 335:	0f 84 b1 01 00 00    	je     4ec <printf+0x1c8>
 33b:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 33e:	8d 45 10             	lea    0x10(%ebp),%eax
 341:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 344:	bf 00 00 00 00       	mov    $0x0,%edi
 349:	eb 2d                	jmp    378 <printf+0x54>
 34b:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 34e:	83 ec 04             	sub    $0x4,%esp
 351:	6a 01                	push   $0x1
 353:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 356:	50                   	push   %eax
 357:	ff 75 08             	pushl  0x8(%ebp)
 35a:	e8 ab fe ff ff       	call   20a <write>
 35f:	83 c4 10             	add    $0x10,%esp
 362:	eb 05                	jmp    369 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 364:	83 ff 25             	cmp    $0x25,%edi
 367:	74 22                	je     38b <printf+0x67>
 369:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 36c:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 370:	84 db                	test   %bl,%bl
 372:	0f 84 74 01 00 00    	je     4ec <printf+0x1c8>
    c = fmt[i] & 0xff;
 378:	0f be d3             	movsbl %bl,%edx
 37b:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 37e:	85 ff                	test   %edi,%edi
 380:	75 e2                	jne    364 <printf+0x40>
      if(c == '%'){
 382:	83 f8 25             	cmp    $0x25,%eax
 385:	75 c4                	jne    34b <printf+0x27>
        state = '%';
 387:	89 c7                	mov    %eax,%edi
 389:	eb de                	jmp    369 <printf+0x45>
      if(c == 'd'){
 38b:	83 f8 64             	cmp    $0x64,%eax
 38e:	74 59                	je     3e9 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 390:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 396:	83 fa 70             	cmp    $0x70,%edx
 399:	74 7a                	je     415 <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 39b:	83 f8 73             	cmp    $0x73,%eax
 39e:	0f 84 9d 00 00 00    	je     441 <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 3a4:	83 f8 63             	cmp    $0x63,%eax
 3a7:	0f 84 f2 00 00 00    	je     49f <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 3ad:	83 f8 25             	cmp    $0x25,%eax
 3b0:	0f 84 15 01 00 00    	je     4cb <printf+0x1a7>
 3b6:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 3ba:	83 ec 04             	sub    $0x4,%esp
 3bd:	6a 01                	push   $0x1
 3bf:	8d 45 e7             	lea    -0x19(%ebp),%eax
 3c2:	50                   	push   %eax
 3c3:	ff 75 08             	pushl  0x8(%ebp)
 3c6:	e8 3f fe ff ff       	call   20a <write>
 3cb:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 3ce:	83 c4 0c             	add    $0xc,%esp
 3d1:	6a 01                	push   $0x1
 3d3:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 3d6:	50                   	push   %eax
 3d7:	ff 75 08             	pushl  0x8(%ebp)
 3da:	e8 2b fe ff ff       	call   20a <write>
 3df:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 3e2:	bf 00 00 00 00       	mov    $0x0,%edi
 3e7:	eb 80                	jmp    369 <printf+0x45>
        printint(fd, *ap, 10, 1);
 3e9:	83 ec 0c             	sub    $0xc,%esp
 3ec:	6a 01                	push   $0x1
 3ee:	b9 0a 00 00 00       	mov    $0xa,%ecx
 3f3:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 3f6:	8b 17                	mov    (%edi),%edx
 3f8:	8b 45 08             	mov    0x8(%ebp),%eax
 3fb:	e8 9a fe ff ff       	call   29a <printint>
        ap++;
 400:	89 f8                	mov    %edi,%eax
 402:	83 c0 04             	add    $0x4,%eax
 405:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 408:	83 c4 10             	add    $0x10,%esp
      state = 0;
 40b:	bf 00 00 00 00       	mov    $0x0,%edi
 410:	e9 54 ff ff ff       	jmp    369 <printf+0x45>
        printint(fd, *ap, 16, 0);
 415:	83 ec 0c             	sub    $0xc,%esp
 418:	6a 00                	push   $0x0
 41a:	b9 10 00 00 00       	mov    $0x10,%ecx
 41f:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 422:	8b 17                	mov    (%edi),%edx
 424:	8b 45 08             	mov    0x8(%ebp),%eax
 427:	e8 6e fe ff ff       	call   29a <printint>
        ap++;
 42c:	89 f8                	mov    %edi,%eax
 42e:	83 c0 04             	add    $0x4,%eax
 431:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 434:	83 c4 10             	add    $0x10,%esp
      state = 0;
 437:	bf 00 00 00 00       	mov    $0x0,%edi
 43c:	e9 28 ff ff ff       	jmp    369 <printf+0x45>
        s = (char*)*ap;
 441:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 444:	8b 01                	mov    (%ecx),%eax
        ap++;
 446:	83 c1 04             	add    $0x4,%ecx
 449:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 44c:	85 c0                	test   %eax,%eax
 44e:	74 13                	je     463 <printf+0x13f>
        s = (char*)*ap;
 450:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 452:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 455:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 45a:	84 c0                	test   %al,%al
 45c:	75 0f                	jne    46d <printf+0x149>
 45e:	e9 06 ff ff ff       	jmp    369 <printf+0x45>
          s = "(null)";
 463:	bb 40 06 00 00       	mov    $0x640,%ebx
        while(*s != 0){
 468:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 46d:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 470:	89 75 d0             	mov    %esi,-0x30(%ebp)
 473:	8b 75 08             	mov    0x8(%ebp),%esi
 476:	88 45 e3             	mov    %al,-0x1d(%ebp)
 479:	83 ec 04             	sub    $0x4,%esp
 47c:	6a 01                	push   $0x1
 47e:	57                   	push   %edi
 47f:	56                   	push   %esi
 480:	e8 85 fd ff ff       	call   20a <write>
          s++;
 485:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 488:	0f b6 03             	movzbl (%ebx),%eax
 48b:	83 c4 10             	add    $0x10,%esp
 48e:	84 c0                	test   %al,%al
 490:	75 e4                	jne    476 <printf+0x152>
 492:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 495:	bf 00 00 00 00       	mov    $0x0,%edi
 49a:	e9 ca fe ff ff       	jmp    369 <printf+0x45>
        putc(fd, *ap);
 49f:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4a2:	8b 07                	mov    (%edi),%eax
 4a4:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 4a7:	83 ec 04             	sub    $0x4,%esp
 4aa:	6a 01                	push   $0x1
 4ac:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 4af:	50                   	push   %eax
 4b0:	ff 75 08             	pushl  0x8(%ebp)
 4b3:	e8 52 fd ff ff       	call   20a <write>
        ap++;
 4b8:	83 c7 04             	add    $0x4,%edi
 4bb:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4be:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4c1:	bf 00 00 00 00       	mov    $0x0,%edi
 4c6:	e9 9e fe ff ff       	jmp    369 <printf+0x45>
 4cb:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 4ce:	83 ec 04             	sub    $0x4,%esp
 4d1:	6a 01                	push   $0x1
 4d3:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 4d6:	50                   	push   %eax
 4d7:	ff 75 08             	pushl  0x8(%ebp)
 4da:	e8 2b fd ff ff       	call   20a <write>
 4df:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4e2:	bf 00 00 00 00       	mov    $0x0,%edi
 4e7:	e9 7d fe ff ff       	jmp    369 <printf+0x45>
    }
  }
}
 4ec:	8d 65 f4             	lea    -0xc(%ebp),%esp
 4ef:	5b                   	pop    %ebx
 4f0:	5e                   	pop    %esi
 4f1:	5f                   	pop    %edi
 4f2:	5d                   	pop    %ebp
 4f3:	c3                   	ret    

000004f4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 4f4:	55                   	push   %ebp
 4f5:	89 e5                	mov    %esp,%ebp
 4f7:	57                   	push   %edi
 4f8:	56                   	push   %esi
 4f9:	53                   	push   %ebx
 4fa:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 4fd:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 500:	a1 b0 08 00 00       	mov    0x8b0,%eax
 505:	eb 0c                	jmp    513 <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 507:	8b 10                	mov    (%eax),%edx
 509:	39 c2                	cmp    %eax,%edx
 50b:	77 04                	ja     511 <free+0x1d>
 50d:	39 ca                	cmp    %ecx,%edx
 50f:	77 10                	ja     521 <free+0x2d>
{
 511:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 513:	39 c8                	cmp    %ecx,%eax
 515:	73 f0                	jae    507 <free+0x13>
 517:	8b 10                	mov    (%eax),%edx
 519:	39 ca                	cmp    %ecx,%edx
 51b:	77 04                	ja     521 <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 51d:	39 c2                	cmp    %eax,%edx
 51f:	77 f0                	ja     511 <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 521:	8b 73 fc             	mov    -0x4(%ebx),%esi
 524:	8b 10                	mov    (%eax),%edx
 526:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 529:	39 fa                	cmp    %edi,%edx
 52b:	74 19                	je     546 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 52d:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 530:	8b 50 04             	mov    0x4(%eax),%edx
 533:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 536:	39 f1                	cmp    %esi,%ecx
 538:	74 1b                	je     555 <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 53a:	89 08                	mov    %ecx,(%eax)
  freep = p;
 53c:	a3 b0 08 00 00       	mov    %eax,0x8b0
}
 541:	5b                   	pop    %ebx
 542:	5e                   	pop    %esi
 543:	5f                   	pop    %edi
 544:	5d                   	pop    %ebp
 545:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 546:	03 72 04             	add    0x4(%edx),%esi
 549:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 54c:	8b 10                	mov    (%eax),%edx
 54e:	8b 12                	mov    (%edx),%edx
 550:	89 53 f8             	mov    %edx,-0x8(%ebx)
 553:	eb db                	jmp    530 <free+0x3c>
    p->s.size += bp->s.size;
 555:	03 53 fc             	add    -0x4(%ebx),%edx
 558:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 55b:	8b 53 f8             	mov    -0x8(%ebx),%edx
 55e:	89 10                	mov    %edx,(%eax)
 560:	eb da                	jmp    53c <free+0x48>

00000562 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 562:	55                   	push   %ebp
 563:	89 e5                	mov    %esp,%ebp
 565:	57                   	push   %edi
 566:	56                   	push   %esi
 567:	53                   	push   %ebx
 568:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 56b:	8b 45 08             	mov    0x8(%ebp),%eax
 56e:	8d 58 07             	lea    0x7(%eax),%ebx
 571:	c1 eb 03             	shr    $0x3,%ebx
 574:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 577:	8b 15 b0 08 00 00    	mov    0x8b0,%edx
 57d:	85 d2                	test   %edx,%edx
 57f:	74 20                	je     5a1 <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 581:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 583:	8b 48 04             	mov    0x4(%eax),%ecx
 586:	39 cb                	cmp    %ecx,%ebx
 588:	76 3c                	jbe    5c6 <malloc+0x64>
 58a:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 590:	be 00 10 00 00       	mov    $0x1000,%esi
 595:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 598:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 59f:	eb 70                	jmp    611 <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 5a1:	c7 05 b0 08 00 00 b4 	movl   $0x8b4,0x8b0
 5a8:	08 00 00 
 5ab:	c7 05 b4 08 00 00 b4 	movl   $0x8b4,0x8b4
 5b2:	08 00 00 
    base.s.size = 0;
 5b5:	c7 05 b8 08 00 00 00 	movl   $0x0,0x8b8
 5bc:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 5bf:	ba b4 08 00 00       	mov    $0x8b4,%edx
 5c4:	eb bb                	jmp    581 <malloc+0x1f>
      if(p->s.size == nunits)
 5c6:	39 cb                	cmp    %ecx,%ebx
 5c8:	74 1c                	je     5e6 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 5ca:	29 d9                	sub    %ebx,%ecx
 5cc:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 5cf:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 5d2:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 5d5:	89 15 b0 08 00 00    	mov    %edx,0x8b0
      return (void*)(p + 1);
 5db:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 5de:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5e1:	5b                   	pop    %ebx
 5e2:	5e                   	pop    %esi
 5e3:	5f                   	pop    %edi
 5e4:	5d                   	pop    %ebp
 5e5:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 5e6:	8b 08                	mov    (%eax),%ecx
 5e8:	89 0a                	mov    %ecx,(%edx)
 5ea:	eb e9                	jmp    5d5 <malloc+0x73>
  hp->s.size = nu;
 5ec:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 5ef:	83 ec 0c             	sub    $0xc,%esp
 5f2:	83 c0 08             	add    $0x8,%eax
 5f5:	50                   	push   %eax
 5f6:	e8 f9 fe ff ff       	call   4f4 <free>
  return freep;
 5fb:	8b 15 b0 08 00 00    	mov    0x8b0,%edx
      if((p = morecore(nunits)) == 0)
 601:	83 c4 10             	add    $0x10,%esp
 604:	85 d2                	test   %edx,%edx
 606:	74 2b                	je     633 <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 608:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 60a:	8b 48 04             	mov    0x4(%eax),%ecx
 60d:	39 d9                	cmp    %ebx,%ecx
 60f:	73 b5                	jae    5c6 <malloc+0x64>
 611:	89 c2                	mov    %eax,%edx
    if(p == freep)
 613:	39 05 b0 08 00 00    	cmp    %eax,0x8b0
 619:	75 ed                	jne    608 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 61b:	83 ec 0c             	sub    $0xc,%esp
 61e:	57                   	push   %edi
 61f:	e8 4e fc ff ff       	call   272 <sbrk>
  if(p == (char*)-1)
 624:	83 c4 10             	add    $0x10,%esp
 627:	83 f8 ff             	cmp    $0xffffffff,%eax
 62a:	75 c0                	jne    5ec <malloc+0x8a>
        return 0;
 62c:	b8 00 00 00 00       	mov    $0x0,%eax
 631:	eb ab                	jmp    5de <malloc+0x7c>
 633:	b8 00 00 00 00       	mov    $0x0,%eax
 638:	eb a4                	jmp    5de <malloc+0x7c>
