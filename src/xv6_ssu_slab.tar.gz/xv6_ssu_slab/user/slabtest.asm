
user/_slabtest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	83 ec 04             	sub    $0x4,%esp
	slabtest();
  11:	e8 65 02 00 00       	call   27b <slabtest>

	exit();
  16:	e8 c0 01 00 00       	call   1db <exit>

0000001b <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
  1b:	55                   	push   %ebp
  1c:	89 e5                	mov    %esp,%ebp
  1e:	53                   	push   %ebx
  1f:	8b 45 08             	mov    0x8(%ebp),%eax
  22:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  25:	89 c2                	mov    %eax,%edx
  27:	83 c1 01             	add    $0x1,%ecx
  2a:	83 c2 01             	add    $0x1,%edx
  2d:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
  31:	88 5a ff             	mov    %bl,-0x1(%edx)
  34:	84 db                	test   %bl,%bl
  36:	75 ef                	jne    27 <strcpy+0xc>
    ;
  return os;
}
  38:	5b                   	pop    %ebx
  39:	5d                   	pop    %ebp
  3a:	c3                   	ret    

0000003b <strcmp>:

int
strcmp(const char *p, const char *q)
{
  3b:	55                   	push   %ebp
  3c:	89 e5                	mov    %esp,%ebp
  3e:	8b 4d 08             	mov    0x8(%ebp),%ecx
  41:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
  44:	0f b6 01             	movzbl (%ecx),%eax
  47:	84 c0                	test   %al,%al
  49:	74 15                	je     60 <strcmp+0x25>
  4b:	3a 02                	cmp    (%edx),%al
  4d:	75 11                	jne    60 <strcmp+0x25>
    p++, q++;
  4f:	83 c1 01             	add    $0x1,%ecx
  52:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
  55:	0f b6 01             	movzbl (%ecx),%eax
  58:	84 c0                	test   %al,%al
  5a:	74 04                	je     60 <strcmp+0x25>
  5c:	3a 02                	cmp    (%edx),%al
  5e:	74 ef                	je     4f <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
  60:	0f b6 c0             	movzbl %al,%eax
  63:	0f b6 12             	movzbl (%edx),%edx
  66:	29 d0                	sub    %edx,%eax
}
  68:	5d                   	pop    %ebp
  69:	c3                   	ret    

0000006a <strlen>:

uint
strlen(const char *s)
{
  6a:	55                   	push   %ebp
  6b:	89 e5                	mov    %esp,%ebp
  6d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
  70:	80 39 00             	cmpb   $0x0,(%ecx)
  73:	74 12                	je     87 <strlen+0x1d>
  75:	ba 00 00 00 00       	mov    $0x0,%edx
  7a:	83 c2 01             	add    $0x1,%edx
  7d:	89 d0                	mov    %edx,%eax
  7f:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
  83:	75 f5                	jne    7a <strlen+0x10>
    ;
  return n;
}
  85:	5d                   	pop    %ebp
  86:	c3                   	ret    
  for(n = 0; s[n]; n++)
  87:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
  8c:	eb f7                	jmp    85 <strlen+0x1b>

0000008e <memset>:

void*
memset(void *dst, int c, uint n)
{
  8e:	55                   	push   %ebp
  8f:	89 e5                	mov    %esp,%ebp
  91:	57                   	push   %edi
  92:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
  95:	89 d7                	mov    %edx,%edi
  97:	8b 4d 10             	mov    0x10(%ebp),%ecx
  9a:	8b 45 0c             	mov    0xc(%ebp),%eax
  9d:	fc                   	cld    
  9e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
  a0:	89 d0                	mov    %edx,%eax
  a2:	5f                   	pop    %edi
  a3:	5d                   	pop    %ebp
  a4:	c3                   	ret    

000000a5 <strchr>:

char*
strchr(const char *s, char c)
{
  a5:	55                   	push   %ebp
  a6:	89 e5                	mov    %esp,%ebp
  a8:	53                   	push   %ebx
  a9:	8b 45 08             	mov    0x8(%ebp),%eax
  ac:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
  af:	0f b6 10             	movzbl (%eax),%edx
  b2:	84 d2                	test   %dl,%dl
  b4:	74 1e                	je     d4 <strchr+0x2f>
  b6:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
  b8:	38 d3                	cmp    %dl,%bl
  ba:	74 15                	je     d1 <strchr+0x2c>
  for(; *s; s++)
  bc:	83 c0 01             	add    $0x1,%eax
  bf:	0f b6 10             	movzbl (%eax),%edx
  c2:	84 d2                	test   %dl,%dl
  c4:	74 06                	je     cc <strchr+0x27>
    if(*s == c)
  c6:	38 ca                	cmp    %cl,%dl
  c8:	75 f2                	jne    bc <strchr+0x17>
  ca:	eb 05                	jmp    d1 <strchr+0x2c>
      return (char*)s;
  return 0;
  cc:	b8 00 00 00 00       	mov    $0x0,%eax
}
  d1:	5b                   	pop    %ebx
  d2:	5d                   	pop    %ebp
  d3:	c3                   	ret    
  return 0;
  d4:	b8 00 00 00 00       	mov    $0x0,%eax
  d9:	eb f6                	jmp    d1 <strchr+0x2c>

000000db <gets>:

char*
gets(char *buf, int max)
{
  db:	55                   	push   %ebp
  dc:	89 e5                	mov    %esp,%ebp
  de:	57                   	push   %edi
  df:	56                   	push   %esi
  e0:	53                   	push   %ebx
  e1:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
  e4:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
  e9:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
  ec:	8d 5e 01             	lea    0x1(%esi),%ebx
  ef:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
  f2:	7d 2b                	jge    11f <gets+0x44>
    cc = read(0, &c, 1);
  f4:	83 ec 04             	sub    $0x4,%esp
  f7:	6a 01                	push   $0x1
  f9:	57                   	push   %edi
  fa:	6a 00                	push   $0x0
  fc:	e8 f2 00 00 00       	call   1f3 <read>
    if(cc < 1)
 101:	83 c4 10             	add    $0x10,%esp
 104:	85 c0                	test   %eax,%eax
 106:	7e 17                	jle    11f <gets+0x44>
      break;
    buf[i++] = c;
 108:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 10c:	8b 55 08             	mov    0x8(%ebp),%edx
 10f:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 113:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 115:	3c 0a                	cmp    $0xa,%al
 117:	74 04                	je     11d <gets+0x42>
 119:	3c 0d                	cmp    $0xd,%al
 11b:	75 cf                	jne    ec <gets+0x11>
  for(i=0; i+1 < max; ){
 11d:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 11f:	8b 45 08             	mov    0x8(%ebp),%eax
 122:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 126:	8d 65 f4             	lea    -0xc(%ebp),%esp
 129:	5b                   	pop    %ebx
 12a:	5e                   	pop    %esi
 12b:	5f                   	pop    %edi
 12c:	5d                   	pop    %ebp
 12d:	c3                   	ret    

0000012e <stat>:

int
stat(const char *n, struct stat *st)
{
 12e:	55                   	push   %ebp
 12f:	89 e5                	mov    %esp,%ebp
 131:	56                   	push   %esi
 132:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 133:	83 ec 08             	sub    $0x8,%esp
 136:	6a 00                	push   $0x0
 138:	ff 75 08             	pushl  0x8(%ebp)
 13b:	e8 db 00 00 00       	call   21b <open>
  if(fd < 0)
 140:	83 c4 10             	add    $0x10,%esp
 143:	85 c0                	test   %eax,%eax
 145:	78 24                	js     16b <stat+0x3d>
 147:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 149:	83 ec 08             	sub    $0x8,%esp
 14c:	ff 75 0c             	pushl  0xc(%ebp)
 14f:	50                   	push   %eax
 150:	e8 de 00 00 00       	call   233 <fstat>
 155:	89 c6                	mov    %eax,%esi
  close(fd);
 157:	89 1c 24             	mov    %ebx,(%esp)
 15a:	e8 a4 00 00 00       	call   203 <close>
  return r;
 15f:	83 c4 10             	add    $0x10,%esp
}
 162:	89 f0                	mov    %esi,%eax
 164:	8d 65 f8             	lea    -0x8(%ebp),%esp
 167:	5b                   	pop    %ebx
 168:	5e                   	pop    %esi
 169:	5d                   	pop    %ebp
 16a:	c3                   	ret    
    return -1;
 16b:	be ff ff ff ff       	mov    $0xffffffff,%esi
 170:	eb f0                	jmp    162 <stat+0x34>

00000172 <atoi>:

int
atoi(const char *s)
{
 172:	55                   	push   %ebp
 173:	89 e5                	mov    %esp,%ebp
 175:	53                   	push   %ebx
 176:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 179:	0f b6 11             	movzbl (%ecx),%edx
 17c:	8d 42 d0             	lea    -0x30(%edx),%eax
 17f:	3c 09                	cmp    $0x9,%al
 181:	77 20                	ja     1a3 <atoi+0x31>
  n = 0;
 183:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 188:	83 c1 01             	add    $0x1,%ecx
 18b:	8d 04 80             	lea    (%eax,%eax,4),%eax
 18e:	0f be d2             	movsbl %dl,%edx
 191:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 195:	0f b6 11             	movzbl (%ecx),%edx
 198:	8d 5a d0             	lea    -0x30(%edx),%ebx
 19b:	80 fb 09             	cmp    $0x9,%bl
 19e:	76 e8                	jbe    188 <atoi+0x16>
  return n;
}
 1a0:	5b                   	pop    %ebx
 1a1:	5d                   	pop    %ebp
 1a2:	c3                   	ret    
  n = 0;
 1a3:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 1a8:	eb f6                	jmp    1a0 <atoi+0x2e>

000001aa <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1aa:	55                   	push   %ebp
 1ab:	89 e5                	mov    %esp,%ebp
 1ad:	56                   	push   %esi
 1ae:	53                   	push   %ebx
 1af:	8b 45 08             	mov    0x8(%ebp),%eax
 1b2:	8b 75 0c             	mov    0xc(%ebp),%esi
 1b5:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 1b8:	85 db                	test   %ebx,%ebx
 1ba:	7e 13                	jle    1cf <memmove+0x25>
 1bc:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 1c1:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 1c5:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 1c8:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 1cb:	39 d3                	cmp    %edx,%ebx
 1cd:	75 f2                	jne    1c1 <memmove+0x17>
  return vdst;
}
 1cf:	5b                   	pop    %ebx
 1d0:	5e                   	pop    %esi
 1d1:	5d                   	pop    %ebp
 1d2:	c3                   	ret    

000001d3 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 1d3:	b8 01 00 00 00       	mov    $0x1,%eax
 1d8:	cd 40                	int    $0x40
 1da:	c3                   	ret    

000001db <exit>:
SYSCALL(exit)
 1db:	b8 02 00 00 00       	mov    $0x2,%eax
 1e0:	cd 40                	int    $0x40
 1e2:	c3                   	ret    

000001e3 <wait>:
SYSCALL(wait)
 1e3:	b8 03 00 00 00       	mov    $0x3,%eax
 1e8:	cd 40                	int    $0x40
 1ea:	c3                   	ret    

000001eb <pipe>:
SYSCALL(pipe)
 1eb:	b8 04 00 00 00       	mov    $0x4,%eax
 1f0:	cd 40                	int    $0x40
 1f2:	c3                   	ret    

000001f3 <read>:
SYSCALL(read)
 1f3:	b8 05 00 00 00       	mov    $0x5,%eax
 1f8:	cd 40                	int    $0x40
 1fa:	c3                   	ret    

000001fb <write>:
SYSCALL(write)
 1fb:	b8 10 00 00 00       	mov    $0x10,%eax
 200:	cd 40                	int    $0x40
 202:	c3                   	ret    

00000203 <close>:
SYSCALL(close)
 203:	b8 15 00 00 00       	mov    $0x15,%eax
 208:	cd 40                	int    $0x40
 20a:	c3                   	ret    

0000020b <kill>:
SYSCALL(kill)
 20b:	b8 06 00 00 00       	mov    $0x6,%eax
 210:	cd 40                	int    $0x40
 212:	c3                   	ret    

00000213 <exec>:
SYSCALL(exec)
 213:	b8 07 00 00 00       	mov    $0x7,%eax
 218:	cd 40                	int    $0x40
 21a:	c3                   	ret    

0000021b <open>:
SYSCALL(open)
 21b:	b8 0f 00 00 00       	mov    $0xf,%eax
 220:	cd 40                	int    $0x40
 222:	c3                   	ret    

00000223 <mknod>:
SYSCALL(mknod)
 223:	b8 11 00 00 00       	mov    $0x11,%eax
 228:	cd 40                	int    $0x40
 22a:	c3                   	ret    

0000022b <unlink>:
SYSCALL(unlink)
 22b:	b8 12 00 00 00       	mov    $0x12,%eax
 230:	cd 40                	int    $0x40
 232:	c3                   	ret    

00000233 <fstat>:
SYSCALL(fstat)
 233:	b8 08 00 00 00       	mov    $0x8,%eax
 238:	cd 40                	int    $0x40
 23a:	c3                   	ret    

0000023b <link>:
SYSCALL(link)
 23b:	b8 13 00 00 00       	mov    $0x13,%eax
 240:	cd 40                	int    $0x40
 242:	c3                   	ret    

00000243 <mkdir>:
SYSCALL(mkdir)
 243:	b8 14 00 00 00       	mov    $0x14,%eax
 248:	cd 40                	int    $0x40
 24a:	c3                   	ret    

0000024b <chdir>:
SYSCALL(chdir)
 24b:	b8 09 00 00 00       	mov    $0x9,%eax
 250:	cd 40                	int    $0x40
 252:	c3                   	ret    

00000253 <dup>:
SYSCALL(dup)
 253:	b8 0a 00 00 00       	mov    $0xa,%eax
 258:	cd 40                	int    $0x40
 25a:	c3                   	ret    

0000025b <getpid>:
SYSCALL(getpid)
 25b:	b8 0b 00 00 00       	mov    $0xb,%eax
 260:	cd 40                	int    $0x40
 262:	c3                   	ret    

00000263 <sbrk>:
SYSCALL(sbrk)
 263:	b8 0c 00 00 00       	mov    $0xc,%eax
 268:	cd 40                	int    $0x40
 26a:	c3                   	ret    

0000026b <sleep>:
SYSCALL(sleep)
 26b:	b8 0d 00 00 00       	mov    $0xd,%eax
 270:	cd 40                	int    $0x40
 272:	c3                   	ret    

00000273 <uptime>:
SYSCALL(uptime)
 273:	b8 0e 00 00 00       	mov    $0xe,%eax
 278:	cd 40                	int    $0x40
 27a:	c3                   	ret    

0000027b <slabtest>:
SYSCALL(slabtest)
 27b:	b8 16 00 00 00       	mov    $0x16,%eax
 280:	cd 40                	int    $0x40
 282:	c3                   	ret    

00000283 <ps>:
SYSCALL(ps)
 283:	b8 17 00 00 00       	mov    $0x17,%eax
 288:	cd 40                	int    $0x40
 28a:	c3                   	ret    

0000028b <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 28b:	55                   	push   %ebp
 28c:	89 e5                	mov    %esp,%ebp
 28e:	57                   	push   %edi
 28f:	56                   	push   %esi
 290:	53                   	push   %ebx
 291:	83 ec 3c             	sub    $0x3c,%esp
 294:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 296:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 29a:	74 14                	je     2b0 <printint+0x25>
 29c:	85 d2                	test   %edx,%edx
 29e:	79 10                	jns    2b0 <printint+0x25>
    neg = 1;
    x = -xx;
 2a0:	f7 da                	neg    %edx
    neg = 1;
 2a2:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 2a9:	bf 00 00 00 00       	mov    $0x0,%edi
 2ae:	eb 0b                	jmp    2bb <printint+0x30>
  neg = 0;
 2b0:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 2b7:	eb f0                	jmp    2a9 <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 2b9:	89 df                	mov    %ebx,%edi
 2bb:	8d 5f 01             	lea    0x1(%edi),%ebx
 2be:	89 d0                	mov    %edx,%eax
 2c0:	ba 00 00 00 00       	mov    $0x0,%edx
 2c5:	f7 f1                	div    %ecx
 2c7:	0f b6 92 34 06 00 00 	movzbl 0x634(%edx),%edx
 2ce:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 2d2:	89 c2                	mov    %eax,%edx
 2d4:	85 c0                	test   %eax,%eax
 2d6:	75 e1                	jne    2b9 <printint+0x2e>
  if(neg)
 2d8:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 2dc:	74 08                	je     2e6 <printint+0x5b>
    buf[i++] = '-';
 2de:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 2e3:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 2e6:	83 eb 01             	sub    $0x1,%ebx
 2e9:	78 22                	js     30d <printint+0x82>
  write(fd, &c, 1);
 2eb:	8d 7d d7             	lea    -0x29(%ebp),%edi
 2ee:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 2f3:	88 45 d7             	mov    %al,-0x29(%ebp)
 2f6:	83 ec 04             	sub    $0x4,%esp
 2f9:	6a 01                	push   $0x1
 2fb:	57                   	push   %edi
 2fc:	56                   	push   %esi
 2fd:	e8 f9 fe ff ff       	call   1fb <write>
  while(--i >= 0)
 302:	83 eb 01             	sub    $0x1,%ebx
 305:	83 c4 10             	add    $0x10,%esp
 308:	83 fb ff             	cmp    $0xffffffff,%ebx
 30b:	75 e1                	jne    2ee <printint+0x63>
    putc(fd, buf[i]);
}
 30d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 310:	5b                   	pop    %ebx
 311:	5e                   	pop    %esi
 312:	5f                   	pop    %edi
 313:	5d                   	pop    %ebp
 314:	c3                   	ret    

00000315 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 315:	55                   	push   %ebp
 316:	89 e5                	mov    %esp,%ebp
 318:	57                   	push   %edi
 319:	56                   	push   %esi
 31a:	53                   	push   %ebx
 31b:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 31e:	8b 75 0c             	mov    0xc(%ebp),%esi
 321:	0f b6 1e             	movzbl (%esi),%ebx
 324:	84 db                	test   %bl,%bl
 326:	0f 84 b1 01 00 00    	je     4dd <printf+0x1c8>
 32c:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 32f:	8d 45 10             	lea    0x10(%ebp),%eax
 332:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 335:	bf 00 00 00 00       	mov    $0x0,%edi
 33a:	eb 2d                	jmp    369 <printf+0x54>
 33c:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 33f:	83 ec 04             	sub    $0x4,%esp
 342:	6a 01                	push   $0x1
 344:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 347:	50                   	push   %eax
 348:	ff 75 08             	pushl  0x8(%ebp)
 34b:	e8 ab fe ff ff       	call   1fb <write>
 350:	83 c4 10             	add    $0x10,%esp
 353:	eb 05                	jmp    35a <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 355:	83 ff 25             	cmp    $0x25,%edi
 358:	74 22                	je     37c <printf+0x67>
 35a:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 35d:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 361:	84 db                	test   %bl,%bl
 363:	0f 84 74 01 00 00    	je     4dd <printf+0x1c8>
    c = fmt[i] & 0xff;
 369:	0f be d3             	movsbl %bl,%edx
 36c:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 36f:	85 ff                	test   %edi,%edi
 371:	75 e2                	jne    355 <printf+0x40>
      if(c == '%'){
 373:	83 f8 25             	cmp    $0x25,%eax
 376:	75 c4                	jne    33c <printf+0x27>
        state = '%';
 378:	89 c7                	mov    %eax,%edi
 37a:	eb de                	jmp    35a <printf+0x45>
      if(c == 'd'){
 37c:	83 f8 64             	cmp    $0x64,%eax
 37f:	74 59                	je     3da <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 381:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 387:	83 fa 70             	cmp    $0x70,%edx
 38a:	74 7a                	je     406 <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 38c:	83 f8 73             	cmp    $0x73,%eax
 38f:	0f 84 9d 00 00 00    	je     432 <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 395:	83 f8 63             	cmp    $0x63,%eax
 398:	0f 84 f2 00 00 00    	je     490 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 39e:	83 f8 25             	cmp    $0x25,%eax
 3a1:	0f 84 15 01 00 00    	je     4bc <printf+0x1a7>
 3a7:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 3ab:	83 ec 04             	sub    $0x4,%esp
 3ae:	6a 01                	push   $0x1
 3b0:	8d 45 e7             	lea    -0x19(%ebp),%eax
 3b3:	50                   	push   %eax
 3b4:	ff 75 08             	pushl  0x8(%ebp)
 3b7:	e8 3f fe ff ff       	call   1fb <write>
 3bc:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 3bf:	83 c4 0c             	add    $0xc,%esp
 3c2:	6a 01                	push   $0x1
 3c4:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 3c7:	50                   	push   %eax
 3c8:	ff 75 08             	pushl  0x8(%ebp)
 3cb:	e8 2b fe ff ff       	call   1fb <write>
 3d0:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 3d3:	bf 00 00 00 00       	mov    $0x0,%edi
 3d8:	eb 80                	jmp    35a <printf+0x45>
        printint(fd, *ap, 10, 1);
 3da:	83 ec 0c             	sub    $0xc,%esp
 3dd:	6a 01                	push   $0x1
 3df:	b9 0a 00 00 00       	mov    $0xa,%ecx
 3e4:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 3e7:	8b 17                	mov    (%edi),%edx
 3e9:	8b 45 08             	mov    0x8(%ebp),%eax
 3ec:	e8 9a fe ff ff       	call   28b <printint>
        ap++;
 3f1:	89 f8                	mov    %edi,%eax
 3f3:	83 c0 04             	add    $0x4,%eax
 3f6:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 3f9:	83 c4 10             	add    $0x10,%esp
      state = 0;
 3fc:	bf 00 00 00 00       	mov    $0x0,%edi
 401:	e9 54 ff ff ff       	jmp    35a <printf+0x45>
        printint(fd, *ap, 16, 0);
 406:	83 ec 0c             	sub    $0xc,%esp
 409:	6a 00                	push   $0x0
 40b:	b9 10 00 00 00       	mov    $0x10,%ecx
 410:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 413:	8b 17                	mov    (%edi),%edx
 415:	8b 45 08             	mov    0x8(%ebp),%eax
 418:	e8 6e fe ff ff       	call   28b <printint>
        ap++;
 41d:	89 f8                	mov    %edi,%eax
 41f:	83 c0 04             	add    $0x4,%eax
 422:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 425:	83 c4 10             	add    $0x10,%esp
      state = 0;
 428:	bf 00 00 00 00       	mov    $0x0,%edi
 42d:	e9 28 ff ff ff       	jmp    35a <printf+0x45>
        s = (char*)*ap;
 432:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 435:	8b 01                	mov    (%ecx),%eax
        ap++;
 437:	83 c1 04             	add    $0x4,%ecx
 43a:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 43d:	85 c0                	test   %eax,%eax
 43f:	74 13                	je     454 <printf+0x13f>
        s = (char*)*ap;
 441:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 443:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 446:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 44b:	84 c0                	test   %al,%al
 44d:	75 0f                	jne    45e <printf+0x149>
 44f:	e9 06 ff ff ff       	jmp    35a <printf+0x45>
          s = "(null)";
 454:	bb 2c 06 00 00       	mov    $0x62c,%ebx
        while(*s != 0){
 459:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 45e:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 461:	89 75 d0             	mov    %esi,-0x30(%ebp)
 464:	8b 75 08             	mov    0x8(%ebp),%esi
 467:	88 45 e3             	mov    %al,-0x1d(%ebp)
 46a:	83 ec 04             	sub    $0x4,%esp
 46d:	6a 01                	push   $0x1
 46f:	57                   	push   %edi
 470:	56                   	push   %esi
 471:	e8 85 fd ff ff       	call   1fb <write>
          s++;
 476:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 479:	0f b6 03             	movzbl (%ebx),%eax
 47c:	83 c4 10             	add    $0x10,%esp
 47f:	84 c0                	test   %al,%al
 481:	75 e4                	jne    467 <printf+0x152>
 483:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 486:	bf 00 00 00 00       	mov    $0x0,%edi
 48b:	e9 ca fe ff ff       	jmp    35a <printf+0x45>
        putc(fd, *ap);
 490:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 493:	8b 07                	mov    (%edi),%eax
 495:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 498:	83 ec 04             	sub    $0x4,%esp
 49b:	6a 01                	push   $0x1
 49d:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 4a0:	50                   	push   %eax
 4a1:	ff 75 08             	pushl  0x8(%ebp)
 4a4:	e8 52 fd ff ff       	call   1fb <write>
        ap++;
 4a9:	83 c7 04             	add    $0x4,%edi
 4ac:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 4af:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4b2:	bf 00 00 00 00       	mov    $0x0,%edi
 4b7:	e9 9e fe ff ff       	jmp    35a <printf+0x45>
 4bc:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 4bf:	83 ec 04             	sub    $0x4,%esp
 4c2:	6a 01                	push   $0x1
 4c4:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 4c7:	50                   	push   %eax
 4c8:	ff 75 08             	pushl  0x8(%ebp)
 4cb:	e8 2b fd ff ff       	call   1fb <write>
 4d0:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4d3:	bf 00 00 00 00       	mov    $0x0,%edi
 4d8:	e9 7d fe ff ff       	jmp    35a <printf+0x45>
    }
  }
}
 4dd:	8d 65 f4             	lea    -0xc(%ebp),%esp
 4e0:	5b                   	pop    %ebx
 4e1:	5e                   	pop    %esi
 4e2:	5f                   	pop    %edi
 4e3:	5d                   	pop    %ebp
 4e4:	c3                   	ret    

000004e5 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 4e5:	55                   	push   %ebp
 4e6:	89 e5                	mov    %esp,%ebp
 4e8:	57                   	push   %edi
 4e9:	56                   	push   %esi
 4ea:	53                   	push   %ebx
 4eb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 4ee:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 4f1:	a1 9c 08 00 00       	mov    0x89c,%eax
 4f6:	eb 0c                	jmp    504 <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 4f8:	8b 10                	mov    (%eax),%edx
 4fa:	39 c2                	cmp    %eax,%edx
 4fc:	77 04                	ja     502 <free+0x1d>
 4fe:	39 ca                	cmp    %ecx,%edx
 500:	77 10                	ja     512 <free+0x2d>
{
 502:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 504:	39 c8                	cmp    %ecx,%eax
 506:	73 f0                	jae    4f8 <free+0x13>
 508:	8b 10                	mov    (%eax),%edx
 50a:	39 ca                	cmp    %ecx,%edx
 50c:	77 04                	ja     512 <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 50e:	39 c2                	cmp    %eax,%edx
 510:	77 f0                	ja     502 <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 512:	8b 73 fc             	mov    -0x4(%ebx),%esi
 515:	8b 10                	mov    (%eax),%edx
 517:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 51a:	39 fa                	cmp    %edi,%edx
 51c:	74 19                	je     537 <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 51e:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 521:	8b 50 04             	mov    0x4(%eax),%edx
 524:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 527:	39 f1                	cmp    %esi,%ecx
 529:	74 1b                	je     546 <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 52b:	89 08                	mov    %ecx,(%eax)
  freep = p;
 52d:	a3 9c 08 00 00       	mov    %eax,0x89c
}
 532:	5b                   	pop    %ebx
 533:	5e                   	pop    %esi
 534:	5f                   	pop    %edi
 535:	5d                   	pop    %ebp
 536:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 537:	03 72 04             	add    0x4(%edx),%esi
 53a:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 53d:	8b 10                	mov    (%eax),%edx
 53f:	8b 12                	mov    (%edx),%edx
 541:	89 53 f8             	mov    %edx,-0x8(%ebx)
 544:	eb db                	jmp    521 <free+0x3c>
    p->s.size += bp->s.size;
 546:	03 53 fc             	add    -0x4(%ebx),%edx
 549:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 54c:	8b 53 f8             	mov    -0x8(%ebx),%edx
 54f:	89 10                	mov    %edx,(%eax)
 551:	eb da                	jmp    52d <free+0x48>

00000553 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 553:	55                   	push   %ebp
 554:	89 e5                	mov    %esp,%ebp
 556:	57                   	push   %edi
 557:	56                   	push   %esi
 558:	53                   	push   %ebx
 559:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 55c:	8b 45 08             	mov    0x8(%ebp),%eax
 55f:	8d 58 07             	lea    0x7(%eax),%ebx
 562:	c1 eb 03             	shr    $0x3,%ebx
 565:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 568:	8b 15 9c 08 00 00    	mov    0x89c,%edx
 56e:	85 d2                	test   %edx,%edx
 570:	74 20                	je     592 <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 572:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 574:	8b 48 04             	mov    0x4(%eax),%ecx
 577:	39 cb                	cmp    %ecx,%ebx
 579:	76 3c                	jbe    5b7 <malloc+0x64>
 57b:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 581:	be 00 10 00 00       	mov    $0x1000,%esi
 586:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 589:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 590:	eb 70                	jmp    602 <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 592:	c7 05 9c 08 00 00 a0 	movl   $0x8a0,0x89c
 599:	08 00 00 
 59c:	c7 05 a0 08 00 00 a0 	movl   $0x8a0,0x8a0
 5a3:	08 00 00 
    base.s.size = 0;
 5a6:	c7 05 a4 08 00 00 00 	movl   $0x0,0x8a4
 5ad:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 5b0:	ba a0 08 00 00       	mov    $0x8a0,%edx
 5b5:	eb bb                	jmp    572 <malloc+0x1f>
      if(p->s.size == nunits)
 5b7:	39 cb                	cmp    %ecx,%ebx
 5b9:	74 1c                	je     5d7 <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 5bb:	29 d9                	sub    %ebx,%ecx
 5bd:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 5c0:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 5c3:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 5c6:	89 15 9c 08 00 00    	mov    %edx,0x89c
      return (void*)(p + 1);
 5cc:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 5cf:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5d2:	5b                   	pop    %ebx
 5d3:	5e                   	pop    %esi
 5d4:	5f                   	pop    %edi
 5d5:	5d                   	pop    %ebp
 5d6:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 5d7:	8b 08                	mov    (%eax),%ecx
 5d9:	89 0a                	mov    %ecx,(%edx)
 5db:	eb e9                	jmp    5c6 <malloc+0x73>
  hp->s.size = nu;
 5dd:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 5e0:	83 ec 0c             	sub    $0xc,%esp
 5e3:	83 c0 08             	add    $0x8,%eax
 5e6:	50                   	push   %eax
 5e7:	e8 f9 fe ff ff       	call   4e5 <free>
  return freep;
 5ec:	8b 15 9c 08 00 00    	mov    0x89c,%edx
      if((p = morecore(nunits)) == 0)
 5f2:	83 c4 10             	add    $0x10,%esp
 5f5:	85 d2                	test   %edx,%edx
 5f7:	74 2b                	je     624 <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 5f9:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 5fb:	8b 48 04             	mov    0x4(%eax),%ecx
 5fe:	39 d9                	cmp    %ebx,%ecx
 600:	73 b5                	jae    5b7 <malloc+0x64>
 602:	89 c2                	mov    %eax,%edx
    if(p == freep)
 604:	39 05 9c 08 00 00    	cmp    %eax,0x89c
 60a:	75 ed                	jne    5f9 <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 60c:	83 ec 0c             	sub    $0xc,%esp
 60f:	57                   	push   %edi
 610:	e8 4e fc ff ff       	call   263 <sbrk>
  if(p == (char*)-1)
 615:	83 c4 10             	add    $0x10,%esp
 618:	83 f8 ff             	cmp    $0xffffffff,%eax
 61b:	75 c0                	jne    5dd <malloc+0x8a>
        return 0;
 61d:	b8 00 00 00 00       	mov    $0x0,%eax
 622:	eb ab                	jmp    5cf <malloc+0x7c>
 624:	b8 00 00 00 00       	mov    $0x0,%eax
 629:	eb a4                	jmp    5cf <malloc+0x7c>
