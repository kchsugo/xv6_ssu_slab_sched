
user/_stressfs:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "fs.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	pushl  -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	81 ec 20 02 00 00    	sub    $0x220,%esp
  int fd, i;
  char path[] = "stressfs0";
  17:	c7 45 de 73 74 72 65 	movl   $0x65727473,-0x22(%ebp)
  1e:	c7 45 e2 73 73 66 73 	movl   $0x73667373,-0x1e(%ebp)
  25:	66 c7 45 e6 30 00    	movw   $0x30,-0x1a(%ebp)
  char data[512];

  printf(1, "stressfs starting\n");
  2b:	68 24 07 00 00       	push   $0x724
  30:	6a 01                	push   $0x1
  32:	e8 d4 03 00 00       	call   40b <printf>
  memset(data, 'a', sizeof(data));
  37:	83 c4 0c             	add    $0xc,%esp
  3a:	68 00 02 00 00       	push   $0x200
  3f:	6a 61                	push   $0x61
  41:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  47:	50                   	push   %eax
  48:	e8 37 01 00 00       	call   184 <memset>
  4d:	83 c4 10             	add    $0x10,%esp

  for(i = 0; i < 4; i++)
  50:	bb 00 00 00 00       	mov    $0x0,%ebx
    if(fork() > 0)
  55:	e8 6f 02 00 00       	call   2c9 <fork>
  5a:	85 c0                	test   %eax,%eax
  5c:	7f 08                	jg     66 <main+0x66>
  for(i = 0; i < 4; i++)
  5e:	83 c3 01             	add    $0x1,%ebx
  61:	83 fb 04             	cmp    $0x4,%ebx
  64:	75 ef                	jne    55 <main+0x55>
      break;

  printf(1, "write %d\n", i);
  66:	83 ec 04             	sub    $0x4,%esp
  69:	53                   	push   %ebx
  6a:	68 37 07 00 00       	push   $0x737
  6f:	6a 01                	push   $0x1
  71:	e8 95 03 00 00       	call   40b <printf>

  path[8] += i;
  76:	00 5d e6             	add    %bl,-0x1a(%ebp)
  fd = open(path, O_CREATE | O_RDWR);
  79:	83 c4 08             	add    $0x8,%esp
  7c:	68 02 02 00 00       	push   $0x202
  81:	8d 45 de             	lea    -0x22(%ebp),%eax
  84:	50                   	push   %eax
  85:	e8 87 02 00 00       	call   311 <open>
  8a:	89 c6                	mov    %eax,%esi
  8c:	83 c4 10             	add    $0x10,%esp
  8f:	bb 14 00 00 00       	mov    $0x14,%ebx
  for(i = 0; i < 20; i++)
//    printf(fd, "%d\n", i);
    write(fd, data, sizeof(data));
  94:	8d bd de fd ff ff    	lea    -0x222(%ebp),%edi
  9a:	83 ec 04             	sub    $0x4,%esp
  9d:	68 00 02 00 00       	push   $0x200
  a2:	57                   	push   %edi
  a3:	56                   	push   %esi
  a4:	e8 48 02 00 00       	call   2f1 <write>
  for(i = 0; i < 20; i++)
  a9:	83 c4 10             	add    $0x10,%esp
  ac:	83 eb 01             	sub    $0x1,%ebx
  af:	75 e9                	jne    9a <main+0x9a>
  close(fd);
  b1:	83 ec 0c             	sub    $0xc,%esp
  b4:	56                   	push   %esi
  b5:	e8 3f 02 00 00       	call   2f9 <close>

  printf(1, "read\n");
  ba:	83 c4 08             	add    $0x8,%esp
  bd:	68 41 07 00 00       	push   $0x741
  c2:	6a 01                	push   $0x1
  c4:	e8 42 03 00 00       	call   40b <printf>

  fd = open(path, O_RDONLY);
  c9:	83 c4 08             	add    $0x8,%esp
  cc:	6a 00                	push   $0x0
  ce:	8d 45 de             	lea    -0x22(%ebp),%eax
  d1:	50                   	push   %eax
  d2:	e8 3a 02 00 00       	call   311 <open>
  d7:	89 c6                	mov    %eax,%esi
  d9:	83 c4 10             	add    $0x10,%esp
  dc:	bb 14 00 00 00       	mov    $0x14,%ebx
  for (i = 0; i < 20; i++)
    read(fd, data, sizeof(data));
  e1:	8d bd de fd ff ff    	lea    -0x222(%ebp),%edi
  e7:	83 ec 04             	sub    $0x4,%esp
  ea:	68 00 02 00 00       	push   $0x200
  ef:	57                   	push   %edi
  f0:	56                   	push   %esi
  f1:	e8 f3 01 00 00       	call   2e9 <read>
  for (i = 0; i < 20; i++)
  f6:	83 c4 10             	add    $0x10,%esp
  f9:	83 eb 01             	sub    $0x1,%ebx
  fc:	75 e9                	jne    e7 <main+0xe7>
  close(fd);
  fe:	83 ec 0c             	sub    $0xc,%esp
 101:	56                   	push   %esi
 102:	e8 f2 01 00 00       	call   2f9 <close>

  wait();
 107:	e8 cd 01 00 00       	call   2d9 <wait>

  exit();
 10c:	e8 c0 01 00 00       	call   2d1 <exit>

00000111 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 111:	55                   	push   %ebp
 112:	89 e5                	mov    %esp,%ebp
 114:	53                   	push   %ebx
 115:	8b 45 08             	mov    0x8(%ebp),%eax
 118:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 11b:	89 c2                	mov    %eax,%edx
 11d:	83 c1 01             	add    $0x1,%ecx
 120:	83 c2 01             	add    $0x1,%edx
 123:	0f b6 59 ff          	movzbl -0x1(%ecx),%ebx
 127:	88 5a ff             	mov    %bl,-0x1(%edx)
 12a:	84 db                	test   %bl,%bl
 12c:	75 ef                	jne    11d <strcpy+0xc>
    ;
  return os;
}
 12e:	5b                   	pop    %ebx
 12f:	5d                   	pop    %ebp
 130:	c3                   	ret    

00000131 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 131:	55                   	push   %ebp
 132:	89 e5                	mov    %esp,%ebp
 134:	8b 4d 08             	mov    0x8(%ebp),%ecx
 137:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 13a:	0f b6 01             	movzbl (%ecx),%eax
 13d:	84 c0                	test   %al,%al
 13f:	74 15                	je     156 <strcmp+0x25>
 141:	3a 02                	cmp    (%edx),%al
 143:	75 11                	jne    156 <strcmp+0x25>
    p++, q++;
 145:	83 c1 01             	add    $0x1,%ecx
 148:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 14b:	0f b6 01             	movzbl (%ecx),%eax
 14e:	84 c0                	test   %al,%al
 150:	74 04                	je     156 <strcmp+0x25>
 152:	3a 02                	cmp    (%edx),%al
 154:	74 ef                	je     145 <strcmp+0x14>
  return (uchar)*p - (uchar)*q;
 156:	0f b6 c0             	movzbl %al,%eax
 159:	0f b6 12             	movzbl (%edx),%edx
 15c:	29 d0                	sub    %edx,%eax
}
 15e:	5d                   	pop    %ebp
 15f:	c3                   	ret    

00000160 <strlen>:

uint
strlen(const char *s)
{
 160:	55                   	push   %ebp
 161:	89 e5                	mov    %esp,%ebp
 163:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 166:	80 39 00             	cmpb   $0x0,(%ecx)
 169:	74 12                	je     17d <strlen+0x1d>
 16b:	ba 00 00 00 00       	mov    $0x0,%edx
 170:	83 c2 01             	add    $0x1,%edx
 173:	89 d0                	mov    %edx,%eax
 175:	80 3c 11 00          	cmpb   $0x0,(%ecx,%edx,1)
 179:	75 f5                	jne    170 <strlen+0x10>
    ;
  return n;
}
 17b:	5d                   	pop    %ebp
 17c:	c3                   	ret    
  for(n = 0; s[n]; n++)
 17d:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 182:	eb f7                	jmp    17b <strlen+0x1b>

00000184 <memset>:

void*
memset(void *dst, int c, uint n)
{
 184:	55                   	push   %ebp
 185:	89 e5                	mov    %esp,%ebp
 187:	57                   	push   %edi
 188:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 18b:	89 d7                	mov    %edx,%edi
 18d:	8b 4d 10             	mov    0x10(%ebp),%ecx
 190:	8b 45 0c             	mov    0xc(%ebp),%eax
 193:	fc                   	cld    
 194:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 196:	89 d0                	mov    %edx,%eax
 198:	5f                   	pop    %edi
 199:	5d                   	pop    %ebp
 19a:	c3                   	ret    

0000019b <strchr>:

char*
strchr(const char *s, char c)
{
 19b:	55                   	push   %ebp
 19c:	89 e5                	mov    %esp,%ebp
 19e:	53                   	push   %ebx
 19f:	8b 45 08             	mov    0x8(%ebp),%eax
 1a2:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  for(; *s; s++)
 1a5:	0f b6 10             	movzbl (%eax),%edx
 1a8:	84 d2                	test   %dl,%dl
 1aa:	74 1e                	je     1ca <strchr+0x2f>
 1ac:	89 d9                	mov    %ebx,%ecx
    if(*s == c)
 1ae:	38 d3                	cmp    %dl,%bl
 1b0:	74 15                	je     1c7 <strchr+0x2c>
  for(; *s; s++)
 1b2:	83 c0 01             	add    $0x1,%eax
 1b5:	0f b6 10             	movzbl (%eax),%edx
 1b8:	84 d2                	test   %dl,%dl
 1ba:	74 06                	je     1c2 <strchr+0x27>
    if(*s == c)
 1bc:	38 ca                	cmp    %cl,%dl
 1be:	75 f2                	jne    1b2 <strchr+0x17>
 1c0:	eb 05                	jmp    1c7 <strchr+0x2c>
      return (char*)s;
  return 0;
 1c2:	b8 00 00 00 00       	mov    $0x0,%eax
}
 1c7:	5b                   	pop    %ebx
 1c8:	5d                   	pop    %ebp
 1c9:	c3                   	ret    
  return 0;
 1ca:	b8 00 00 00 00       	mov    $0x0,%eax
 1cf:	eb f6                	jmp    1c7 <strchr+0x2c>

000001d1 <gets>:

char*
gets(char *buf, int max)
{
 1d1:	55                   	push   %ebp
 1d2:	89 e5                	mov    %esp,%ebp
 1d4:	57                   	push   %edi
 1d5:	56                   	push   %esi
 1d6:	53                   	push   %ebx
 1d7:	83 ec 1c             	sub    $0x1c,%esp
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1da:	be 00 00 00 00       	mov    $0x0,%esi
    cc = read(0, &c, 1);
 1df:	8d 7d e7             	lea    -0x19(%ebp),%edi
  for(i=0; i+1 < max; ){
 1e2:	8d 5e 01             	lea    0x1(%esi),%ebx
 1e5:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1e8:	7d 2b                	jge    215 <gets+0x44>
    cc = read(0, &c, 1);
 1ea:	83 ec 04             	sub    $0x4,%esp
 1ed:	6a 01                	push   $0x1
 1ef:	57                   	push   %edi
 1f0:	6a 00                	push   $0x0
 1f2:	e8 f2 00 00 00       	call   2e9 <read>
    if(cc < 1)
 1f7:	83 c4 10             	add    $0x10,%esp
 1fa:	85 c0                	test   %eax,%eax
 1fc:	7e 17                	jle    215 <gets+0x44>
      break;
    buf[i++] = c;
 1fe:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 202:	8b 55 08             	mov    0x8(%ebp),%edx
 205:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
  for(i=0; i+1 < max; ){
 209:	89 de                	mov    %ebx,%esi
    if(c == '\n' || c == '\r')
 20b:	3c 0a                	cmp    $0xa,%al
 20d:	74 04                	je     213 <gets+0x42>
 20f:	3c 0d                	cmp    $0xd,%al
 211:	75 cf                	jne    1e2 <gets+0x11>
  for(i=0; i+1 < max; ){
 213:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 215:	8b 45 08             	mov    0x8(%ebp),%eax
 218:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 21c:	8d 65 f4             	lea    -0xc(%ebp),%esp
 21f:	5b                   	pop    %ebx
 220:	5e                   	pop    %esi
 221:	5f                   	pop    %edi
 222:	5d                   	pop    %ebp
 223:	c3                   	ret    

00000224 <stat>:

int
stat(const char *n, struct stat *st)
{
 224:	55                   	push   %ebp
 225:	89 e5                	mov    %esp,%ebp
 227:	56                   	push   %esi
 228:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 229:	83 ec 08             	sub    $0x8,%esp
 22c:	6a 00                	push   $0x0
 22e:	ff 75 08             	pushl  0x8(%ebp)
 231:	e8 db 00 00 00       	call   311 <open>
  if(fd < 0)
 236:	83 c4 10             	add    $0x10,%esp
 239:	85 c0                	test   %eax,%eax
 23b:	78 24                	js     261 <stat+0x3d>
 23d:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 23f:	83 ec 08             	sub    $0x8,%esp
 242:	ff 75 0c             	pushl  0xc(%ebp)
 245:	50                   	push   %eax
 246:	e8 de 00 00 00       	call   329 <fstat>
 24b:	89 c6                	mov    %eax,%esi
  close(fd);
 24d:	89 1c 24             	mov    %ebx,(%esp)
 250:	e8 a4 00 00 00       	call   2f9 <close>
  return r;
 255:	83 c4 10             	add    $0x10,%esp
}
 258:	89 f0                	mov    %esi,%eax
 25a:	8d 65 f8             	lea    -0x8(%ebp),%esp
 25d:	5b                   	pop    %ebx
 25e:	5e                   	pop    %esi
 25f:	5d                   	pop    %ebp
 260:	c3                   	ret    
    return -1;
 261:	be ff ff ff ff       	mov    $0xffffffff,%esi
 266:	eb f0                	jmp    258 <stat+0x34>

00000268 <atoi>:

int
atoi(const char *s)
{
 268:	55                   	push   %ebp
 269:	89 e5                	mov    %esp,%ebp
 26b:	53                   	push   %ebx
 26c:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 26f:	0f b6 11             	movzbl (%ecx),%edx
 272:	8d 42 d0             	lea    -0x30(%edx),%eax
 275:	3c 09                	cmp    $0x9,%al
 277:	77 20                	ja     299 <atoi+0x31>
  n = 0;
 279:	b8 00 00 00 00       	mov    $0x0,%eax
    n = n*10 + *s++ - '0';
 27e:	83 c1 01             	add    $0x1,%ecx
 281:	8d 04 80             	lea    (%eax,%eax,4),%eax
 284:	0f be d2             	movsbl %dl,%edx
 287:	8d 44 42 d0          	lea    -0x30(%edx,%eax,2),%eax
  while('0' <= *s && *s <= '9')
 28b:	0f b6 11             	movzbl (%ecx),%edx
 28e:	8d 5a d0             	lea    -0x30(%edx),%ebx
 291:	80 fb 09             	cmp    $0x9,%bl
 294:	76 e8                	jbe    27e <atoi+0x16>
  return n;
}
 296:	5b                   	pop    %ebx
 297:	5d                   	pop    %ebp
 298:	c3                   	ret    
  n = 0;
 299:	b8 00 00 00 00       	mov    $0x0,%eax
  return n;
 29e:	eb f6                	jmp    296 <atoi+0x2e>

000002a0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2a0:	55                   	push   %ebp
 2a1:	89 e5                	mov    %esp,%ebp
 2a3:	56                   	push   %esi
 2a4:	53                   	push   %ebx
 2a5:	8b 45 08             	mov    0x8(%ebp),%eax
 2a8:	8b 75 0c             	mov    0xc(%ebp),%esi
 2ab:	8b 5d 10             	mov    0x10(%ebp),%ebx
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 2ae:	85 db                	test   %ebx,%ebx
 2b0:	7e 13                	jle    2c5 <memmove+0x25>
 2b2:	ba 00 00 00 00       	mov    $0x0,%edx
    *dst++ = *src++;
 2b7:	0f b6 0c 16          	movzbl (%esi,%edx,1),%ecx
 2bb:	88 0c 10             	mov    %cl,(%eax,%edx,1)
 2be:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0)
 2c1:	39 d3                	cmp    %edx,%ebx
 2c3:	75 f2                	jne    2b7 <memmove+0x17>
  return vdst;
}
 2c5:	5b                   	pop    %ebx
 2c6:	5e                   	pop    %esi
 2c7:	5d                   	pop    %ebp
 2c8:	c3                   	ret    

000002c9 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2c9:	b8 01 00 00 00       	mov    $0x1,%eax
 2ce:	cd 40                	int    $0x40
 2d0:	c3                   	ret    

000002d1 <exit>:
SYSCALL(exit)
 2d1:	b8 02 00 00 00       	mov    $0x2,%eax
 2d6:	cd 40                	int    $0x40
 2d8:	c3                   	ret    

000002d9 <wait>:
SYSCALL(wait)
 2d9:	b8 03 00 00 00       	mov    $0x3,%eax
 2de:	cd 40                	int    $0x40
 2e0:	c3                   	ret    

000002e1 <pipe>:
SYSCALL(pipe)
 2e1:	b8 04 00 00 00       	mov    $0x4,%eax
 2e6:	cd 40                	int    $0x40
 2e8:	c3                   	ret    

000002e9 <read>:
SYSCALL(read)
 2e9:	b8 05 00 00 00       	mov    $0x5,%eax
 2ee:	cd 40                	int    $0x40
 2f0:	c3                   	ret    

000002f1 <write>:
SYSCALL(write)
 2f1:	b8 10 00 00 00       	mov    $0x10,%eax
 2f6:	cd 40                	int    $0x40
 2f8:	c3                   	ret    

000002f9 <close>:
SYSCALL(close)
 2f9:	b8 15 00 00 00       	mov    $0x15,%eax
 2fe:	cd 40                	int    $0x40
 300:	c3                   	ret    

00000301 <kill>:
SYSCALL(kill)
 301:	b8 06 00 00 00       	mov    $0x6,%eax
 306:	cd 40                	int    $0x40
 308:	c3                   	ret    

00000309 <exec>:
SYSCALL(exec)
 309:	b8 07 00 00 00       	mov    $0x7,%eax
 30e:	cd 40                	int    $0x40
 310:	c3                   	ret    

00000311 <open>:
SYSCALL(open)
 311:	b8 0f 00 00 00       	mov    $0xf,%eax
 316:	cd 40                	int    $0x40
 318:	c3                   	ret    

00000319 <mknod>:
SYSCALL(mknod)
 319:	b8 11 00 00 00       	mov    $0x11,%eax
 31e:	cd 40                	int    $0x40
 320:	c3                   	ret    

00000321 <unlink>:
SYSCALL(unlink)
 321:	b8 12 00 00 00       	mov    $0x12,%eax
 326:	cd 40                	int    $0x40
 328:	c3                   	ret    

00000329 <fstat>:
SYSCALL(fstat)
 329:	b8 08 00 00 00       	mov    $0x8,%eax
 32e:	cd 40                	int    $0x40
 330:	c3                   	ret    

00000331 <link>:
SYSCALL(link)
 331:	b8 13 00 00 00       	mov    $0x13,%eax
 336:	cd 40                	int    $0x40
 338:	c3                   	ret    

00000339 <mkdir>:
SYSCALL(mkdir)
 339:	b8 14 00 00 00       	mov    $0x14,%eax
 33e:	cd 40                	int    $0x40
 340:	c3                   	ret    

00000341 <chdir>:
SYSCALL(chdir)
 341:	b8 09 00 00 00       	mov    $0x9,%eax
 346:	cd 40                	int    $0x40
 348:	c3                   	ret    

00000349 <dup>:
SYSCALL(dup)
 349:	b8 0a 00 00 00       	mov    $0xa,%eax
 34e:	cd 40                	int    $0x40
 350:	c3                   	ret    

00000351 <getpid>:
SYSCALL(getpid)
 351:	b8 0b 00 00 00       	mov    $0xb,%eax
 356:	cd 40                	int    $0x40
 358:	c3                   	ret    

00000359 <sbrk>:
SYSCALL(sbrk)
 359:	b8 0c 00 00 00       	mov    $0xc,%eax
 35e:	cd 40                	int    $0x40
 360:	c3                   	ret    

00000361 <sleep>:
SYSCALL(sleep)
 361:	b8 0d 00 00 00       	mov    $0xd,%eax
 366:	cd 40                	int    $0x40
 368:	c3                   	ret    

00000369 <uptime>:
SYSCALL(uptime)
 369:	b8 0e 00 00 00       	mov    $0xe,%eax
 36e:	cd 40                	int    $0x40
 370:	c3                   	ret    

00000371 <slabtest>:
SYSCALL(slabtest)
 371:	b8 16 00 00 00       	mov    $0x16,%eax
 376:	cd 40                	int    $0x40
 378:	c3                   	ret    

00000379 <ps>:
SYSCALL(ps)
 379:	b8 17 00 00 00       	mov    $0x17,%eax
 37e:	cd 40                	int    $0x40
 380:	c3                   	ret    

00000381 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 381:	55                   	push   %ebp
 382:	89 e5                	mov    %esp,%ebp
 384:	57                   	push   %edi
 385:	56                   	push   %esi
 386:	53                   	push   %ebx
 387:	83 ec 3c             	sub    $0x3c,%esp
 38a:	89 c6                	mov    %eax,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 38c:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 390:	74 14                	je     3a6 <printint+0x25>
 392:	85 d2                	test   %edx,%edx
 394:	79 10                	jns    3a6 <printint+0x25>
    neg = 1;
    x = -xx;
 396:	f7 da                	neg    %edx
    neg = 1;
 398:	c7 45 c4 01 00 00 00 	movl   $0x1,-0x3c(%ebp)
  } else {
    x = xx;
  }

  i = 0;
 39f:	bf 00 00 00 00       	mov    $0x0,%edi
 3a4:	eb 0b                	jmp    3b1 <printint+0x30>
  neg = 0;
 3a6:	c7 45 c4 00 00 00 00 	movl   $0x0,-0x3c(%ebp)
 3ad:	eb f0                	jmp    39f <printint+0x1e>
  do{
    buf[i++] = digits[x % base];
 3af:	89 df                	mov    %ebx,%edi
 3b1:	8d 5f 01             	lea    0x1(%edi),%ebx
 3b4:	89 d0                	mov    %edx,%eax
 3b6:	ba 00 00 00 00       	mov    $0x0,%edx
 3bb:	f7 f1                	div    %ecx
 3bd:	0f b6 92 50 07 00 00 	movzbl 0x750(%edx),%edx
 3c4:	88 54 1d d7          	mov    %dl,-0x29(%ebp,%ebx,1)
  }while((x /= base) != 0);
 3c8:	89 c2                	mov    %eax,%edx
 3ca:	85 c0                	test   %eax,%eax
 3cc:	75 e1                	jne    3af <printint+0x2e>
  if(neg)
 3ce:	83 7d c4 00          	cmpl   $0x0,-0x3c(%ebp)
 3d2:	74 08                	je     3dc <printint+0x5b>
    buf[i++] = '-';
 3d4:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 3d9:	8d 5f 02             	lea    0x2(%edi),%ebx

  while(--i >= 0)
 3dc:	83 eb 01             	sub    $0x1,%ebx
 3df:	78 22                	js     403 <printint+0x82>
  write(fd, &c, 1);
 3e1:	8d 7d d7             	lea    -0x29(%ebp),%edi
 3e4:	0f b6 44 1d d8       	movzbl -0x28(%ebp,%ebx,1),%eax
 3e9:	88 45 d7             	mov    %al,-0x29(%ebp)
 3ec:	83 ec 04             	sub    $0x4,%esp
 3ef:	6a 01                	push   $0x1
 3f1:	57                   	push   %edi
 3f2:	56                   	push   %esi
 3f3:	e8 f9 fe ff ff       	call   2f1 <write>
  while(--i >= 0)
 3f8:	83 eb 01             	sub    $0x1,%ebx
 3fb:	83 c4 10             	add    $0x10,%esp
 3fe:	83 fb ff             	cmp    $0xffffffff,%ebx
 401:	75 e1                	jne    3e4 <printint+0x63>
    putc(fd, buf[i]);
}
 403:	8d 65 f4             	lea    -0xc(%ebp),%esp
 406:	5b                   	pop    %ebx
 407:	5e                   	pop    %esi
 408:	5f                   	pop    %edi
 409:	5d                   	pop    %ebp
 40a:	c3                   	ret    

0000040b <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 40b:	55                   	push   %ebp
 40c:	89 e5                	mov    %esp,%ebp
 40e:	57                   	push   %edi
 40f:	56                   	push   %esi
 410:	53                   	push   %ebx
 411:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 414:	8b 75 0c             	mov    0xc(%ebp),%esi
 417:	0f b6 1e             	movzbl (%esi),%ebx
 41a:	84 db                	test   %bl,%bl
 41c:	0f 84 b1 01 00 00    	je     5d3 <printf+0x1c8>
 422:	83 c6 01             	add    $0x1,%esi
  ap = (uint*)(void*)&fmt + 1;
 425:	8d 45 10             	lea    0x10(%ebp),%eax
 428:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  state = 0;
 42b:	bf 00 00 00 00       	mov    $0x0,%edi
 430:	eb 2d                	jmp    45f <printf+0x54>
 432:	88 5d e2             	mov    %bl,-0x1e(%ebp)
  write(fd, &c, 1);
 435:	83 ec 04             	sub    $0x4,%esp
 438:	6a 01                	push   $0x1
 43a:	8d 45 e2             	lea    -0x1e(%ebp),%eax
 43d:	50                   	push   %eax
 43e:	ff 75 08             	pushl  0x8(%ebp)
 441:	e8 ab fe ff ff       	call   2f1 <write>
 446:	83 c4 10             	add    $0x10,%esp
 449:	eb 05                	jmp    450 <printf+0x45>
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 44b:	83 ff 25             	cmp    $0x25,%edi
 44e:	74 22                	je     472 <printf+0x67>
 450:	83 c6 01             	add    $0x1,%esi
  for(i = 0; fmt[i]; i++){
 453:	0f b6 5e ff          	movzbl -0x1(%esi),%ebx
 457:	84 db                	test   %bl,%bl
 459:	0f 84 74 01 00 00    	je     5d3 <printf+0x1c8>
    c = fmt[i] & 0xff;
 45f:	0f be d3             	movsbl %bl,%edx
 462:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 465:	85 ff                	test   %edi,%edi
 467:	75 e2                	jne    44b <printf+0x40>
      if(c == '%'){
 469:	83 f8 25             	cmp    $0x25,%eax
 46c:	75 c4                	jne    432 <printf+0x27>
        state = '%';
 46e:	89 c7                	mov    %eax,%edi
 470:	eb de                	jmp    450 <printf+0x45>
      if(c == 'd'){
 472:	83 f8 64             	cmp    $0x64,%eax
 475:	74 59                	je     4d0 <printf+0xc5>
        printint(fd, *ap, 10, 1);
        ap++;
      } else if(c == 'x' || c == 'p'){
 477:	81 e2 f7 00 00 00    	and    $0xf7,%edx
 47d:	83 fa 70             	cmp    $0x70,%edx
 480:	74 7a                	je     4fc <printf+0xf1>
        printint(fd, *ap, 16, 0);
        ap++;
      } else if(c == 's'){
 482:	83 f8 73             	cmp    $0x73,%eax
 485:	0f 84 9d 00 00 00    	je     528 <printf+0x11d>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 48b:	83 f8 63             	cmp    $0x63,%eax
 48e:	0f 84 f2 00 00 00    	je     586 <printf+0x17b>
        putc(fd, *ap);
        ap++;
      } else if(c == '%'){
 494:	83 f8 25             	cmp    $0x25,%eax
 497:	0f 84 15 01 00 00    	je     5b2 <printf+0x1a7>
 49d:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 4a1:	83 ec 04             	sub    $0x4,%esp
 4a4:	6a 01                	push   $0x1
 4a6:	8d 45 e7             	lea    -0x19(%ebp),%eax
 4a9:	50                   	push   %eax
 4aa:	ff 75 08             	pushl  0x8(%ebp)
 4ad:	e8 3f fe ff ff       	call   2f1 <write>
 4b2:	88 5d e6             	mov    %bl,-0x1a(%ebp)
 4b5:	83 c4 0c             	add    $0xc,%esp
 4b8:	6a 01                	push   $0x1
 4ba:	8d 45 e6             	lea    -0x1a(%ebp),%eax
 4bd:	50                   	push   %eax
 4be:	ff 75 08             	pushl  0x8(%ebp)
 4c1:	e8 2b fe ff ff       	call   2f1 <write>
 4c6:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 4c9:	bf 00 00 00 00       	mov    $0x0,%edi
 4ce:	eb 80                	jmp    450 <printf+0x45>
        printint(fd, *ap, 10, 1);
 4d0:	83 ec 0c             	sub    $0xc,%esp
 4d3:	6a 01                	push   $0x1
 4d5:	b9 0a 00 00 00       	mov    $0xa,%ecx
 4da:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 4dd:	8b 17                	mov    (%edi),%edx
 4df:	8b 45 08             	mov    0x8(%ebp),%eax
 4e2:	e8 9a fe ff ff       	call   381 <printint>
        ap++;
 4e7:	89 f8                	mov    %edi,%eax
 4e9:	83 c0 04             	add    $0x4,%eax
 4ec:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4ef:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4f2:	bf 00 00 00 00       	mov    $0x0,%edi
 4f7:	e9 54 ff ff ff       	jmp    450 <printf+0x45>
        printint(fd, *ap, 16, 0);
 4fc:	83 ec 0c             	sub    $0xc,%esp
 4ff:	6a 00                	push   $0x0
 501:	b9 10 00 00 00       	mov    $0x10,%ecx
 506:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 509:	8b 17                	mov    (%edi),%edx
 50b:	8b 45 08             	mov    0x8(%ebp),%eax
 50e:	e8 6e fe ff ff       	call   381 <printint>
        ap++;
 513:	89 f8                	mov    %edi,%eax
 515:	83 c0 04             	add    $0x4,%eax
 518:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 51b:	83 c4 10             	add    $0x10,%esp
      state = 0;
 51e:	bf 00 00 00 00       	mov    $0x0,%edi
 523:	e9 28 ff ff ff       	jmp    450 <printf+0x45>
        s = (char*)*ap;
 528:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 52b:	8b 01                	mov    (%ecx),%eax
        ap++;
 52d:	83 c1 04             	add    $0x4,%ecx
 530:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
        if(s == 0)
 533:	85 c0                	test   %eax,%eax
 535:	74 13                	je     54a <printf+0x13f>
        s = (char*)*ap;
 537:	89 c3                	mov    %eax,%ebx
        while(*s != 0){
 539:	0f b6 00             	movzbl (%eax),%eax
      state = 0;
 53c:	bf 00 00 00 00       	mov    $0x0,%edi
        while(*s != 0){
 541:	84 c0                	test   %al,%al
 543:	75 0f                	jne    554 <printf+0x149>
 545:	e9 06 ff ff ff       	jmp    450 <printf+0x45>
          s = "(null)";
 54a:	bb 47 07 00 00       	mov    $0x747,%ebx
        while(*s != 0){
 54f:	b8 28 00 00 00       	mov    $0x28,%eax
  write(fd, &c, 1);
 554:	8d 7d e3             	lea    -0x1d(%ebp),%edi
 557:	89 75 d0             	mov    %esi,-0x30(%ebp)
 55a:	8b 75 08             	mov    0x8(%ebp),%esi
 55d:	88 45 e3             	mov    %al,-0x1d(%ebp)
 560:	83 ec 04             	sub    $0x4,%esp
 563:	6a 01                	push   $0x1
 565:	57                   	push   %edi
 566:	56                   	push   %esi
 567:	e8 85 fd ff ff       	call   2f1 <write>
          s++;
 56c:	83 c3 01             	add    $0x1,%ebx
        while(*s != 0){
 56f:	0f b6 03             	movzbl (%ebx),%eax
 572:	83 c4 10             	add    $0x10,%esp
 575:	84 c0                	test   %al,%al
 577:	75 e4                	jne    55d <printf+0x152>
 579:	8b 75 d0             	mov    -0x30(%ebp),%esi
      state = 0;
 57c:	bf 00 00 00 00       	mov    $0x0,%edi
 581:	e9 ca fe ff ff       	jmp    450 <printf+0x45>
        putc(fd, *ap);
 586:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 589:	8b 07                	mov    (%edi),%eax
 58b:	88 45 e4             	mov    %al,-0x1c(%ebp)
  write(fd, &c, 1);
 58e:	83 ec 04             	sub    $0x4,%esp
 591:	6a 01                	push   $0x1
 593:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 596:	50                   	push   %eax
 597:	ff 75 08             	pushl  0x8(%ebp)
 59a:	e8 52 fd ff ff       	call   2f1 <write>
        ap++;
 59f:	83 c7 04             	add    $0x4,%edi
 5a2:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 5a5:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5a8:	bf 00 00 00 00       	mov    $0x0,%edi
 5ad:	e9 9e fe ff ff       	jmp    450 <printf+0x45>
 5b2:	88 5d e5             	mov    %bl,-0x1b(%ebp)
  write(fd, &c, 1);
 5b5:	83 ec 04             	sub    $0x4,%esp
 5b8:	6a 01                	push   $0x1
 5ba:	8d 45 e5             	lea    -0x1b(%ebp),%eax
 5bd:	50                   	push   %eax
 5be:	ff 75 08             	pushl  0x8(%ebp)
 5c1:	e8 2b fd ff ff       	call   2f1 <write>
 5c6:	83 c4 10             	add    $0x10,%esp
      state = 0;
 5c9:	bf 00 00 00 00       	mov    $0x0,%edi
 5ce:	e9 7d fe ff ff       	jmp    450 <printf+0x45>
    }
  }
}
 5d3:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5d6:	5b                   	pop    %ebx
 5d7:	5e                   	pop    %esi
 5d8:	5f                   	pop    %edi
 5d9:	5d                   	pop    %ebp
 5da:	c3                   	ret    

000005db <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 5db:	55                   	push   %ebp
 5dc:	89 e5                	mov    %esp,%ebp
 5de:	57                   	push   %edi
 5df:	56                   	push   %esi
 5e0:	53                   	push   %ebx
 5e1:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 5e4:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5e7:	a1 c4 09 00 00       	mov    0x9c4,%eax
 5ec:	eb 0c                	jmp    5fa <free+0x1f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 5ee:	8b 10                	mov    (%eax),%edx
 5f0:	39 c2                	cmp    %eax,%edx
 5f2:	77 04                	ja     5f8 <free+0x1d>
 5f4:	39 ca                	cmp    %ecx,%edx
 5f6:	77 10                	ja     608 <free+0x2d>
{
 5f8:	89 d0                	mov    %edx,%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 5fa:	39 c8                	cmp    %ecx,%eax
 5fc:	73 f0                	jae    5ee <free+0x13>
 5fe:	8b 10                	mov    (%eax),%edx
 600:	39 ca                	cmp    %ecx,%edx
 602:	77 04                	ja     608 <free+0x2d>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 604:	39 c2                	cmp    %eax,%edx
 606:	77 f0                	ja     5f8 <free+0x1d>
      break;
  if(bp + bp->s.size == p->s.ptr){
 608:	8b 73 fc             	mov    -0x4(%ebx),%esi
 60b:	8b 10                	mov    (%eax),%edx
 60d:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 610:	39 fa                	cmp    %edi,%edx
 612:	74 19                	je     62d <free+0x52>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 614:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 617:	8b 50 04             	mov    0x4(%eax),%edx
 61a:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 61d:	39 f1                	cmp    %esi,%ecx
 61f:	74 1b                	je     63c <free+0x61>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 621:	89 08                	mov    %ecx,(%eax)
  freep = p;
 623:	a3 c4 09 00 00       	mov    %eax,0x9c4
}
 628:	5b                   	pop    %ebx
 629:	5e                   	pop    %esi
 62a:	5f                   	pop    %edi
 62b:	5d                   	pop    %ebp
 62c:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 62d:	03 72 04             	add    0x4(%edx),%esi
 630:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 633:	8b 10                	mov    (%eax),%edx
 635:	8b 12                	mov    (%edx),%edx
 637:	89 53 f8             	mov    %edx,-0x8(%ebx)
 63a:	eb db                	jmp    617 <free+0x3c>
    p->s.size += bp->s.size;
 63c:	03 53 fc             	add    -0x4(%ebx),%edx
 63f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 642:	8b 53 f8             	mov    -0x8(%ebx),%edx
 645:	89 10                	mov    %edx,(%eax)
 647:	eb da                	jmp    623 <free+0x48>

00000649 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 649:	55                   	push   %ebp
 64a:	89 e5                	mov    %esp,%ebp
 64c:	57                   	push   %edi
 64d:	56                   	push   %esi
 64e:	53                   	push   %ebx
 64f:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 652:	8b 45 08             	mov    0x8(%ebp),%eax
 655:	8d 58 07             	lea    0x7(%eax),%ebx
 658:	c1 eb 03             	shr    $0x3,%ebx
 65b:	83 c3 01             	add    $0x1,%ebx
  if((prevp = freep) == 0){
 65e:	8b 15 c4 09 00 00    	mov    0x9c4,%edx
 664:	85 d2                	test   %edx,%edx
 666:	74 20                	je     688 <malloc+0x3f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 668:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 66a:	8b 48 04             	mov    0x4(%eax),%ecx
 66d:	39 cb                	cmp    %ecx,%ebx
 66f:	76 3c                	jbe    6ad <malloc+0x64>
 671:	81 fb 00 10 00 00    	cmp    $0x1000,%ebx
 677:	be 00 10 00 00       	mov    $0x1000,%esi
 67c:	0f 43 f3             	cmovae %ebx,%esi
  p = sbrk(nu * sizeof(Header));
 67f:	8d 3c f5 00 00 00 00 	lea    0x0(,%esi,8),%edi
 686:	eb 70                	jmp    6f8 <malloc+0xaf>
    base.s.ptr = freep = prevp = &base;
 688:	c7 05 c4 09 00 00 c8 	movl   $0x9c8,0x9c4
 68f:	09 00 00 
 692:	c7 05 c8 09 00 00 c8 	movl   $0x9c8,0x9c8
 699:	09 00 00 
    base.s.size = 0;
 69c:	c7 05 cc 09 00 00 00 	movl   $0x0,0x9cc
 6a3:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 6a6:	ba c8 09 00 00       	mov    $0x9c8,%edx
 6ab:	eb bb                	jmp    668 <malloc+0x1f>
      if(p->s.size == nunits)
 6ad:	39 cb                	cmp    %ecx,%ebx
 6af:	74 1c                	je     6cd <malloc+0x84>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 6b1:	29 d9                	sub    %ebx,%ecx
 6b3:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 6b6:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 6b9:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 6bc:	89 15 c4 09 00 00    	mov    %edx,0x9c4
      return (void*)(p + 1);
 6c2:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 6c5:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6c8:	5b                   	pop    %ebx
 6c9:	5e                   	pop    %esi
 6ca:	5f                   	pop    %edi
 6cb:	5d                   	pop    %ebp
 6cc:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 6cd:	8b 08                	mov    (%eax),%ecx
 6cf:	89 0a                	mov    %ecx,(%edx)
 6d1:	eb e9                	jmp    6bc <malloc+0x73>
  hp->s.size = nu;
 6d3:	89 70 04             	mov    %esi,0x4(%eax)
  free((void*)(hp + 1));
 6d6:	83 ec 0c             	sub    $0xc,%esp
 6d9:	83 c0 08             	add    $0x8,%eax
 6dc:	50                   	push   %eax
 6dd:	e8 f9 fe ff ff       	call   5db <free>
  return freep;
 6e2:	8b 15 c4 09 00 00    	mov    0x9c4,%edx
      if((p = morecore(nunits)) == 0)
 6e8:	83 c4 10             	add    $0x10,%esp
 6eb:	85 d2                	test   %edx,%edx
 6ed:	74 2b                	je     71a <malloc+0xd1>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 6ef:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 6f1:	8b 48 04             	mov    0x4(%eax),%ecx
 6f4:	39 d9                	cmp    %ebx,%ecx
 6f6:	73 b5                	jae    6ad <malloc+0x64>
 6f8:	89 c2                	mov    %eax,%edx
    if(p == freep)
 6fa:	39 05 c4 09 00 00    	cmp    %eax,0x9c4
 700:	75 ed                	jne    6ef <malloc+0xa6>
  p = sbrk(nu * sizeof(Header));
 702:	83 ec 0c             	sub    $0xc,%esp
 705:	57                   	push   %edi
 706:	e8 4e fc ff ff       	call   359 <sbrk>
  if(p == (char*)-1)
 70b:	83 c4 10             	add    $0x10,%esp
 70e:	83 f8 ff             	cmp    $0xffffffff,%eax
 711:	75 c0                	jne    6d3 <malloc+0x8a>
        return 0;
 713:	b8 00 00 00 00       	mov    $0x0,%eax
 718:	eb ab                	jmp    6c5 <malloc+0x7c>
 71a:	b8 00 00 00 00       	mov    $0x0,%eax
 71f:	eb a4                	jmp    6c5 <malloc+0x7c>
